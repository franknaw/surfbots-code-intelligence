"""Fail-safe model-profile validation and activation orchestration."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .generation_provider import GenerationRequest, GenerationUnavailable
from .local_generation_rollout import LocalGenerationRollout
from .managed_generation.manager import ManagedGenerationManager, EXTERNAL_GENERATION_PROVIDERS
from .model_profiles import ModelProfile, ProviderConnectionError, ProviderConnectionStore
from .role_resolver import RoleResolver


@dataclass(frozen=True)
class ManagedGenerationState:
    """Current state of managed generation deployment."""
    running: bool
    replicas: int
    model_label: str | None = None


class NoOpManagedGenerationManager:
    """No-op manager for testing when Kubernetes is not available."""
    
    async def scale_to_zero(self) -> None:
        pass
    
    async def scale_to_one(self, model_label: str) -> None:
        pass
    
    async def get_state(self) -> ManagedGenerationState:
        return ManagedGenerationState(running=False, replicas=0)
    
    async def ensure_state(
        self,
        active_profile_id: str,
        provider: str,
        model_label: str | None = None,
    ) -> None:
        pass
    
    async def reconcile_active_profile(self, active_profile_id: str) -> None:
        pass


@dataclass(frozen=True)
class ActivationResult:
    activated: bool
    active_profile_id: str
    requested_profile_id: str
    status: str
    message: str | None = None


class ProfileActivationService:
    """Validate every role before atomically changing active_profile_id."""

    def __init__(
        self,
        store: ProviderConnectionStore,
        resolver: RoleResolver,
        rollout: LocalGenerationRollout | None = None,
        managed_manager: ManagedGenerationManager | NoOpManagedGenerationManager | None = None,
    ):
        self.store = store
        self.resolver = resolver
        self.rollout = rollout or LocalGenerationRollout()
        self.managed_manager = managed_manager or NoOpManagedGenerationManager()

    @staticmethod
    def _requires_local_rollout(current: ModelProfile, candidate: ModelProfile) -> bool:
        for role_key, binding in candidate.roles.items():
            current_binding = current.roles.get(role_key)
            if binding.provider == "local" and (
                current_binding is None or current_binding.provider != "local" or current_binding.model != binding.model
            ):
                return True
        return False

    @staticmethod
    def _local_model_label(profile: ModelProfile) -> str | None:
        labels = {binding.model for binding in profile.roles.values() if binding.provider == "local"}
        if len(labels) > 1:
            raise GenerationUnavailable("All local role bindings must use the same local generation profile")
        return labels.pop() if labels else None

    @staticmethod
    def _is_external_provider(provider: str) -> bool:
        """Check if a provider is external (not managed in-cluster)."""
        return provider in EXTERNAL_GENERATION_PROVIDERS

    async def _validate_role(self, profile: ModelProfile, role_key: str) -> None:
        resolved = await self.resolver.resolve_profile_role(profile, role_key)
        try:
            if resolved.provider != "local":
                try:
                    models = await resolved.client.list_models()
                except GenerationUnavailable:
                    # Compatible providers may not implement discovery. Smoke test remains authoritative.
                    models = []
                if models and resolved.model not in {
                    item.get("id") or item.get("name") for item in models
                }:
                    raise GenerationUnavailable(f"Provider does not offer configured model '{resolved.model}'")
            elif not await resolved.client.health_check():
                raise GenerationUnavailable("Local generation provider health check failed")
            await resolved.client.generate(GenerationRequest(
                system_prompt="Respond with OK.", user_prompt="Health check.", max_tokens=4, role=role_key,
            ))
        finally:
            if resolved.close_after_request:
                await resolved.client.close()

    async def activate(self, profile_id: str, actor: str) -> ActivationResult:
        previous = self.store.get_active_profile()
        rollout_completed = False
        try:
            candidate = self.store.get_profile(profile_id)
            target_local_label = self._local_model_label(candidate)
            self.store.mark_activation_pending(profile_id)
            
            # Determine if we're switching to or from managed generation
            previous_provider = previous.roles.get("generation", None)
            candidate_provider = candidate.roles.get("generation", None)
            
            previous_is_external = (
                previous_provider is not None and self._is_external_provider(previous_provider.provider)
            )
            candidate_is_external = (
                candidate_provider is not None and self._is_external_provider(candidate_provider.provider)
            )
            
            # If switching from external to managed, scale up managed generation first
            if not previous_is_external and candidate_is_external:
                # Current is managed, target is external - scale down managed after switch
                pass
            elif previous_is_external and not candidate_is_external:
                # Current is external, target is managed - scale up managed first
                if target_local_label is None:
                    raise GenerationUnavailable("Local generation rollout requires a selected local generation profile")
                await self.rollout.rollout(target_local_label)
                rollout_completed = True
                for role_key in ("generation", "reviewer", "promptRefiner", "collaborator"):
                    if candidate.roles[role_key].provider == "local":
                        await self._validate_role(candidate, role_key)
            else:
                # Same category (both managed or both external)
                if candidate_is_external:
                    # Both external - no managed generation changes needed
                    pass
                else:
                    # Both managed - check if model needs rollout
                    if self._requires_local_rollout(previous, candidate):
                        if target_local_label is None:
                            raise GenerationUnavailable("Local generation rollout requires a selected local generation profile")
                        await self.rollout.rollout(target_local_label)
                        rollout_completed = True
                        for role_key in ("generation", "reviewer", "promptRefiner", "collaborator"):
                            if candidate.roles[role_key].provider == "local":
                                await self._validate_role(candidate, role_key)
            
            # Validate all roles for the candidate profile
            for role_key in ("generation", "reviewer", "promptRefiner", "collaborator"):
                if candidate.roles[role_key].provider != "local" or not self._requires_local_rollout(previous, candidate):
                    await self._validate_role(candidate, role_key)
            
            # Atomically switch active profile
            self.store.activate_profile(profile_id, actor)
            
            # Now scale managed generation based on new active profile
            new_provider = candidate.roles.get("generation", None)
            if new_provider is None or self._is_external_provider(new_provider.provider):
                # External provider selected - scale down managed generation
                await self.managed_manager.scale_to_zero()
            else:
                # Managed provider selected - ensure it's running with correct model
                await self.managed_manager.scale_to_one(target_local_label)
            
            return ActivationResult(True, profile_id, profile_id, "active")
        except (ProviderConnectionError, GenerationUnavailable) as error:
            message = str(error)
            if rollout_completed:
                previous_local_label = self._local_model_label(previous)
                if previous_local_label:
                    try:
                        await self.rollout.rollout(previous_local_label)
                    except GenerationUnavailable:
                        message = f"{message}; local generation rollback failed"
            self.store.mark_activation_failed(profile_id, message)
            return ActivationResult(False, previous.id, profile_id, "activation_failed", message)
