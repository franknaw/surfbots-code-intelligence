"""Provider-connection metadata and server-side credential storage.

This Phase 1 module deliberately has no HTTP routes. Phase 6 will expose these
operations through the existing privileged Admin authorization boundary.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import sqlite3
from typing import Protocol
from urllib.parse import urlparse

import httpx

from ..core.config import settings

CONNECTION_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,62}$")
PROVIDER_TYPES = {"openai", "openai-compatible", "azure-openai", "local-openai"}
ROLE_KEYS = {"generation", "reviewer", "promptRefiner", "collaborator"}
ROLE_PROVIDER_TYPES = {"local", "openai", "openai-compatible", "azure-openai", "local-openai"}


class ProviderConnectionError(RuntimeError):
    """Raised for invalid provider-connection metadata or storage failures."""


class ProviderCredentialStore(Protocol):
    """Server-side token store. Implementations must never return tokens to APIs."""

    async def put(self, connection_id: str, token: str) -> None:
        """Create or replace the token for a connection."""

    async def get(self, connection_id: str) -> str | None:
        """Return a token only to a server-side provider client."""

    async def has(self, connection_id: str) -> bool:
        """Report token availability without disclosing its value."""


def _credential_key(connection_id: str) -> str:
    return f"{connection_id}.token"


class KubernetesSecretCredentialStore:
    """Store provider credentials as keys in one RBAC-scoped Kubernetes Secret."""

    def __init__(
        self,
        namespace: str | None = None,
        secret_name: str | None = None,
        token_path: str | None = None,
        ca_path: str | None = None,
        api_base_url: str | None = None,
    ):
        self.namespace = namespace or settings.kubernetes_namespace
        self.secret_name = secret_name or settings.provider_credentials_secret_name
        self.token_path = Path(token_path or settings.kubernetes_service_account_token_path)
        self.ca_path = Path(ca_path or settings.kubernetes_service_account_ca_path)
        host = api_base_url or self._service_host()
        self.api_base_url = host.rstrip("/")

    @staticmethod
    def _service_host() -> str:
        import os

        host = os.environ.get("KUBERNETES_SERVICE_HOST", "")
        port = os.environ.get("KUBERNETES_SERVICE_PORT_HTTPS", "443")
        if not host:
            return ""
        return f"https://{host}:{port}"

    @property
    def _resource_url(self) -> str:
        return f"{self.api_base_url}/api/v1/namespaces/{self.namespace}/secrets/{self.secret_name}"

    def _headers(self) -> dict[str, str]:
        if not self.api_base_url or not self.token_path.is_file():
            raise ProviderConnectionError("Kubernetes Secret store is not configured")
        token = self.token_path.read_text(encoding="utf-8").strip()
        if not token:
            raise ProviderConnectionError("Kubernetes service-account token is empty")
        return {"Authorization": f"Bearer {token}"}

    async def _request(self, method: str, url: str, **kwargs) -> httpx.Response:
        try:
            headers = self._headers()
            headers.update(kwargs.pop("headers", {}))
            async with httpx.AsyncClient(verify=str(self.ca_path), timeout=10.0) as client:
                return await client.request(method, url, headers=headers, **kwargs)
        except (OSError, httpx.HTTPError) as error:
            raise ProviderConnectionError("Kubernetes Secret store is unavailable") from error

    async def put(self, connection_id: str, token: str, provider_type: str | None = None) -> None:
        # Allow empty token for local-openai provider (no auth required)
        if not token.strip() and provider_type != "local-openai":
            raise ProviderConnectionError("Provider token must not be empty")
        response = await self._request(
            "PATCH",
            self._resource_url,
            content=json.dumps({"stringData": {_credential_key(connection_id): token}}),
            headers={"Content-Type": "application/merge-patch+json"},
        )
        if response.is_error:
            raise ProviderConnectionError(f"Kubernetes Secret write failed ({response.status_code})")

    async def get(self, connection_id: str) -> str | None:
        response = await self._request("GET", self._resource_url)
        if response.status_code == 404:
            return None
        if response.is_error:
            raise ProviderConnectionError(f"Kubernetes Secret read failed ({response.status_code})")
        encoded = response.json().get("data", {}).get(_credential_key(connection_id))
        if not encoded:
            return None
        try:
            return base64.b64decode(encoded).decode("utf-8")
        except (ValueError, UnicodeDecodeError) as error:
            raise ProviderConnectionError("Stored provider credential is invalid") from error

    async def has(self, connection_id: str) -> bool:
        return (await self.get(connection_id)) is not None


@dataclass(frozen=True)
class ProviderConnection:
    """Safe provider-connection read model; it has no token field."""

    id: str
    name: str
    provider_type: str
    base_url: str
    api_version: str | None
    secret_ref: str
    enabled: bool
    created_at: str
    updated_at: str
    last_tested_at: str | None
    last_test_status: str | None
    has_token: bool = False


@dataclass(frozen=True)
class ProfileRoleBinding:
    """A credential-free binding from one logical role to a provider/model."""

    provider: str
    model: str
    connection_id: str | None = None


@dataclass(frozen=True)
class ModelProfile:
    """A named generation/supervision profile; retrieval settings never belong here."""

    id: str
    name: str
    roles: dict[str, ProfileRoleBinding]
    created_at: str
    updated_at: str


@dataclass(frozen=True)
class ActivationState:
    """Safe runtime state for the active profile and the most recent attempt."""

    active_profile_id: str
    status: str
    pending_profile_id: str | None
    failure_message: str | None
    updated_at: str


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _validate_connection(id: str, name: str, provider_type: str, base_url: str, api_version: str | None = None) -> None:
    if not CONNECTION_ID.fullmatch(id):
        raise ProviderConnectionError("Connection ID must use lowercase letters, digits, and hyphens")
    if not name.strip() or len(name) > 120:
        raise ProviderConnectionError("Connection name must be between 1 and 120 characters")
    if provider_type not in PROVIDER_TYPES:
        raise ProviderConnectionError("Provider type must be openai, azure-openai, or openai-compatible")
    parsed = urlparse(base_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ProviderConnectionError("Provider base URL must be an absolute HTTP(S) URL")
    if provider_type == "azure-openai" and (not api_version or not re.fullmatch(r"20\d{2}-\d{2}-\d{2}(?:-preview)?", api_version)):
        raise ProviderConnectionError("Azure OpenAI API version must use YYYY-MM-DD or YYYY-MM-DD-preview")


def _validate_profile(id: str, name: str, roles: dict[str, ProfileRoleBinding]) -> None:
    if not CONNECTION_ID.fullmatch(id):
        raise ProviderConnectionError("Profile ID must use lowercase letters, digits, and hyphens")
    if not name.strip() or len(name) > 120:
        raise ProviderConnectionError("Profile name must be between 1 and 120 characters")
    if set(roles) != ROLE_KEYS:
        raise ProviderConnectionError("Profile must bind generation, reviewer, promptRefiner, and collaborator")
    for role, binding in roles.items():
        if binding.provider not in ROLE_PROVIDER_TYPES:
            raise ProviderConnectionError(f"Role '{role}' has an unsupported provider")
        if not binding.model.strip() or len(binding.model) > 200:
            raise ProviderConnectionError(f"Role '{role}' must specify a model")
        if binding.provider == "local" and binding.connection_id:
            raise ProviderConnectionError(f"Local role '{role}' must not specify a connection")
        if binding.provider != "local" and not binding.connection_id:
            raise ProviderConnectionError(f"Remote role '{role}' must specify a connection")


class ProviderConnectionStore:
    """SQLite metadata store; credentials are held only by its credential store."""

    def __init__(self, db_path: str | Path | None = None, credentials: ProviderCredentialStore | None = None, local_generation_profile: str | None = None):
        self.db_path = Path(db_path or settings.model_profiles_db)
        self.credentials = credentials or KubernetesSecretCredentialStore()
        self.local_generation_profile = local_generation_profile or settings.local_generation_profile

    def _connection(self) -> sqlite3.Connection:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.db_path, timeout=5)
        connection.row_factory = sqlite3.Row
        connection.execute(
            "CREATE TABLE IF NOT EXISTS provider_connections ("
            "id TEXT PRIMARY KEY, name TEXT NOT NULL, provider_type TEXT NOT NULL, base_url TEXT NOT NULL, api_version TEXT, "
            "secret_ref TEXT NOT NULL, enabled INTEGER NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, "
            "last_tested_at TEXT, last_test_status TEXT)"
        )
        connection.execute(
            "CREATE TABLE IF NOT EXISTS model_profile_audit ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, event_type TEXT NOT NULL, actor TEXT NOT NULL, "
            "connection_id TEXT, details_json TEXT NOT NULL, created_at TEXT NOT NULL)"
        )
        connection.execute(
            "CREATE TABLE IF NOT EXISTS model_profiles ("
            "id TEXT PRIMARY KEY, name TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)"
        )
        connection.execute(
            "CREATE TABLE IF NOT EXISTS model_profile_roles ("
            "profile_id TEXT NOT NULL, role_key TEXT NOT NULL, provider TEXT NOT NULL, "
            "connection_id TEXT, model TEXT NOT NULL, PRIMARY KEY(profile_id, role_key), "
            "FOREIGN KEY(profile_id) REFERENCES model_profiles(id) ON DELETE CASCADE)"
        )
        connection.execute(
            "CREATE TABLE IF NOT EXISTS model_profile_runtime ("
            "id INTEGER PRIMARY KEY CHECK(id = 1), active_profile_id TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active', "
            "pending_profile_id TEXT, failure_message TEXT, updated_at TEXT NOT NULL, "
            "FOREIGN KEY(active_profile_id) REFERENCES model_profiles(id))"
        )
        runtime_columns = {row[1] for row in connection.execute("PRAGMA table_info(model_profile_runtime)")}
        for name, definition in (
            ("status", "TEXT NOT NULL DEFAULT 'active'"),
            ("pending_profile_id", "TEXT"),
            ("failure_message", "TEXT"),
        ):
            if name not in runtime_columns:
                connection.execute(f"ALTER TABLE model_profile_runtime ADD COLUMN {name} {definition}")
        connection_columns = {row[1] for row in connection.execute("PRAGMA table_info(provider_connections)")}
        if "api_version" not in connection_columns:
            connection.execute("ALTER TABLE provider_connections ADD COLUMN api_version TEXT")
        connection.execute(
            "UPDATE provider_connections SET api_version = '2025-04-01-preview' WHERE provider_type = 'azure-openai' AND api_version IS NULL"
        )
        return connection

    @staticmethod
    def _secret_ref(connection_id: str) -> str:
        return f"{settings.provider_credentials_secret_name}/{_credential_key(connection_id)}"

    def _audit(self, connection: sqlite3.Connection, event_type: str, actor: str, connection_id: str, details: dict) -> None:
        connection.execute(
            "INSERT INTO model_profile_audit (event_type, actor, connection_id, details_json, created_at) VALUES (?, ?, ?, ?, ?)",
            (event_type, actor, connection_id, json.dumps(details, sort_keys=True), _now()),
        )

    async def create(self, *, id: str, name: str, provider_type: str, base_url: str, token: str, actor: str, api_version: str | None = None) -> ProviderConnection:
        api_version = api_version or ("2025-04-01-preview" if provider_type == "azure-openai" else None)
        _validate_connection(id, name, provider_type, base_url, api_version)
        with self._connection() as connection:
            existing = connection.execute("SELECT 1 FROM provider_connections WHERE id = ?", (id,)).fetchone()
        if existing is not None:
            raise ProviderConnectionError(f"Provider connection '{id}' already exists")
        await self.credentials.put(id, token, provider_type)
        timestamp = _now()
        try:
            with self._connection() as connection:
                connection.execute(
                    "INSERT INTO provider_connections (id, name, provider_type, base_url, api_version, secret_ref, enabled, created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)",
                    (id, name.strip(), provider_type, base_url.rstrip("/"), api_version, self._secret_ref(id), timestamp, timestamp),
                )
                self._audit(connection, "provider_connection_created", actor, id, {"provider_type": provider_type, "base_url": base_url.rstrip("/")})
        except sqlite3.IntegrityError as error:
            raise ProviderConnectionError(f"Provider connection '{id}' already exists") from error
        return await self.get(id)

    async def get(self, id: str) -> ProviderConnection:
        with self._connection() as connection:
            row = connection.execute("SELECT * FROM provider_connections WHERE id = ?", (id,)).fetchone()
        if row is None:
            raise ProviderConnectionError(f"Provider connection '{id}' was not found")
        data = dict(row)
        data["enabled"] = bool(data["enabled"])
        return ProviderConnection(**data, has_token=await self.credentials.has(id))

    async def list(self) -> list[ProviderConnection]:
        with self._connection() as connection:
            rows = connection.execute("SELECT * FROM provider_connections ORDER BY name, id").fetchall()
        connections = []
        for row in rows:
            data = dict(row)
            data["enabled"] = bool(data["enabled"])
            connections.append(ProviderConnection(**data, has_token=await self.credentials.has(data["id"])))
        return connections

    async def update(self, id: str, *, name: str | None = None, provider_type: str | None = None, base_url: str | None = None, api_version: str | None = None, enabled: bool | None = None, token: str | None = None, actor: str) -> ProviderConnection:
        current = await self.get(id)
        updated_name = name.strip() if name is not None else current.name
        updated_type = provider_type if provider_type is not None else current.provider_type
        updated_url = base_url.rstrip("/") if base_url is not None else current.base_url
        updated_api_version = api_version or (current.api_version if updated_type == current.provider_type else "2025-04-01-preview")
        _validate_connection(id, updated_name, updated_type, updated_url, updated_api_version)
        if token is not None:
            await self.credentials.put(id, token)
        with self._connection() as connection:
            connection.execute(
                "UPDATE provider_connections SET name = ?, provider_type = ?, base_url = ?, api_version = ?, enabled = ?, updated_at = ? WHERE id = ?",
                (updated_name, updated_type, updated_url, updated_api_version, int(enabled if enabled is not None else current.enabled), _now(), id),
            )
            details = {"name": updated_name, "provider_type": updated_type, "base_url": updated_url, "api_version": updated_api_version, "enabled": enabled if enabled is not None else current.enabled}
            self._audit(connection, "provider_connection_updated", actor, id, details)
            if token is not None:
                self._audit(connection, "provider_token_replaced", actor, id, {})
        return await self.get(id)

    def delete(self, id: str, actor: str) -> None:
        with self._connection() as connection:
            used = connection.execute("SELECT 1 FROM model_profile_roles WHERE connection_id = ? LIMIT 1", (id,)).fetchone()
            if used:
                raise ProviderConnectionError(f"Provider connection '{id}' is used by a model profile")
            result = connection.execute("DELETE FROM provider_connections WHERE id = ?", (id,))
            if result.rowcount == 0:
                raise ProviderConnectionError(f"Provider connection '{id}' was not found")
            self._audit(connection, "provider_connection_deleted", actor, id, {})

    @staticmethod
    def _profile_from_rows(profile, bindings) -> ModelProfile:
        roles = {
            row["role_key"]: ProfileRoleBinding(
                provider=row["provider"], model=row["model"], connection_id=row["connection_id"]
            )
            for row in bindings
        }
        return ModelProfile(
            id=profile["id"], name=profile["name"], roles=roles,
            created_at=profile["created_at"], updated_at=profile["updated_at"],
        )

    def _read_profile(self, connection: sqlite3.Connection, profile_id: str) -> ModelProfile | None:
        profile = connection.execute("SELECT * FROM model_profiles WHERE id = ?", (profile_id,)).fetchone()
        if profile is None:
            return None
        bindings = connection.execute(
            "SELECT role_key, provider, connection_id, model FROM model_profile_roles WHERE profile_id = ?", (profile_id,)
        ).fetchall()
        return self._profile_from_rows(profile, bindings)

    def _ensure_current_local_profile(self, connection: sqlite3.Connection) -> None:
        """Migrate local-only installations without reading or altering retrieval state."""
        runtime = connection.execute("SELECT active_profile_id FROM model_profile_runtime WHERE id = 1").fetchone()
        if runtime is not None:
            profile = self._read_profile(connection, runtime["active_profile_id"])
            if profile is not None and profile.id == "current-local":
                if all(
                    binding.provider == "local" and binding.model == "profile-generation"
                    for binding in profile.roles.values()
                ):
                    connection.execute(
                        "UPDATE model_profile_roles SET model = ? WHERE profile_id = ?",
                        (self.local_generation_profile, "current-local"),
                    )

                existing_roles = set(profile.roles)
                for role_key in sorted(ROLE_KEYS - existing_roles):
                    connection.execute(
                        "INSERT INTO model_profile_roles "
                        "(profile_id, role_key, provider, connection_id, model) "
                        "VALUES (?, ?, 'local', NULL, ?)",
                        ("current-local", role_key, self.local_generation_profile),
                    )

                connection.execute(
                    "UPDATE model_profiles SET updated_at = ? WHERE id = ?",
                    (_now(), "current-local"),
                )
            return
        timestamp = _now()
        connection.execute(
            "INSERT OR IGNORE INTO model_profiles (id, name, created_at, updated_at) VALUES (?, ?, ?, ?)",
            ("current-local", "Current Local", timestamp, timestamp),
        )
        for role_key in sorted(ROLE_KEYS):
            connection.execute(
                "INSERT OR IGNORE INTO model_profile_roles (profile_id, role_key, provider, connection_id, model) "
                "VALUES (?, ?, 'local', NULL, ?)",
                ("current-local", role_key, self.local_generation_profile),
            )
        connection.execute(
            "INSERT INTO model_profile_runtime (id, active_profile_id, updated_at) VALUES (1, ?, ?)",
            ("current-local", timestamp),
        )

    def get_active_profile(self) -> ModelProfile:
        with self._connection() as connection:
            self._ensure_current_local_profile(connection)
            runtime = connection.execute("SELECT active_profile_id FROM model_profile_runtime WHERE id = 1").fetchone()
            profile = self._read_profile(connection, runtime["active_profile_id"])
        if profile is None:
            raise ProviderConnectionError("Active model profile is missing")
        return profile

    def get_profile(self, profile_id: str) -> ModelProfile:
        with self._connection() as connection:
            profile = self._read_profile(connection, profile_id)
        if profile is None:
            raise ProviderConnectionError(f"Model profile '{profile_id}' was not found")
        return profile

    def get_activation_state(self) -> ActivationState:
        with self._connection() as connection:
            self._ensure_current_local_profile(connection)
            row = connection.execute("SELECT * FROM model_profile_runtime WHERE id = 1").fetchone()
        return ActivationState(
            active_profile_id=row["active_profile_id"], status=row["status"],
            pending_profile_id=row["pending_profile_id"], failure_message=row["failure_message"],
            updated_at=row["updated_at"],
        )

    def mark_activation_pending(self, profile_id: str) -> None:
        self.get_profile(profile_id)
        with self._connection() as connection:
            self._ensure_current_local_profile(connection)
            connection.execute(
                "UPDATE model_profile_runtime SET status = 'pending', pending_profile_id = ?, failure_message = NULL, updated_at = ? WHERE id = 1",
                (profile_id, _now()),
            )

    def mark_activation_failed(self, profile_id: str, message: str) -> None:
        with self._connection() as connection:
            connection.execute(
                "UPDATE model_profile_runtime SET status = 'activation_failed', pending_profile_id = ?, failure_message = ?, updated_at = ? WHERE id = 1",
                (profile_id, message[:500], _now()),
            )

    def activate_profile(self, profile_id: str, actor: str) -> ModelProfile:
        with self._connection() as connection:
            profile = self._read_profile(connection, profile_id)
            if profile is None:
                raise ProviderConnectionError(f"Model profile '{profile_id}' was not found")
            connection.execute(
                "UPDATE model_profile_runtime SET active_profile_id = ?, status = 'active', pending_profile_id = NULL, failure_message = NULL, updated_at = ? WHERE id = 1",
                (profile_id, _now()),
            )
            self._audit(connection, "model_profile_activated", actor, profile_id, {"roles": sorted(profile.roles)})
        return profile

    def create_profile(self, *, id: str, name: str, roles: dict[str, ProfileRoleBinding], actor: str) -> ModelProfile:
        _validate_profile(id, name, roles)
        timestamp = _now()
        try:
            with self._connection() as connection:
                connection.execute(
                    "INSERT INTO model_profiles (id, name, created_at, updated_at) VALUES (?, ?, ?, ?)",
                    (id, name.strip(), timestamp, timestamp),
                )
                connection.executemany(
                    "INSERT INTO model_profile_roles (profile_id, role_key, provider, connection_id, model) VALUES (?, ?, ?, ?, ?)",
                    [(id, role_key, binding.provider, binding.connection_id, binding.model) for role_key, binding in roles.items()],
                )
                self._audit(connection, "model_profile_created", actor, id, {"roles": sorted(roles)})
                profile = self._read_profile(connection, id)
        except sqlite3.IntegrityError as error:
            raise ProviderConnectionError(f"Model profile '{id}' already exists") from error
        if profile is None:
            raise ProviderConnectionError(f"Model profile '{id}' was not created")
        return profile

    def list_profiles(self) -> list[ModelProfile]:
        with self._connection() as connection:
            return [self._read_profile(connection, row["id"]) for row in connection.execute("SELECT id FROM model_profiles ORDER BY name, id")]

    def delete_profile(self, profile_id: str, actor: str) -> None:
        with self._connection() as connection:
            self._ensure_current_local_profile(connection)
            active = connection.execute("SELECT active_profile_id FROM model_profile_runtime WHERE id = 1").fetchone()["active_profile_id"]
            if profile_id == active:
                raise ProviderConnectionError("The active model profile cannot be deleted")
            result = connection.execute("DELETE FROM model_profiles WHERE id = ?", (profile_id,))
            if result.rowcount == 0:
                raise ProviderConnectionError(f"Model profile '{profile_id}' was not found")
            self._audit(connection, "model_profile_deleted", actor, profile_id, {})

    def update_profile(self, profile_id: str, *, name: str, roles: dict[str, ProfileRoleBinding], actor: str) -> ModelProfile:
        _validate_profile(profile_id, name, roles)
        with self._connection() as connection:
            if self._read_profile(connection, profile_id) is None:
                raise ProviderConnectionError(f"Model profile '{profile_id}' was not found")
            connection.execute("UPDATE model_profiles SET name = ?, updated_at = ? WHERE id = ?", (name.strip(), _now(), profile_id))
            connection.execute("DELETE FROM model_profile_roles WHERE profile_id = ?", (profile_id,))
            connection.executemany(
                "INSERT INTO model_profile_roles (profile_id, role_key, provider, connection_id, model) VALUES (?, ?, ?, ?, ?)",
                [(profile_id, role_key, binding.provider, binding.connection_id, binding.model) for role_key, binding in roles.items()],
            )
            self._audit(connection, "model_profile_updated", actor, profile_id, {"roles": sorted(roles)})
            return self._read_profile(connection, profile_id)


provider_connection_store = ProviderConnectionStore()