"""MCP Server application entry point with Streamable HTTP transport."""
import asyncio
import sys
import signal
from typing import Any
import json

from mcp.server.lowlevel import Server
from mcp.shared.exceptions import MCPError

from app.api.mcp_server import mcp_server
from app.core.config import settings


class MCPHTTPServer:
    """MCP Server with Streamable HTTP support."""

    def __init__(self):
        self.running = True

    async def start(self):
        """Start the MCP server."""
        import uvicorn
        from fastapi import FastAPI, Request, Response
        from fastapi.responses import JSONResponse

        # Get the MCP server instance
        self.mcp = mcp_server.get_server()

        # Create FastAPI app
        app = FastAPI(
            title="Surfbots Dev Platform MCP",
            description="Code Intelligence MCP Server for AI Agents",
            version="1.0.0",
        )

        # Health endpoint (non-MCP)
        @app.get("/health")
        async def health():
            return {
                "status": "healthy",
                "server": "surfbots-dev-platform-mcp",
                "transport": "streamable-http",
            }

        # Root endpoint
        @app.get("/")
        async def root():
            return {
                "service": "surfbots-dev-platform-mcp",
                "version": "1.0.0",
                "description": "MCP Server for AI Agents",
                "transport": "streamable-http",
                "endpoints": {
                    "health": "/health",
                    "mcp": "/mcp",
                },
            }

        # MCP endpoint - Streamable HTTP (JSON-RPC)
        @app.post("/mcp")
        async def mcp_endpoint(request: Request):
            """Handle MCP JSON-RPC requests."""
            try:
                data = await request.json()
                result = await self._handle_mcp_request(data)
                if result is None:
                    return Response(status_code=202)
                return result
            except Exception as e:
                return JSONResponse(
                    status_code=500,
                    content={
                        "jsonrpc": "2.0",
                        "error": {
                            "code": -32603,
                            "message": str(e)
                        },
                        "id": None
                    }
                )

        # Start server
        config = uvicorn.Config(
            app=app,
            host=settings.host,
            port=settings.port,
            log_level="info",
        )
        server = uvicorn.Server(config)

        # Set up signal handlers
        loop = asyncio.get_running_loop()

        def signal_handler():
            print("\nShutting down MCP Server...")
            self.running = False
            if server:
                server.should_exit = True

        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, signal_handler)

        await server.serve()

    async def _handle_mcp_request(self, request: dict) -> dict | None:
        """Handle MCP JSON-RPC requests. Returns None for notifications."""
        from app.api.mcp_server import mcp_server
        
        method = request.get("method")
        params = request.get("params", {})
        req_id = request.get("id")

        # Notifications carry no id and must not receive a JSON-RPC response.
        if req_id is None and method and method.startswith("notifications/"):
            return None

        try:
            if method == "tools/list":
                tools = mcp_server._create_tools()
                result = {
                    "tools": [
                        t.model_dump(by_alias=True, exclude_none=True) for t in tools
                    ]
                }
                return self._make_response(req_id, result)

            elif method == "tools/call":
                tool_name = params.get("name")
                arguments = params.get("arguments", {})
                try:
                    result = await mcp_server._on_call_tool(tool_name, arguments)
                    return self._make_response(
                        req_id, result.model_dump(by_alias=True, exclude_none=True)
                    )
                except MCPError:
                    raise
                except Exception as e:
                    raise MCPError(-32603, str(e))

            elif method == "ping":
                return self._make_response(req_id, {})

            elif method == "initialize":
                result = {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {
                        "tools": {}
                    },
                    "serverInfo": {
                        "name": "surfbots-dev-platform-mcp",
                        "version": "1.0.0"
                    }
                }
                return self._make_response(req_id, result)

            else:
                raise MCPError(-32601, f"Method not found: {method}")

        except MCPError:
            raise
        except Exception as e:
            raise MCPError(-32603, str(e))

    def _make_response(self, req_id: int | None, result: dict) -> dict:
        """Create MCP response."""
        return {
            "jsonrpc": "2.0",
            "result": result,
            "id": req_id
        }

    def _make_error_response(self, req_id: int | None, code: int, message: str) -> dict:
        """Create MCP error response."""
        return {
            "jsonrpc": "2.0",
            "error": {
                "code": code,
                "message": message
            },
            "id": req_id
        }

    async def close(self):
        """Clean up resources."""
        pass


async def main():
    """Run the MCP server."""
    print(f"Starting MCP Server on {settings.host}:{settings.port}")
    print(f"Transport: Streamable HTTP (JSON-RPC)")
    print(f"Code Search API URL: {settings.code_search_url}")

    server = MCPHTTPServer()

    try:
        await server.start()
    except asyncio.CancelledError:
        pass
    finally:
        await server.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nMCP Server stopped")
        sys.exit(0)
