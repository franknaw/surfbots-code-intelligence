# surfbots-dev-platform Shell Scripts Reference

This document provides an overview of all shell scripts in the surfbots-dev-platform repository, organized by purpose and usage frequency.

---

## Quick Reference: Main Scripts

| Script | Purpose | Usage |
|--------|---------|-------|
| **bootstrap.sh** | Install the surfbots-dev CLI from releases | `./bootstrap.sh` |
| **cluster.sh** | Manage k3d cluster and services | `./cluster.sh create|destroy|status|deploy|deploy-generation|undeploy` |
| **surfbots-admin.sh** | Admin commands (start/stop/status/services) | `./surfbots-admin.sh start|stop|status|embed|gen|rerank|mcp|qdrant` |
| **deploy-models.sh** | Deploy model servers | `./deploy-models.sh` |

---

## Detailed Script Reference

### 1. bootstrap.sh (Main Install Script)

**Purpose**: Minimal bootstrap that downloads the surfbots-dev CLI from releases.

**When to use**: First-time installation of the platform.

**What it does**:
- Verifies Docker, Helm, and kubectl are installed
- Downloads the compiled surfbots-dev CLI binary from releases
- Verifies checksums for security
- Installs CLI to ~/.local/bin/surfbots-dev
- Provides next steps for usage

**Usage**:
```bash
./bootstrap.sh
```

**Environment Variables**:
- SURFBOTS_VERSION - Version to install (default: v0.2.0)
- BASE_URL - Override download URL

**After bootstrap**:
```bash
surfbots-dev --version
surfbots-dev doctor
surfbots-dev repo add /path/to/project
```

---

### 2. cluster.sh (Cluster Management)

**Purpose**: Full cluster lifecycle management with k3d.

**When to use**: When you need to create, destroy, or manage the k3d cluster and services.

**What it does**:
- Creates/destroys k3d cluster with proper volumes
- Sets up file shares for data persistence
- Deploys/undeploys all services (Qdrant, code-search-api, mcp-server)
- Provides status and health check commands

**Usage**:
```bash
./cluster.sh create      # Create a new cluster
./cluster.sh status      # Show cluster status
./cluster.sh deploy      # Deploy all services
./cluster.sh deploy-generation # Deploy only the selected local generation profile
./cluster.sh undeploy    # Undeploy all services (keeps data)
./cluster.sh destroy     # Destroy cluster and data
./cluster.sh test        # Run health checks
```

**Persistence**:
- File shares at .local/surfbots/ (relative to repo)
- k3d data at .local/k3d-data/

`SURFBOTS_INFERENCE_PROFILE` remains the compatibility environment variable for
the local generation deployment selection. It accepts `local-lightweight` or
`local-quality`; it does not change embedding, reranking, Qdrant collections, or
other retrieval state. Use `surfbots-dev profile show` to inspect it.

### Provider-Aware Model Profiles

Use `surfbots-dev models`, not `surfbots-admin.sh`, for provider connections and
generation/supervision role profiles. The CLI opens a temporary localhost-only
control-plane tunnel for each command and obtains a ten-minute Kubernetes
service-account token. Provider credentials are collected only through hidden
input and are stored server-side in Kubernetes Secrets.

```bash
surfbots-dev models status
surfbots-dev models connection add "OpenAI Main"
surfbots-dev models profile add "Remote Review"
surfbots-dev models activate "Remote Review"
```

See [INSTALL.md](INSTALL.md#provider-aware-model-profiles) for connection,
export/import, activation, and retrieval-isolation details.

---

### 3. surfbots-admin.sh (Admin Dashboard)

**Purpose**: Quick admin commands and port-forward management.

**When to use**: For routine admin tasks and checking platform status.

**What it does**:
- Starts/stops cluster and services
- Manages background port-forwards for every service
- Shows platform status and URLs

**Usage**:
```bash
./surfbots-admin.sh start   # Start cluster and services
./surfbots-admin.sh stop    # Stop all services
./surfbots-admin.sh status  # Show status
./surfbots-admin.sh mcp     # Start/reuse MCP background port-forward (8003)
./surfbots-admin.sh qdrant  # Start/reuse Qdrant background port-forward (6333)
./surfbots-admin.sh urls    # Show service URLs
```

**Port-forwards**: `start` launches all of these in the background and records
their PIDs in `/tmp/surfbots-*.pid`. If a preferred port is occupied, the next
available port is selected and reported by `urls` and `status`.
- Code Indexer: http://localhost:8000
- Code Search API: http://localhost:8001
- MCP Server: http://localhost:8003
- Qdrant Admin: http://localhost:6333
- Model Embedding: http://localhost:8004
- Model Generation: http://localhost:8005
- Model Reranker: http://localhost:8006

---

### 4. deploy-models.sh (Model Deployment)

**Purpose**: Deploy model servers (generation, embedding, reranking).

**When to use**: When you need to deploy the model services to Kubernetes.

**What it does**:
- Creates surfbots-dev-platform namespace
- Deploys model generation server (Qwen3-8B)
- Deploys model embedding server (Qwen3-Embedding-0.6B)
- Deploys model reranking server (BGE-reranker-v2-m3)
- Waits for pods to be ready

**Usage**:
```bash
./deploy-models.sh
```

**Model Endpoints**:
- Generation: http://model-generation:8000
- Embedding: http://model-embedding:8001
- Reranking: http://model-reranker:8002

---

### 5. tooling/repo-bootstrap/install.sh (Repository Setup)

**Purpose**: Setup a local repository for use with the surfbots-dev-platform.

**When to use**: When adding a new repository to the platform.

**What it does**:
- Analyzes the repository (git info, languages)
- Creates .surfbots/config.yaml with repository metadata
- Detects host/workspace mapping for Docker volumes
- Creates platform path mapping
- Installs .clinerules/surfbots-code-search.md

**Usage**:
```bash
./tooling/repo-bootstrap/install.sh /path/to/repository
./tooling/repo-bootstrap/install.sh .  # current directory
```

---

### 6. scripts/mcp-connect.sh (MCP Port-Forward)

**Purpose**: Port-forward MCP server to local machine.

**When to use**: When you need to connect to the MCP server (e.g., from Cline).

**What it does**:
- Sets up port-forward from Kubernetes service to localhost:8003

**Usage**:
```bash
./scripts/mcp-connect.sh
# or via surfbots-admin.sh
./surfbots-admin.sh mcp
```

---

## Script Selection Guide

### Get Started (Once)
```bash
./bootstrap.sh
./surfbots-admin.sh start
./surfbots-admin.sh status
```

### Add a Repository
```bash
./tooling/repo-bootstrap/install.sh /path/to/repo
./surfbots-admin.sh status
curl -X POST http://localhost:8001/api/v1/repositories -H 'Content-Type: application/json' -d @.surfbots/config.yaml
```

### Restart Platform
```bash
./surfbots-admin.sh stop
./surfbots-admin.sh start
```

### Completely Reset
```bash
./surfbots-admin.sh stop
./cluster.sh destroy
./cluster.sh create
./cluster.sh deploy
```

### Deploy Models
```bash
./deploy-models.sh
```

---

## Summary

| Frequency | Script | Purpose |
|-----------|--------|---------|
| Once | bootstrap.sh | Install CLI |
| Daily | surfbots-admin.sh | Start/stop/status |
| Per repo | tooling/repo-bootstrap/install.sh | Setup repository |
| Setup | cluster.sh | Create/destroy cluster |
| Setup | deploy-models.sh | Deploy models |
| Debug | scripts/mcp-connect.sh | Port-forward MCP |
