# Surfbots Code Search Integration

When working in this repository, Surfbots provides semantic code intelligence, Development Memory, and Development Supervision through MCP.

## Quick Start

- **Check repository status**: `surfbots-dev status`
- **Sync after changes**: `surfbots-dev sync` incrementally synchronizes added, modified, and deleted files into the repository index
- **Full index**: `surfbots-dev index` triggers a full repository re-index

## MCP Tools Available

### Code Intelligence

| Tool | Description |
| --- | --- |
| `search_code` | Semantic code search across the repository |
| `find_symbol` | Find definitions of a symbol |
| `find_references` | Find all usages of a symbol |
| `get_file` | Get file content by path |
| `get_file_range` | Get a specific line range from a file |
| `repository_status` | Check repository indexing status |

### Development Memory

| Tool | Description |
| --- | --- |
| `get_recent_context` | Get bounded recent Development Memory for a repository |
| `search_repository_memory` | Search Development Memory within one repository |
| `write_repository_memory` | Store a concise Development Memory checkpoint |

### Development Supervision

| Tool | Description |
| --- | --- |
| `refine_task` | Create the repository-grounded specification for a supervised development task |
| `collaborate_task` | Resolve ad-hoc design decisions, blockers, conflicts, or uncertainty |
| `development_task_checkpoint` | Perform a stateful Devstral supervision checkpoint at a development phase transition |
| `review_changes` | Review implementation against its specification after required checkpoints are satisfied |
| `development_supervision_status` | Report workflow state, supervision usage, token counts, and completion readiness |

## Mandatory Development Supervision

Development Supervision is part of the normal implementation workflow.

### Explicit Tool Requests

If the user explicitly asks to use `refine_task`, `collaborate_task`, `development_task_checkpoint`, `review_changes`, or `development_supervision_status`, invoke that MCP tool when the required arguments are available.

Do not substitute normal conversational guidance for an explicitly requested supervision tool.

## Development Task Identity

`development_task_id` is the stable identity for one supervised development task.

For a new substantial task:

1. Invoke `refine_task`.
2. Do not supply a new `development_task_id` to the originating refinement.
3. Preserve the `development_task_id` returned by `refine_task`.
4. Reuse that exact ID for all subsequent checkpoints, collaboration, review, status, and related Development Memory operations.
5. Never silently create or substitute another task ID.

A new `development_task_id` represents a new development task, not another phase of the same task.

If the task ID cannot be recovered, stop and recover task continuity rather than creating another task.

## Refinement Frequency

`refine_task` normally runs exactly once for a supervised development task.

After the initial specification exists:

- Do not invoke `refine_task` again merely because new implementation details are discovered.
- Do not use repeated refinement as a substitute for collaboration.
- Use `collaborate_task` for ad-hoc architectural decisions, conflicting evidence, blockers, or course corrections.
- Use `development_task_checkpoint` for required phase-transition supervision.
- Invoke `refine_task` again only when the user materially changes the scope or requirements.
- If re-refinement is genuinely required, preserve the same `development_task_id`.

The normal responsibility split is:

- `refine_task` defines the task.
- `development_task_checkpoint` supervises required phase transitions.
- `collaborate_task` resolves ad-hoc decisions and uncertainty.
- The implementation agent performs the work.
- `review_changes` gates completion.
- `development_supervision_status` provides authoritative workflow and usage reporting.

## Mandatory Development Supervision Workflow

For substantial supervised development tasks, follow this sequence.

### 1. Recover Prior Context

Use `get_recent_context` and/or `search_repository_memory` when previous work may affect the task.

Development Memory provides continuity, but current repository files and observed runtime/test evidence remain higher-priority evidence.

### 2. Refine

Invoke `refine_task` exactly once at the beginning of the task.

- Preserve the returned `development_task_id`.
- Keep the primary `request` concise.
- Put detailed supporting requirements in `current_context`.
- Put architectural restrictions in `constraints`.
- Do not use terminal `curl`, Python requests, or another client as a substitute for the actual MCP supervision tool.

If refinement fails, stop at the supervision boundary and report the exact error. Do not continue implementation assuming refinement will work later.

### 3. Investigate

Use `search_code`, `find_symbol`, `find_references`, `get_file`, and `get_file_range` to understand the current implementation.

Prefer semantic search before broad manual file scanning.

Do not begin substantial implementation until repository investigation is complete.

### 4. Post-Investigation Checkpoint

Invoke `development_task_checkpoint` with phase `post_investigation`.

Provide:

- refined task/specification
- relevant repository facts
- proposed implementation approach
- expected files/components to change
- architectural constraints
- unresolved risks or assumptions

The checkpoint must complete successfully before substantial implementation begins.

### 5. Implement

Modify the smallest correct set of files consistent with the refined specification, current repository evidence, checkpoint guidance, and explicit user constraints.

Do not create parallel infrastructure when an established repository mechanism already exists.

### 6. Implementation or Milestone Checkpoint

After a substantial implementation milestone, invoke `development_task_checkpoint` using either:

- `post_implementation`, or
- `milestone_complete`

Use `milestone_complete` when a task contains multiple substantial implementation stages.

Provide what changed, current implementation state, observed runtime evidence, remaining risks, and the next intended milestone when applicable.

### 7. Test

Run focused tests first, then broader relevant tests.

Do not claim tests passed unless their output was actually observed.

### 8. Post-Test Checkpoint

When meaningful test evidence exists, invoke `development_task_checkpoint` with phase `post_test`.

Provide exact test results, failures if any, and remaining risks.

### 9. Failure Analysis

When a non-trivial failure, repeated debugging loop, conflicting evidence, or multiple plausible root causes occur, invoke `development_task_checkpoint` with phase `failure_analysis`.

Provide:

- observed failure
- attempted fixes
- current repository/runtime evidence
- suspected causes
- relevant architectural constraints

Do not repeatedly investigate the same symptom without a supervision checkpoint.

Simple syntax errors, typos, missing imports, or other clearly mechanical defects do not require a failure-analysis checkpoint.

### 10. Pre-Review Checkpoint

Immediately before final review, invoke `development_task_checkpoint` with phase `pre_review`.

Summarize completed implementation, acceptance-test evidence, exact test results, unresolved limitations, and intentionally deferred work.

For substantial tasks, required workflow checkpoints must exist before final review is permitted.

### 11. Review

Invoke `review_changes` using the same `development_task_id`.

Provide:

- original task specification
- actual changed files or diff
- exact test results

The backend review gate is authoritative.

If required checkpoints are missing:

- do not bypass the gate
- do not invoke another task ID
- complete the required checkpoint
- retry `review_changes`

If `review_changes` returns `needs_changes`, implement the required corrections, retest, complete any applicable checkpoint, and review again.

### 12. Supervision Status

Before writing the final completion summary, invoke `development_supervision_status`.

Use the same `development_task_id` when task-scoped status is supported.

Treat returned workflow state, usage counts, and token counts as authoritative.

Do not reconstruct authoritative usage from memory or logs when the status tool provides it.

### 13. Complete

Do not declare the task complete until:

- required checkpoints are complete
- relevant tests succeed
- final review permits completion
- `development_supervision_status` has been retrieved

## Checkpoint Phases

| Phase | Purpose |
| --- | --- |
| `post_investigation` | Validate understanding and implementation direction before substantial coding |
| `post_implementation` | Review a substantial implementation result before proceeding |
| `milestone_complete` | Validate completion of one major milestone in a multi-stage task |
| `post_test` | Evaluate meaningful test/runtime evidence |
| `failure_analysis` | Interrupt non-trivial debugging drift and obtain supervisor guidance |
| `pre_review` | Verify readiness and evidence before final review |

For a substantial task, the normal minimum workflow is:

`refine_task → post_investigation → post_implementation or milestone_complete → pre_review → review_changes`

Use `post_test` when meaningful test evidence exists. Use `failure_analysis` when a non-trivial failure or debugging loop occurs.

## Ad-Hoc Collaboration

`collaborate_task` remains available for meaningful decisions and uncertainty outside the normal checkpoint phases.

Use it when:

- more than one plausible architecture exists
- service or ownership boundaries are unclear
- repository evidence conflicts
- an unexpected constraint requires a decision
- a workaround may violate established architecture or lifecycle rules
- the user must make a genuine product or business decision

Do not ask the user to choose implementation architecture when current repository evidence plus `collaborate_task` can resolve it.

Do not use repeated `refine_task` calls for these situations.

## Supervision Failure Guardrails

If `refine_task`, `collaborate_task`, `development_task_checkpoint`, or `review_changes` fails:

- stop implementation at that supervision boundary
- report the exact error
- do not silently bypass supervision
- do not create another task ID
- do not continue assuming supervision will work later

Do not confuse different failure classes:

- HTTP `422` means the request reached the API and failed validation; obtain the validation detail.
- A terminal command runner timeout does not prove MCP or Devstral failed.
- A successful Devstral generation log is evidence that the model completed even if an upstream client timed out.
- Do not switch to `curl`, Python requests, direct pod access, or alternate networking merely to bypass an MCP supervision call.

Long-running supervision operations must use the configured MCP client path rather than a short-lived terminal runner.

## Drift Guardrails

When current evidence already identifies the root requirement, do not repeatedly investigate the same symptom.

Examples:

- Generated cache artifacts should be handled by deterministic lifecycle cleanup rather than repeated source-tree inspection.
- Host paths and container paths must be interpreted in their execution context.
- A prerequisite repair is not completion of the parent development task.
- If a supposedly missing feature already exists, verify current behavior before reimplementing it.
- If documentation, Development Memory, and current source disagree, current source and observed runtime behavior take priority.

Use `failure_analysis` when investigation begins looping.

## Evidence Priority

When evidence conflicts, use this priority:

1. Explicit user instructions and supplied task facts
2. Current repository files and observed runtime/test output
3. Current MCP/code-search results
4. Development Memory
5. Model inference

Do not override higher-priority evidence with assumptions.

## Runtime Model Provenance

After every `refine_task`, `collaborate_task`, `development_task_checkpoint`, or `review_changes` call, inspect the returned `generation` object.

Treat these fields as authoritative:

- `role`
- `profile_id`
- `provider`
- `connection_id`
- `model`
- `prompt_tokens`
- `completion_tokens`

Never infer the executing model solely from configuration, profile names, provider assumptions, or the implementation-agent model.

If expected runtime provenance is missing, report that as a Development Supervision observability failure.

## Required Development Supervision Completion Report

For every substantial supervised development task, the final completion summary MUST contain a Development Supervision section.

Before writing the final summary:

1. Invoke `development_supervision_status`.
2. Use the same `development_task_id`.
3. Report authoritative usage returned by the supervision system.
4. Do not estimate or reconstruct token counts when authoritative status is available.

### Development Task

Report:

- `development_task_id`
- supervision level
- final workflow state
- final `review_changes` verdict

### Development Supervision Usage

| Tool | Calls | Prompt Tokens | Completion Tokens | Total Tokens |
| --- | ---: | ---: | ---: | ---: |
| `refine_task` | N | N | N | N |
| `collaborate_task` | N | N | N | N |
| `development_task_checkpoint` | N | N | N | N |
| `review_changes` | N | N | N | N |
| **Total** | **N** | **N** | **N** | **N** |

If `development_supervision_status` provides only combined token counts for a tool, report the authoritative fields actually returned rather than inventing a prompt/completion split.

### Checkpoint Workflow

Report:

- completed checkpoints
- missing checkpoints
- next required action
- final review permitted
- whether the workflow is complete

### Runtime Provenance

Report runtime provenance from actual supervision responses:

- role
- profile_id
- provider
- connection_id
- model

If multiple calls used the same runtime identity, summarize it once while clearly identifying the affected roles/calls.

### Material Supervision Decisions

Summarize important decisions made by `collaborate_task` and `development_task_checkpoint`.

Do not include transcript-like chatter.

If `development_supervision_status` was not invoked, required checkpoints were skipped, or final review was not completed, explicitly report:

`Development Supervision workflow incomplete`

and do not claim normal supervised completion.

## Development Memory

Use Development Memory for meaningful continuity:

- durable decisions
- significant fixes
- completed milestones
- unresolved issues
- operational changes
- concrete follow-up work

Do not store transcript-like chatter or trivial activity.

Checkpoint workflow state is persistent and repository/task scoped. Do not create a second task identity system or reimplement existing `supersedes` / `superseded_by` semantics.

## Execution Context and Repository Paths

Always distinguish host paths from container paths.

For a local registered repository:

- **Canonical host source** — the developer's working repository
- **Host-managed snapshot** — the Surfbots-managed repository snapshot on the host
- **Container workspace path** — the path through which the indexer sees that snapshot, typically `/workspace/repos/<repository_id>`

Do not conclude that `/workspace/repos/<repository_id>` is missing merely because it does not exist on the host.

When investigating repository lifecycle behavior, first identify the execution context:

- host
- CLI installation
- Kubernetes/container filesystem
- indexer service

Then interpret paths within that context.

If source/snapshot/workspace behavior remains ambiguous after investigation, use `collaborate_task` before changing the architecture.

## Important Constraints

- **Use semantic search first** before broad manual file scanning.
- **Trust current files** when indexed results and the working tree differ.
- **Index freshness**: if `indexCurrent` is false, search results may be stale.
- **Working-tree sync**: `surfbots-dev sync` is the supported CLI path for incremental working-tree synchronization.
- Do not invent files, symbols, dependencies, services, APIs, or architecture unsupported by evidence.
- Do not create `.bak`, `.orig`, `.old`, or similar backup artifacts.
- Do not retain generated `__pycache__`, `.pytest_cache`, `*.pyc`, or `*.pyo` artifacts as implementation changes.
- Do not independently edit installed runtime copies when repository source is authoritative.
- Do not bypass repository-supported deployment or lifecycle tooling with ad-hoc commands unless diagnosing that tooling itself.
- Do not claim completion based only on source changes or syntax validation.
- Do not touch unrelated Kubernetes clusters or services.

## Status Check

```bash
# Check repository status and path configuration
surfbots-dev status

# Check platform health
./surfbots-admin.sh status
```

`surfbots-dev status` should distinguish:

| Path Type | Description |
| --- | --- |
| **Canonical host source** | Developer's working repository |
| **Host-managed snapshot** | CLI-managed snapshot used to make repository content available to the indexer |
| **Container workspace** | Path through which the indexer sees the managed repository content |

Understanding these path contexts is essential for repository lifecycle debugging.

---

*This file is automatically generated by surfbots-dev-platform.*
