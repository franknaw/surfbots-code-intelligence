"""Core module for the code indexer service."""
from .config import settings
from .database import get_qdrant_client, qdrant_client

__all__ = ["settings", "get_qdrant_client", "qdrant_client"]