"""Repository Path Resolver - Dynamic repository path resolution.

This module handles resolving registered repository paths to container-accessible
paths for dynamic multi-repository support.

The path resolution follows this architecture:
    Host: ${XDG_DATA_HOME:-$HOME/.local/share}/surfbots-dev-platform/repos/<repository_id>
    Node (k3d): /var/lib/surfbots-dev-platform/repos/<repository_id>
    Container: /workspace/repos/<repository_id>
"""
import os
import hashlib
from pathlib import Path
from typing import Dict, Any, Optional, Tuple
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class RepositoryResolver:
    """Resolves repository paths between host and container."""
    
    def __init__(self, workspace_base: str = "/workspace/repos"):
        """Initialize the repository resolver.
        
        Args:
            workspace_base: Base path inside container for repositories
        """
        self.workspace_base = Path(workspace_base).resolve()
        self.repos_mount_path = os.environ.get(
            "REPOS_MOUNT_PATH", "/mnt/surfbots/repos"
        )
        
        # Get the host file share base from environment or default
        self.file_share_base = os.environ.get(
            "FILE_SHARE_BASE", "/var/lib/surfbots"
        )
        self.host_repos_base = Path(self.file_share_base) / "repos"
        
        logger.info(f"Repository Resolver initialized:")
        logger.info(f"  Workspace base: {self.workspace_base}")
        logger.info(f"  Repos mount path: {self.repos_mount_path}")
        logger.info(f"  Host repos base: {self.host_repos_base}")
    
    def get_repository_container_path(self, repository_id: str) -> Path:
        """Get the container path for a repository.
        
        Args:
            repository_id: Unique repository identifier
            
        Returns:
            Path inside container for this repository
        """
        return self.workspace_base / repository_id
    
    def get_repository_host_path(self, repository_id: str) -> Path:
        """Get the host path for a repository.
        
        Args:
            repository_id: Unique repository identifier
            
        Returns:
            Path on host for this repository
        """
        return self.host_repos_base / repository_id
    
    def get_repository_mount_path(self, repository_id: str) -> Path:
        """Get the mount path inside container (from repos-share volume).
        
        Args:
            repository_id: Unique repository identifier
            
        Returns:
            Mount path inside container
        """
        return Path(self.repos_mount_path) / repository_id
    
    def resolve_host_path(self, host_path: str) -> Tuple[bool, str]:
        """Resolve a host path to see if it's under the repos base.
        
        Args:
            host_path: Path on the host filesystem
            
        Returns:
            Tuple of (is_valid, message)
        """
        try:
            path = Path(host_path).resolve()
            
            # Check if path is under repos base
            if not str(path).startswith(str(self.host_repos_base)):
                return False, f"Path '{host_path}' is not under repos base"
            
            # Extract repository_id from path
            relative = path.relative_to(self.host_repos_base)
            if len(relative.parts) == 0:
                return False, "Path points to repos base directory itself"
            
            repository_id = relative.parts[0]
            return True, repository_id
        except Exception as e:
            return False, f"Error resolving path: {e}"
    
    def resolve_container_path(self, container_path: str) -> Tuple[bool, str]:
        """Resolve a container path to see if it's under workspace repos.
        
        Args:
            container_path: Path inside container
            
        Returns:
            Tuple of (is_valid, message)
        """
        try:
            path = Path(container_path).resolve()
            
            # Check if path is under workspace repos
            if not str(path).startswith(str(self.workspace_base)):
                return False, f"Path '{container_path}' is not under workspace base"
            
            # Extract repository_id from path
            relative = path.relative_to(self.workspace_base)
            if len(relative.parts) == 0:
                return False, "Path points to workspace base directory itself"
            
            repository_id = relative.parts[0]
            return True, repository_id
        except Exception as e:
            return False, f"Error resolving path: {e}"
    
    def ensure_repository_directory(self, repository_id: str, host_path: Optional[str] = None) -> bool:
        """Ensure the repository directory exists.
        
        Args:
            repository_id: Unique repository identifier
            host_path: Optional host path to symlink (for existing repos)
            
        Returns:
            True if directory exists or was created
        """
        # Create host directory
        host_dir = self.get_repository_host_path(repository_id)
        host_dir.mkdir(parents=True, exist_ok=True)
        
        # Create container directory
        container_dir = self.get_repository_container_path(repository_id)
        container_dir.mkdir(parents=True, exist_ok=True)
        
        # Create mount directory
        mount_dir = self.get_repository_mount_path(repository_id)
        mount_dir.mkdir(parents=True, exist_ok=True)
        
        # If host_path provided, create symlink
        if host_path:
            try:
                src_path = Path(host_path).resolve()
                if src_path.exists():
                    # Create symlink in host repos dir pointing to source
                    link_path = host_dir / "source"
                    if link_path.exists():
                        link_path.unlink()
                    link_path.symlink_to(src_path)
                    logger.info(f"Created symlink: {link_path} -> {src_path}")
            except Exception as e:
                logger.warning(f"Failed to create symlink for {repository_id}: {e}")
        
        return True
    
    def validate_repository_access(self, repository_id: str, file_path: str) -> Tuple[bool, str]:
        """Validate that a file path is within the allowed repository root.
        
        Args:
            repository_id: Unique repository identifier
            file_path: Path to validate
            
        Returns:
            Tuple of (is_valid, resolved_path_or_error)
        """
        repo_root = self.get_repository_container_path(repository_id)
        
        try:
            # Resolve the file path
            full_path = (repo_root / file_path).resolve()
            
            # Check if path is within repository root
            if not str(full_path).startswith(str(repo_root)):
                return False, f"Access denied: path '{file_path}' is outside repository root"
            
            # Check if file exists
            if not full_path.exists():
                return False, f"File not found: {file_path}"
            
            return True, str(full_path)
        except Exception as e:
            return False, f"Error validating path: {e}"
