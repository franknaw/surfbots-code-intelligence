"""Tests for host-side incremental synchronization.

These exercise change detection, batching, failure isolation, debounce, and
repository scoping without requiring a running cluster.
"""
import json
import sys
import time
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))

import surfbots_sync as sync
import surfbots_watch as watchmod


@pytest.fixture()
def state_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))
    return tmp_path


@pytest.fixture()
def repo(tmp_path):
    root = tmp_path / "repo"
    (root / "src").mkdir(parents=True)
    (root / "src" / "main.py").write_text("def main():\n    return 1\n")
    (root / "README.md").write_text("# readme\n")
    (root / "node_modules").mkdir()
    (root / "node_modules" / "junk.py").write_text("ignored = True\n")
    return root


class FakeApi:
    """Records calls and can be told to fail specific paths."""

    def __init__(self, fail_paths=None, raise_on=None):
        self.calls = []
        self.fail_paths = set(fail_paths or [])
        self.raise_on = raise_on

    def __call__(self, path, method="GET", payload=None):
        self.calls.append((method, path, payload))
        if self.raise_on and self.raise_on in path:
            raise RuntimeError("indexer unavailable")
        paths = (payload or {}).get("paths", [])
        if "files/index" in path:
            ok = [p for p in paths if p not in self.fail_paths]
            failed = [{"path": p, "error": "boom"} for p in paths if p in self.fail_paths]
            return {"indexed": ok, "failed": failed, "chunks_added": len(ok), "chunks_removed": len(ok)}
        return {"deleted": paths, "chunks_removed": len(paths)}

    @property
    def indexed_paths(self):
        out = []
        for method, path, payload in self.calls:
            if "files/index" in path:
                out.extend((payload or {}).get("paths", []))
        return out

    @property
    def deleted_paths(self):
        out = []
        for method, path, payload in self.calls:
            if method == "DELETE":
                out.extend((payload or {}).get("paths", []))
        return out


def make_sync(repo_root, api, repository_id="repo_test"):
    refreshed = []
    return sync.RepositorySynchronizer(
        repository_id=repository_id,
        canonical_source=str(repo_root),
        refresh_snapshot=lambda rid, src: refreshed.append((rid, src)) or str(repo_root),
        api_request=api,
    ), refreshed


def test_new_file_is_indexed(state_dir, repo):
    api = FakeApi()
    synchronizer, _ = make_sync(repo, api)
    synchronizer.synchronize()

    api2 = FakeApi()
    synchronizer2, _ = make_sync(repo, api2)
    (repo / "src" / "added.py").write_text("x = 1\n")
    result = synchronizer2.synchronize()

    assert "src/added.py" in api2.indexed_paths
    assert result["changed"] == 1


def test_modified_file_replaces_chunks_without_duplicates(state_dir, repo):
    api = FakeApi()
    synchronizer, _ = make_sync(repo, api)
    synchronizer.synchronize()

    (repo / "src" / "main.py").write_text("def main():\n    return 2\n")
    api2 = FakeApi()
    synchronizer2, _ = make_sync(repo, api2)
    result = synchronizer2.synchronize()

    assert api2.indexed_paths == ["src/main.py"]
    # The endpoint deletes before inserting, so replacement is not additive.
    assert result["chunks_removed"] >= 1


def test_deleted_file_removes_only_that_file(state_dir, repo):
    api = FakeApi()
    synchronizer, _ = make_sync(repo, api)
    synchronizer.synchronize()

    (repo / "README.md").unlink()
    api2 = FakeApi()
    synchronizer2, _ = make_sync(repo, api2)
    synchronizer2.synchronize()

    assert api2.deleted_paths == ["README.md"]
    assert api2.indexed_paths == []


def test_unchanged_repository_does_no_work(state_dir, repo):
    api = FakeApi()
    synchronizer, refreshed = make_sync(repo, api)
    synchronizer.synchronize()

    api2 = FakeApi()
    synchronizer2, refreshed2 = make_sync(repo, api2)
    result = synchronizer2.synchronize()

    assert result["status"] == "unchanged"
    assert api2.calls == []
    assert refreshed2 == []


def test_ignored_directories_are_never_indexed(state_dir, repo):
    api = FakeApi()
    synchronizer, _ = make_sync(repo, api)
    synchronizer.synchronize()
    assert not any("node_modules" in p for p in api.indexed_paths)


def test_multiple_changed_files_are_one_batch(state_dir, repo):
    api = FakeApi()
    synchronizer, _ = make_sync(repo, api)
    synchronizer.synchronize()

    (repo / "src" / "a.py").write_text("a = 1\n")
    (repo / "src" / "b.py").write_text("b = 2\n")
    api2 = FakeApi()
    synchronizer2, _ = make_sync(repo, api2)
    synchronizer2.synchronize()

    index_calls = [c for c in api2.calls if "files/index" in c[1]]
    assert len(index_calls) == 1
    assert sorted(index_calls[0][2]["paths"]) == ["src/a.py", "src/b.py"]


def test_repositories_stay_scoped(state_dir, tmp_path):
    repo_a = tmp_path / "a"
    repo_b = tmp_path / "b"
    for root in (repo_a, repo_b):
        root.mkdir()
        (root / "f.py").write_text("x = 1\n")

    api_a = FakeApi()
    sync_a, _ = make_sync(repo_a, api_a, repository_id="repo_a")
    sync_a.synchronize()

    api_b = FakeApi()
    sync_b, _ = make_sync(repo_b, api_b, repository_id="repo_b")
    sync_b.synchronize()

    assert all("repo_a" in path for _, path, _ in api_a.calls)
    assert all("repo_b" in path for _, path, _ in api_b.calls)


def test_failed_file_is_retried_on_next_pass(state_dir, repo):
    api = FakeApi(fail_paths={"src/main.py"})
    synchronizer, _ = make_sync(repo, api)
    result = synchronizer.synchronize()
    assert result["failed"]

    # The failure stays out of the manifest, so the next pass tries it again.
    api2 = FakeApi()
    synchronizer2, _ = make_sync(repo, api2)
    synchronizer2.synchronize()
    assert "src/main.py" in api2.indexed_paths


def test_failed_refresh_leaves_manifest_intact(state_dir, repo):
    api = FakeApi()
    synchronizer, _ = make_sync(repo, api)
    synchronizer.synchronize()
    before = dict(synchronizer.manifest.files)

    def failing_refresh(rid, src):
        raise RuntimeError("rsync failed")

    broken = sync.RepositorySynchronizer(
        repository_id="repo_test",
        canonical_source=str(repo),
        refresh_snapshot=failing_refresh,
        api_request=FakeApi(),
    )
    (repo / "src" / "main.py").write_text("changed = True\n")
    with pytest.raises(RuntimeError):
        broken.synchronize()

    reloaded = sync.Manifest.load("repo_test")
    assert reloaded.files.keys() == before.keys()


def test_repeated_identical_sync_is_idempotent(state_dir, repo):
    api = FakeApi()
    synchronizer, _ = make_sync(repo, api)
    synchronizer.synchronize()
    first = len(api.indexed_paths)

    api2 = FakeApi()
    synchronizer2, _ = make_sync(repo, api2)
    synchronizer2.synchronize()
    assert first > 0
    assert api2.indexed_paths == []


def test_content_hash_not_mtime_decides_change(state_dir, repo):
    api = FakeApi()
    synchronizer, _ = make_sync(repo, api)
    synchronizer.synchronize()

    # Touch without changing bytes.
    target = repo / "src" / "main.py"
    target.write_text(target.read_text())
    api2 = FakeApi()
    synchronizer2, _ = make_sync(repo, api2)
    result = synchronizer2.synchronize()
    assert result["status"] == "unchanged"


def test_large_change_set_is_batched(state_dir, tmp_path):
    root = tmp_path / "big"
    root.mkdir()
    for i in range(sync.BATCH_SIZE + 25):
        (root / f"f{i}.py").write_text(f"x = {i}\n")

    api = FakeApi()
    synchronizer, _ = make_sync(root, api)
    synchronizer.synchronize()

    index_calls = [c for c in api.calls if "files/index" in c[1]]
    assert len(index_calls) == 2
    assert all(len(c[2]["paths"]) <= sync.BATCH_SIZE for c in index_calls)


def test_debounce_coalesces_rapid_events(state_dir, repo):
    api = FakeApi()
    synchronizer, _ = make_sync(repo, api)
    watcher = watchmod.RepositoryWatcher(synchronizer, debounce_seconds=5, reconcile_seconds=10_000)

    now = 1_000.0
    for _ in range(5):
        watcher.note_event(now)
    assert watcher.tick(now) is None, "must not fire before the quiet period"

    result = watcher.tick(now + 6)
    assert result is not None
    index_calls = [c for c in api.calls if "files/index" in c[1]]
    assert len(index_calls) == 1


def test_watcher_survives_indexer_failure(state_dir, repo):
    api = FakeApi(raise_on="files/index")
    synchronizer, _ = make_sync(repo, api)
    watcher = watchmod.RepositoryWatcher(synchronizer, debounce_seconds=0, reconcile_seconds=0)

    watcher.note_event(1_000.0)
    result = watcher.tick(1_000.0)
    assert result["status"] == "error"
    # Still alive and still marked dirty so reconciliation retries.
    assert watcher._dirty is True


def test_reconciliation_catches_missed_events(state_dir, repo):
    api = FakeApi()
    synchronizer, _ = make_sync(repo, api)
    synchronizer.synchronize()

    # Change made while no watcher was running.
    (repo / "src" / "offline.py").write_text("offline = True\n")

    api2 = FakeApi()
    synchronizer2, _ = make_sync(repo, api2)
    watcher = watchmod.RepositoryWatcher(synchronizer2, debounce_seconds=3, reconcile_seconds=600)
    result = watcher.tick(10_000.0)

    assert result is not None
    assert "src/offline.py" in api2.indexed_paths


def test_manifest_survives_reload(state_dir, repo):
    api = FakeApi()
    synchronizer, _ = make_sync(repo, api)
    synchronizer.synchronize()

    reloaded = sync.Manifest.load("repo_test")
    assert "src/main.py" in reloaded.files
    assert reloaded.files["src/main.py"].content_hash
