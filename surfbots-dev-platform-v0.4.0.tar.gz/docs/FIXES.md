# Platform Bring-Up Fixes

Defects found and fixed while getting every Kubernetes workload in
`surfbots-dev-platform` running and healthy.

**Result:** all seven workloads report `1/1 Running` and pass `./cluster.sh test`.

```
code-indexer: OK      code-search-api: OK   mcp-server: OK   qdrant: OK
model-embedding: OK   model-generation: OK  model-reranker: OK
```

---

## 1. Model servers never started (CrashLoopBackOff)

**Symptom:** `model-reranker` and `model-embedding` cycled through
`CrashLoopBackOff`. Logs showed a successful `pip install` and then nothing —
no traceback, no uvicorn banner.

**Cause:** In both server-script ConfigMaps the Python source is embedded in a
YAML literal block (`server.py: |`) indented by four spaces, but the entrypoint
block sat at column 0:

```yaml
data:
  server.py: |
    from fastapi import FastAPI
    ...

if __name__ == "__main__":          # <-- column 0, outside the block scalar
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)
```

YAML therefore parsed `if __name__ == "__main__":` as a sibling mapping key of
`data`, not as part of the script. Kubernetes silently discarded the unknown
field, so the mounted `/app/server.py` ended at the last route definition.
`python /app/server.py` imported FastAPI, defined the app, and exited 0 — which
the kubelet treats as a crash and restarts.

**Fix:** Indented the block into the literal scalar and replaced the hardcoded
port with the chart value.

These ConfigMaps no longer exist; both charts were rewritten to run real model
images in [3a](#3a-model-services-replaced-with-real-inference).

> This class of bug is silent in both `helm template` and `kubectl apply`.
> To detect it, compare the rendered ConfigMap against the source:
> `kubectl get cm <name> -o jsonpath='{.data.server\.py}' | tail`

---

## 2. Model service names did not match their consumers

**Symptom:** `code-indexer` could not reach any model service; the admin
script's `embed` / `gen` / `rerank` port-forwards targeted services that did not
exist.

**Cause:** The service templates derived their name from the release name:

```yaml
metadata:
  name: {{ .Release.Name }}-embedding    # -> model-embedding-embedding
```

Consumers address `model-embedding`, `model-generation`, and `model-reranker`
(hardcoded in `helm/code-indexer/values-local.yaml` and `surfbots-admin.sh`).

**Fix:** Pinned the `Service` names, since each chart owns exactly one service.
Deployment and selector labels still use the release name.

- [helm/model-embedding/templates/service.yaml](../helm/model-embedding/templates/service.yaml)
- [helm/model-generation/templates/service.yaml](../helm/model-generation/templates/service.yaml)
- [helm/model-reranker/templates/service.yaml](../helm/model-reranker/templates/service.yaml)

---

## 3. `model-generation` was never deployable locally

**Symptom:** No `model-generation` release existed; `./cluster.sh deploy` had
been silently skipping or failing it.

**Cause:** Two hard blockers in `values-local.yaml`:

1. `nvidia.com/gpu: 1` in both requests and limits — the k3d node advertises no
   GPU capacity, so the pod was unschedulable.
2. An init container downloading a multi-GB Qwen3-8B GGUF before the app could
   start.

**Fix:** Replaced the chart with a provider abstraction. `provider: local` runs
`ghcr.io/ggml-org/llama.cpp:server` on CPU with `Qwen2.5-Coder-3B-Instruct` Q4_K_M
(no GPU request, weights fetched via `-hf` into the shared cache).
`provider: external` emits an `ExternalName` service pointing at an OpenAI-compatible
server outside the cluster, so a GPU-equipped host can serve a stronger model without
running a second CPU-only copy inside Kubernetes.

- [helm/model-generation/templates/deployment.yaml](../helm/model-generation/templates/deployment.yaml)
- [helm/model-generation/templates/service.yaml](../helm/model-generation/templates/service.yaml)
- [helm/model-generation/values-local.yaml](../helm/model-generation/values-local.yaml)

---

## 3a. Model services replaced with real inference

The embedding and reranker charts originally ran throwaway FastAPI scripts injected
from a ConfigMap that returned zero vectors and a constant `0.5` score. They are now
proper services with their own images:

- `surfbots/model-embedding` — `Qwen/Qwen3-Embedding-0.6B`, 1024-dim, CPU torch
- `surfbots/model-reranker` — `BAAI/bge-reranker-v2-m3` cross-encoder

Two things worth noting:

- **`transformers` must be ≥ 4.51.** With 4.46 the embedding pod failed at load with
  `checkpoint ... has model type 'qwen3' but Transformers does not recognize this
  architecture`. The load runs in a background thread, so the process stayed up and
  only `/health` returning 503 revealed it.
- **Readiness reflects the model, not the process.** `/health` returns 503 until the
  weights are loaded, and a `startupProbe` grants a long runway for the first
  download. This makes `helm --wait` and `kubectl wait` meaningful.

Weights are cached on a shared hostPath (`/mnt/surfbots/models`), so the ~5.3 GB is
downloaded once; a warm restart of the embedding pod reaches ready in ~11s.

- [src/model-embedding/](../src/model-embedding/)
- [src/model-reranker/](../src/model-reranker/)

---

## 4. Pending PVCs blocked `helm --wait`

**Symptom:** `helm upgrade --install model-embedding ... --wait` failed with
`Error: context deadline exceeded` after the full timeout, even though the pod
was `1/1 Running`. Repeated retries left the release in `failed` state
(revision 13) and later upgrades failed on immutable PVC fields.

**Cause:** The embedding and reranker charts create a PVC when
`persistentVolume.enabled` is true, but their deployments mount `model-storage`
from `emptyDir` and never reference the claim. An unbound PVC with no consumer
stays `Pending` forever under the `local-path` provisioner (it binds on first
use), and `helm --wait` waits on it.

**Fix:** Disabled the unused claims in the local values files.

- [helm/model-embedding/values-local.yaml](../helm/model-embedding/values-local.yaml)
- [helm/model-reranker/values-local.yaml](../helm/model-reranker/values-local.yaml)

---

## 5. `cluster.sh deploy` was not idempotent

**Cause:** Every release used `helm install --replace`. `--replace` only reuses
a release name in a deleted/failed state; against an already-`deployed` release
it errors out, so re-running `deploy` on a live cluster failed partway through.

**Fix:** Switched all seven releases to `helm upgrade --install`.

- [cluster.sh](../cluster.sh)

---

## 6. `cluster.sh test` checked the wrong things

**Cause:** The health check curled `localhost:8000/8001/8002`, which assumes a
particular set of host port-forwards, covered only three of seven services, used
the wrong path for two of them, and always exited 0 regardless of failures.

**Fix:** Rewrote it to run an ephemeral `curlimages/curl` pod inside the cluster
and probe every service by its cluster DNS name with the correct health path
(`/health/ready` for `code-search-api`, `/readyz` for Qdrant, `/health`
elsewhere). It now reports per-service status and returns non-zero on failure.

- [cluster.sh](../cluster.sh)

---

## 6a. Search returned zero results for every query

**Symptom:** Every `POST /api/v1/search` returned
`{"results": [], "total": 0, "error": "object of type 'QueryResponse' has no len()"}`,
even though the embedding call and the Qdrant query both returned 200.

**Cause:** `client.query_points()` returns a `QueryResponse`, not a list. The
result comprehension correctly iterated `results.points`, but the sibling line
called `len(results)` on the response object. The resulting `TypeError` was
swallowed by the surrounding `except`, which returned an empty result set with
HTTP 200 — so the failure looked like "nothing indexed" rather than a crash.

Present in all three endpoints: `/api/v1/search`, `/api/v1/search/related`, and
the symbol search.

**Fix:** `len(results)` → `len(results.points)`.

- [src/indexer/app/api/search.py](../src/indexer/app/api/search.py)

> Worth noting the shape of this bug: a broad `except` that returns HTTP 200 with
> an empty payload turns a code defect into what looks like missing data.

---

## 6b. Repository-scoped delete and reindex lifecycle

**Symptom:** Re-indexing an already-indexed repository would silently double its
point count, and `delete_repository(delete_index=True)` raised `AttributeError`.

**Causes:**

1. `settings.collection_prefix` did not exist. The delete path built a
   per-repository collection name (`{prefix}_{repository_id}`) even though the
   architecture uses a single shared `code-index` collection.
2. `delete_collection_points()` deleted by a numeric ID *range* (`1..count`),
   while chunk point IDs are UUID strings — so it matched nothing.
3. `reindex` indexed straight over the old points. Each chunk gets a fresh
   `uuid4()`, so nothing was overwritten and every pass appended a full copy.

**Fix:** Deletion is now a payload-filter delete on the stable boundary,
`repository_id`, in a new `delete_repository_points()`:

```python
client.delete(
    collection_name="code-index",
    points_selector=FilterSelector(filter=Filter(must=[
        FieldCondition(key="repository_id", match=MatchValue(value=repository_id))
    ])),
    wait=True,
)
```

`reindex` is now delete-then-index, making repeated runs idempotent in point
count. `delete_index` on repository removal defaults to `true`, and
`remove_repository()` will only unlink a path that resolves inside
`WORKSPACE_BASE` — the developer's canonical source directory can never be
removed. The per-repository collection logic and the `QDRANT_COLLECTION_PREFIX`
env var are gone.

- [src/indexer/app/core/database.py](../src/indexer/app/core/database.py)
- [src/indexer/app/api/repositories.py](../src/indexer/app/api/repositories.py)
- [src/indexer/app/services/repository_manager.py](../src/indexer/app/services/repository_manager.py)

---

## 6c. Shell scripts were invisible to search

**Symptom:** Queries about `start_port_forward` or cluster bootstrap matched the
docs describing them, never `surfbots-admin.sh` or `cluster.sh`.

**Cause:** Two enumeration paths disagreed. `_get_filesystem_file_list()`
filtered by `supported_extensions` (which had no shell entries), while
`_get_git_file_list()` applied no filter at all. Depending on which path a
repository took, the indexed file set differed.

**Fix:** Added `.sh`, `.bash`, `.zsh` to `supported_extensions`, applied the same
extension filter to both enumeration paths, and added a `language` label to each
point's payload (derived from extension) so results can be filtered and
displayed by language.

- [src/indexer/app/core/config.py](../src/indexer/app/core/config.py)
- [src/indexer/app/services/indexer.py](../src/indexer/app/services/indexer.py)
- [src/indexer/app/services/repository_parser.py](../src/indexer/app/services/repository_parser.py)

Regression coverage lives in
[src/indexer/tests/test_repository_lifecycle.py](../src/indexer/tests/test_repository_lifecycle.py).

---

## 6d. Search failures impersonated empty results

Following on from 6a: every search endpoint caught all exceptions and returned
HTTP 200 with `{"results": [], "total": 0}`. A broken query, an unreachable
embedding service, and a genuinely empty index were indistinguishable to callers.

**Fix:** Search now raises `503` when the embedding service returns nothing and
`500` on query failure, and logs with `logger.exception` so the traceback
survives.

- [src/indexer/app/api/search.py](../src/indexer/app/api/search.py)

---

## 6e. `search_code` returned nothing through MCP

**Symptom:** `search_code` returned zero results for every query, for every
repository, while `code-index` held 929 points and `repository_status` reported
the repository as `indexed`.

**Causes:** four independent defects in the same request path.

1. **Transport mismatch.** The indexer declared `POST /api/v1/search` with
   `Form(...)` parameters, but `code-search-api` posts JSON. FastAPI answered
   `422`; `indexer_client.search` caught the `HTTPError` and returned
   `{"results": [], "total": 0, "error": ...}`. `POST /api/v1/search/related`
   had the same mismatch through undeclared scalars, which FastAPI reads as
   query parameters.
2. **Wrong payload key.** Result normalization read `payload["chunk_content"]`,
   but the indexer writes the chunk text under `content`, and `language` at the
   payload root rather than under `file_info`.
3. **Repository filter dropped.** The MCP server sent `repositoryName`, while
   `SearchQuery` declares `repository_name`. Pydantic ignored the unknown field,
   so every search ran unscoped.
4. **Formatter key mismatch.** `_format_search_results` read `path`, `content`,
   and `symbol`; the normalized records use `file_path`, `chunk_content`, and
   `symbol_name`. Agents received bare `Score:` lines with no code.

**Fix:** The indexer search endpoints take Pydantic JSON bodies. Normalization
reads `content` and the root-level `language`. The Code Search API resolves a
`repository_name` to its `repository_id` before filtering, and
`get_repository_status` falls back to the same resolution, so both accept a name
or an ID. The MCP server sends `repository_name` and formats results with the
normalized keys, and reports explicitly when nothing matched.

- [src/indexer/app/api/search.py](../src/indexer/app/api/search.py)
- [src/code-search-api/app/services/search_service.py](../src/code-search-api/app/services/search_service.py)
- [src/code-search-api/app/services/indexer_client.py](../src/code-search-api/app/services/indexer_client.py)
- [src/mcp-server/app/api/mcp_server.py](../src/mcp-server/app/api/mcp_server.py)

> Same failure signature as 6a and 6d: a caught exception returning an empty
> success payload. The `422` was visible in neither the client nor the agent.

---

## 6f. Cline never saw the MCP server

**Symptom:** `surfbots-dev mcp configure cline` reported success and the settings
file was valid, but Cline's MCP panel stayed empty. Workspace Skills loaded
normally, so the workspace itself was being read.

**Cause:** Cline 4.x ships two runtimes and selects one at activation. The
legacy bundle reads VS Code global storage; the current bundle reads
`$CLINE_DIR/data/settings/cline_mcp_settings.json` (default `~/.cline`). The CLI
wrote only the global storage path, so the active runtime kept loading
`{"mcpServers": {}}`.

A second defect: the generated entry used `"timeout": 30000`. Cline's schema is
`timeout: number().min(1).default(60)` in **seconds**.

**Fix:** `cline_settings_paths()` returns both locations and the entry is merged
into each, preserving unrelated servers. Timeout is `60`.

- [tooling/repo-bootstrap/surfbots-dev](../tooling/repo-bootstrap/surfbots-dev)

---

## 6g. Cline could not load the Development Context Skill

**Symptom:** The Skill was installed by `surfbots-dev init` but never appeared in
Cline.

**Cause:** The Skill was written only to `.github/skills`, which is the Copilot
location. Cline discovers Skills in `.clinerules/skills`, `.cline/skills`,
`.claude/skills`, and `.agents/skills`, each requiring a `SKILL.md` with `name`
and `description` frontmatter whose `name` matches the directory.

**Fix:** A Cline-native Skill ships in `tooling/repo-bootstrap/.clinerules/skills/`,
and `surfbots-dev init` copies the whole `.clinerules` tree rather than two
named files, so nested Skills install with it.

- [tooling/repo-bootstrap/surfbots-dev](../tooling/repo-bootstrap/surfbots-dev)
- [tooling/repo-bootstrap/.clinerules/skills/surfbots-development-context/SKILL.md](../tooling/repo-bootstrap/.clinerules/skills/surfbots-development-context/SKILL.md)

---

## 6h. File tools returned fabricated content, and search could not be narrowed

**Symptom:** An agent reported that `search_code` results were too noisy to use —
README prose outranked the class definition it was looking for — and that
`get_file` "appears to have a bug where it returns an empty result".

**Causes:** three defects, one of them dangerous.

1. **The indexer's file API was placeholder data.** `get_file` returned a
   hardcoded `"# Example file content\nprint('Hello, World!')"`, `get_file_range`
   returned `["# Line 1", "# Line 2"]`, and `list_files` returned an empty list
   with a "to be implemented" message. The MCP tool happened to call
   `/api/v1/files` (the list endpoint) with a `path` parameter it does not
   accept, so it received the empty list. That accident was the only thing
   preventing agents from being served invented file contents as if they were
   real source.
2. **`repositoryId` was ignored.** The MCP server sent camelCase while the API
   declares `repository_id`, the same mismatch as `repositoryName` in 6e. The
   response echoed `repository_id: None`.
3. **Search filters were accepted and discarded.** `SearchQuery` declares
   `language` and `file_path`, and the service threaded them into the cache key,
   but never passed them to the indexer, which had no filter parameters at all.
   Callers could specify filters and observe no effect.

Route ordering compounded this: `/api/v1/files/range` was declared after
`/api/v1/files/{file_id}`, so it was unreachable — requests matched the path
parameter with `file_id="range"`.

**Fix:** The indexer reads real content from the managed snapshot through
`GET /api/v1/files/content?repository_id=&path=`, with optional `start_line` and
`end_line`. Resolution is confined to the snapshot root, so a traversing path is
rejected with 400 rather than reaching host files. The remaining `file_id`
endpoints return 501 instead of fabricating data. Search accepts `language` as an
exact payload match and `file_path` as a substring match applied after scoring,
both surfaced as optional `search_code` arguments.

- [src/indexer/app/api/files.py](../src/indexer/app/api/files.py)
- [src/indexer/app/api/search.py](../src/indexer/app/api/search.py)
- [src/code-search-api/app/api/files.py](../src/code-search-api/app/api/files.py)
- [src/code-search-api/app/services/indexer_client.py](../src/code-search-api/app/services/indexer_client.py)
- [src/mcp-server/app/api/mcp_server.py](../src/mcp-server/app/api/mcp_server.py)

> A stub that returns plausible fake data is worse than one that fails. Had the
> endpoint mapping been "fixed" without reading the implementation, agents would
> have started quoting invented source code with full confidence.

---

## 6i. Symbol tools could never return a result

**Symptom:** `find_symbol` and `find_references` both returned an empty content
list — no results, no error.

**Cause:** indexing never extracts symbols. No indexed chunk carries a
`symbol_name`, and `file_info` has no `symbol_type`:

```
payload keys across 984 points:
  repository_id, file_path, content, file_info, chunk_index, total_chunks, language
points with symbol_name: 0
```

So `find_symbol` ran a semantic search filtered on `file_info.symbol_type`, a key
that does not exist, and result normalization read an always-absent
`symbol_name`. `find_references` called `/api/v1/symbols/{symbol_id}/references`,
which returned `{"message": "... to be implemented"}`. Three key mismatches
compounded it: the MCP server sent camelCase `repositoryId`, and both it and the
Code Search API read a `symbols` key from an indexer response that returns
`results`. There are no symbol IDs anywhere in the system, so the `symbol_id`
addressing was unreachable by construction.

**Fix:** Symbols are resolved by scanning the managed snapshot rather than the
vector index, since chunk embeddings carry no structural information.
`GET /api/v1/symbols/search` returns definitions using per-language patterns for
Python, JavaScript, TypeScript, Go, Rust, Java, and shell, with a generic
keyword fallback. `GET /api/v1/symbols/references` returns whole-word
occurrences. Both report `path:line` with the matching source line, skip
vendored and oversized files, and are bounded by `limit`. The `symbol_id`
endpoints return 501.

- [src/indexer/app/services/symbol_search.py](../src/indexer/app/services/symbol_search.py)
- [src/indexer/app/api/search.py](../src/indexer/app/api/search.py)
- [src/code-search-api/app/api/search.py](../src/code-search-api/app/api/search.py)
- [src/mcp-server/app/api/mcp_server.py](../src/mcp-server/app/api/mcp_server.py)

> Because these read the snapshot, they are exactly as current as the last
> `surfbots-dev repo reindex`. During verification `find_references` returned 5
> of 7 known occurrences purely because the snapshot predated the edit; after a
> refresh it matched `grep` exactly.

---

## 6j. The search cache never returned a hit

**Symptom:** Repeated identical searches took the same time as the first, and
`Cache hit` never appeared in the logs.

**Cause:** reads and writes derived the key with different functions.
`SearchService._generate_cache_key` hashed a flat dict including
`include_related_memory`, while `CacheService._generate_key` hashed a dict whose
`filters` entry was a nested JSON string. For identical inputs:

```
read  key (cache.get): 4b9401274442d16af1e4517e4a1a3f77
write key (cache.set): 0a979541104a14e75e94661c57d085fe
```

Every search paid full embedding and query cost, and every result was written to
an entry no reader could address.

**Fix:** One derivation. `CacheService.make_key` is public and used by both
sides, `set_by_key` stores under it, and the duplicate key builder in
`SearchService` is gone. Repeated queries drop from ~91ms to ~9ms.

Cache entries are also versioned by the repository's index generation
(`status:indexed_at`), so a reindex retires them without any cross-service
invalidation call. The version is memoized for `INDEX_VERSION_TTL` seconds, so
this costs one status request per window rather than one per search. Because the
key carries the version, correctness does not depend on which replica serves the
request or on cache state surviving a rollout.

- [src/code-search-api/app/services/cache.py](../src/code-search-api/app/services/cache.py)
- [src/code-search-api/app/services/search_service.py](../src/code-search-api/app/services/search_service.py)

> `clear_by_repository` predates this and is still never called; versioned keys
> make explicit invalidation unnecessary.

---

## 7. `surfbots-admin.sh` port-forward handling

**Causes:**

- `start` searched for a free MCP port but then invoked `scripts/mcp-connect.sh`,
  which hardcodes `8003` — so the discovered port was ignored and the forward
  collided.
- `code-indexer` and `code-search-api` forwards were advertised in the URL banner
  but never actually started.
- `stop` only killed the MCP and Qdrant forwards.
- `status` and `urls` printed `8001`/`8000` as literals rather than the ports in
  use.
- Repeated `start` invocations stacked duplicate `kubectl port-forward`
  processes.

**Fix:** Replaced the ad-hoc logic with `start_port_forward` /
`stop_port_forward` / `read_pf_port` / `read_pf_pid` helpers. Each forward
records its PID and chosen port in `/tmp/surfbots-<label>.pid`, reuses a live
forward instead of stacking a duplicate, falls back to the next free port, and
is torn down by `stop`. `status` and `urls` now report actual ports.

- [surfbots-admin.sh](../surfbots-admin.sh)

---

## 8. Repository refresh crossed the host/container boundary

**Symptom:** A repository registration stored a container workspace path as its
source, and `reindex` tried to have the indexer perform both source refresh and
indexing. That design could not work safely: the indexer pod cannot see arbitrary
developer paths, does not have `rsync`, and must not receive broad host mounts.

**Fix:** Adopted Option B: the host CLI owns canonical-source access and snapshot
refresh; the indexer owns only snapshot indexing.

- `surfbots-dev repo add <path>` stores the canonical host path, refreshes
  `repos/<repository_id>` with `rsync -a --delete`, then requests indexing.
- `surfbots-dev repo reindex <id>` validates the stored source and synchronizes
  through `repos/.<repository_id>.refreshing`. Only a successful synchronization
  is swapped into `repos/<repository_id>` and allowed to call the API. A failed
  refresh exits non-zero without deleting existing Qdrant points.
- `POST /api/v1/repositories/{id}/index` indexes only the current managed
  `/workspace/repos/<repository_id>` snapshot. The former `/reindex` path is a
  deprecated snapshot-only compatibility alias.
- `repo remove` deletes the index, registry record, and managed snapshot but
  never the canonical source.
- The indexer image now includes `git`, enabling `git ls-files` and real
  `last_indexed_commit` values in snapshots.

The code-indexer mount remains scoped to `/workspace/repos`; `$HOME`,
`~/nsurfbots`, and arbitrary developer source roots are not mounted into k3d.

Regression coverage in
[tooling/repo-bootstrap/test_refresh_lifecycle.py](../tooling/repo-bootstrap/test_refresh_lifecycle.py)
covers edits, deletions, idempotency, staging cleanup, missing sources,
failure preservation, exclusions, and rejection of managed snapshots as
canonical sources.

The Helm template also now preserves an explicitly configured `readOnly: false`.
Helm's `default` considers `false` empty, so the old
`{{ .readOnly | default true }}` expression always rendered `true`.

---

## Known Limitations

- **Generation runs on CPU.** `Qwen2.5-Coder-3B-Instruct` Q4_K_M is chosen so the
  platform stays responsive without a GPU. Hosts with a usable GPU should set
  `provider: external` and point at a host-side llama-server.
- **Port collisions on the host.** If a local process already owns a default
  port (e.g. an unrelated `llama-server` on `8001`), the admin script shifts to
  the next free port. Always read the actual URLs from
  `./surfbots-admin.sh urls`.
- **Host refresh dependency.** `surfbots-dev repo add` and `repo reindex`
  require `rsync` on the host. They intentionally do not fall back to `copytree`,
  because that has different deletion and metadata semantics.
- **Vectors are not HNSW-indexed yet.** `code-index` reports
  `indexed_vectors_count: 0` until the collection passes Qdrant's
  `indexing_threshold` (10000). Searches are exact brute-force scans until then,
  which is correct but scales linearly.
- **Port-forwards do not survive a pod restart.** Rolling a deployment leaves the
  recorded forward pointing at a deleted pod, so the local port accepts
  connections and then returns an empty reply. Re-run `./surfbots-admin.sh start`
  after a rollout.
- **Only registered repositories are searchable.** A workspace with
  `.surfbots/config.yaml` is not indexed until `surfbots-dev repo add` runs;
  `search_code` returns nothing for it.

## Verification

```bash
./cluster.sh deploy    # idempotent; safe to re-run
./cluster.sh test      # in-cluster health check, non-zero on failure
./surfbots-admin.sh start
./surfbots-admin.sh status
surfbots-dev repo reindex <repository_id>  # refresh + index
```
