"""MCP Server package."""
