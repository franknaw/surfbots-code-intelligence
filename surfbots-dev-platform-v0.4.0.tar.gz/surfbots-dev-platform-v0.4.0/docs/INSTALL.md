# Install Surfbots Dev Platform

Surfbots Dev Platform installs once per developer machine and can index multiple local repositories. The platform runs local infrastructure in k3d and only exposes managed repository snapshots to Kubernetes.

## Download, Inspect, Run

Download the public bootstrap script, inspect it, then execute it:

```bash
curl -fsSL https://www.surfbots.ai/bootstrap/latest/surfbots-bootstrap.sh \
  -o /tmp/surfbots-bootstrap.sh
less /tmp/surfbots-bootstrap.sh
bash /tmp/surfbots-bootstrap.sh
```

The public bootstrap downloads the selected version from the public `franknaw/surfbots-code-intelligence` GitHub Release. It never clones the private development repository.

### Bootstrap Flow

- **Source of Truth**: `surfbots-dev-platform` (private development repository)
- **Public Distribution**: `franknaw/surfbots-code-intelligence` (public GitHub repository)
- **Website Delivery**: `https://www.surfbots.ai/bootstrap/latest/surfbots-bootstrap.sh` (SWA static deployment)

The website serves the bootstrap script from a static path that is populated by the release deployment process in `surfbots-main`. The bootstrap is not hand-copied between repositories - it is generated once and published.

## Release Packaging

Maintainers package a clean private checkout into a sanitized runtime archive:

```bash
scripts/package-release.sh --version v0.2.0
```

This creates a release artifact that includes:
- The bootstrap script (`bootstrap.sh`)
- All runtime code (Helm charts, source code, CLI)
- Installation scripts
- Manifest with release metadata

The release is published to GitHub and the SWA deployment automatically copies the bootstrap from the public repository to `https://www.surfbots.ai/bootstrap/latest/surfbots-bootstrap.sh`.

## Versioned Releases

To install a specific version:

```bash
curl -fsSL https://www.surfbots.ai/bootstrap/latest/surfbots-bootstrap.sh \
  -o /tmp/surfbots-bootstrap.sh
bash /tmp/surfbots-bootstrap.sh --version v0.3.0
```

## Local Profiles

`local-lightweight` is the default profile. It uses Qwen3 embedding at 1024 dimensions, BGE reranking, and Qwen2.5-Coder-1.5B Q4_K_M generation. `local-quality` keeps the same code and session-memory retrieval stack and selects Qwen2.5-Coder-3B Q4_K_M generation.

The command runs the indexer and Code Search API test suites plus live cluster health checks by default, stages only an explicit runtime allowlist, and produces:

```text
release-artifacts/out/surfbots-dev-platform-v0.2.0.tar.gz
release-artifacts/out/surfbots-dev-platform-v0.2.0.sha256
release-artifacts/out/manifest.json
```

After review, an authenticated maintainer can publish without overwriting an existing release:

```bash
scripts/package-release.sh --version v0.2.0 --publish
```

Publishing requires the GitHub CLI authenticated for `franknaw/surfbots-code-intelligence`. The release archive excludes `.git`, `.env` files, credentials, caches, virtual environments, tests, and private development history.

## Requirements

The current bootstrap supports Linux on `x86_64`, `aarch64`, and `arm64`. It checks for:

- `curl`, `git`, `rsync`, and `python3`
- Docker with non-root daemon access
- `kubectl`, `k3d`, and Helm
- At least 20 GiB of free disk
- Available RAM, CPU count, and GPU presence when `nvidia-smi` is available

The bootstrap does not use `sudo` and does not silently install operating-system packages. It reports missing dependencies and stops before creating a cluster or changing platform data.

## Local Generation Profiles

The supported bootstrap mode offers two local generation profiles.
`local-lightweight` is the default. Both retain the fixed retrieval stack and
change only the in-cluster generation deployment:

| Profile | Embedding | Reranker | Generation |
| --- | --- |
| `local-lightweight` | `Qwen/Qwen3-Embedding-0.6B` (1024 dimensions) | `BAAI/bge-reranker-v2-m3` | `Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF` (`Q4_K_M`) |
| `local-quality` | `Qwen/Qwen3-Embedding-0.6B` (1024 dimensions) | `BAAI/bge-reranker-v2-m3` | `Qwen/Qwen2.5-Coder-3B-Instruct-GGUF` (`Q4_K_M`) |

Choose a profile interactively or pin it for automation:

```bash
bash /tmp/surfbots-bootstrap.sh --profile local-lightweight
bash /tmp/surfbots-bootstrap.sh --profile local-quality
```

The selected profile is stored in `${XDG_CONFIG_HOME:-$HOME/.config}/surfbots-dev-platform/inference-profile.env` and is reused by bootstrap reruns, cluster restarts, and Helm upgrades. Inspect it with `surfbots-dev profile show` or list choices with `surfbots-dev profile list`.

Both profiles deliberately share the same embedding model, 1024-dimensional vector schema, cosine distance, and local reranker. Switching profiles changes only the generation model. It does not recreate or invalidate `code-index` or `session-memory`, and it does not require repository or memory reindexing. The host-backed model cache retains both generation models, so switching back reuses a downloaded model; cleanup remains explicit.

The installer reports RAM, available disk, CPU count, and GPU detection. It warns when available RAM is below 12 GiB, but the developer selects the final mode.

## Provider-Aware Model Profiles

`surfbots-dev models` configures generation and Development Supervision roles
without changing MCP client configuration or retrieval. Each named profile binds
`generation`, `reviewer`, and `promptRefiner` independently to either the shared
local generation deployment, an OpenAI connection, an Azure OpenAI connection,
or another OpenAI-compatible connection.

All control-plane operations are local only. For each command, the CLI creates a
ten-minute Kubernetes service-account token, opens a command-lifetime
localhost-only port-forward to the internal Code Search API, and closes it when
the command finishes. The API validates connections, performs discovery and
smoke checks, stores provider credentials in Kubernetes Secrets, and activates
profiles. No model-control endpoint is published through MCP, ingress, or the
Admin web application.

Create an OpenAI, Azure OpenAI, or compatible connection interactively. The
token prompt is hidden; never
put a provider credential in a command argument, shell history, YAML file,
Helm value, `.env` file, MCP configuration, or source control:

```bash
surfbots-dev models connection add "OpenAI Main"
# Provider type: openai
# Base URL: https://api.openai.com/v1
# Provider token: [hidden input]
surfbots-dev models connection test "OpenAI Main"
surfbots-dev models connection models "OpenAI Main"
```

For Azure OpenAI, use provider type `azure-openai` and the resource endpoint,
such as `https://your-resource.openai.azure.com`. The profile model value is the
Azure **deployment name**, not necessarily the underlying model family name.
The Azure API key is submitted through the same hidden input and is sent only as
the server-side `api-key` request header. Azure does not provide deployment
listing through this workflow, so enter each deployment name manually:

```bash
surfbots-dev models connection add "Azure Main"
# Provider type: azure-openai
# Base URL: https://your-resource.openai.azure.com
# Provider token: [hidden Azure API key]
surfbots-dev models profile add "Azure Review"
# Select azure-openai, Azure Main, and your Azure deployment name per role.
```

To convert your existing `openai` connection to Azure without re-entering its
stored credential, run `surfbots-dev models connection update openai`, choose
`azure-openai`, retain the Azure resource URL, and answer `no` when asked to
replace the provider token.

Connections store only endpoint and credential settings. Model IDs belong to a
specific role in a profile. To change one configured remote role directly,
without reopening all profile prompts, use:

```bash
surfbots-dev models profile set-model "Azure Review" reviewer your-azure-deployment
```

For Azure, the final value is the Azure deployment name. For OpenAI and other
compatible providers, it is the provider model ID.

Create or change a profile interactively. Discovery is offered for remote model
selection, but a compatible manual model ID is accepted when discovery is
unavailable:

```bash
surfbots-dev models profile add "Remote Review"
surfbots-dev models activate "Remote Review"
surfbots-dev models status
```

Remote-only activation applies to the next request. A local model-label change
rolls only `model-generation`, waits for readiness, runs a source-free smoke
check, and retains the prior active profile on failure. A model-generation pod
replacement may invalidate a separately managed generation port-forward; start
it again with `./surfbots-admin.sh gen` when needed.

Exported profiles contain only role bindings, connection names, and provider
types. Import rejects credential-like fields before the API is contacted:

```bash
surfbots-dev models profile export "Remote Review" --output remote-review.yaml
surfbots-dev models profile apply remote-review.yaml
```

Changing generation, reviewer, or prompt-refiner models never rebuilds or
modifies `code-index` or `session-memory`. Replacing an embedding model is a
separate retrieval-profile migration and is not part of this workflow.
The supported local defaults remain `Qwen/Qwen3-Embedding-0.6B` at 1024
dimensions and `BAAI/bge-reranker-v2-m3`; Azure model profiles do not change
either one.

## Data Locations

The installer uses user-owned XDG directories:

| Purpose | Location |
| --- | --- |
| Configuration | `${XDG_CONFIG_HOME:-$HOME/.config}/surfbots-dev-platform` |
| Platform data, model cache, SQLite, and managed snapshots | `${XDG_DATA_HOME:-$HOME/.local/share}/surfbots-dev-platform` |
| Bootstrap logs | `${XDG_STATE_HOME:-$HOME/.local/state}/surfbots-dev-platform` |
| CLI wrapper | `$HOME/.local/bin/surfbots-dev` |

Managed snapshots are under the platform data directory. Canonical developer repositories are never mounted broadly into Kubernetes and are never deleted by platform cleanup.

## Bootstrap Workflow

The bootstrap is idempotent. It reuses an existing `surfbots` k3d cluster and uses Helm upgrade/install semantics through the platform scripts.

It:

1. Validates the environment and local resources.
2. Clones or updates the platform source in the XDG data directory.
3. Creates a user-owned Python environment for the CLI.
4. Builds and imports local service images into k3d.
5. Creates or reuses the cluster and deploys platform services.
6. Runs `./cluster.sh test`.
7. Starts local port-forwards with `./surfbots-admin.sh start`.
8. Configures Cline and Copilot MCP integration for the current workspace.
9. Offers to initialize and index the current Git repository.

After installation, use:

```bash
surfbots-dev doctor
surfbots-dev repo list
surfbots-dev repo add .
surfbots-dev mcp test --repository-id <repository-id>
```

## Platform Capabilities

Surfbots provides three capabilities. Verification treats them separately, because
a reachable MCP server does not prove any of them works.

| Capability | Question it answers | Tools |
|---|---|---|
| Code Intelligence | What does the repository contain now? | `search_code`, `repository_status`, `find_symbol`, `find_references`, `get_file`, `get_file_range` |
| Development Memory | What were we doing, and why? | `get_recent_context`, `search_repository_memory`, `write_repository_memory` |
| Development Supervision | What should the agent do, and did it do it correctly? | `refine_task`, `review_changes` |

Supervision reuses the generation model already loaded by the active inference
profile. Selecting `local-lightweight` or `local-quality` changes the model
behind both tools with no configuration change, and no additional model process
is started.

```bash
surfbots-dev mcp test --repository-id <repository-id>
```

This exercises each capability behaviourally rather than listing tool names, and
reports service health separately from capability health:

```
MCP Server:                 Running
Code Intelligence:          Ready
Development Memory:         Ready
Development Supervision:    Ready
Cline Integration:          Configured
Copilot Integration:        Configured
```

Any capability that is missing, broken, or returns output that fails schema
validation is reported `Not Ready` and the command exits non-zero. Supervision
failure does not mask working retrieval; each capability is reported on its own.

Review results carry deterministic coverage. `no_issues_found` means no defect
was found in the evidence actually reviewed, not that the change is correct, and
`incomplete_review` or `unable_to_review` are never success. The reviewer is a
small local model and will miss defects; it is a second pass, not an authority.

## Coding Client Integration
`surfbots-dev init <repository>` installs repository-side Cline rules, the Cline Skill, Copilot instructions, and the Development Context Skill. `surfbots-dev mcp configure auto --path <repository>` merges the MCP connection into Cline's configuration and the workspace `.vscode/mcp.json` without removing unrelated servers.

Cline ships two runtimes that read different settings files, so the Cline configuration is written to both `$CLINE_DIR/data/settings/cline_mcp_settings.json` (default `~/.cline`) and the VS Code global storage path. Reload Cline after configuring. Cline reads Skills from `.clinerules/skills`; Copilot reads them from `.github/skills`.

All nine Surfbots tools are added to Cline's `autoApprove` list, so context retrieval at session start and checkpointing at session end run without a prompt. Approval prompts are what stop Development Memory from accumulating, and it is only useful once it does. Checkpoint writes are redacted server-side for common credential patterns and are keyed by `session_id`, so a session that checkpoints repeatedly supersedes its own record rather than adding new ones. Remove `write_repository_memory` from `autoApprove` if you would rather review each checkpoint.

The stable MCP server name is `surfbots-dev-platform`. Its resolved local URL is shown by:

```bash
./surfbots-admin.sh urls
```

The Development Context workflow retrieves repository status, bounded recent memory, relevant prior decisions, and current code before meaningful edits. Current code remains the authority when stored memory and code conflict.

## Self Tests and Troubleshooting

Run platform service checks:

```bash
./cluster.sh test
./surfbots-admin.sh summary
surfbots-dev mcp test --repository-id <repository-id>
```

Use `./surfbots-admin.sh status` to see pod and port-forward state. Bootstrap failures write a log under the XDG state directory and print its path.

## Uninstall and Cleanup

Stop only the deployed workloads while preserving data:

```bash
./cluster.sh undeploy
```

Remove the k3d cluster while preserving platform data:

```bash
./cluster.sh destroy
```

To permanently remove Surfbots data, explicitly delete the relevant XDG directories after confirming they contain only platform data. This deletes managed snapshots, SQLite registry data, Qdrant data, model caches, configuration, and logs. It never deletes a canonical developer repository.

```bash
rm -rf "${XDG_DATA_HOME:-$HOME/.local/share}/surfbots-dev-platform"
rm -rf "${XDG_CONFIG_HOME:-$HOME/.config}/surfbots-dev-platform"
rm -rf "${XDG_STATE_HOME:-$HOME/.local/state}/surfbots-dev-platform"
rm -f "$HOME/.local/bin/surfbots-dev"
```
