"""Focused Phase 7 tests for the local model-profile control client."""
import importlib.machinery
import importlib.util
import json
import subprocess
import sys
import builtins
from pathlib import Path
from types import SimpleNamespace

import pytest


BOOTSTRAP = Path(__file__).resolve().parent
spec = importlib.util.spec_from_loader(
    "surfbots_dev_model_cli",
    importlib.machinery.SourceFileLoader("surfbots_dev_model_cli", str(BOOTSTRAP / "surfbots-dev")),
)
cli = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cli)


class FakeProcess:
    def __init__(self):
        self.terminated = False
        self.waited = False

    def poll(self):
        return None if not self.terminated else 0

    def terminate(self):
        self.terminated = True

    def wait(self, timeout):
        self.waited = True

    def kill(self):
        self.terminated = True


class FakeResponse:
    def __init__(self, data):
        self.data = data

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def read(self):
        return json.dumps(self.data).encode()


class FakeConnection:
    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


def test_model_control_client_uses_ephemeral_bearer_header_and_cleans_up(monkeypatch):
    process = FakeProcess()
    captured = {}

    def create_token(command, **kwargs):
        captured["token_command"] = command
        return SimpleNamespace(returncode=0, stdout="short-lived-token\n")

    monkeypatch.setattr(cli.subprocess, "run", create_token)
    monkeypatch.setattr(cli.subprocess, "Popen", lambda *args, **kwargs: process)
    monkeypatch.setattr(cli.socket, "create_connection", lambda *args, **kwargs: FakeConnection())

    def urlopen(request, timeout):
        captured["url"] = request.full_url
        captured["authorization"] = request.headers["Authorization"]
        return FakeResponse({"ok": True})

    import urllib.request
    monkeypatch.setattr(urllib.request, "urlopen", urlopen)

    with cli.ModelControlClient() as client:
        assert client.request("/status") == {"ok": True}

    assert captured["url"].endswith("/api/v1/internal/model-control/status")
    assert captured["authorization"] == "Bearer short-lived-token"
    assert "--duration=10m" in captured["token_command"]
    assert process.terminated and process.waited


def test_connection_add_uses_hidden_token_prompt_and_never_prints_token(monkeypatch, capsys):
    captured = {}
    answers = iter(["openai", ""])
    monkeypatch.setattr(builtins, "input", lambda prompt: next(answers))
    monkeypatch.setattr(cli.getpass, "getpass", lambda prompt: "hidden-provider-token")
    monkeypatch.setattr(cli, "model_control_request", lambda path, method, payload: captured.update(path=path, method=method, payload=payload) or {
        "id": "openai-main", "name": "OpenAI Main", "provider_type": "openai", "base_url": "https://api.openai.com/v1", "enabled": True, "has_token": True,
    })

    assert cli.models_connection_add(SimpleNamespace(name="OpenAI Main")) == 0

    assert captured["path"] == "/connections"
    assert captured["payload"]["token"] == "hidden-provider-token"
    assert "hidden-provider-token" not in capsys.readouterr().out


def test_azure_connection_add_prompts_for_safe_api_version(monkeypatch):
    captured = {}
    answers = iter(["azure-openai", "https://example.openai.azure.com", ""])
    monkeypatch.setattr(builtins, "input", lambda prompt: next(answers))
    monkeypatch.setattr(cli.getpass, "getpass", lambda prompt: "hidden-provider-token")
    monkeypatch.setattr(cli, "model_control_request", lambda path, method, payload: captured.update(payload=payload) or payload)

    assert cli.models_connection_add(SimpleNamespace(name="Azure Main")) == 0
    assert captured["payload"]["api_version"] == "2025-04-01-preview"


def test_portable_export_uses_connection_names_and_apply_resolves_them(monkeypatch, tmp_path):
    profile = {"id": "hybrid", "name": "Hybrid", "roles": {"generation": {"provider": "openai-compatible", "model": "gpt-test", "connection_id": "openai-main"}}}
    connection = {"id": "openai-main", "name": "OpenAI Main", "provider_type": "openai", "has_token": True}
    monkeypatch.setattr(cli, "find_profile", lambda name: profile)
    monkeypatch.setattr(cli, "list_connections_data", lambda: [connection])
    exported_path = tmp_path / "hybrid.yaml"

    assert cli.models_profile_export(SimpleNamespace(name="Hybrid", output=str(exported_path))) == 0
    document = cli.yaml.safe_load(exported_path.read_text())
    binding = document["roles"]["generation"]
    assert binding == {"provider": "openai-compatible", "model": "gpt-test", "connection": "OpenAI Main", "provider_type": "openai"}
    assert "secret_ref" not in exported_path.read_text()

    captured = {}
    monkeypatch.setattr(cli, "model_control_request", lambda path, method, payload: captured.update(path=path, method=method, payload=payload) or payload)
    assert cli.models_profile_apply(SimpleNamespace(file=str(exported_path))) == 0
    assert captured["path"] == "/profiles/apply"
    assert captured["payload"]["roles"]["generation"]["connection_id"] == "openai-main"
    assert "connection" not in captured["payload"]["roles"]["generation"]


def test_profile_apply_rejects_credential_yaml_before_api_request(monkeypatch, tmp_path, capsys):
    source = tmp_path / "unsafe.yaml"
    source.write_text("id: unsafe\nname: Unsafe\ntoken: should-not-send\nroles: {}\n")
    monkeypatch.setattr(cli, "model_control_request", lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("API must not be called")))

    assert cli.models_profile_apply(SimpleNamespace(file=str(source))) == 1
    assert "credential field 'token'" in capsys.readouterr().out


def test_model_control_http_error_includes_safe_api_detail(monkeypatch):
    import urllib.error
    import urllib.request

    class Error(urllib.error.HTTPError):
        def __init__(self):
            super().__init__("http://control.test", 400, "Bad Request", {}, None)

        def read(self):
            return b'{"detail":"Provider connection \\"openai\\" already exists"}'

    monkeypatch.setattr(urllib.request, "urlopen", lambda *args, **kwargs: (_ for _ in ()).throw(Error()))
    client = cli.ModelControlClient()
    client.base_url = "http://control.test"
    client.token = "short-lived-token"

    with pytest.raises(cli.ModelControlError, match="already exists"):
        client.request("/connections", "POST", {})


def test_profile_set_model_updates_one_remote_role_without_prompting(monkeypatch, capsys):
    profile = {
        "id": "azure-profile", "name": "Azure Profile", "roles": {
            "generation": {"provider": "azure-openai", "connection_id": "azure", "model": "old-deployment"},
            "reviewer": {"provider": "local", "connection_id": None, "model": "local-lightweight"},
            "promptRefiner": {"provider": "azure-openai", "connection_id": "azure", "model": "old-deployment"},
        },
    }
    captured = {}
    monkeypatch.setattr(cli, "find_profile", lambda name: profile)
    monkeypatch.setattr(cli, "model_control_request", lambda path, method, payload: captured.update(path=path, method=method, payload=payload) or payload)

    assert cli.models_profile_set_model(SimpleNamespace(name="Azure Profile", role="generation", model_id="new-deployment")) == 0

    assert captured["path"] == "/profiles/azure-profile"
    assert captured["method"] == "PATCH"
    assert captured["payload"]["roles"]["generation"]["model"] == "new-deployment"
    assert "Azure deployment name: new-deployment" in capsys.readouterr().out


def test_role_prompt_exposes_and_normalizes_both_local_generation_profiles(monkeypatch):
    answers = iter(["local-quality", "local-lightweight", "local-quality", "local-quality"])
    monkeypatch.setattr(builtins, "input", lambda prompt: next(answers))

    bindings = cli.prompt_role_bindings()

    assert bindings == {
        "generation": {"provider": "local", "model": "local-quality"},
        "reviewer": {"provider": "local", "model": "local-lightweight"},
        "promptRefiner": {"provider": "local", "model": "local-quality"},
        "collaborator": {"provider": "local", "model": "local-quality"},
    }


def test_remote_role_prompt_lists_saved_connection_and_defaults_to_its_name(monkeypatch, capsys):
    answers = iter(["azure-openai", "", "deployment-name", "local-lightweight", "local-lightweight", "local-lightweight"])
    connection = {"id": "azure", "name": "Azure Main", "provider_type": "azure-openai", "base_url": "https://example.openai.azure.com", "enabled": True}
    monkeypatch.setattr(builtins, "input", lambda prompt: next(answers))
    monkeypatch.setattr(cli, "list_connections_data", lambda: [connection])
    monkeypatch.setattr(cli, "model_control_request", lambda *args, **kwargs: {"models": []})

    bindings = cli.prompt_role_bindings()

    assert bindings["generation"] == {"provider": "azure-openai", "connection_id": "azure", "model": "deployment-name"}
    assert "Available azure-openai connections:" in capsys.readouterr().out


def test_keyboard_interrupt_returns_standard_cancel_exit_code(monkeypatch, capsys):
    monkeypatch.setattr(cli, "main", lambda: (_ for _ in ()).throw(KeyboardInterrupt()))

    assert cli.run_cli() == 130
    assert "Cancelled" in capsys.readouterr().out


def test_models_help_explains_connection_and_model_id_boundaries(tmp_path):
    result = subprocess.run(
        [sys.executable, str(BOOTSTRAP / "surfbots-dev"), "models", "-h"],
        capture_output=True, text=True, check=True,
    )

    assert "Connection: endpoint, provider type, and credential only." in result.stdout
    assert "Profile: per-role provider plus model ID or Azure deployment name." in result.stdout
    assert "models profile set-model" in result.stdout


def test_terminal_color_respects_explicit_preference_and_no_color(monkeypatch):
    monkeypatch.setenv("SURFBOTS_COLOR", "always")
    monkeypatch.delenv("NO_COLOR", raising=False)
    assert cli.color("models", "36") == "\033[36mmodels\033[0m"

    monkeypatch.setenv("NO_COLOR", "1")
    assert cli.color("models", "36") == "models"


def test_top_level_help_uses_the_colored_command_guide():
    result = subprocess.run(
        [sys.executable, str(BOOTSTRAP / "surfbots-dev"), "-h"],
        capture_output=True, text=True, check=True,
        env={**__import__("os").environ, "SURFBOTS_COLOR": "always"},
    )

    assert "\033[1;36mpositional arguments\033[0m" in result.stdout
    assert "surfbots-dev models -h" in result.stdout


def test_activation_failure_and_status_display_safe_failure_reason(monkeypatch, capsys):
    profile = {"id": "azure", "name": "Azure", "roles": {}}
    monkeypatch.setattr(cli, "find_profile", lambda name: profile)
    monkeypatch.setattr(cli, "model_control_request", lambda *args: {
        "status": "activation_failed", "active_profile_id": "current-local", "message": "Generation service returned 401",
    })

    assert cli.models_activate(SimpleNamespace(name="Azure")) == 1
    assert "Failure reason: Generation service returned 401" in capsys.readouterr().out

    monkeypatch.setattr(cli, "model_control_request", lambda *args: {
        "activation": {"status": "activation_failed", "failure_message": "Generation service returned 401"},
        "active_profile": {"name": "Current Local", "roles": {}},
    })
    assert cli.models_status(SimpleNamespace()) == 0
    assert "Failure reason: Generation service returned 401" in capsys.readouterr().out