"""Tests for the CLI-owned managed snapshot refresh lifecycle (Option B).

The CLI owns canonical-source access and snapshot refresh; the indexer only ever
reads WORKSPACE_BASE/<repository_id>. These tests pin that boundary.
"""

import os
import shutil
import subprocess
import types
import pytest


def load_cli(monkeypatch, data_home):
    """Load the argparse-based CLI script as an importable module."""
    monkeypatch.setenv("SURFBOTS_DATA_HOME", str(data_home))
    path = os.path.join(os.path.dirname(__file__), "surfbots-dev")
    mod = types.ModuleType("surfbots_dev")
    mod.__file__ = path
    with open(path) as f:
        exec(compile(f.read(), path, "exec"), mod.__dict__)
    return mod


@pytest.fixture
def cli(tmp_path, monkeypatch):
    return load_cli(monkeypatch, tmp_path / "data")


@pytest.fixture
def source(tmp_path):
    src = tmp_path / "canonical" / "myrepo"
    (src / "app").mkdir(parents=True)
    (src / "app" / "main.py").write_text("print('hello')\n")
    (src / "run.sh").write_text("#!/bin/sh\necho run\n")
    return src


requires_rsync = pytest.mark.skipif(
    shutil.which("rsync") is None, reason="rsync not installed"
)


@requires_rsync
def test_refresh_creates_snapshot_under_repository_id(cli, source):
    dest = cli.refresh_snapshot("repo_abc123", str(source))

    assert dest == cli.snapshot_path("repo_abc123")
    assert os.path.basename(dest) == "repo_abc123"
    assert (open(os.path.join(dest, "app", "main.py")).read()) == "print('hello')\n"


@requires_rsync
def test_refresh_propagates_edits(cli, source):
    cli.refresh_snapshot("repo_abc123", str(source))
    (source / "app" / "main.py").write_text("print('changed')\n")

    dest = cli.refresh_snapshot("repo_abc123", str(source))

    assert open(os.path.join(dest, "app", "main.py")).read() == "print('changed')\n"


@requires_rsync
def test_refresh_deletes_files_removed_from_source(cli, source):
    dest = cli.refresh_snapshot("repo_abc123", str(source))
    assert os.path.exists(os.path.join(dest, "run.sh"))

    (source / "run.sh").unlink()
    dest = cli.refresh_snapshot("repo_abc123", str(source))

    assert not os.path.exists(os.path.join(dest, "run.sh"))


@requires_rsync
def test_refresh_is_idempotent(cli, source):
    first = cli.refresh_snapshot("repo_abc123", str(source))
    listing_first = sorted(os.listdir(first))
    second = cli.refresh_snapshot("repo_abc123", str(source))

    assert sorted(os.listdir(second)) == listing_first


@requires_rsync
def test_refresh_excludes_regenerated_directories(cli, source):
    (source / "__pycache__").mkdir()
    (source / "__pycache__" / "x.pyc").write_text("junk")
    (source / ".venv-mcp").mkdir()
    (source / ".venv-mcp" / "pyvenv.cfg").write_text("junk")

    dest = cli.refresh_snapshot("repo_abc123", str(source))

    assert not os.path.exists(os.path.join(dest, "__pycache__"))
    assert not os.path.exists(os.path.join(dest, ".venv-mcp"))


def test_refresh_rejects_missing_source(cli, tmp_path):
    with pytest.raises(cli.RefreshError, match="not a directory"):
        cli.refresh_snapshot("repo_abc123", str(tmp_path / "does-not-exist"))


@requires_rsync
def test_failed_refresh_preserves_previous_snapshot(cli, source, monkeypatch):
    dest = cli.refresh_snapshot("repo_abc123", str(source))
    assert os.path.exists(os.path.join(dest, "app", "main.py"))

    real_run = subprocess.run

    def failing_run(cmd, *a, **kw):
        if cmd and cmd[0] == "rsync":
            return subprocess.CompletedProcess(cmd, 23, "", "rsync: boom")
        return real_run(cmd, *a, **kw)

    monkeypatch.setattr(cli.subprocess, "run", failing_run)

    with pytest.raises(cli.RefreshError, match="rsync failed"):
        cli.refresh_snapshot("repo_abc123", str(source))

    # The old snapshot must survive so the existing index stays coherent
    assert open(os.path.join(dest, "app", "main.py")).read() == "print('hello')\n"


@requires_rsync
def test_failed_refresh_leaves_no_staging_directory(cli, source, monkeypatch):
    real_run = subprocess.run
    monkeypatch.setattr(
        cli.subprocess,
        "run",
        lambda cmd, *a, **kw: subprocess.CompletedProcess(cmd, 23, "", "boom")
        if cmd and cmd[0] == "rsync"
        else real_run(cmd, *a, **kw),
    )

    with pytest.raises(cli.RefreshError):
        cli.refresh_snapshot("repo_abc123", str(source))

    leftovers = [
        n for n in os.listdir(cli.workspace_base()) if n.startswith(".repo_abc123")
    ]
    assert leftovers == []


@requires_rsync
def test_snapshot_may_not_be_used_as_canonical_source(cli, source):
    """A snapshot must never be promoted to canonical source."""
    dest = cli.refresh_snapshot("repo_abc123", str(source))

    with pytest.raises(cli.RefreshError, match="outside the managed workspace"):
        cli.refresh_snapshot("repo_def456", dest)


def test_refresh_requires_rsync(cli, source, monkeypatch):
    """Never silently fall back to copy semantics with different behaviour."""
    monkeypatch.setattr(cli.shutil, "which", lambda name: None)

    with pytest.raises(cli.RefreshError, match="rsync is required"):
        cli.refresh_snapshot("repo_abc123", str(source))


@requires_rsync
def test_refresh_never_modifies_canonical_source(cli, source):
    before = {
        p: open(os.path.join(dp, p)).read()
        for dp, _, fs in os.walk(source)
        for p in fs
    }

    dest = cli.refresh_snapshot("repo_abc123", str(source))
    (dest and open(os.path.join(dest, "app", "main.py"), "w").write("tampered\n"))
    cli.refresh_snapshot("repo_abc123", str(source))

    after = {
        p: open(os.path.join(dp, p)).read()
        for dp, _, fs in os.walk(source)
        for p in fs
    }
    assert after == before


def test_status_shows_path_information(cli, tmp_path, monkeypatch):
    """Test that status_repo displays the three path types clearly."""
    import sys
    import io
    from pathlib import Path
    
    # Create a test repository with .surfbots config
    repo_dir = tmp_path / "test-repo"
    repo_dir.mkdir()
    
    # Create .surfbots directory and config
    surfbots_dir = repo_dir / ".surfbots"
    surfbots_dir.mkdir()
    
    config = {
        "name": "test-repo",
        "source": {
            "type": "local",
            "host_root": str(tmp_path / "projects"),
            "platform_path": "/workspaces/test-repo"
        },
        "branch": "main",
        "commit": "abc123"
    }
    
    import yaml
    config_path = surfbots_dir / "config.yaml"
    with open(config_path, 'w') as f:
        yaml.dump(config, f)
    
    # Mock args
    class Args:
        path = str(repo_dir)
    
    # Capture output
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()
    
    try:
        cli.status_repo(Args())
        output = sys.stdout.getvalue()
    finally:
        sys.stdout = old_stdout
    
    # Verify output contains the three path types
    assert "Canonical host source:" in output
    assert "Host-managed snapshot:" in output
    assert "Container workspace:" in output
    
    # Verify paths are correctly displayed
    assert str(tmp_path / "projects") in output
    assert "test-repo" in output
    assert "/workspace/repos/" in output


def test_status_repo_error_when_no_config(cli, tmp_path):
    """Test that status_repo fails gracefully when config is missing."""
    import sys
    import io
    
    repo_dir = tmp_path / "no-config"
    repo_dir.mkdir()
    
    class Args:
        path = str(repo_dir)
    
    # Capture output
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()
    
    try:
        cli.status_repo(Args())
        output = sys.stdout.getvalue()
    except SystemExit as e:
        # Expected to exit with code 1
        output = sys.stdout.getvalue() + sys.stderr.getvalue()
        assert e.code == 1
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr
    
    # Verify error message
    assert "Error: .surfbots/config.yaml not found" in output or "Run 'surfbots-dev init' first" in output
