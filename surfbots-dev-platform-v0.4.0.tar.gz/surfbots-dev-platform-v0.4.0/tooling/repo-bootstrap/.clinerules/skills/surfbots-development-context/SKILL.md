---
name: surfbots-development-context
description: "Use when working in a Surfbots-indexed repository to retrieve repository status, recent Development Memory, related memory, and current code evidence through the Surfbots MCP server before meaningful edits."
---

# Surfbots Development Context

Use Surfbots MCP as the first context source for meaningful coding work in this repository.

## Tool Autonomy and Clarification Rules

When using Surfbots tools such as `refine_task`, `collaborate_task`, code search, repository context, or related MCP tools:

1. **Do not ask the user to choose a focus** when the intent can reasonably be inferred from:
   * the current request;
   * current repository;
   * conversation context;
   * loaded skills;
   * available code/documentation context.

2. **Prefer autonomous read-only investigation** over clarification.

3. **For broad system-understanding requests**, automatically investigate relevant areas such as:
   * overall architecture;
   * major components and services;
   * component interactions;
   * deployment/runtime infrastructure;
   * APIs and endpoints;
   * storage/persistence;
   * indexing/search/RAG flows;
   * MCP integration;
   * model services;
   * configuration;
   * lifecycle management;
   * developer workflows.

4. **If several interpretations are reasonable**, choose the broadest useful interpretation and proceed.

5. **Mention reasonable assumptions** in the final answer instead of interrupting execution with a question.

6. **Read-only tools do not require conversational permission.**

7. **Continue gathering read-only context** until enough information exists to answer the user's actual request.

## Startup Procedure

1. Determine the repository ID from `.surfbots/config.yaml` or the workspace folder name.
2. Call `repository_status` for the repository.
3. Call `get_recent_context` with a bounded limit.
4. Use `search_repository_memory` when the task involves prior decisions, deployment behavior, migrations, named symbols, or unresolved work.
5. Use `search_code`, `find_symbol`, `find_references`, `get_file`, or `get_file_range` to verify current implementation details before changing code.

## Source of Truth

- Use Development Memory for prior decisions, outcomes, constraints, validation history, and unfinished work.
- Use current source files and configuration as the authority for implementation details.
- If indexed context and files disagree, follow the current files and mention the mismatch.

## Checkpoints

After meaningful features, significant fixes, durable decisions, operational changes, or concrete follow-up work, call `write_repository_memory` with a concise checkpoint. Do not store transcripts, hidden reasoning, secrets, or unrestricted command output.

## Development Supervision

Two tools assist with the work itself rather than retrieving context.

### Before coding

Call `refine_task` when the request is substantial or ambiguous:

```
refine_task(repository, request)
  -> objective, requirements, constraints, relevant_context, tests, acceptance_criteria
```

Implement against that specification. Keep it; `review_changes` needs it later.

### During implementation

Use `collaborate_task` when a meaningful issue requires resolution.

```
collaborate_task(repository, task, current_state, question, refined_task=None, options=None)
  -> assessment, recommendation, next_steps, risks, requires_user_decision
```

Stop and ask the user if `requires_user_decision = true`.

Skip refinement for trivial work: typo fixes, comment edits, single-line corrections, or a request that is already a precise instruction.

### After implementing

Run the tests first, then:

```
review_changes(repository, task_specification, diff, test_results)
  -> verdict, summary, findings, tests_required, coverage
```

Fix the findings, retest, and review again if needed. Stop after **two** automatic cycles and report anything still unresolved rather than iterating further.

### Reading the result

The verdict and the coverage must be read together.

| Verdict | Meaning |
|---|---|
| `no_issues_found` | No defect found in the evidence reviewed. Not proof of correctness. |
| `needs_changes` | Act on the findings. |
| `incomplete_review` | Evidence was omitted. Not success. |
| `unable_to_review` | Nothing reviewable fit the context. Not success. |

`coverage.level` is `full`, `partial`, or `unable_to_review`, and is computed from
what actually fit the model context rather than reported by the model.
`coverage.omitted_files` names what was not reviewed. When coverage is partial,
either review the omitted files separately or state plainly that they were not
reviewed.

The reviewer is a small local model. It is a useful second pass, not an
authority, and it will miss defects. Do not present its verdict as a guarantee.

If supervision is unavailable, the tool returns an error rather than a pass.
Continue with normal retrieval and say the review did not run.

## Available Surfbots MCP Tools

- `repository_status`
- `get_recent_context`
- `search_repository_memory`
- `search_code`
- `find_symbol`
- `find_references`
- `get_file`
- `get_file_range`
- `write_repository_memory`
- `refine_task`
- `collaborate_task`
- `review_changes`

`sync_repository` is not a live MCP tool. The host `surfbots-dev sync` command currently reports pending working-tree changes only.