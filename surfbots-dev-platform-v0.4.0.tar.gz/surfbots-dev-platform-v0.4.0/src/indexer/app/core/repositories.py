"""Repository storage using SQLite as the authoritative registry.

This module acts as a wrapper around SQLiteRepositoryStore, providing
a consistent interface for repository operations while delegating
to the SQLite-backed registry.

Qdrant is used ONLY for storing indexed code chunks and symbols,
NOT for repository metadata.
"""
from typing import Dict, Any, Optional, List
from datetime import datetime
import logging

from .sqlite_repo_store import SQLiteRepositoryStore

logger = logging.getLogger(__name__)

# Global SQLite repository store instance
_repository_store: Optional[SQLiteRepositoryStore] = None


def _get_store() -> SQLiteRepositoryStore:
    """Get or create the SQLite repository store instance."""
    global _repository_store
    if _repository_store is None:
        _repository_store = SQLiteRepositoryStore()
    return _repository_store


def get_repositories() -> Dict[str, Dict[str, Any]]:
    """Get all repositories from SQLite registry."""
    store = _get_store()
    return {r["repository_id"]: r for r in store.get_repositories()}


def get_repository(repo_id: str) -> Optional[Dict[str, Any]]:
    """Get a repository by ID from SQLite registry."""
    store = _get_store()
    return store.get_repository(repo_id)


def create_repository(
    repo_id: str,
    name: str,
    source_type: str,
    source: Dict[str, Any],
    branch: str = "main"
) -> Dict[str, Any]:
    """Create a new repository in SQLite registry."""
    store = _get_store()
    
    repo_data = {
        "repository_id": repo_id,
        "name": name,
        "source_type": source_type,
        "source": source,
        "branch": branch,
        "status": "registered",
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat(),
        "last_indexed_at": None,
        "file_count": 0,
        "chunk_count": 0,
        "indexed_commit": None,
        "repository_commit": None
    }
    
    store.add_or_update_repository(repo_data)
    return repo_data


def update_repository(repo_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Update a repository in SQLite registry."""
    store = _get_store()
    
    # Get current data
    current = store.get_repository(repo_id)
    if not current:
        return None
    
    # Update fields
    for key, value in updates.items():
        if key not in ["repository_id", "created_at"]:
            current[key] = value
    
    current["updated_at"] = datetime.utcnow().isoformat()
    
    store.add_or_update_repository(current)
    return current


def delete_repository(repo_id: str) -> bool:
    """Delete a repository from SQLite registry."""
    store = _get_store()
    return store.delete_repository(repo_id)


def list_repositories() -> List[Dict[str, Any]]:
    """List all repositories from SQLite registry."""
    return list(get_repositories().values())


# Cleanup: Remove the repositories collection from Qdrant if it exists
# This ensures Qdrant is only used for code chunks, not repository metadata
def _cleanup_qdrant_repository_collection():
    """Remove repositories collection from Qdrant to prevent dual-source confusion."""
    try:
        from .database import get_qdrant_client
        client = get_qdrant_client()
        try:
            client.get_collection("repositories")
            # Collection exists - delete it
            client.delete_collection("repositories")
            logger.info("Removed obsolete 'repositories' collection from Qdrant")
        except Exception:
            # Collection doesn't exist, nothing to clean up
            pass
    except Exception as e:
        logger.warning(f"Failed to clean up Qdrant repositories collection: {e}")


# Perform cleanup on module import
_cleanup_qdrant_repository_collection()
