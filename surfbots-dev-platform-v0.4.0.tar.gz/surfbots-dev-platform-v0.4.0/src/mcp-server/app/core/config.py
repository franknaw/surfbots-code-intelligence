"""Configuration for the MCP Server."""
from pydantic import Field
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """MCP Server configuration."""
    
    # Server settings
    host: str = Field(default="0.0.0.0", description="Server host address")
    port: int = Field(default=8003, description="Server port (8003 to avoid conflict with llama-server on 8002)")
    
    # Code Search API configuration
    code_search_url: str = Field(
        default="http://code-search-api:8000",
        description="URL of the Code Search API service"
    )
    
    # MCP Server settings
    debug: bool = Field(default=False, description="Enable debug mode")
    
    class Config:
        """Pydantic configuration."""
        env_prefix = ""
        env_file = ".env"
        extra = "ignore"


# Global settings instance
settings = Settings()
