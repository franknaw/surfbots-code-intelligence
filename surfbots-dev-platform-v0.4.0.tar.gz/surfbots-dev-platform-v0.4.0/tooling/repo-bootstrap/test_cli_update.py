"""Tests for the CLI update mechanism.

This module tests that the installed CLI can be updated from the authoritative
source (tooling/repo-bootstrap/surfbots-dev) to the installed location
(~/.local/share/surfbots-dev-platform/cli/repo-bootstrap/surfbots-dev).
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

BOOTSTRAP = Path(__file__).resolve().parent
CLI_SOURCE = BOOTSTRAP / "surfbots-dev"


class MockArgs:
    """Mock args for update_cli function."""
    pass


def test_update_cli_copies_to_installed_location(tmp_path, monkeypatch):
    """Test that update_cli copies the CLI to the installed location."""
    import types
    
    # Load the CLI module
    path = os.path.join(os.path.dirname(__file__), "surfbots-dev")
    mod = types.ModuleType("surfbots_dev")
    mod.__file__ = path
    with open(path) as f:
        exec(f.read(), mod.__dict__)
    
    # Set up temp directories
    data_home = tmp_path / "data"
    data_home.mkdir()
    cli_root = data_home / "surfbots-dev-platform" / "cli"
    repo_bootstrap = cli_root / "repo-bootstrap"
    installed_cli = repo_bootstrap / "surfbots-dev"
    
    monkeypatch.setenv("XDG_DATA_HOME", str(data_home))
    
    # Run update_cli
    args = MockArgs()
    result = mod.update_cli(args)
    
    assert result == 0, "update_cli should succeed"
    assert installed_cli.exists(), "Installed CLI should exist"
    assert os.access(installed_cli, os.X_OK), "Installed CLI should be executable"
    
    # Verify the installed CLI matches the source
    assert installed_cli.read_text() == CLI_SOURCE.read_text(), \
        "Installed CLI should match source"


def test_update_cli_creates_wrapper(tmp_path, monkeypatch):
    """Test that update_cli creates the wrapper script."""
    import types
    
    path = os.path.join(os.path.dirname(__file__), "surfbots-dev")
    mod = types.ModuleType("surfbots_dev")
    mod.__file__ = path
    with open(path) as f:
        exec(f.read(), mod.__dict__)
    
    data_home = tmp_path / "data"
    data_home.mkdir()
    bin_dir = Path.home() / ".local" / "bin"
    
    monkeypatch.setenv("XDG_DATA_HOME", str(data_home))
    
    args = MockArgs()
    result = mod.update_cli(args)
    
    assert result == 0, "update_cli should succeed"
    
    # Check wrapper exists
    wrapper = bin_dir / "surfbots-dev"
    assert wrapper.exists(), "Wrapper should exist"
    assert os.access(wrapper, os.X_OK), "Wrapper should be executable"
    
    # Verify wrapper content
    content = wrapper.read_text()
    assert "PYTHON_RUNTIME" in content, "Wrapper should define PYTHON_RUNTIME"
    assert "surfbots-dev" in content, "Wrapper should reference surfbots-dev"


def test_update_cli_verifies_installation(tmp_path, monkeypatch):
    """Test that update_cli verifies the installation."""
    import types
    import filecmp
    
    path = os.path.join(os.path.dirname(__file__), "surfbots-dev")
    mod = types.ModuleType("surfbots_dev")
    mod.__file__ = path
    with open(path) as f:
        exec(f.read(), mod.__dict__)
    
    data_home = tmp_path / "data"
    data_home.mkdir()
    cli_root = data_home / "surfbots-dev-platform" / "cli"
    repo_bootstrap = cli_root / "repo-bootstrap"
    installed_cli = repo_bootstrap / "surfbots-dev"
    
    monkeypatch.setenv("XDG_DATA_HOME", str(data_home))
    
    args = MockArgs()
    result = mod.update_cli(args)
    
    assert result == 0, "update_cli should succeed"
    
    # Verify the installed file matches source
    assert filecmp.cmp(CLI_SOURCE, installed_cli, shallow=False), \
        "Installed CLI should exactly match source"


def test_update_cli_preserves_external_cli(tmp_path, monkeypatch):
    """Test that update_cli works when the CLI is installed from a different location."""
    import types
    
    path = os.path.join(os.path.dirname(__file__), "surfbots-dev")
    mod = types.ModuleType("surfbots_dev")
    mod.__file__ = path
    with open(path) as f:
        exec(f.read(), mod.__dict__)
    
    data_home = tmp_path / "data"
    data_home.mkdir()
    cli_root = data_home / "surfbots-dev-platform" / "cli"
    repo_bootstrap = cli_root / "repo-bootstrap"
    installed_cli = repo_bootstrap / "surfbots-dev"
    
    monkeypatch.setenv("XDG_DATA_HOME", str(data_home))
    
    # First, manually copy the CLI to simulate existing installation
    repo_bootstrap.mkdir(parents=True, exist_ok=True)
    shutil.copy(CLI_SOURCE, installed_cli)
    installed_cli.chmod(0o755)
    
    args = MockArgs()
    result = mod.update_cli(args)
    
    # Should succeed even when CLI already exists
    assert result == 0, "update_cli should succeed when CLI already exists"


def test_update_cli_copies_support_files(tmp_path, monkeypatch):
    """Test that update_cli copies support files like .clinerules and .github."""
    import types
    
    path = os.path.join(os.path.dirname(__file__), "surfbots-dev")
    mod = types.ModuleType("surfbots_dev")
    mod.__file__ = path
    with open(path) as f:
        exec(f.read(), mod.__dict__)
    
    data_home = tmp_path / "data"
    data_home.mkdir()
    cli_root = data_home / "surfbots-dev-platform" / "cli"
    repo_bootstrap = cli_root / "repo-bootstrap"
    
    monkeypatch.setenv("XDG_DATA_HOME", str(data_home))
    
    args = MockArgs()
    result = mod.update_cli(args)
    
    assert result == 0, "update_cli should succeed"
    
    # Check support files were copied
    assert (repo_bootstrap / ".clinerules").exists(), ".clinerules should be copied"
    assert (repo_bootstrap / ".github").exists(), ".github should be copied"
    assert (repo_bootstrap / "surfbots-dev").exists(), "surfbots-dev should be copied"


def test_update_cli_removes_stale_cache_artifacts(tmp_path, monkeypatch):
    """Test that update_cli removes stale __pycache__ and .pytest_cache directories."""
    import types
    
    path = os.path.join(os.path.dirname(__file__), "surfbots-dev")
    mod = types.ModuleType("surfbots_dev")
    mod.__file__ = path
    with open(path) as f:
        exec(f.read(), mod.__dict__)
    
    data_home = tmp_path / "data"
    data_home.mkdir()
    cli_root = data_home / "surfbots-dev-platform" / "cli"
    repo_bootstrap = cli_root / "repo-bootstrap"
    repo_bootstrap.mkdir(parents=True, exist_ok=True)
    
    # Create stale cache directories in the installed location
    stale_pycache = repo_bootstrap / "__pycache__"
    stale_pycache.mkdir()
    (stale_pycache / "stale.cpython-313.pyc").write_text("stale")
    
    stale_pytest = repo_bootstrap / ".pytest_cache"
    stale_pytest.mkdir()
    (stale_pytest / "stale.txt").write_text("stale")
    
    stale_pyc_file = repo_bootstrap / "stale.pyc"
    stale_pyc_file.write_text("stale")
    
    monkeypatch.setenv("XDG_DATA_HOME", str(data_home))
    
    args = MockArgs()
    result = mod.update_cli(args)
    
    assert result == 0, "update_cli should succeed"
    
    # Verify stale cache directories were removed
    assert not stale_pycache.exists(), "__pycache__ should be removed"
    assert not stale_pytest.exists(), ".pytest_cache should be removed"
    assert not stale_pyc_file.exists(), ".pyc file should be removed"


def test_update_cli_keeps_allowed_directories(tmp_path, monkeypatch):
    """Test that update_cli keeps allowed directories like .clinerules and .github."""
    import types
    
    path = os.path.join(os.path.dirname(__file__), "surfbots-dev")
    mod = types.ModuleType("surfbots_dev")
    mod.__file__ = path
    with open(path) as f:
        exec(f.read(), mod.__dict__)
    
    data_home = tmp_path / "data"
    data_home.mkdir()
    cli_root = data_home / "surfbots-dev-platform" / "cli"
    repo_bootstrap = cli_root / "repo-bootstrap"
    repo_bootstrap.mkdir(parents=True, exist_ok=True)
    
    monkeypatch.setenv("XDG_DATA_HOME", str(data_home))
    
    args = MockArgs()
    result = mod.update_cli(args)
    
    assert result == 0, "update_cli should succeed"
    
    # Verify allowed directories are present
    assert (repo_bootstrap / ".clinerules").exists(), ".clinerules should be present"
    assert (repo_bootstrap / ".github").exists(), ".github should be present"
    assert (repo_bootstrap / "surfbots-dev").exists(), "surfbots-dev should be present"
