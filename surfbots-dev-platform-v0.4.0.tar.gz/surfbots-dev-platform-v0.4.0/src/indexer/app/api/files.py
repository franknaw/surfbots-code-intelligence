"""File content endpoints."""
from fastapi import APIRouter, HTTPException, Query
from pathlib import Path
from typing import List, Optional
import logging
import os

logger = logging.getLogger(__name__)
router = APIRouter()

WORKSPACE_BASE = os.environ.get("WORKSPACE_BASE", "/workspace/repos")


def _snapshot_root(repository_id: str) -> Path:
    root = Path(WORKSPACE_BASE, repository_id).resolve()
    if not root.is_dir():
        raise HTTPException(status_code=404, detail=f"No managed snapshot for {repository_id}")
    return root


def _resolve_in_snapshot(root: Path, path: str) -> Path:
    """Contain resolution inside the snapshot so traversal cannot reach host files."""
    target = (root / path.lstrip("/")).resolve()
    if target != root and root not in target.parents:
        raise HTTPException(status_code=400, detail="Path escapes the repository snapshot")
    return target


# Declared before /{file_id} so this literal segment is not captured as an id.
@router.get("/api/v1/files/content")
async def get_file_content(
    repository_id: str = Query(...),
    path: str = Query(...),
    start_line: Optional[int] = Query(None, ge=1),
    end_line: Optional[int] = Query(None, ge=1),
):
    """Return file content, or a line range, from the managed snapshot."""
    target = _resolve_in_snapshot(_snapshot_root(repository_id), path)
    if not target.is_file():
        raise HTTPException(status_code=404, detail=f"File not found: {path}")

    try:
        lines = target.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as error:
        logger.exception("Reading snapshot file failed")
        raise HTTPException(status_code=500, detail=f"Could not read file: {error}") from error

    total = len(lines)
    first = start_line or 1
    last = min(end_line or total, total)
    if total and first > total:
        raise HTTPException(status_code=416, detail=f"start_line {first} exceeds file length {total}")

    return {
        "repository_id": repository_id,
        "path": path,
        "content": "\n".join(lines[first - 1:last]),
        "start_line": first,
        "end_line": last,
        "total_lines": total,
        "truncated": (first, last) != (1, total),
    }


@router.get("/api/v1/files")
async def list_files(
    repository_id: str = Query(...),
    directory: Optional[str] = None,
    limit: int = Query(default=100, le=1000),
    offset: int = 0,
):
    """List files present in the managed snapshot."""
    root = _snapshot_root(repository_id)
    base = _resolve_in_snapshot(root, directory) if directory else root
    if not base.is_dir():
        raise HTTPException(status_code=404, detail=f"Directory not found: {directory}")

    files = sorted(
        str(p.relative_to(root))
        for p in base.rglob("*")
        if p.is_file() and ".git" not in p.parts
    )
    return {
        "files": [{"path": p} for p in files[offset:offset + limit]],
        "total": len(files),
        "repository_id": repository_id,
        "directory": directory,
    }


@router.get("/api/v1/files/{file_id}")
async def get_file(file_id: str):
    """Retained for compatibility; content is addressed by repository and path."""
    raise HTTPException(
        status_code=501,
        detail="Use GET /api/v1/files/content?repository_id=&path= instead of file_id lookup",
    )


@router.get("/api/v1/files/{file_id}/outline")
async def get_file_outline(file_id: str):
    """Symbol outlines are not extracted during indexing yet."""
    raise HTTPException(status_code=501, detail="File outline extraction is not implemented")