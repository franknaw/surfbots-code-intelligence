"""Change review orchestration.

Coverage is computed from what actually fit the generation context, never
reported by the model. A review that could not see the evidence must not be
able to claim the implementation is clean.
"""
from typing import Any, Optional
import logging
import re

from ..search_service import search_service
from .parsing import InvalidGenerationResponse, parse_with_retry
from .roles import get_role, new_budget, role_runner
from .checkpoint import persist_review_evidence

logger = logging.getLogger(__name__)

REVIEWER_SCHEMA = {
    "verdict": str,
    "summary": str,
    "findings": list,
    "tests_required": list,
}

FULL = "full"
PARTIAL = "partial"
UNABLE = "unable_to_review"

NO_ISSUES = "no_issues_found"
NEEDS_CHANGES = "needs_changes"
INCOMPLETE = "incomplete_review"

_CLEAN_VERDICTS = {"no_issues_found", "pass", "passed", "ok", "approved", "no_issues"}
_CHANGE_VERDICTS = {"needs_changes", "fail", "failed", "changes_required", "rejected", "reject"}

_DIFF_FILE = re.compile(r"^diff --git a/(?P<a>\S+) b/(?P<b>\S+)$", re.MULTILINE)

MAX_CONTEXT_SNIPPETS = 4
SNIPPET_CHARS = 800


class RepositoryNotFound(LookupError):
    """Raised when the requested repository is not registered."""


def split_diff_by_file(diff: str) -> dict[str, str]:
    """Split a unified diff into per-file sections.

    Per-file granularity is what makes partial coverage meaningful: omitted
    files can be named instead of the diff being cut mid-hunk.
    """
    matches = list(_DIFF_FILE.finditer(diff))
    if not matches:
        return {"(diff)": diff} if diff.strip() else {}

    sections: dict[str, str] = {}
    for index, match in enumerate(matches):
        start = match.start()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(diff)
        sections[match.group("b")] = diff[start:end]
    return sections


def _normalize_verdict(raw: str, has_findings: bool) -> Optional[str]:
    """Map model wording onto our vocabulary, biased toward not claiming clean."""
    value = (raw or "").strip().lower().replace("-", "_").replace(" ", "_")
    if value in _CLEAN_VERDICTS:
        return NO_ISSUES
    if value in _CHANGE_VERDICTS:
        return NEEDS_CHANGES
    # Unrecognised wording: trust findings if present, otherwise do not claim clean.
    return NEEDS_CHANGES if has_findings else None


async def _resolve(repository: str) -> tuple[str, dict[str, Any]]:
    status = await search_service.get_repository_status(repository)
    if "error" in status:
        raise RepositoryNotFound(f"Repository not found: {repository}")
    return status.get("repository_id") or repository, status


async def _current_code_for(repository_id: str, paths: list[str], budget) -> list[str]:
    """Pull current implementation for changed files when no diff was supplied."""
    sections = []
    for path in paths[:MAX_CONTEXT_SNIPPETS]:
        try:
            results = await search_service.search(
                query=path, repository_id=repository_id, file_path=path, limit=1
            )
        except Exception:
            logger.warning("Code retrieval failed during review", exc_info=True)
            continue
        for item in results.get("results", []):
            snippet = (item.get("chunk_content") or "")[:SNIPPET_CHARS]
            if not snippet:
                continue
            label = f"code:{item.get('file_path')}"
            if budget.offer(label, snippet):
                sections.append(f"Current code in {item.get('file_path')}:\n{snippet}")
    return sections


def _build_prompt(
    specification: str,
    diff_sections: dict[str, str],
    included_files: list[str],
    omitted_files: list[str],
    code_sections: list[str],
    test_results: Optional[str],
) -> str:
    parts = [f"Task specification:\n{specification}"]

    if test_results:
        parts.append(f"Test results:\n{test_results}")

    if included_files:
        body = "\n\n".join(diff_sections[name] for name in included_files if name in diff_sections)
        parts.append(f"Changes under review:\n\n{body}")

    if code_sections:
        parts.append("Current repository code:\n\n" + "\n\n".join(code_sections))

    if omitted_files:
        # Stated so the model does not treat absence of evidence as absence of defects.
        parts.append(
            "The following changed files were NOT provided and were not reviewed:\n"
            + "\n".join(f"- {name}" for name in omitted_files)
            + "\nDo not draw conclusions about these files."
        )

    return "\n\n".join(parts)


async def review_changes(
    repository: str,
    task_specification: str,
    diff: Optional[str] = None,
    changed_files: Optional[list[str]] = None,
    test_results: Optional[str] = None,
    development_task_id: Optional[str] = None,
) -> dict[str, Any]:
    """Review an implementation against its specification and current code."""
    repository_id, _ = await _resolve(repository)

    role = get_role("reviewer")
    budget = new_budget(role)

    # A review requires implementation evidence. Without a diff or changed-file
    # list, invoking the model would force it to speculate about work it has not
    # actually seen.
    has_diff = bool((diff or "").strip())
    has_changed_files = bool(changed_files)
    if not has_diff and not has_changed_files:
        return {
            "development_task_id": development_task_id,
            "repository_id": repository_id,
            "verdict": UNABLE,
            "summary": "No implementation changes were supplied for review.",
            "findings": [],
            "tests_required": [],
            "coverage": {
                "level": UNABLE,
                "reviewed_files": [],
                "omitted_files": [],
                "reason": "No diff or changed_files were supplied.",
            },
            "generation": {
                "role": role.name,
                "prompt_version": role.prompt_version,
                "invoked": False,
            },
        }

    # The specification is mandatory evidence; without it there is nothing to review against.
    if not budget.offer("task_specification", task_specification):
        return {
            "development_task_id": development_task_id,
            "repository_id": repository_id,
            "verdict": UNABLE,
            "summary": "The task specification alone exceeds the review context budget.",
            "findings": [],
            "tests_required": [],
            "coverage": {
                "level": UNABLE,
                "reviewed_files": [],
                "omitted_files": sorted(split_diff_by_file(diff or "")),
                "reason": "Task specification did not fit the generation context.",
            },
            "generation": {"role": role.name, "prompt_version": role.prompt_version, "invoked": False},
        }

    if test_results:
        budget.offer("test_results", test_results)

    diff_sections = split_diff_by_file(diff or "")
    included_files, omitted_files = [], []
    for name, section in diff_sections.items():
        if budget.offer(f"diff:{name}", section):
            included_files.append(name)
        else:
            omitted_files.append(name)

    code_sections: list[str] = []
    # Retrieve current code for changed files in both modes:
    # - When no diff (changed_files mode): current state only
    # - When diff supplied: also retrieve current state to compare changes
    files_to_retrieve = changed_files or list(diff_sections)
    if files_to_retrieve:
        code_sections = await _current_code_for(repository_id, files_to_retrieve, budget)

    if diff_sections and not included_files:
        return {
            "development_task_id": development_task_id,
            "repository_id": repository_id,
            "verdict": UNABLE,
            "summary": "No changed file fit the review context budget.",
            "findings": [],
            "tests_required": [],
            "coverage": {
                "level": UNABLE,
                "reviewed_files": [],
                "omitted_files": omitted_files,
                "reason": "Every supplied file exceeded the remaining context budget.",
            },
            "generation": {"role": role.name, "prompt_version": role.prompt_version, "invoked": False},
        }

    prompt = _build_prompt(
        task_specification, diff_sections, included_files, omitted_files, code_sections, test_results
    )

    async def call(correction):
        return await role_runner.run(role, prompt, repository_id=repository_id, correction=correction)

    review, raw = await parse_with_retry(call, REVIEWER_SCHEMA)

    findings = [f for f in review.get("findings", []) if isinstance(f, dict)]
    model_verdict = _normalize_verdict(review.get("verdict", ""), bool(findings))

    level = FULL if not omitted_files else PARTIAL
    reason = (
        "All supplied evidence fit the context budget."
        if level == FULL
        else f"{len(omitted_files)} changed file(s) did not fit the context budget."
    )

    # A review that did not see everything may report defects, but may never
    # report an unqualified clean result.
    if model_verdict is None:
        verdict = INCOMPLETE
    elif level == PARTIAL and model_verdict == NO_ISSUES:
        verdict = INCOMPLETE
    else:
        verdict = model_verdict

    return {
        "development_task_id": development_task_id,
        "repository_id": repository_id,
        "verdict": verdict,
        "summary": review.get("summary", ""),
        "findings": findings,
        "tests_required": review.get("tests_required", []),
        "coverage": {
            "level": level,
            "reviewed_files": included_files,
            "omitted_files": omitted_files,
            "reason": reason,
        },
        "generation": {
            "role": role.name,
            "prompt_version": role.prompt_version,
            "invoked": True,
            "duration_seconds": raw.get("duration_seconds"),
            "prompt_tokens": raw.get("prompt_tokens"),
            "completion_tokens": raw.get("completion_tokens"),
            "profile_id": (raw.get("runtime_execution") or {}).get("profile_id"),
            "provider": (raw.get("runtime_execution") or {}).get("provider"),
            "connection_id": (raw.get("runtime_execution") or {}).get("connection_id"),
            "model": (raw.get("runtime_execution") or {}).get("model"),
        },
    }
