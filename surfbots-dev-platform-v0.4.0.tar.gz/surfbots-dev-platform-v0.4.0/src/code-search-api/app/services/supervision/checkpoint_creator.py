"""Automatic creation of Development Memory checkpoints from supervision activities."""
import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

RECENT_MEMORY_LOOKUP_LIMIT = 20


class CheckpointCreator:
    """Creates repository-scoped Development Memory checkpoints automatically.
    
    Design principles:
    - development_task_id remains stable task identifier
    - Each checkpoint has unique session_id to prevent upsert
    - Use supersedes to link checkpoints for same task
    - Only create checkpoints for meaningful outcomes
    """

    def __init__(self, indexer_client: Any):
        """Initialize with an indexer client for memory operations."""
        self.indexer_client = indexer_client
        self._checkpoint_counters = {}  # Track checkpoint numbers per task

    async def create_from_refinement(
        self,
        repository_id: str,
        development_task_id: str,
        request: str,
        specification: dict[str, Any],
    ) -> Optional[dict[str, Any]]:
        """Create checkpoint after task refinement if meaningful."""
        if not self._is_meaningful_refinement(specification):
            return None

        session_id = self._generate_session_id(development_task_id)
        summary = self._build_summary("refinement", request, specification)
        
        checkpoint = {
            "session_id": session_id,
            "development_task_id": development_task_id,
            "summary": summary,
            "memory_type": "supervision_refinement",
            "retention_class": "transient",
            "decisions": self._extract_decisions(specification),
            "files_touched": self._extract_files(specification),
            "symbols_touched": self._extract_symbols(specification),
            "completed": self._extract_completed(specification),
            "unresolved": self._extract_unresolved(specification),
            "test_results": [],
            "supersedes": await self._previous_checkpoint_ids(
                repository_id, development_task_id, memory_type="supervision_refinement"
            ),
        }

        return await self._write_checkpoint(repository_id, checkpoint)

    async def create_from_collaboration(
        self,
        repository_id: str,
        development_task_id: str,
        task: str,
        question: str,
        recommendation: dict[str, Any],
    ) -> Optional[dict[str, Any]]:
        """Create checkpoint after collaboration if meaningful."""
        if not self._is_meaningful_collaboration(recommendation):
            return None

        session_id = self._generate_session_id(development_task_id)
        summary = self._build_summary("collaboration", question, recommendation)
        
        checkpoint = {
            "session_id": session_id,
            "development_task_id": development_task_id,
            "summary": summary,
            "memory_type": "supervision_collaboration",
            "retention_class": "transient",
            "decisions": [recommendation.get("decision", "")] if recommendation.get("decision") else [],
            "files_touched": [],
            "symbols_touched": [],
            "completed": [],
            "unresolved": recommendation.get("next_steps", []),
            "test_results": [],
            "supersedes": await self._previous_checkpoint_ids(
                repository_id, development_task_id, memory_type="supervision_collaboration"
            ),
        }

        return await self._write_checkpoint(repository_id, checkpoint)

    async def create_from_review(
        self,
        repository_id: str,
        development_task_id: str,
        review_result: dict[str, Any],
        changed_files: Optional[list[str]] = None,
    ) -> Optional[dict[str, Any]]:
        """Create checkpoint after review if meaningful."""
        if not self._is_meaningful_review(review_result):
            return None

        session_id = self._generate_session_id(development_task_id)
        summary = self._build_summary("review", review_result.get("verdict", ""), review_result)
        
        checkpoint = {
            "session_id": session_id,
            "development_task_id": development_task_id,
            "summary": summary,
            "memory_type": "supervision_review",
            "retention_class": "transient",
            "decisions": [],
            "files_touched": changed_files or [],
            "symbols_touched": [],
            "completed": self._extract_resolved_findings(review_result),
            "unresolved": self._extract_unresolved_findings(review_result),
            "test_results": [],
            "supersedes": await self._previous_checkpoint_ids(
                repository_id, development_task_id, memory_type="supervision_review"
            ),
            "evidence": {
                "review_evidence": review_result,
                "task_specification": {"task_specification": "Review completed"},
            },
        }

        return await self._write_checkpoint(repository_id, checkpoint)

    async def _previous_checkpoint_ids(
        self, repository_id: str, development_task_id: str, memory_type: str = None
    ) -> list[str]:
        # Return the newest prior checkpoint for this task in this repository.
        # If memory_type is specified, only return checkpoints of that type.
        try:
            result = await self.indexer_client.get_recent_session_memory(
                repository_id, limit=RECENT_MEMORY_LOOKUP_LIMIT
            )
            if result.get("error"):
                logger.warning("Previous checkpoint lookup failed for %s/%s: %s", repository_id, development_task_id, result.get("error"))
                return []
            
            # Filter for this task
            task_records = [r for r in result.get("records", []) 
                           if r.get("development_task_id") == development_task_id]
            
            # If memory_type specified, filter by type
            if memory_type:
                task_records = [r for r in task_records 
                               if r.get("memory_type") == memory_type]
            
            # Explicitly sort by created_at DESC to ensure we get the newest record
            # (the original _list returns sorted, but filtering might affect order)
            task_records = sorted(task_records, key=lambda r: r.get("created_at", ""), reverse=True)
            
            # Return the newest record's memory_id
            for record in task_records:
                memory_id = record.get("memory_id")
                if memory_id:
                    return [memory_id]
            return []
        except Exception:
            logger.warning("Previous checkpoint lookup failed for %s/%s", repository_id, development_task_id, exc_info=True)
            return []

    def _generate_session_id(self, development_task_id: str) -> str:
        """Generate unique session_id per checkpoint to prevent upsert."""
        counter = self._checkpoint_counters.get(development_task_id, 0) + 1
        self._checkpoint_counters[development_task_id] = counter
        return f"{development_task_id}_cp{counter}"

    async def _write_checkpoint(
        self, repository_id: str, checkpoint: dict[str, Any]
    ) -> Optional[dict[str, Any]]:
        """Write checkpoint and log result."""
        try:
            result = await self.indexer_client.create_session_memory(
                repository_id, checkpoint
            )
            if result.get("error"):
                logger.error(f"Checkpoint creation failed: {result.get('error')}")
                return None
            logger.info(f"Created checkpoint {checkpoint['session_id']} for {repository_id}")
            return result
        except Exception as e:
            logger.error(f"Exception in checkpoint creation: {e}")
            return None

    def _is_meaningful_refinement(self, spec: dict[str, Any]) -> bool:
        """Check if refinement has substance for checkpointing."""
        plan = spec.get("implementation_plan", [])
        return bool(plan and len(plan) > 0)

    def _is_meaningful_collaboration(self, rec: dict[str, Any]) -> bool:
        """Check if collaboration has substance for checkpointing."""
        return bool(rec.get("assessment") or rec.get("decision"))

    def _is_meaningful_review(self, review: dict[str, Any]) -> bool:
        """Check if review has substance for checkpointing."""
        return review.get("verdict") in ["no_issues_found", "needs_changes"]

    def _build_summary(self, operation: str, primary: str, details: dict[str, Any]) -> str:
        """Build concise summary from operation details."""
        if operation == "refinement":
            plan = details.get("implementation_plan", [])
            return f"Refined into {len(plan)} step(s). Focus: {details.get('focus', 'N/A')}"
        elif operation == "collaboration":
            return f"Collaborated on: {primary[:80]}... Decision: {details.get('decision', 'N/A')[:50]}"
        elif operation == "review":
            return f"Review verdict: {primary}. Findings: {len(details.get('findings', []))}"
        return f"{operation.capitalize()}: {primary[:100]}..."

    def _extract_decisions(self, spec: dict[str, Any]) -> list[str]:
        """Extract decisions from specification."""
        decisions = []
        if "architectural_decisions" in spec:
            decisions.extend(spec["architectural_decisions"])
        if "design_decisions" in spec:
            decisions.extend(spec["design_decisions"])
        return decisions[:20]

    def _extract_files(self, spec: dict[str, Any]) -> list[str]:
        """Extract file references from specification."""
        files = []
        if "files_to_change" in spec:
            files.extend(spec["files_to_change"])
        if "new_files" in spec:
            files.extend(spec["new_files"])
        return files[:100]

    def _extract_symbols(self, spec: dict[str, Any]) -> list[str]:
        """Extract symbol references from specification."""
        symbols = []
        if "symbols_to_change" in spec:
            symbols.extend(spec["symbols_to_change"])
        if "new_symbols" in spec:
            symbols.extend(spec["new_symbols"])
        return symbols[:100]

    def _extract_completed(self, spec: dict[str, Any]) -> list[str]:
        """Extract completed items from specification."""
        completed = []
        for item in spec.get("implementation_plan", []):
            if item.get("status") == "completed":
                completed.append(item.get("description", ""))
        return completed[:50]

    def _extract_unresolved(self, spec: dict[str, Any]) -> list[str]:
        """Extract unresolved items from specification."""
        unresolved = []
        for item in spec.get("implementation_plan", []):
            if item.get("status") in ["unresolved", "pending", "blocked"]:
                unresolved.append(item.get("description", ""))
        return unresolved[:50]

    def _extract_resolved_findings(self, review: dict[str, Any]) -> list[str]:
        """Extract resolved findings from review."""
        resolved = []
        for finding in review.get("findings", []):
            if isinstance(finding, dict) and finding.get("status") == "resolved":
                resolved.append(finding.get("description", ""))
        return resolved[:50]

    def _extract_unresolved_findings(self, review: dict[str, Any]) -> list[str]:
        """Extract unresolved findings from review."""
        unresolved = []
        for finding in review.get("findings", []):
            if isinstance(finding, dict) and finding.get("status") != "resolved":
                unresolved.append(finding.get("description", ""))
        return unresolved[:50]
