"""Service models for model API interactions."""
from pydantic import BaseModel
from typing import List, Optional


class EmbeddingRequest(BaseModel):
    """Request model for embedding generation."""
    text: str
    model: Optional[str] = None


class EmbeddingResponse(BaseModel):
    """Response model for embedding generation."""
    embedding: List[float]
    dimensions: int
    model: Optional[str] = None


class EmbeddingsBatchRequest(BaseModel):
    """Request model for batch embedding generation."""
    texts: List[str]
    model: Optional[str] = None


class EmbeddingsBatchResponse(BaseModel):
    """Response model for batch embedding generation."""
    embeddings: List[List[float]]
    dimensions: int
    model: Optional[str] = None


class RerankRequest(BaseModel):
    """Request model for reranking."""
    query: str
    documents: List[str]
    top_n: Optional[int] = None
    model: Optional[str] = None


class RerankDocument(BaseModel):
    """Reranked document result."""
    document: str
    score: float
    index: int


class RerankResponse(BaseModel):
    """Response model for reranking."""
    results: List[RerankDocument]
    model: Optional[str] = None