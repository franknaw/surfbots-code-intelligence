"""Indexing job endpoints."""
from fastapi import APIRouter, HTTPException, BackgroundTasks
from typing import List, Optional, Dict, Any
from uuid import uuid4
import logging

from ..core.database import get_qdrant_client
from ..core.repositories import get_repository as _get_repository
from ..services import CodeIndexer

logger = logging.getLogger(__name__)
router = APIRouter()

# In-memory storage for indexing jobs
index_jobs: dict = {}


@router.post("/api/v1/indexes")
async def create_index_job(
    repository_id: str,
    job_type: str = "full",
    force: bool = False,
    background_tasks: BackgroundTasks = None
):
    """Start an indexing job."""
    job_id = f"job_{uuid4().hex[:12]}"

    index_jobs[job_id] = {
        "job_id": job_id,
        "repository_id": repository_id,
        "job_type": job_type,
        "status": "pending",
        "progress": 0.0,
        "started_at": None,
        "completed_at": None
    }

    background_tasks.add_task(_run_index_job, job_id)

    return index_jobs[job_id]


@router.get("/api/v1/indexes/{job_id}", response_model=dict)
async def get_index_job(job_id: str):
    """Get indexing job status."""
    if job_id not in index_jobs:
        raise HTTPException(status_code=404, detail="Job not found")

    return index_jobs[job_id]


async def _run_index_job(job_id: str):
    """Background task to run an indexing job."""
    try:
        job = index_jobs[job_id]
        job["status"] = "running"
        job["started_at"] = "2026-08-28T12:00:00Z"

        # Get repository info from shared repositories dict
        repo_id = job.get("repository_id")
        repo = _get_repository(repo_id)
        
        if not repo:
            raise HTTPException(status_code=404, detail="Repository not found")
        
        indexer = CodeIndexer()
        source = repo.get("source", {})
        branch = repo.get("branch", "main")

        result = await indexer.index_repository(repo_id, source, branch)

        job.update({
            "status": "completed",
            "progress": 100.0,
            "completed_at": "2026-08-28T12:00:00Z",
            "files_indexed": result.get("files_indexed", 0),
            "chunks_created": result.get("chunks_created", 0)
        })
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Index job {job_id} failed: {e}")
        import traceback
        traceback.print_exc()
        index_jobs[job_id].update({
            "status": "failed",
            "error_message": str(e),
            "completed_at": "2026-08-28T12:00:00Z"
        })
