# Surfbots Dev Platform Bootstrap Validation Harness

This directory contains a validation harness for testing the Surfbots Dev Platform public bootstrap/release-artifact installation path.

## Overview

The validation harness (`validate_bootstrap.py`) tests that a downloadable standalone release behaves the same as the locally installed runtime and contains all required bundled client assets.

## Prerequisites

- Python 3.8+
- `curl` (for downloading releases)
- `sha256sum` (Linux) or `shasum` (macOS) for checksum verification
- `git` (for testing repository provisioning)

## What It Validates

### A. Installation
- Public bootstrap or release artifact installs successfully
- Resulting `surfbots-dev` launcher/binary exists
- Installed runtime is under the expected XDG/local data path

### B. Source-checkout independence
- The installed CLI can run when the surfbots-dev-platform source checkout is unavailable
- `surfbots-dev --help` succeeds without importing/executing files from the source checkout

### C. Bundled client assets
Installed runtime contains:
- `.clinerules/surfbots-code-search.md`
- `.clinerules/surfbots-development-context.md`
- `.clinerules/surfbots-development-supervision.md`
- `.clinerules/skills/surfbots-development-context/SKILL.md`
- `.github/instructions/surfbots-development-context.instructions.md`
- `.github/skills/surfbots-development-context/SKILL.md`
- `.github/skills/surfbots-development-context/scripts/build_context.py`

### D. Repository provisioning
- Create a disposable git repository
- Run installed `surfbots-dev repo add <repo>`
- Confirm Cline/Copilot assets are copied into the repository
- Verify copied hashes match the installed bundled assets

### E. Repository lifecycle
If the platform services are available:
- Repository registration succeeds
- Managed snapshot is created
- Indexing is triggered
- Status can be queried
- Repository can be removed afterward

If services are unavailable:
- Asset and installation validation should still be testable
- Clearly report integration steps as skipped rather than failed

## Usage

### Test a local release artifact

```bash
python validate_bootstrap.py --file /path/to/surfbots-dev-platform-v0.2.0.tar.gz
```

### Test the public bootstrap URL

```bash
python validate_bootstrap.py --url https://releases.surfbots.ai/v0.2.0
```

### Disable platform services tests (for CI environments)

```bash
python validate_bootstrap.py --url https://releases.surfbots.ai/v0.2.0 --no-services
```

### Enable verbose output

```bash
python validate_bootstrap.py --url https://releases.surfbots.ai/v0.2.0 --verbose
```

## Expected Output

```
[INFO] === Starting Validation Harness ===

[INFO] Downloading release from https://releases.surfbots.ai/v0.2.0
[INFO] Downloading surfbots-dev-linux-amd64...
[SUCCESS] Downloaded: /tmp/surfbots-download-xxx/surfbots-dev-linux-amd64
[INFO] Extracting release artifact: /tmp/surfbots-download-xxx/surfbots-dev-linux-amd64
[SUCCESS] Extracted to: /tmp/surfbots-extract-xxx/surfbots-dev-platform-v0.2.0
[INFO] Verifying bundled assets in release...
[SUCCESS] All 8 bundled assets present in release
[INFO] Installing release...
[SUCCESS] Copied repo-bootstrap: /tmp/surfbots-install-xxx/.local/share/surfbots-dev-platform/cli/repo-bootstrap
[SUCCESS] Created virtual environment: /tmp/surfbots-install-xxx/.local/share/surfbots-dev-platform/cli/venv
[SUCCESS] Installed launcher: /tmp/surfbots-install-xxx/.local/bin/surfbots-dev
[SUCCESS] Installed runtime: /tmp/surfbots-install-xxx/.local/share/surfbots-dev-platform/cli
[SUCCESS] Launcher exists and is executable: /tmp/surfbots-install-xxx/.local/bin/surfbots-dev
[SUCCESS] CLI is self-contained (no source checkout dependency)
[SUCCESS] --help works and shows available commands
[INFO] Verifying installed assets...
[SUCCESS] All 8 installed assets present
[INFO] Comparing asset hashes...
[SUCCESS] All 8 assets have matching hashes
[INFO] Creating test repository...
[SUCCESS] Created test repository: /tmp/surfbots-repo-xxx
[INFO] Running repo add...
[SUCCESS] repo add successfully provisioned Cline and Copilot assets
[INFO] Verifying provisioned asset hashes...
[SUCCESS] All 8 provisioned assets match installed runtime
[INFO] Cleaning up...
[SUCCESS] Cleanup complete

=== Validation Summary ===
Passed: 8/8
Failed: 0/8

  launcher_exists: PASS
  self_contained: PASS
  help_available: PASS
  verify_installed_assets: PASS
  compare_asset_hashes: PASS
  repo_add: PASS
  repo_asset_hashes: PASS
```

## Integration Checks

### Tests that require running platform services

- `repo_add` - Tests that the installed CLI can register a repository with the platform
- `repo_asset_hashes` - Verifies that provisioned assets match the installed runtime
- `repo_remove` - Tests that a repository can be removed from the platform

These tests are automatically skipped if `--no-services` is specified or if the platform services are not available.

## Cleanup

The harness automatically cleans up:
- Temporary directories created for download and extraction
- Test repositories created during testing
- Installed runtime directories

It does **NOT** delete:
- The user's real `~/.local/share/surfbots-dev-platform` installation
- The primary repository except through normal test execution

## Integration with CI/CD

Add this to your CI workflow:

```yaml
- name: Validate release artifact
  run: |
    python tooling/repo-bootstrap/test-harness/validate_bootstrap.py \
      --url https://releases.surfbots.ai/${{ env.VERSION }} \
      --no-services
```

For full integration testing:

```yaml
- name: Start platform services
  run: ./surfbots-admin.sh start

- name: Validate release artifact
  run: |
    python tooling/repo-bootstrap/test-harness/validate_bootstrap.py \
      --url https://releases.surfbots.ai/${{ env.VERSION }}
```

## Troubleshooting

### Checksum verification failed

This indicates the downloaded artifact is corrupted or the release was not built correctly. Verify:

1. The release artifact is correctly signed with SHA256SUMS
2. The download completed without corruption
3. The release was built from a clean working tree

### Launcher depends on source checkout

The release artifact should be self-contained. This failure indicates:

1. The release was not built from a clean `tooling/repo-bootstrap/` directory
2. The launcher script was not properly embedded
3. The virtual environment was not properly created

### Missing bundled assets

The release artifact must include all bundled client assets. This failure indicates:

1. The release packaging script is missing some assets
2. The asset paths in the release manifest are incorrect
3. The release was built from a partial source tree

## Files

- `validate_bootstrap.py` - Main validation harness
- `README.md` - This documentation

## License

Same as the main Surfbots Dev Platform repository.
