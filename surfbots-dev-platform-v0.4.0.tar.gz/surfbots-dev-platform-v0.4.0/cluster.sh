#!/bin/bash
# surfbots-dev-platform Cluster Management Script
# Usage: ./cluster.sh {create|destroy|status|deploy|undeploy|test|build|redeploy|rebuild|restart}

set -e

# Set user and group IDs for file permissions
SURFBOTS_UID="${SURFBOTS_UID:-$(id -u)}"
SURFBOTS_GID="${SURFBOTS_GID:-$(id -g)}"

# Authoritative cluster configuration - DO NOT CHANGE
CLUSTER_NAME="surfbots-dev-platform"
KUBE_CONTEXT="k3d-${CLUSTER_NAME}"
NAMESPACE="surfbots-dev-platform"
REGISTRY_NAME="surfbots-dev-platform-registry"
HOST_REGISTRY="${SURFBOTS_HOST_REGISTRY:-localhost:5000}"
CLUSTER_REGISTRY="${SURFBOTS_CLUSTER_REGISTRY:-k3d-${REGISTRY_NAME}:5000}"

# XDG Data Home - standard location for user data
XDG_DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"

# Surfbots data directory (parent for all platform data)
SURFBOTS_DATA_HOME="${XDG_DATA_HOME}/surfbots-dev-platform"
BUILD_RECORD_DIR="${SURFBOTS_DATA_HOME}/builds"

# File share base directory for persistence
# This is the host path mounted into k3d nodes
FILE_SHARE_BASE="${FILE_SHARE_BASE:-$SURFBOTS_DATA_HOME}"

# Repository storage directory (shared parent for all repositories)
REPOS_SHARE_BASE="${REPOS_SHARE_BASE:-$FILE_SHARE_BASE/repos}"
PROFILE_CONFIG="${XDG_CONFIG_HOME}/surfbots-dev-platform/inference-profile.env"

log_info() { echo -e "[INFO] $1"; }
log_warn() { echo -e "[WARN] $1"; }
log_error() { echo -e "[ERROR] $1"; }
log_success() { echo -e "[SUCCESS] $1"; }

# kubectl wrapper - explicitly uses Dev Platform context
kctl() {
    kubectl --context "${KUBE_CONTEXT}" --namespace "${NAMESPACE}" "$@"
}

# Check if the expected cluster exists (exact match)
cluster_exists() {
    k3d cluster list --no-headers 2>/dev/null | awk '{print $1}' | grep -Fxq "${CLUSTER_NAME}"
}

# Check if the expected context exists
context_exists() {
    kubectl config get-contexts -o name 2>/dev/null | grep -Fxq "${KUBE_CONTEXT}"
}

# Registry verification helper - check exact repo:tag exists via HTTP API
# Uses HOST_REGISTRY (localhost:5000) to query the registry
# Arguments: $1 = image tag, $2 = service name
verify_registry_image() {
    local tag="$1"
    local service="$2"
    local repo="surfbots/${service}"
    local url="http://${HOST_REGISTRY}/v2/${repo}/manifests/${tag}"
    
    # Use Accept header that supports both Docker and OCI formats
    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" \
        -H "Accept: application/vnd.oci.image.index.v1+json, application/vnd.docker.distribution.manifest.list.v2+json, application/vnd.oci.image.manifest.v1+json, application/vnd.docker.distribution.manifest.v2+json" \
        "${url}" 2>/dev/null) || {
        log_error "Registry verification failed for ${service}:${tag}: unable to reach registry"
        return 1
    }
    
    if [[ "${http_code}" == "200" ]]; then
        return 0
    elif [[ "${http_code}" == "404" ]]; then
        log_error "Registry image not found: ${service}:${tag} (HTTP ${http_code})"
        return 1
    else
        log_error "Registry verification failed for ${service}:${tag}: HTTP ${http_code}"
        return 1
    fi
}

# Split cluster image into repository and tag
# Input: k3d-surfbots-dev-platform-registry:5000/surfbots/<service>:<tag>
# Output: repository: k3d-surfbots-dev-platform-registry:5000/surfbots/<service>
#         tag: <tag>
# Writes to global variables: SPLIT_IMAGE_REPO, SPLIT_IMAGE_TAG
split_cluster_image() {
    local cluster_image="$1"
    # Remove the tag portion (everything after the last colon)
    SPLIT_IMAGE_REPO="${cluster_image%:*}"
    # Extract the tag (everything after the last colon in original)
    SPLIT_IMAGE_TAG="${cluster_image##*:}"
}

# Helper to construct registry verification URL from cluster image
get_registry_verification_url() {
    local cluster_image="$1"
    local service="$2"
    # Extract tag from cluster image
    local tag="${cluster_image##*:}"
    # Return URL using host registry
    echo "http://${HOST_REGISTRY}/v2/surfbots/${service}/manifests/${tag}"
}

resolve_local_generation_profile() {
    local configured="${SURFBOTS_INFERENCE_PROFILE:-}"
    if [[ -z "$configured" && -f "$PROFILE_CONFIG" ]]; then
        # shellcheck disable=SC1090
        source "$PROFILE_CONFIG"
        configured="${SURFBOTS_INFERENCE_PROFILE:-}"
    fi
    LOCAL_GENERATION_PROFILE="${configured:-local-lightweight}"
    case "$LOCAL_GENERATION_PROFILE" in
        local-lightweight|local-quality) ;;
        *) log_error "Unsupported local generation profile: $LOCAL_GENERATION_PROFILE"; return 1 ;;
    esac
    export SURFBOTS_INFERENCE_PROFILE="$LOCAL_GENERATION_PROFILE"
}

generation_profile_values() {
    case "$LOCAL_GENERATION_PROFILE" in
        local-lightweight) echo "./helm/model-generation/values-local.yaml" ;;
        local-quality) echo "./helm/model-generation/values-local-quality.yaml" ;;
    esac
}

deploy_generation() {
    resolve_local_generation_profile
    log_info "Deploying model-generation service with ${LOCAL_GENERATION_PROFILE}..."
    helm upgrade --install model-generation ./helm/model-generation \
        --namespace ${NAMESPACE} -f ./helm/model-generation/values-local.yaml \
        -f "$(generation_profile_values)" --wait
}

# Setup file shares for persistence across cluster restarts
setup_file_shares() {
    log_info "Setting up file shares for persistence..."
    
    # Get the absolute path for the volume mount
    CLUSTER_BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    ABS_FILE_SHARE_BASE="${FILE_SHARE_BASE}"
    if [[ "${FILE_SHARE_BASE}" != /* ]]; then
        ABS_FILE_SHARE_BASE="${CLUSTER_BASE_DIR}/${FILE_SHARE_BASE}"
    fi
    
    # Create local directories for data persistence
    mkdir -p "${ABS_FILE_SHARE_BASE}/qdrant"
    mkdir -p "${ABS_FILE_SHARE_BASE}/code-indexer/repos"
    mkdir -p "${ABS_FILE_SHARE_BASE}/code-search-api"
    mkdir -p "${ABS_FILE_SHARE_BASE}/mcp-server"
    mkdir -p "${ABS_FILE_SHARE_BASE}/data"
    mkdir -p "${ABS_FILE_SHARE_BASE}/repos"  # Shared parent for all repositories
    
    # Set permissions
    chmod 755 "${ABS_FILE_SHARE_BASE}"
    chmod 755 "${ABS_FILE_SHARE_BASE}/qdrant"
    chmod 755 "${ABS_FILE_SHARE_BASE}/code-indexer"
    chmod 755 "${ABS_FILE_SHARE_BASE}/code-indexer/repos"
    chmod 755 "${ABS_FILE_SHARE_BASE}/code-search-api"
    chmod 755 "${ABS_FILE_SHARE_BASE}/mcp-server"
    chmod 755 "${ABS_FILE_SHARE_BASE}/data"
    chmod 755 "${ABS_FILE_SHARE_BASE}/repos"
    
    log_info "File shares created at ${ABS_FILE_SHARE_BASE}/"
    log_info "  - Qdrant: ${ABS_FILE_SHARE_BASE}/qdrant"
    log_info "  - Code Indexer: ${ABS_FILE_SHARE_BASE}/code-indexer"
    log_info "  - Code Search API: ${ABS_FILE_SHARE_BASE}/code-search-api"
    log_info "  - MCP Server: ${ABS_FILE_SHARE_BASE}/mcp-server"
    log_info "  - Repositories: ${ABS_FILE_SHARE_BASE}/repos (shared parent)"
}

create_cluster() {
    # Check if expected cluster exists
    if cluster_exists; then
        log_error "Cluster ${CLUSTER_NAME} already exists"
        log_info "To destroy: ./cluster.sh destroy"
        exit 1
    fi

    # Check if a conflicting cluster exists
    local existing=$(k3d cluster list --no-headers 2>/dev/null | awk '{print $1}' | grep -E "^surfbots" || true)
    if [ -n "$existing" ]; then
        log_error "Conflicting cluster(s) exist: $existing"
        log_error "Expected cluster: ${CLUSTER_NAME}"
        log_error "Destroy conflicting clusters before creating the expected cluster"
        exit 1
    fi

    log_info "Creating k3d cluster: ${CLUSTER_NAME}"
    
    # Get the absolute path for the volume mount
    CLUSTER_BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    ABS_FILE_SHARE_BASE="${FILE_SHARE_BASE}"
    if [[ "${FILE_SHARE_BASE}" != /* ]]; then
        ABS_FILE_SHARE_BASE="${CLUSTER_BASE_DIR}/${FILE_SHARE_BASE}"
    fi
    # Create runtime directories for data persistence
    mkdir -p "${ABS_FILE_SHARE_BASE}/qdrant"
    mkdir -p "${ABS_FILE_SHARE_BASE}/code-indexer/repos"
    mkdir -p "${ABS_FILE_SHARE_BASE}/code-search-api"
    mkdir -p "${ABS_FILE_SHARE_BASE}/mcp-server"
    mkdir -p "${ABS_FILE_SHARE_BASE}/data"
    mkdir -p "${ABS_FILE_SHARE_BASE}/repos"  # Shared parent for all repositories
    
    # Set permissions
    chmod 755 "${ABS_FILE_SHARE_BASE}"
    chmod 755 "${ABS_FILE_SHARE_BASE}/qdrant"
    chmod 755 "${ABS_FILE_SHARE_BASE}/code-indexer"
    chmod 755 "${ABS_FILE_SHARE_BASE}/code-indexer/repos"
    chmod 755 "${ABS_FILE_SHARE_BASE}/code-search-api"
    chmod 755 "${ABS_FILE_SHARE_BASE}/mcp-server"
    chmod 755 "${ABS_FILE_SHARE_BASE}/data"
    chmod 755 "${ABS_FILE_SHARE_BASE}/repos"
    
    # Ensure the dedicated local registry exists before creating the cluster.
    if ! k3d registry list --no-headers 2>/dev/null | awk '{print $1}' | grep -Fxq "k3d-${REGISTRY_NAME}"; then
        log_info "Creating registry: ${REGISTRY_NAME} on host port 5000"
        k3d registry create "${REGISTRY_NAME}" --port 5000
    fi

    # Create cluster with the registry wired in from the beginning.
    # Use --k3s-arg to disable cpushare checks (required for rootless environments where cpuset is not delegated)
    # This allows k3s to run in environments without cpuset controller access
    k3d cluster create "${CLUSTER_NAME}" \
        --registry-use "${CLUSTER_REGISTRY}" \
        --network k3d-surfbots-dev-platform \
        --port "8081:80@loadbalancer" \
        --port "8444:443@loadbalancer" \
        --volume "${ABS_FILE_SHARE_BASE}:/mnt/surfbots@all" \
        --k3s-arg "--disable=cpuset-cgroups@server:*"
    # Setup file shares after cluster creation
    setup_file_shares
    
    log_info "Cluster created successfully"
    log_info "File shares created at ${ABS_FILE_SHARE_BASE}/"
    log_info "  - Qdrant: ${ABS_FILE_SHARE_BASE}/qdrant"
    log_info "  - Code Indexer: ${ABS_FILE_SHARE_BASE}/code-indexer"
    log_info "  - Code Search API: ${ABS_FILE_SHARE_BASE}/code-search-api"
    log_info "  - MCP Server: ${ABS_FILE_SHARE_BASE}/mcp-server"
}

destroy_cluster() {
    # Check if cluster exists (exact match)
    if ! cluster_exists; then
        log_warn "Cluster ${CLUSTER_NAME} does not exist"
        exit 0
    fi
    log_warn "Destroying k3d cluster: ${CLUSTER_NAME}"
    k3d cluster delete ${CLUSTER_NAME}
    log_info "Cluster destroyed successfully"
}

show_status() {
    log_info "=== Cluster Status ==="
    
    # Check cluster
    if cluster_exists; then
        log_success "Cluster: ${CLUSTER_NAME} - Running"
    else
        log_error "Cluster: ${CLUSTER_NAME} - Missing"
    fi
    
    # Check context
    if context_exists; then
        log_success "Context: ${KUBE_CONTEXT} - Available"
    else
        log_error "Context: ${KUBE_CONTEXT} - Missing"
    fi
    
    # Check namespace
    if kctl get namespace "${NAMESPACE}" >/dev/null 2>&1; then
        log_success "Namespace: ${NAMESPACE} - Active"
    else
        log_error "Namespace: ${NAMESPACE} - Missing"
    fi
    
    # Check deployments
    log_info ""
    log_info "=== Deployments ==="
    kctl get deployments 2>/dev/null || log_error "No deployments found"
    
    # Check pods
    log_info ""
    log_info "=== Pods ==="
    kctl get pods 2>/dev/null || log_error "No pods found"
    
    # Check services
    log_info ""
    log_info "=== Services ==="
    kctl get services 2>/dev/null || log_error "No services found"
    
    log_info ""
    log_info "File Shares:"
    
    # Get the absolute path for the volume mount
    CLUSTER_BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    ABS_FILE_SHARE_BASE="${FILE_SHARE_BASE}"
    if [[ "${FILE_SHARE_BASE}" != /* ]]; then
        ABS_FILE_SHARE_BASE="${CLUSTER_BASE_DIR}/${FILE_SHARE_BASE}"
    fi
    
    if [ -d "${ABS_FILE_SHARE_BASE}" ]; then
        log_info "  Location: ${ABS_FILE_SHARE_BASE}"
        log_info "  Contents:"
        ls -la "${ABS_FILE_SHARE_BASE}/" 2>/dev/null | sed 's/^/    /' || echo "    (empty)"
    else
        log_info "  ${ABS_FILE_SHARE_BASE} - not created yet"
    fi
}

deploy_services() {
    log_info "Deploying services..."
    resolve_local_generation_profile
    log_info "Local generation profile: ${LOCAL_GENERATION_PROFILE}"

    # A clean deployment must use exact previously-built immutable images.
    require_all_build_records
    
    # Use kubectl wrapper for explicit context
    kctl create namespace "${NAMESPACE}" --dry-run=client -o yaml | kctl apply -f -
    
    # Setup file shares
    setup_file_shares
    
    helm repo add qdrant https://qdrant.github.io/qdrant-helm 2>/dev/null || true
    helm repo update 2>/dev/null || true
    
    # Deploy Qdrant with persistent storage
    # Repositories share the code-index collection and are isolated by repository_id.
    helm upgrade --install qdrant qdrant/qdrant \
        --namespace ${NAMESPACE} \
        --set persistence.enabled=true \
        --set persistence.size=10Gi \
        --set resources.limits.cpu=2 \
        --set resources.limits.memory=4Gi \
        --set extraEnv[0].name=QDRANT__STORAGE__PERSISTENCE_PATH \
        --set extraEnv[0].value=/var/lib/qdrant \
        --set extraEnv[1].name=QDRANT__STORAGE__SNAPSHOTS_PATH \
        --set extraEnv[1].value=/var/lib/qdrant/snapshots \
        --wait
    # Use kubectl wrapper for explicit context
    kctl create configmap code-indexer-config \
        --from-literal=config.yaml='qdrantUrl: "http://qdrant:6333"' \
        --dry-run=client -o yaml | kctl apply -f -
    
    # Install/update the local charts with the exact immutable images from recorded builds.
    # The recorded image is in cluster format (k3d-registry:5000/surfbots/<service>:<tag>)
    # We pass repository and tag separately to Helm.
    
    # code-indexer
    local code_indexer_image code_indexer_repo code_indexer_tag
    code_indexer_image="$(read_recorded_image code-indexer)"
    code_indexer_repo="${code_indexer_image%:*}"
    code_indexer_tag="${code_indexer_image##*:}"
    helm upgrade --install code-indexer ./helm/code-indexer \
        --namespace ${NAMESPACE} -f ./helm/code-indexer/values-cluster.yaml \
        --set image.repository="${code_indexer_repo}" \
        --set image.tag="${code_indexer_tag}" \
        --set securityContext.runAsUser="${SURFBOTS_UID}" \
        --set securityContext.runAsGroup="${SURFBOTS_GID}"

    # code-search-api
    local code_search_api_image code_search_api_repo code_search_api_tag
    code_search_api_image="$(read_recorded_image code-search-api)"
    code_search_api_repo="${code_search_api_image%:*}"
    code_search_api_tag="${code_search_api_image##*:}"
    helm upgrade --install code-search-api ./helm/code-search-api \
        --namespace ${NAMESPACE} -f ./helm/code-search-api/values-local.yaml \
        --set image.repository="${code_search_api_repo}" \
        --set image.tag="${code_search_api_tag}" \
        --set modelProfiles.localGenerationProfile="${LOCAL_GENERATION_PROFILE}" \
        --set securityContext.runAsUser="${SURFBOTS_UID}" \
        --set securityContext.runAsGroup="${SURFBOTS_GID}"

    # mcp-server
    local mcp_server_image mcp_server_repo mcp_server_tag
    mcp_server_image="$(read_recorded_image mcp-server)"
    mcp_server_repo="${mcp_server_image%:*}"
    mcp_server_tag="${mcp_server_image##*:}"
    helm upgrade --install mcp-server ./helm/mcp-server \
        --namespace ${NAMESPACE} -f ./helm/mcp-server/values-local.yaml \
        --set image.repository="${mcp_server_repo}" \
        --set image.tag="${mcp_server_tag}" \
        --set securityContext.runAsUser="${SURFBOTS_UID}" \
        --set securityContext.runAsGroup="${SURFBOTS_GID}"

    # Deploy model services. Generation is upstream; embedding/reranker are local immutable builds.
    log_info "Deploying model-embedding service..."
    local model_embedding_image model_embedding_repo model_embedding_tag
    model_embedding_image="$(read_recorded_image model-embedding)"
    model_embedding_repo="${model_embedding_image%:*}"
    model_embedding_tag="${model_embedding_image##*:}"
    helm upgrade --install model-embedding ./helm/model-embedding \
        --namespace ${NAMESPACE} -f ./helm/model-embedding/values-local.yaml \
        --set image.repository="${model_embedding_repo}" \
        --set image.tag="${model_embedding_tag}"

    deploy_generation

    log_info "Deploying model-reranker service..."
    local model_reranker_image model_reranker_repo model_reranker_tag
    model_reranker_image="$(read_recorded_image model-reranker)"
    model_reranker_repo="${model_reranker_image%:*}"
    model_reranker_tag="${model_reranker_image##*:}"
    helm upgrade --install model-reranker ./helm/model-reranker \
        --namespace ${NAMESPACE} -f ./helm/model-reranker/values-local.yaml \
        --set image.repository="${model_reranker_repo}" \
        --set image.tag="${model_reranker_tag}"
    
    log_info "All services deployed successfully"
}

undeploy_services() {
    log_warn "Undeploying services..."
    
    # Undeploy model services first
    log_info "Undeploying model-reranker service..."
    helm uninstall model-reranker -n ${NAMESPACE} 2>/dev/null || true
    
    log_info "Undeploying model-generation service..."
    helm uninstall model-generation -n ${NAMESPACE} 2>/dev/null || true
    
    log_info "Undeploying model-embedding service..."
    helm uninstall model-embedding -n ${NAMESPACE} 2>/dev/null || true
    
    # Undeploy other services
    helm uninstall mcp-server -n ${NAMESPACE} 2>/dev/null || true
    helm uninstall code-search-api -n ${NAMESPACE} 2>/dev/null || true
    helm uninstall code-indexer -n ${NAMESPACE} 2>/dev/null || true
    helm uninstall qdrant -n ${NAMESPACE} 2>/dev/null || true
    
    log_info "Services undeployed successfully"
    
    # Get the absolute path for the volume mount
    CLUSTER_BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    ABS_FILE_SHARE_BASE="${FILE_SHARE_BASE}"
    if [[ "${FILE_SHARE_BASE}" != /* ]]; then
        ABS_FILE_SHARE_BASE="${CLUSTER_BASE_DIR}/${FILE_SHARE_BASE}"
    fi
    
    log_info "Note: File shares at ${ABS_FILE_SHARE_BASE} are preserved for persistence"
    log_info "Run 'rm -rf ${ABS_FILE_SHARE_BASE}' to completely clean up data"
}

run_tests() {
    log_info "Running in-cluster health checks..."
    local failed=0
    # service:port:health-path
    local targets="code-indexer:8000:/health code-search-api:8000:/health/ready mcp-server:8003:/health qdrant:6333:/readyz model-embedding:8001:/health model-generation:8000:/health model-reranker:8002:/health"

    for target in ${targets}; do
        local svc="${target%%:*}"
        local rest="${target#*:}"
        local port="${rest%%:*}"
        local path="${rest#*:}"
        local name="${svc}"

        if kctl run "healthcheck-$$-${name}" --rm -i --restart=Never \
            --image=curlimages/curl:latest --quiet -- \
            curl -sf --max-time 10 "http://${svc}:${port}${path}" >/dev/null 2>&1; then
            log_info "  ${name}: OK"
        else
            log_error "  ${name}: FAILED (http://${svc}:${port}${path})"
            failed=$((failed + 1))
        fi
    done

    if [ ${failed} -gt 0 ]; then
        log_error "${failed} service(s) unhealthy"
        return 1
    fi
    log_info "All services healthy"
}

# Local image services. model-generation intentionally uses an upstream llama.cpp image.
LOCAL_IMAGE_SERVICES="code-indexer code-search-api mcp-server model-embedding model-reranker"

service_build_context() {
    case "$1" in
        code-indexer) echo "src/indexer" ;;
        code-search-api) echo "src/code-search-api" ;;
        mcp-server) echo "src/mcp-server" ;;
        model-embedding) echo "src/model-embedding" ;;
        model-reranker) echo "src/model-reranker" ;;
        model-generation)
            log_error "model-generation is not locally built; it uses ghcr.io/ggml-org/llama.cpp:server"
            return 2
            ;;
        *)
            log_error "Unknown service: $1"
            return 2
            ;;
    esac
}

service_container_name() {
    case "$1" in
        code-indexer) echo "code-indexer" ;;
        code-search-api) echo "code-search-api" ;;
        mcp-server) echo "mcp-server" ;;
        model-embedding) echo "embedding-server" ;;
        model-reranker) echo "reranker-server" ;;
        model-generation) echo "model-generation" ;;
        *) return 2 ;;
    esac
}

build_record_file() {
    echo "${BUILD_RECORD_DIR}/$1.latest"
}

record_built_image() {
    local service="$1" image="$2"
    mkdir -p "${BUILD_RECORD_DIR}"
    printf '%s\n' "${image}" > "$(build_record_file "${service}")"
}

read_recorded_image() {
    local service="$1" file
    file="$(build_record_file "${service}")"
    if [[ ! -s "${file}" ]]; then
        log_error "No recorded image for ${service}: ${file}"
        log_info "Run: $0 build ${service}"
        return 1
    fi
    head -n 1 "${file}"
}

require_all_build_records() {
    local svc image tag missing=0 invalid=0
    for svc in ${LOCAL_IMAGE_SERVICES}; do
        local file
        file="$(build_record_file "${svc}")"
        if [[ ! -s "${file}" ]]; then
            log_error "Missing immutable build record for ${svc}: ${file}"
            missing=1
            continue
        fi
        
        # Read and verify the recorded image exists in registry
        image="$(read_recorded_image "${svc}")" || {
            invalid=1
            continue
        }
        
        # Extract tag from cluster image (last colon-separated part)
        tag="${image##*:}"
        
        if ! verify_registry_image "${tag}" "${svc}"; then
            log_error "Recorded image invalid for ${svc}:"
            log_error "  ${image}"
            log_error "  (tag ${tag} not found in registry)"
            invalid=1
        fi
    done
    
    if [[ "${missing}" -ne 0 ]] || [[ "${invalid}" -ne 0 ]]; then
        log_error ""
        log_error "Build local services before deploy: $0 build all"
        log_error ""
        log_error "Invalid records will be rejected during deployment."
        return 1
    fi
}

make_build_tag() {
    local stamp sha
    stamp="$(date -u +%Y%m%d%H%M%S)"
    sha="$(git -C "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" rev-parse --short HEAD 2>/dev/null || echo nogit)"
    printf '%s-%s\n' "${stamp}" "${sha}"
}

# Build and push one immutable local image, then record the exact cluster-visible reference.
build_one_image() {
    local service="$1" context dockerfile tag host_image cluster_image
    context="$(service_build_context "${service}")" || return $?
    dockerfile="${context}/Dockerfile"

    if [[ ! -f "${dockerfile}" ]]; then
        log_error "Dockerfile not found for ${service}: ${dockerfile}"
        return 1
    fi

    tag="$(make_build_tag)"
    host_image="${HOST_REGISTRY}/surfbots/${service}:${tag}"
    cluster_image="${CLUSTER_REGISTRY}/surfbots/${service}:${tag}"

    log_info "Building image for: ${service}"
    log_info "  Context: ${context}"
    log_info "  Image:   ${host_image}"
    # Use --load to ensure image is available in local Docker daemon for push
    docker build --load -f "${dockerfile}" -t "${host_image}" "${context}"

    log_info "Pushing immutable image to local registry..."
    # Push to localhost:5000 (the single registry instance)
    # Use podman for rootless compatibility with --tls-verify=false
    podman push --tls-verify=false "${host_image}" 2>/dev/null || docker push "${host_image}"

    # Verify the image exists in registry BEFORE recording
    log_info "Verifying image exists in registry..."
    if ! verify_registry_image "${tag}" "${service}"; then
        log_error ""
        log_error "ERROR: Image verification failed for ${service}:${tag}"
        log_error "The image was pushed but is not accessible via the registry."
        log_error "Aborting - recorded image will NOT be updated."
        return 1
    fi

    # Record the cluster-facing image reference (same repository:tag, different hostname)
    record_built_image "${service}" "${cluster_image}"
    log_info "Recorded image: $(build_record_file "${service}")"
    log_info "  ${cluster_image}"
}

# Ensure all local image builds exist - rebuild only missing or invalid ones.
# This is used by start for self-healing before deploy.
ensure_all_builds() {
    local svc image tag missing=0 invalid=0
    local rebuild_needed=false

    for svc in ${LOCAL_IMAGE_SERVICES}; do
        local file
        file="$(build_record_file "${svc}")"
        
        # Check if record exists
        if [[ ! -s "${file}" ]]; then
            log_warn "Missing build record for ${svc}, will rebuild"
            missing=$((missing + 1))
            rebuild_needed=true
            continue
        fi

        # Read and verify the recorded image exists in registry
        image="$(read_recorded_image "${svc}")" || {
            invalid=$((invalid + 1))
            rebuild_needed=true
            continue
        }

        # Extract tag from cluster image (last colon-separated part)
        tag="${image##*:}"

        if ! verify_registry_image "${tag}" "${svc}"; then
            log_warn "Recorded image invalid for ${svc} (${tag} not found in registry), will rebuild"
            invalid=$((invalid + 1))
            rebuild_needed=true
        fi
    done

    # Rebuild only services that are missing or invalid
    if [[ "${rebuild_needed}" == "true" ]]; then
        log_info ""
        log_info "Rebuilding missing or invalid images..."
        for svc in ${LOCAL_IMAGE_SERVICES}; do
            local file
            file="$(build_record_file "${svc}")"
            local image tag

            # Skip if record and image are valid
            if [[ -s "${file}" ]]; then
                image="$(read_recorded_image "${svc}")" || continue
                tag="${image##*:}"
                if verify_registry_image "${tag}" "${svc}"; then
                    continue
                fi
            fi

            # Rebuild this service
            log_info "Rebuilding ${svc}..."
            build_one_image "${svc}"
        done
    fi

    if [[ "${missing}" -gt 0 ]] || [[ "${invalid}" -gt 0 ]]; then
        log_info ""
        log_info "Self-healing complete: ${missing} missing, ${invalid} invalid rebuilt"
    fi

    return 0
}

# Build immutable image(s) - DO NOT deploy.
# Build creates and records immutable images. It does NOT require or check for Deployments.
build_image() {
    local service="${1:-all}" svc
    case "${service}" in
        all)
            log_info "Building all local images..."
            for svc in ${LOCAL_IMAGE_SERVICES}; do
                build_one_image "${svc}"
            done
            ;;
        code-indexer|code-search-api|mcp-server|model-embedding|model-reranker)
            build_one_image "${service}"
            ;;
        model-generation)
            log_error "model-generation uses upstream image ghcr.io/ggml-org/llama.cpp:server and is not built locally"
            return 2
            ;;
        *)
            log_error "Unknown service: ${service}"
            log_info "Locally built: ${LOCAL_IMAGE_SERVICES}"
            log_info "Upstream-only: model-generation"
            return 2
            ;;
    esac
}

# Apply a recorded immutable image to an existing Deployment.
apply_recorded_image() {
    local service="$1" image container tag
    image="$(read_recorded_image "${service}")" || return 1
    container="$(service_container_name "${service}")" || return 1

    if ! kctl get "deployment/${service}" >/dev/null 2>&1; then
        log_error "Deployment does not exist: ${service}"
        return 1
    fi

    # Extract tag from cluster image for registry verification
    tag="${image##*:}"

    # Verify the recorded image exists in registry before applying
    if ! verify_registry_image "${tag}" "${service}"; then
        log_error ""
        log_error "ERROR: Recorded image verification failed for ${service}"
        log_error "  ${image}"
        log_error "  (tag ${tag} not found in registry)"
        log_error ""
        log_error "This indicates a mismatch between the recorded image and registry contents."
        log_error "Run: $0 rebuild ${service}"
        return 1
    fi

    log_info "Deploying recorded image for ${service}:"
    log_info "  ${image}"
    kctl set image "deployment/${service}" "${container}=${image}"
    # Use a bounded timeout (20s) to avoid Cline command runner timeout
    # Rollout may still be progressing - use cluster.sh status to verify
    kctl rollout status "deployment/${service}" --timeout=20s || {
        local exit_code=$?
        if [ $exit_code -eq 1 ]; then
            # Rollout timed out but may still be progressing
            log_info "Rollout still in progress after 20s - use './cluster.sh status' to verify"
            return 0
        fi
        return $exit_code
    }
}

# Redeploy using recorded immutable image - DO NOT build.
redeploy_service() {
    local service="${1:-}" svc
    if [[ -z "${service}" ]]; then
        log_error "Service name required"
        log_info "Usage: $0 redeploy <service|all>"
        return 1
    fi

    case "${service}" in
        all)
            for svc in ${LOCAL_IMAGE_SERVICES}; do
                apply_recorded_image "${svc}"
            done
            ;;
        code-indexer|code-search-api|mcp-server|model-embedding|model-reranker)
            apply_recorded_image "${service}"
            ;;
        model-generation)
            log_error "model-generation has no recorded local image; use '$0 deploy-generation' or '$0 restart model-generation'"
            return 2
            ;;
        *)
            log_error "Unknown service: ${service}"
            return 2
            ;;
    esac
}

# Rebuild = build + record + deploy.
rebuild_service() {
    local service="${1:-}" svc
    if [[ -z "${service}" ]]; then
        log_error "Service name required"
        log_info "Usage: $0 rebuild <service|all>"
        return 1
    fi

    case "${service}" in
        all)
            for svc in ${LOCAL_IMAGE_SERVICES}; do
                build_one_image "${svc}"
            done
            # Deploy all after building
            deploy_services
            ;;
        code-indexer|code-search-api|mcp-server|model-embedding|model-reranker)
            build_one_image "${service}"
            # Use redeploy to apply the new image
            redeploy_service "${service}"
            ;;
        model-generation)
            log_error "model-generation uses an upstream image and cannot be rebuilt by this script"
            return 2
            ;;
        *)
            log_error "Unknown service: ${service}"
            return 2
            ;;
    esac
}

# Restart = kubectl rollout restart only, DO NOT build or change image.
restart_service() {
    local service="${1:-}" svc
    if [[ -z "${service}" ]]; then
        log_error "Service name required"
        log_info "Usage: $0 restart <service|all>"
        return 1
    fi

    if [[ "${service}" == "all" ]]; then
        for svc in ${LOCAL_IMAGE_SERVICES} model-generation; do
            kctl rollout restart "deployment/${svc}"
            kctl rollout status "deployment/${svc}" --timeout=5m
        done
        return 0
    fi

    case "${service}" in
        code-indexer|code-search-api|mcp-server|model-embedding|model-generation|model-reranker) ;;
        *) log_error "Unknown service: ${service}"; return 2 ;;
    esac

    log_info "Restarting: ${service}"
    kctl rollout restart "deployment/${service}"
    kctl rollout status "deployment/${service}" --timeout=5m
}

case "${1:-help}" in
    create) create_cluster ;;
    destroy|delete) destroy_cluster ;;
    status|info) show_status ;;
    deploy) deploy_services ;;
    deploy-generation) deploy_generation ;;
    undeploy|uninstall) undeploy_services ;;
    test) run_tests ;;
    build) build_image "$2" ;;
    ensure_all_builds) ensure_all_builds ;;
    redeploy) redeploy_service "$2" ;;
    rebuild) rebuild_service "$2" ;;
    restart) restart_service "$2" ;;
    help|--help|-h)
        echo "Usage: $0 {create|destroy|status|deploy|deploy-generation|undeploy|test|build|ensure_all_builds|redeploy|rebuild|restart}"
        echo ""
        echo "Commands:"
        echo "  create            - Create k3d cluster"
        echo "  destroy           - Destroy k3d cluster"
        echo "  status            - Show cluster status"
        echo "  deploy            - Deploy all services"
        echo "  deploy-generation - Deploy only model-generation"
        echo "  undeploy          - Undeploy all services"
        echo "  test              - Run health checks"
        echo "  build             - Build immutable image (no deploy)"
        echo "  ensure_all_builds - Check and rebuild missing/invalid images (self-healing)"
        echo "  redeploy          - Use recorded image, make available, deploy"
        echo "  rebuild           - Build + record + deploy"
        echo "  restart           - kubectl rollout restart (no build)"
        ;;
    *) log_error "Unknown command: ${1}"; echo "Run '$0 help' for usage"; exit 1 ;;
esac
