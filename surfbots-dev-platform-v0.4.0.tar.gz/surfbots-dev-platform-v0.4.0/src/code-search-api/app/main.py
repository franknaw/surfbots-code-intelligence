"""Main FastAPI application for the code search API."""
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api import (
    health_router,
    search_router,
    files_router,
    repositories_router,
    memory_router,
    supervision_router,
    model_control_router,
)

from .core.config import settings
from .services.generation_client import generation_client
from .services.model_profiles import provider_connection_store
from .services.role_resolver import RoleResolver

logger = logging.getLogger(__name__)

# Configure logging
logging.basicConfig(
    level=logging.INFO if not settings.debug else logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

app = FastAPI(
    title="Surfbots Code Search API",
    description="Semantic code search service for the surfbots-dev-platform",
    version="0.1.0",
    docs_url="/docs" if settings.debug else None,
    redoc_url="/redoc" if settings.debug else None
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


async def reconcile_managed_generation():
    """Reconcile managed generation state with the active profile on startup."""
    try:
        from .services.managed_generation.manager import managed_generation_manager
        profile = provider_connection_store.get_active_profile()
        await managed_generation_manager.reconcile_active_profile(profile.id)
        state = await managed_generation_manager.get_state()
        if state.running:
            logger.info("Managed generation model is running: %s", state.model_label)
        else:
            logger.info("Managed generation model is scaled to zero (external provider active)")
    except Exception as error:
        logger.warning("Managed generation reconciliation skipped: %s", error)


@app.on_event("startup")
async def startup_event():
    """Initialize resources on startup."""
    logger.info("Initializing Code Search API...")
    logger.info(f"Indexer URL: {settings.indexer_url}")
    profile = provider_connection_store.get_active_profile()
    if profile.id == "current-local":
        resolver = RoleResolver(generation_client.provider, provider_connection_store)
        for role_key in ("generation", "reviewer", "promptRefiner", "collaborator"):
            resolved = await resolver.resolve_role(role_key)
            if resolved.provider != "local":
                raise RuntimeError(f"Default local profile resolved {role_key} to a non-local provider")
        logger.info("Initialized default local generation profile: %s", settings.local_generation_profile)
    
    # Reconcile managed generation state with active profile
    await reconcile_managed_generation()


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup resources on shutdown."""
    logger.info("Shutting down Code Search API...")


# Include routers
app.include_router(health_router, prefix="", tags=["health"])
app.include_router(search_router, prefix="", tags=["search"])
app.include_router(files_router, prefix="", tags=["files"])
app.include_router(repositories_router, prefix="", tags=["repositories"])
app.include_router(memory_router, prefix="", tags=["development-memory"])
app.include_router(supervision_router, prefix="", tags=["development-supervision"])
app.include_router(model_control_router, prefix="", tags=["internal-model-control"])


@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "service": "code-search-api",
        "version": "0.1.0",
        "status": "running",
        "indexer_url": settings.indexer_url,
        "docs": "/docs" if settings.debug else "disabled"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug
    )
