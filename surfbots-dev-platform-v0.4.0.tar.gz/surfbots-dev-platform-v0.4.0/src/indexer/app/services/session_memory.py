"""Qdrant persistence for repository-scoped Development Memory checkpoints."""
from datetime import datetime, timedelta, timezone
import logging
import re
from typing import Any, Literal
from fastapi import HTTPException
from uuid import NAMESPACE_URL, uuid5

from pydantic import BaseModel, Field
from qdrant_client.models import (
    Distance,
    DatetimeRange,
    FieldCondition,
    Filter,
    FilterSelector,
    MatchAny,
    MatchValue,
    PayloadSchemaType,
    PointStruct,
    VectorParams,
)

from ..core.config import settings
from ..core.database import get_qdrant_client
from .model_client import EmbeddingClient

logger = logging.getLogger(__name__)

COLLECTION_NAME = "session-memory"
MEMORY_TYPES = Literal["session_checkpoint", "decision", "issue", "milestone", "preference", "checkpoint_workflow", "supervision_refinement", "supervision_review", "supervision_collaboration"]
RETENTION_CLASSES = Literal["transient", "durable"]
SECRET_PATTERNS = (
    re.compile(r"(?i)(api[_-]?key|token|password|secret)\s*[:=]\s*[^\s,;]+"),
    re.compile(r"(?i)authorization:\s*bearer\s+[^\s,;]+"),
)


class SessionMemoryCheckpoint(BaseModel):
    """A concise, reviewable outcome from a coding session."""

    session_id: str = Field(min_length=1, max_length=200)
    development_task_id: str | None = Field(default=None, min_length=1, max_length=128)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    memory_type: MEMORY_TYPES = "session_checkpoint"
    retention_class: RETENTION_CLASSES = "transient"
    summary: str = Field(min_length=1, max_length=2_000)
    decisions: list[str] = Field(default_factory=list, max_length=20)
    files_touched: list[str] = Field(default_factory=list, max_length=100)
    symbols_touched: list[str] = Field(default_factory=list, max_length=100)
    completed: list[str] = Field(default_factory=list, max_length=50)
    unresolved: list[str] = Field(default_factory=list, max_length=50)
    test_results: list[str] = Field(default_factory=list, max_length=50)
    commit_sha: str | None = Field(default=None, max_length=128)
    supersedes: list[str] = Field(default_factory=list, max_length=20)
    checkpoint_phase: str | None = Field(default=None, max_length=64)
    workflow_state: dict[str, Any] | None = Field(default=None)
    evidence: dict[str, Any] | None = Field(default=None)


def ensure_session_memory_collection() -> None:
    """Create the memory collection once without modifying the code collection."""
    client = get_qdrant_client()
    try:
        client.get_collection(COLLECTION_NAME)
    except Exception:
        client.create_collection(
            collection_name=COLLECTION_NAME,
            vectors_config=VectorParams(
                size=settings.qdrant_vector_size,
                distance=Distance.COSINE,
            ),
        )

    # Applied unconditionally so collections created before these fields existed
    # still gain them; Qdrant treats re-creating an existing index as a no-op.
    for field_name, field_schema in (
        ("repository_id", PayloadSchemaType.KEYWORD),
        ("development_task_id", PayloadSchemaType.KEYWORD),
        ("created_at", PayloadSchemaType.DATETIME),
        ("memory_type", PayloadSchemaType.KEYWORD),
        ("retention_class", PayloadSchemaType.KEYWORD),
        ("files_touched", PayloadSchemaType.KEYWORD),
        ("symbols_touched", PayloadSchemaType.KEYWORD),
    ):
        try:
            client.create_payload_index(
                collection_name=COLLECTION_NAME,
                field_name=field_name,
                field_schema=field_schema,
            )
        except Exception:
            logger.debug("Payload index for %s already present", field_name)


def checkpoint_text(checkpoint: SessionMemoryCheckpoint) -> str:
    """Build the bounded text used for semantic retrieval, never a transcript."""
    sections = [checkpoint.summary]
    for label, values in (
        ("Decisions", checkpoint.decisions),
        ("Completed", checkpoint.completed),
        ("Unresolved", checkpoint.unresolved),
        ("Tests", checkpoint.test_results),
    ):
        if values:
            sections.append(f"{label}: " + "; ".join(values))
    return "\n".join(sections)


def redact_checkpoint(checkpoint: SessionMemoryCheckpoint) -> SessionMemoryCheckpoint:
    """Redact common secret formats regardless of which API client submitted it."""
    def redact(value: str) -> str:
        for pattern in SECRET_PATTERNS:
            value = pattern.sub("[REDACTED]", value)
        return value

    return checkpoint.model_copy(update={
        "summary": redact(checkpoint.summary),
        "decisions": [redact(value) for value in checkpoint.decisions],
        "completed": [redact(value) for value in checkpoint.completed],
        "unresolved": [redact(value) for value in checkpoint.unresolved],
        "test_results": [redact(value) for value in checkpoint.test_results],
    })


class SessionMemoryStore:
    """Persist and retrieve checkpoints with mandatory repository isolation."""

    def __init__(self, embedding_client: EmbeddingClient | None = None):
        self.embedding_client = embedding_client or EmbeddingClient()

    async def _get_memory_type(self, repository_id: str, memory_id: str) -> str | None:
        """Get the memory_type for a given memory_id."""
        try:
            client = get_qdrant_client()
            records, _ = client.scroll(
                collection_name=COLLECTION_NAME,
                scroll_filter=Filter(must=[
                    FieldCondition(key="repository_id", match=MatchValue(value=repository_id)),
                    FieldCondition(key="memory_id", match=MatchValue(value=memory_id)),
                ]),
                limit=1,
                with_payload=True,
                with_vectors=False,
            )
            if records:
                return records[0].payload.get("memory_type")
        except Exception:
            pass
        return None

    async def create(self, repository_id: str, checkpoint: SessionMemoryCheckpoint) -> dict[str, Any]:
        self._require_enabled()
        ensure_session_memory_collection()
        checkpoint = redact_checkpoint(checkpoint)
        
        # Validate type-based supersession chain
        # Each memory type can only supersede records of the same type
        checkpoint_type = checkpoint.memory_type
        for prior_memory_id in checkpoint.supersedes:
            prior_type = await self._get_memory_type(repository_id, prior_memory_id)
            if prior_type is None:
                logger.warning(
                    f"Superseded memory_id {prior_memory_id} not found in repository {repository_id}"
                )
            elif prior_type != checkpoint_type:
                raise HTTPException(
                    status_code=422,
                    detail=f"Cannot supersede {prior_type} record with {checkpoint_type} record. Type mismatch."
                )
        
        embedding = await self.embedding_client.generate_embedding(checkpoint_text(checkpoint))
        if not embedding or not embedding.embedding:
            raise RuntimeError("Embedding service unavailable")

        memory_id = str(uuid5(NAMESPACE_URL, f"{repository_id}:{checkpoint.session_id}"))
        payload = checkpoint.model_dump(mode="json")
        payload["repository_id"] = repository_id
        payload["memory_id"] = memory_id
        client = get_qdrant_client()
        client.upsert(
            collection_name=COLLECTION_NAME,
            points=[PointStruct(id=memory_id, vector=embedding.embedding, payload=payload)],
            wait=True,
        )
        for prior_memory_id in checkpoint.supersedes:
            client.set_payload(
                collection_name=COLLECTION_NAME,
                payload={"superseded_by": memory_id},
                points=FilterSelector(filter=Filter(must=[
                    FieldCondition(key="repository_id", match=MatchValue(value=repository_id)),
                    FieldCondition(key="memory_id", match=MatchValue(value=prior_memory_id)),
                ])),
                wait=True,
            )
        return payload

    def recent(self, repository_id: str, limit: int = 5) -> list[dict[str, Any]]:
        return self._list(repository_id, limit=limit)

    async def search(
        self,
        repository_id: str,
        query: str,
        limit: int = 10,
        memory_types: list[str] | None = None,
        retention_classes: list[str] | None = None,
        file_path: str | None = None,
        symbol: str | None = None,
        created_after: datetime | None = None,
        created_before: datetime | None = None,
    ) -> list[dict[str, Any]]:
        self._require_enabled()
        ensure_session_memory_collection()
        embedding = await self.embedding_client.generate_embedding(query)
        if not embedding or not embedding.embedding:
            raise RuntimeError("Embedding service unavailable")

        filters = [FieldCondition(key="repository_id", match=MatchValue(value=repository_id))]
        if memory_types:
            filters.append(FieldCondition(key="memory_type", match=MatchAny(any=memory_types)))
        if retention_classes:
            filters.append(FieldCondition(key="retention_class", match=MatchAny(any=retention_classes)))
        if file_path:
            filters.append(FieldCondition(key="files_touched", match=MatchValue(value=file_path)))
        if symbol:
            filters.append(FieldCondition(key="symbols_touched", match=MatchValue(value=symbol)))
        if created_after or created_before:
            filters.append(FieldCondition(key="created_at", range=DatetimeRange(
                gte=created_after.isoformat() if created_after else None,
                lte=created_before.isoformat() if created_before else None,
            )))
        results = get_qdrant_client().query_points(
            collection_name=COLLECTION_NAME,
            query=embedding.embedding,
            query_filter=Filter(must=filters),
            with_vectors=False,
            limit=limit,
        )
        return [point.payload | {"score": point.score} for point in results.points]

    def context(
        self,
        repository_id: str,
        limit: int | None = None,
        created_after: datetime | None = None,
    ) -> list[dict[str, Any]]:
        self._require_enabled()
        limit = limit or settings.session_memory_context_limit
        records = self._list(repository_id, limit=100)
        if created_after:
            records = [record for record in records if datetime.fromisoformat(
                record["created_at"].replace("Z", "+00:00")
            ) >= created_after]
        current_records = [record for record in records if not record.get("superseded_by")]
        durable = [record for record in current_records if record["retention_class"] == "durable"]
        recent = [record for record in current_records if record["retention_class"] != "durable"]
        selected = []
        remaining = settings.session_memory_context_char_budget
        for record in durable + recent:
            text_size = len(checkpoint_text(SessionMemoryCheckpoint.model_validate(record)))
            if text_size > remaining:
                continue
            selected.append(record)
            remaining -= text_size
            if len(selected) == limit:
                break
        return selected

    def delete(self, repository_id: str, memory_id: str) -> bool:
        self._require_enabled()
        ensure_session_memory_collection()
        selector = FilterSelector(filter=Filter(must=[
            FieldCondition(key="repository_id", match=MatchValue(value=repository_id)),
            FieldCondition(key="memory_id", match=MatchValue(value=memory_id)),
        ]))
        get_qdrant_client().delete(COLLECTION_NAME, points_selector=selector, wait=True)
        return True

    def delete_repository(self, repository_id: str) -> None:
        """Delete every Development Memory record for a removed repository."""
        self._require_enabled()
        ensure_session_memory_collection()
        selector = FilterSelector(filter=Filter(must=[FieldCondition(
            key="repository_id", match=MatchValue(value=repository_id)
        )]))
        get_qdrant_client().delete(COLLECTION_NAME, points_selector=selector, wait=True)

    def cleanup(self, repository_id: str | None = None, dry_run: bool = False) -> int:
        """Purge expired and excess transient records, retaining durable records."""
        self._require_enabled()
        ensure_session_memory_collection()
        filters = [FieldCondition(key="retention_class", match=MatchValue(value="transient"))]
        if repository_id:
            filters.append(FieldCondition(key="repository_id", match=MatchValue(value=repository_id)))
        records, _ = get_qdrant_client().scroll(
            collection_name=COLLECTION_NAME,
            scroll_filter=Filter(must=filters),
            with_vectors=False,
            limit=10_000,
        )
        cutoff = datetime.now(timezone.utc) - timedelta(days=settings.session_memory_transient_days)
        grouped: dict[str, list[Any]] = {}
        for record in records:
            grouped.setdefault(record.payload["repository_id"], []).append(record)
        expired_ids = []
        for repository_records in grouped.values():
            ordered = sorted(repository_records, key=lambda item: item.payload["created_at"], reverse=True)
            for index, record in enumerate(ordered):
                created_at = datetime.fromisoformat(record.payload["created_at"].replace("Z", "+00:00"))
                if created_at < cutoff or index >= settings.session_memory_max_transient_records:
                    expired_ids.append(record.id)
        if expired_ids and not dry_run:
            get_qdrant_client().delete(COLLECTION_NAME, points_selector=expired_ids, wait=True)
        return len(expired_ids)

    def _list(self, repository_id: str, limit: int) -> list[dict[str, Any]]:
        self._require_enabled()
        ensure_session_memory_collection()
        records, _ = get_qdrant_client().scroll(
            collection_name=COLLECTION_NAME,
            scroll_filter=Filter(must=[FieldCondition(
                key="repository_id", match=MatchValue(value=repository_id)
            )]),
            with_vectors=False,
            limit=100,
        )
        payloads = [record.payload for record in records]
        return sorted(payloads, key=lambda record: record["created_at"], reverse=True)[:limit]

    @staticmethod
    def _require_enabled() -> None:
        if not settings.session_memory_enabled:
            raise RuntimeError("Development Memory is disabled")