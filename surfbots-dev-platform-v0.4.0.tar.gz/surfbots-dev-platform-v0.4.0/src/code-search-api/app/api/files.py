"""File content endpoints."""
from fastapi import APIRouter, HTTPException, Query
from typing import Optional
import logging

from ..services.search_service import search_service

logger = logging.getLogger(__name__)
router = APIRouter()


# Declared before /{file_id} so this literal segment is not captured as an id.
@router.get("/api/v1/files/content")
async def get_file_content(
    repository_id: str = Query(...),
    path: str = Query(...),
    start_line: Optional[int] = Query(None, ge=1),
    end_line: Optional[int] = Query(None, ge=1),
):
    """Return file content, or a line range, by repository and path."""
    resolved = await search_service.resolve_repository_id(repository_id) or repository_id
    result = await search_service.indexer.get_file_content(resolved, path, start_line, end_line)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result


@router.get("/api/v1/files")
async def list_files(
    repository_id: Optional[str] = None,
    directory: Optional[str] = None,
    language: Optional[str] = None,
    limit: int = Query(default=100, le=1000),
    offset: int = Query(default=0)
):
    """List files in a repository."""
    try:
        results = await search_service.list_files(
            repository_id=repository_id,
            directory=directory,
            language=language,
            limit=limit,
            offset=offset
        )
        return results
    except Exception as e:
        logger.error(f"List files failed: {e}")
        raise HTTPException(status_code=500, detail=f"List files failed: {str(e)}")


@router.get("/api/v1/files/{file_id}")
async def get_file(file_id: str):
    """Get file content."""
    try:
        results = await search_service.indexer.get_file(file_id=file_id)
        return results
    except Exception as e:
        logger.error(f"Get file failed: {e}")
        raise HTTPException(status_code=500, detail=f"Get file failed: {str(e)}")


@router.get("/api/v1/files/range")
async def get_file_range(
    file_id: str = Query(...),
    start_line: int = Query(default=1, ge=1),
    end_line: Optional[int] = Query(None)
):
    """Get a specific range of lines from a file."""
    try:
        results = await search_service.indexer.get_file_range(
            file_id=file_id,
            start_line=start_line,
            end_line=end_line
        )
        return results
    except Exception as e:
        logger.error(f"Get file range failed: {e}")
        raise HTTPException(status_code=500, detail=f"Get file range failed: {str(e)}")


@router.get("/api/v1/files/{file_id}/outline")
async def get_file_outline(file_id: str):
    """Get file structure outline (symbols)."""
    try:
        results = await search_service.indexer.get_file_outline(file_id=file_id)
        return results
    except Exception as e:
        logger.error(f"Get file outline failed: {e}")
        raise HTTPException(status_code=500, detail=f"Get file outline failed: {str(e)}")