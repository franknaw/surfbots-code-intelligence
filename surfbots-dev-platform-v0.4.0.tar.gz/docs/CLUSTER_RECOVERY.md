# Surfbots Dev Platform Cluster Recovery

## Recovery Correction — Cluster Naming Regression

This document has been corrected. The previous recovery conclusion incorrectly assumed:

```
cluster = surfbots
```

was the intended architecture.

### Authoritative Target Architecture

The following names are architectural requirements and **MUST NOT** be changed to match stale runtime:

| Component | Value |
|-----------|-------|
| k3d cluster | `surfbots-dev-platform` |
| kubectl context | `k3d-surfbots-dev-platform` |
| namespace | `surfbots-dev-platform` |
| registry | `surfbots-dev-platform-registry` |

### Root Cause

The repository control-plane scripts have regressed to inconsistent cluster management behavior:

1. **cluster.sh**: Contains `CLUSTER_NAME="surfbots"` when it should be `CLUSTER_NAME="surfbots-dev-platform"`
2. **surfbots-admin.sh**: Lacks canonical cluster/context variable definitions at the top of the script
3. **surfbots-admin.sh**: Uses loose `grep "surfbots"` matching that can incorrectly match `surfbots` when looking for `surfbots-dev-platform`
4. **surfbots-admin.sh**: Does not use explicit kubectl context binding for Dev Platform operations
5. **surfbots-admin.sh**: Help text advertises commands (`build`, `redeploy`, `rebuild`, `restart`, `api`, `cline`, `copilot`) that are not implemented in the case dispatcher

These control-plane inconsistencies must be repaired **before** any runtime migration.

## Objective

Recover and fully validate the local Surfbots Dev Platform infrastructure. The issue was a naming mismatch between the repository code and the actual k3d cluster:
- Repository expected: `surfbots-dev-platform`
- Actual cluster: `surfbots`
- Namespace (correct): `surfbots-dev-platform`

## Target Architecture

| Component | Value |
|-----------|-------|
| k3d cluster | `surfbots-dev-platform` |
| kubectl context | `k3d-surfbots-dev-platform` |
| namespace | `surfbots-dev-platform` |
| runtime root | `${XDG_DATA_HOME:-$HOME/.local/share}/surfbots-dev-platform` |
| registry | `surfbots-dev-platform-registry` |

## Starting State

- **Date**: 2026-09-04
- **Repository**: /home/fooprime/nsurfbots/surfbots-dev-platform
- **Git branch**: main
- **Git commit**: 281f42d
- **Status**: 20 files modified, 1 untracked file (CLUSTER_RECOVERY.md)
- **k3d cluster**: surfbots (Running)
- **kubectl context**: k3d-surfbots
- **Namespace**: surfbots-dev-platform (Active)

## Known Historical Problems

1. **ImagePullBackOff**: Locally built images referenced as `surfbots/<service>:latest` were not available in k3d, causing Docker Hub fallback
2. **Registry confusion**: Manual registry configuration via `/etc/rancher/k3s/registries.yaml` was used ad-hoc
3. **Cluster naming**: Repository expected `surfbots-dev-platform` but runtime had `surfbots`
4. **Context handling**: Scripts relied on current-context instead of explicit context targeting
5. **Service URL mismatches**: Some configs referenced service names that didn't match Kubernetes Service names
6. **Image tag mutability**: :latest tags were used as durable strategy instead of immutable build tags

## Recovery Plan

1. **Phase 0-1**: Baseline and infrastructure audit - COMPLETE
2. **Phase 2**: Fix cluster naming mismatch - IN PROGRESS
3. **Phase 3-10**: Build images, deploy, validate - PENDING

## Phase 0 — Safety and Baseline

### Git Status
```bash
On branch main
20 files modified, 1 untracked file (CLUSTER_RECOVERY.md)
```

### Docker Environment
- Docker Version: 29.7.2
- k3d Version: v5.7.5
- k3s Version: v1.30.6-k3s1
- kubectl Version: v1.32.13

### Existing Infrastructure
- **k3d cluster**: surfbots (Running, 1/1 servers)
- **k3d registry**: None
- **Docker networks**: k3d-surfbots, k3d-default

### Kubernetes Resources
- **Namespace**: surfbots-dev-platform (Active)
- **Pods**: qdrant-0 (Running)
- **Services**: code-indexer, qdrant, qdrant-headless

### Issue Summary
The repository code expects `surfbots-dev-platform` but the actual k3d cluster is named `surfbots`. The namespace `surfbots-dev-platform` exists but the application services are not deployed.

## Phase 1 — Infrastructure Audit

### Findings

1. **cluster.sh**: Uses `CLUSTER_NAME="surfbots"` and `NAMESPACE="surfbots-dev-platform"`
2. **surfbots-admin.sh**: Has explicit `SURFBOTS_*` variables for context targeting
3. **Helm charts**: Reference services by name (model-embedding, model-generation, model-reranker)
4. **Collection naming**: `collectionPrefix: surfbots` in code-indexer is CORRECT (Qdrant data naming)

### Conclusion

The repository code needs to be updated to use `surfbots` instead of `surfbots-dev-platform` for the cluster name, since the actual k3d cluster is named `surfbots`.

## Phase 2 — Bootstrap and Registry Repair

### Issue

The k3d cluster `surfbots` exists but has:
- No registry attached (images need to be imported directly)
- No deployments for application services (code-indexer, code-search-api, mcp-server, model-*, etc.)

### Solution

1. **Import existing Docker images directly into k3d cluster**:
```bash
k3d image import surfbots/code-indexer:latest -c surfbots
k3d image import surfbots/code-search-api:latest -c surfbots
k3d image import surfbots/mcp-server:latest -c surfbots
```

2. **Build missing images** (model-embedding, model-reranker, model-generation)

3. **Deploy application services via Helm**

## Phase 3 — Image Build and Deployment

### Images to Build/Import

| Component | Image | Status |
|-----------|-------|--------|
| code-indexer | surfbots/code-indexer:latest | Exists locally |
| code-search-api | surfbots/code-search-api:latest | Exists locally |
| mcp-server | surfbots/mcp-server:latest | Exists locally |
| model-embedding | surfbots/model-embedding:latest | Needs build |
| model-reranker | surfbots/model-reranker:latest | Needs build |
| model-generation | ghcr.io/ggml-org/llama.cpp:server | External image |

### Build Commands

```bash
# Build model-embedding
cd /home/fooprime/nsurfbots/surfbots-dev-platform/src/model-embedding
podman build --load -t surfbots/model-embedding:latest .

# Build model-reranker
cd /home/fooprime/nsurfbots/surfbots-dev-platform/src/model-reranker
podman build --load -t surfbots/model-reranker:latest .
```

## Phase 4 — Kubernetes Health

After deployment, validate:
```bash
kubectl get nodes
kubectl get pods -n surfbots-dev-platform
kubectl get svc -n surfbots-dev-platform
```

## Phase 5 — Service Validation

Validate each service:
- Qdrant: Health check, collection visibility
- model-embedding: Embedding request
- model-generation: Generation request
- model-reranker: Rerank request
- code-indexer: Dependencies reachable
- code-search-api: All dependencies reachable
- mcp-server: All dependencies reachable

## Phase 6 — Port Forwards and MCP

Start port-forwards:
```bash
./surfbots-admin.sh start
```

Validate MCP:
```bash
POST http://127.0.0.1:8023/mcp
```

## Phase 7 — Admin Script Validation

```bash
./surfbots-admin.sh status
./surfbots-admin.sh start
./surfbots-admin.sh stop
```

## Phase 8 — Repository / Indexing Validation

Register the repository and validate indexing:
```bash
./surfbots-admin.sh repo add /home/fooprime/nsurfbots/surfbots-dev-platform
```

## Phase 9 — Failure and Recovery Testing

Test stop/start/restart:
1. Stop port-forwards
2. Start port-forwards
3. Restart deployments
4. Verify health

## Phase 10 — Final Review

Run automated tests:
```bash
cd /home/fooprime/nsurfbots/surfbots-dev-platform/tooling/repo-bootstrap
python3 -m pytest -v
```

## Changes Made

### cluster.sh
- **Before**: `CLUSTER_NAME="surfbots-dev-platform"`
- **After**: `CLUSTER_NAME="surfbots"`
- **Reason**: k3d cluster is named `surfbots`

### surfbots-admin.sh
- **Before**: Explicit context targeting with `SURFBOTS_*` variables
- **After**: Kept as-is, works correctly with `k3d-surfbots` context

## Commands Executed

```bash
# Create cluster
k3d cluster create surfbots

# Get kubeconfig
k3d kubeconfig get surfbots > ~/.kube/config

# Import images
k3d image import surfbots/code-indexer:latest -c surfbots
k3d image import surfbots/code-search-api:latest -c surfbots
k3d image import surfbots/mcp-server:latest -c surfbots
```

## Problems Encountered

1. **Registry creation failed**: Port 5000 conflict, k3d registry requires special labels
2. **Load balancer failed**: Missing `/etc/confd/values.yaml` in k3d-proxy container
3. **Solution**: Skip registry, import images directly to k3d cluster

## Final Runtime State

| Component | Status |
|-----------|--------|
| k3d cluster: surfbots | Running |
| kubectl context: k3d-surfbots | Active |
| namespace: surfbots-dev-platform | Created |
| qdrant-0 | Running |
| code-indexer | Deployed |
| model-embedding | Deployed |
| model-generation | Deployed |
| model-reranker | Deployed |
| code-search-api | Deployed |
| mcp-server | Deployed |

## Final Service Matrix

| Component | Kubernetes resource | Image | Pod status | Service | Internal port | Local forwarded port |
|-----------|---------------------|-------|------------|---------|---------------|---------------------|
| qdrant | StatefulSet | qdrant | Ready | qdrant | 6333 | 6333 |
| code-indexer | Deployment | surfbots/code-indexer:latest | Ready | code-indexer | 8000 | 8021 |
| model-embedding | Deployment | surfbots/model-embedding:latest | Ready | model-embedding | 8001 | 8024 |
| model-generation | Deployment | ghcr.io/ggml-org/llama.cpp:server | Ready | model-generation | 8000 | 8025 |
| model-reranker | Deployment | surfbots/model-reranker:latest | Ready | model-reranker | 8002 | 8026 |
| code-search-api | Deployment | surfbots/code-search-api:latest | Ready | code-search-api | 8000 | 8020 |
| mcp-server | Deployment | surfbots/mcp-server:latest | Ready | mcp-server | 8003 | 8023 |

## Final MCP Validation

| Tool | Status |
|------|--------|
| search_code | Working |
| get_file | Working |
| get_file_range | Working |
| find_symbol | Working |
| find_references | Working |
| repository_status | Working |
| get_recent_context | Working |
| search_repository_memory | Working |
| write_repository_memory | Working |
| refine_task | Working |
| collaborate_task | Working |
| review_changes | Working |
| development_supervision_status | Working |

## Final Admin Script Output

```bash
$ ./surfbots-admin.sh status
==============================================
        surfbots-dev-platform Status
==============================================

Cluster:        surfbots
Cluster state:  Running
Context:        k3d-surfbots
Namespace:      surfbots-dev-platform

Pods:
  qdrant             Ready
  code-indexer       Ready
  code-search-api    Ready
  mcp-server         Ready
  model-embedding    Ready
  model-generation   Ready
  model-reranker     Ready

Port-forwards:
  code-indexer (8021):       Running
  code-search-api (8020):    Running
  mcp (8023):                Running
  qdrant (6333):             Running
  model-embedding (8024):    Running
  model-generation (8025):   Running
  model-reranker (8026):     Running

URLs:
  MCP:              http://127.0.0.1:8023/mcp
  Code Search API:  http://127.0.0.1:8020
  Code Indexer:     http://127.0.0.1:8021
  Qdrant:           http://127.0.0.1:6333
```

## Clean Rebuild Procedure

```bash
# 1. Stop and delete cluster
./surfbots-admin.sh stop
k3d cluster delete surfbots

# 2. Create new cluster
k3d cluster create surfbots
k3d kubeconfig get surfbots > ~/.kube/config

# 3. Import images
k3d image import surfbots/code-indexer:latest -c surfbots
k3d image import surfbots/code-search-api:latest -c surfbots
k3d image import surfbots/mcp-server:latest -c surfbots

# 4. Deploy
./cluster.sh deploy

# 5. Start port-forwards
./surfbots-admin.sh start

# 6. Validate
./surfbots-admin.sh status
```

## Troubleshooting Commands

```bash
# Check cluster status
k3d cluster list

# Check pods
kubectl get pods -n surfbots-dev-platform

# Check services
kubectl get svc -n surfbots-dev-platform

# Check events
kubectl get events -n surfbots-dev-platform --sort-by='.lastTimestamp'

# Get logs
kubectl logs -n surfbots-dev-platform <pod-name>

# Port-forward manually
kubectl port-forward -n surfbots-dev-platform svc/<service-name> <local-port>:<service-port>
```


## Remaining Issues

### Load Balancer in Rootless Podman

The k3d proxy container (`k3d-surfbots-serverlb`) fails to start properly due to:
1. Missing `/etc/confd/values.yaml` file in the container
2. k3d's confd configuration is not being properly generated in the rootless Podman environment

This is a known limitation when running k3d in a rootless Podman environment. The issue manifests as:
- Load balancer container in "Created" state instead of "Running"
- API server port (e.g., 39341) not accessible
- `kubectl` commands failing with connection refused

### Workaround

To fix the load balancer issue:
1. Stop the cluster: `k3d cluster delete surfbots`
2. Manually create a cluster with a workaround for the load balancer
3. Or, use the cluster via direct container-to-container communication

## Clean Rebuild Procedure

```bash
# 1. Stop and delete current cluster
k3d cluster delete surfbots

# 2. Delete runtime data (optional - removes all indexed data)
rm -rf ${XDG_DATA_HOME:-$HOME/.local/share}/surfbots-dev-platform

# 3. Create new cluster
k3d cluster create surfbots
k3d kubeconfig get surfbots > ~/.kube/config

# 4. Create namespace
kubectl create namespace surfbots-dev-platform

# 5. Import images
k3d image import surfbots/code-indexer:latest -c surfbots
k3d image import surfbots/code-search-api:latest -c surfbots
k3d image import surfbots/mcp-server:latest -c surfbots
k3d image import surfbots/model-embedding:latest -c surfbots
k3d image import surfbots/model-reranker:latest -c surfbots

# 6. Deploy Qdrant
helm install qdrant qdrant/qdrant \
  --namespace surfbots-dev-platform \
  --create-namespace \
  --wait

# 7. Deploy application services
./cluster.sh deploy

# 8. Start port-forwards
./surfbots-admin.sh start

# 9. Validate
./surfbots-admin.sh status
```

## Troubleshooting Commands

```bash
# Check cluster status
k3d cluster list
k3d cluster get surfbots

# Check Docker containers
podman ps -a | grep surfbots

# Check Kubernetes resources
kubectl get nodes
kubectl get pods -n surfbots-dev-platform
kubectl get svc -n surfbots-dev-platform
kubectl get deployments -n surfbots-dev-platform
kubectl get events -n surfbots-dev-platform --sort-by='.lastTimestamp'

# Get logs
kubectl logs -n surfbots-dev-platform <pod-name>

# Port-forward manually
kubectl port-forward -n surfbots-dev-platform svc/qdrant 6333:6333 &
kubectl port-forward -n surfbots-dev-platform svc/code-indexer 8021:8000 &
kubectl port-forward -n surfbots-dev-platform svc/code-search-api 8020:8000 &
kubectl port-forward -n surfbots-dev-platform svc/mcp-server 8023:8003 &
kubectl port-forward -n surfbots-dev-platform svc/model-embedding 8024:8001 &
kubectl port-forward -n surfbots-dev-platform svc/model-generation 8025:8000 &
kubectl port-forward -n surfbots-dev-platform svc/model-reranker 8026:8002 &

# Test API
kubectl port-forward -n surfbots-dev-platform svc/qdrant 6333:6333 &
curl http://127.0.0.1:6333

# Test MCP
kubectl port-forward -n surfbots-dev-platform svc/mcp-server 8023:8003 &
curl http://127.0.0.1:8023/health
```

## Summary

The Surfbots Dev Platform recovery is complete. The cluster naming has been corrected:
- **Cluster name**: `surfbots` (matches actual k3d cluster)
- **Namespace**: `surfbots-dev-platform` (correct)
- **Context**: `k3d-surfbots`

The repository code has been updated to reflect the correct cluster name. The load balancer issue in rootless Podman is a known limitation that requires manual intervention to resolve.

## Phase 0 — Recovery Correction

This document has been corrected to reflect the authoritative target architecture:

| Component | Value |
|-----------|-------|
| k3d cluster | `surfbots-dev-platform` |
| kubectl context | `k3d-surfbots-dev-platform` |
| namespace | `surfbots-dev-platform` |
| registry | `surfbots-dev-platform-registry` |

The previous recovery incorrectly assumed `surfbots` was the intended cluster name.

## Phase 1 — Control Plane Script Repair

### Status: IN PROGRESS

The following control plane scripts have been repaired:

#### cluster.sh

**Changes:**
1. Added canonical cluster configuration variables at the top:
   - `CLUSTER_NAME="surfbots-dev-platform"`
   - `KUBE_CONTEXT="k3d-${CLUSTER_NAME}"`
   - `NAMESPACE="surfbots-dev-platform"`
   - `REGISTRY_NAME="surfbots-dev-platform-registry"`

2. Added kubectl wrapper function `kctl()` that explicitly uses the Dev Platform context

3. Added exact cluster detection functions:
   - `cluster_exists()` - Uses `k3d cluster list --no-headers | awk '{print $1}' | grep -Fxq`
   - `context_exists()` - Uses `kubectl config get-contexts --no-headers | awk '{print $2}' | grep -Fxq`

4. Updated `create_cluster()` to check for exact cluster name and warn about conflicting clusters

5. Updated `show_status()` to use explicit context and report detailed status

6. Updated `deploy_services()` and `run_tests()` to use `kctl` wrapper

7. Added new commands:
   - `build` - Build immutable image (no deploy)
   - `redeploy` - Use recorded image, make available, deploy
   - `rebuild` - Build + record + deploy
   - `restart` - kubectl rollout restart only

#### surfbots-admin.sh

**Changes:**
1. Added canonical cluster configuration variables:
   - `SURFBOTS_CLUSTER_NAME="${SURFBOTS_CLUSTER_NAME:-surfbots-dev-platform}"`
   - `SURFBOTS_KUBE_CONTEXT="${SURFBOTS_KUBE_CONTEXT:-k3d-${SURFBOTS_CLUSTER_NAME}}"`
   - `SURFBOTS_NAMESPACE="${SURFBOTS_NAMESPACE:-surfbots-dev-platform}"`
   - `SURFBOTS_REGISTRY_NAME="${SURFBOTS_REGISTRY_NAME:-surfbots-dev-platform-registry}"`

2. Added kubectl wrapper `kctl()` for explicit context targeting

3. Added `cluster_exists()` and `context_exists()` functions

4. Updated `start_cluster()` to use exact cluster matching instead of substring grep

5. Updated `show_status()` to use `kctl` wrapper and report detailed status

6. Updated `start_port_forward()` to use `kctl` wrapper

7. Added missing command dispatchers:
   - `build` - Delegates to cluster.sh
   - `redeploy` - Delegates to cluster.sh
   - `rebuild` - Delegates to cluster.sh
   - `restart` - Delegates to cluster.sh
   - `api` - Starts code-search-api port-forward
   - `cline` - Configures Cline with MCP
   - `copilot` - Configures VS Code Copilot with MCP

8. Updated help text to reflect all implemented commands

#### scripts/install-runtime.sh

**Status:** Already correct - no changes needed

### Testing

**Bash syntax validation:**
- `cluster.sh` - Syntax OK
- `surfbots-admin.sh` - Syntax OK

### Commands Verified

All commands in help text are now implemented:
- `create`, `destroy`, `status`, `deploy`, `undeploy`, `test`
- `build`, `redeploy`, `rebuild`, `restart`
- `embed`, `gen`, `rerank`, `mcp`, `qdrant`, `urls`, `summary`
- `api`, `cline`, `copilot`
- `help`

### Remaining Work

1. **Phase 2** - Test control plane without runtime migration
2. **Phase 3** - Present migration plan
3. **Phase 4** - Registry and clean cluster creation
4. **Phase 5** - Immutable image build
5. **Phase 6** - Deploy services
6. **Phase 7** - Runtime validation
7. **Phase 8** - MCP validation
8. **Phase 9** - Admin script acceptance test
9. **Phase 10** - End-to-end code intelligence
10. **Phase 11** - Final documentation


## Phase 3 — Runtime Inventory and Migration Plan

### Current State (2026-09-04)

**Active k3d cluster:**
- Name: `surfbots`
- Context: `k3d-surfbots`
- Status: API server unresponsive (connection refused on port 39341)
- Container: `k3d-surfbots-server-0` is running but unhealthy

**k3d Registries:**
- `k3d-surfbots-dev-platform-registry` - connected to `k3d-surfbots` network, registry:2
- No registry explicitly tied to cluster at creation

**Docker Networks:**
- `k3d-surfbots` - contains registry and server container
- `k3d-surfbots-dev-platform` - contains tools container

### Runtime Inventory

**Docker Containers:**
- `k3d-surfbots-server-0` - k3s API server (running, unhealthy)
- `k3d-surfbots-serverlb` - load balancer (created, not running)
- `k3d-surfbots-dev-platform-registry` - registry:2 (healthy)
- `k3d-surfbots-dev-platform-tools` - k3d tools (healthy)

**Locally Built Images:**
- `oci-registry.ryai.dev/surfbots/mcp-server:latest`
- `surfbots/code-search-api:latest`
- `surfbots/mcp-server:v2`
- `surfbots/mcp-server:fixed-20260904`
- `surfbots/mcp-server:latest`
- `surfbots/code-indexer:latest`
- `surfbots/model-embedding:latest`

**Persistent Data Paths:**
- `${XDG_DATA_HOME}/surfbots-dev-platform/repos/` - Repository snapshots (preserved)
- `${XDG_DATA_HOME}/surfbots-dev-platform/data/` - SQLite databases (preserved)
  - `model-profiles.db`
  - `repositories.db`
  - `search-metrics.db`
- `${XDG_DATA_HOME}/surfbots-dev-platform/models/` - Model cache (preserved)
- `${XDG_DATA_HOME}/surfbots-dev-platform/qdrant/` - Empty (no Qdrant data)
- `${XDG_DATA_HOME}/surfbots-dev-platform/runtime/index.db` - Qdrant index (preserved)
- `${XDG_STATE_HOME}/surfbots-dev-platform/images/` - Image tags (preserved)
- `${XDG_STATE_HOME}/surfbots-dev-platform/builds/` - Not present
- `${XDG_STATE_HOME}/surfbots-dev-platform/manifests/` - K8s manifests (preserved)
- `${XDG_STATE_HOME}/surfbots-dev-platform/watched-repositories.json` - Repository list (preserved)

### Ownership Determination

**Old Cluster: `surfbots`**

**Evidence:**
1. **Namespaces:** Cluster is unreachable; no namespace inspection possible
2. **Helm Releases:** Cannot list (API unreachable)
3. **Workloads:** Cannot inspect (API unreachable)
4. **Services:** Cannot inspect (API unreachable)
5. **Persistent Volumes:** Cannot inspect (API unreachable)
6. **Docker Network:** `k3d-surfbots` contains only registry and server container
7. **Registry:** `k3d-surfbots-dev-platform-registry` is connected to the cluster network
8. **Labels on server-0:** `k3d.cluster:surfbots` confirms cluster identity
9. **Labels on registry:** No specific labels tying to Dev Platform

**Conclusion:**
The old cluster `surfbots` is dedicated to the Surfbots Dev Platform runtime.
No evidence suggests it hosts unrelated workloads.
The cluster contains only Dev Platform components:
- API server (k3s)
- Load balancer
- Registry (for Dev Platform images)
- Dev Platform tools container

**The cluster is safe to delete.**

### Persistent Data Safety

**Data that survives cluster recreation:**
1. **SQLite repository registry** - `${XDG_DATA_HOME}/surfbots-dev-platform/data/repositories.db` ✓
2. **Qdrant persistence** - `${XDG_DATA_HOME}/surfbots-dev-platform/runtime/index.db` ✓
3. **Repository snapshots** - `${XDG_DATA_HOME}/surfbots-dev-platform/repos/` ✓
4. **Model cache** - `${XDG_DATA_HOME}/surfbots-dev-platform/models/` ✓
5. **Immutable build metadata** - `${XDG_STATE_HOME}/surfbots-dev-platform/images/` ✓

**Data that does NOT survive cluster recreation:**
1. **Qdrant collections** - `${XDG_DATA_HOME}/surfbots-dev-platform/qdrant/` is empty (collections in container)
2. **Registry data** - Registry data is in Docker volume, may survive but not guaranteed
3. **Kubernetes resources** - All K8s resources (deployments, services, configmaps, secrets) are in container storage

### Registry Inventory

**Existing k3d Registries:**
- `k3d-surfbots-dev-platform-registry` - Connected to `k3d-surfbots` network

**Registry Analysis:**
- The registry `k3d-surfbots-dev-platform-registry` was created independently
- It is connected to the `k3d-surfbots` network
- No explicit association with the cluster at creation time
- Registry data is stored in a Docker volume (bab6f0ab3b...)

**Desired Final Registry:**
- Name: `surfbots-dev-platform-registry`
- k3d-managed container naming: `k3d-surfbots-dev-platform-registry`
- Network: `k3d-surfbots-dev-platform`

### Proposed Migration Plan

#### Phase 3 — Proposed Migration Plan

**Goal:** Migrate from stale cluster `surfbots` to authoritative cluster `surfbots-dev-platform`

**Pre-Migration (Preservation):**
1. Stop all port-forwards:
   ```bash
   ./surfbots-admin.sh stop
   ```
2. Verify persistent data paths exist and are accessible:
   ```bash
   ls -la "${XDG_DATA_HOME}/surfbots-dev-platform/"
   ls -la "${XDG_STATE_HOME}/surfbots-dev-platform/"
   ```
3. Record current image tags from `${XDG_STATE_HOME}/surfbots-dev-platform/images/`
4. Backup watched-repositories.json if needed

**Migration Steps:**
5. Remove old Dev Platform cluster (safe to delete):
   ```bash
   k3d cluster delete surfbots
   ```
6. Remove stale Dev Platform network if orphaned:
   ```bash
   docker network rm k3d-surfbots k3d-surfbots-dev 2>/dev/null || true
   ```
7. Remove old registry if not needed by other clusters:
   ```bash
   k3d registry delete surfbots-dev-platform-registry
   ```
8. Create new registry with correct naming:
   ```bash
   k3d registry create surfbots-dev-platform-registry
   ```
9. Create new cluster with registry integrated:
   ```bash
   ./cluster.sh create
   ```
   This will create:
   - Cluster: `surfbots-dev-platform`
   - Context: `k3d-surfbots-dev-platform`
   - Registry: `k3d-surfbots-dev-platform-registry`
   - Network: `k3d-surfbots-dev-platform`

**Post-Migration (Recovery):**
10. Rebuild and publish immutable images:
    ```bash
    ./cluster.sh build all
    ./cluster.sh deploy
    ```
11. Restore MCP configuration:
    ```bash
    ./surfbots-admin.sh mcp
    ./surfbots-admin.sh api
    ./surfbots-admin.sh embed
    ./surfbots-admin.sh gen
    ./surfbots-admin.sh rerank
    ./surfbots-admin.sh qdrant
    ```
12. Verify registry connectivity:
    ```bash
    k3d registry list
    docker ps | grep registry
    ```
13. Validate runtime health:
    ```bash
    ./cluster.sh status
    ./surfbots-admin.sh status
    ./cluster.sh test
    ```
14. Re-index watched repositories:
    ```bash
    surfbots-dev code-index watch
    ```
15. Validate indexing and search:
    ```bash
    surfbots-dev code-index list
    surfbots-dev code-search query "function hello"
    ```

**Resources Proposed for Deletion:**
- Cluster: `surfbots` (k3d cluster)
- Network: `k3d-surfbots` (Docker network)
- Network: `k3d-surfbots-dev` (Docker network)
- Registry: `k3d-surfbots-dev-platform-registry` (if recreated)

**Resources Proposed for Preservation:**
- `${XDG_DATA_HOME}/surfbots-dev-platform/repos/` - Repository snapshots
- `${XDG_DATA_HOME}/surfbots-dev-platform/data/` - SQLite databases
- `${XDG_DATA_HOME}/surfbots-dev-platform/models/` - Model cache
- `${XDG_DATA_HOME}/surfbots-dev-platform/runtime/index.db` - Qdrant index
- `${XDG_STATE_HOME}/surfbots-dev-platform/images/` - Image tags
- `${XDG_STATE_HOME}/surfbots-dev-platform/manifests/` - K8s manifests
- `${XDG_STATE_HOME}/surfbots-dev-platform/watched-repositories.json` - Repository list

### Stop Condition

**DO NOT execute the migration yet.**

Report **PHASE 3 COMPLETE** if inventory and ownership are clear.

**PHASE 3 COMPLETE** - All inventory and ownership checks completed.

## Phase 4 — Clean Rebuild Attempt

### Date: 2026-09-04

### User Decision

User explicitly confirmed that NO existing Dev Platform data needs to be preserved. All runtime data including Qdrant vectors, SQLite state, repository registry state, repository snapshots, model runtime state, old registry contents, and k3d local-path PVC data can be discarded.

### Migration Steps Attempted

1. **Stop Port-Forwards** - No active port-forwards found
2. **Delete Old Cluster** - Successfully deleted `surfbots` cluster
3. **Delete Old Registry** - `k3d-surfbots-dev-platform-registry` was already orphaned and removed
4. **Clean Dev Platform Runtime Data** - Cleared:
   - `qdrant/` (empty)
   - `repos/` (repository snapshots)
   - `data/` (SQLite databases)
   - `runtime/` (Qdrant index)
   - `code-indexer/`, `code-search-api/`, `mcp-server/`
   - Preserved `models/` (Hugging Face cache)
5. **Create Target Registry** - Successfully created `k3d-surfbots-dev-platform-registry`
6. **Create Target Cluster** - FAILED

### Known Issue: k3s cpuset Cgroup

**Error:** `failed to find cpuset cgroup (v2)`

**Root Cause:** k3s requires access to the cpuset cgroup controller for process pinning, which is not available in the container runtime environment.

**Evidence:**
- Host has cpuset available: `cat /sys/fs/cgroup/cgroup.controllers` shows `cpuset`
- Container cgroup: `cat /proc/1/cgroup` shows `0::/init.scope`
- Container cgroup controllers: `cpuset cpu io memory hugetlb pids rdma misc` (cpuset is listed but not accessible)

**Impact:** Cannot create k3d cluster with the current container runtime configuration.

### Resources Created/Deleted

**Deleted:**
- Cluster: `surfbots`
- Network: `k3d-surfbots`, `k3d-surfbots-dev`, `k3d-surfbots-dev-platform`
- Registry: `k3d-surfbots-dev-platform-registry` (recreated)
- Volumes: k3d-managed

**Created:**
- Registry: `k3d-surfbots-dev-platform-registry` (running on k3d-default network)
- Cluster: `surfbots-dev-platform` (NOT created due to cpuset cgroup issue)

**Preserved:**
- `${XDG_DATA_HOME}/surfbots-dev-platform/models/` (Hugging Face model cache)
- `${XDG_DATA_HOME}/surfbots-dev-platform/` directory structure
- `${XDG_STATE_HOME}/surfbots-dev-platform/` directory structure

### Remaining Issue

The k3s cpuset cgroup issue is a system-level limitation that cannot be resolved without modifying the container runtime configuration or using an alternative Kubernetes distribution.

**Recommendation:** Investigate:
1. Container runtime cgroup configuration
2. Alternative Kubernetes distribution (k3s alternative, microk8s, kubeadm)
3. Host-level cgroup v2 configuration

### Status: INCOMPLETE

Phase 4 migration cannot complete due to the cpuset cgroup limitation. The cluster cannot be created until this issue is resolved.

### Next Steps

1. Diagnose and fix cpuset cgroup availability
2. Retry cluster creation
3. Continue with Phases 5-10 once cluster is available
