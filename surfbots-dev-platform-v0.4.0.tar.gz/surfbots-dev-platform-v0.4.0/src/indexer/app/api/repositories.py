"""Repository management endpoints with local filesystem support."""
from fastapi import APIRouter, HTTPException, Query, BackgroundTasks
from typing import List, Optional, Dict, Any
from uuid import uuid4
import logging
import os
from pathlib import Path

from ..core.config import settings
from ..core.database import get_qdrant_client, create_collection, delete_repository_points
from ..services.session_memory import SessionMemoryStore
from ..services import RepositoryParser, CodeIndexer
from ..services.repository_manager import (
    RepositoryRegistry,
    WORKSPACE_BASE,
    
)
from ..models import RepositoryCreate, RepositoryResponse

logger = logging.getLogger(__name__)
router = APIRouter()


def get_registry() -> RepositoryRegistry:
    """Get repository registry instance."""
    return RepositoryRegistry()


def parse_source(source: Any) -> tuple[str, Dict[str, Any]]:
    """Parse source into (source_type, source_dict)."""
    if isinstance(source, dict):
        return source.get("type", "local"), source
    return "local", {"path": str(source)}


def validate_local_path(path_str: str) -> bool:
    """Validate that a local path exists and is accessible."""
    path = Path(path_str)
    return path.exists() and path.is_dir()


def validate_git_repo(path_str: str) -> bool:
    """Validate that a path is a Git repository."""
    try:
        path = Path(path_str)
        git_dir = path / ".git"
        return git_dir.exists() and (git_dir.is_dir() or git_dir.is_file())
    except Exception:
        return False


@router.post("/api/v1/repositories")
async def create_repository(
    repo: RepositoryCreate,
):
    """Register a repository with the indexer.
    
    For local repositories:
    - The source path remains the developer's working tree
    - The indexer sees it at /workspace/repos/<repository_id>
    - No files are copied; only canonical-source metadata is stored
    - The path is validated and synchronized by the host CLI, not this pod
    
    For platform-managed repositories:
    - Surfbots creates and manages the checkout
    - Both source and workspace point to managed locations
    """
    # Parse source
    source_type, source_dict = parse_source(repo.source)
    
    # Get source path
    if source_type == "local" or "path" in source_dict:
        source_path = source_dict.get("path", "")
        if not source_path:
            raise HTTPException(
                status_code=400,
                detail="Local path is required for local filesystem indexing"
            )
    
    # Get or create registry
    registry = get_registry()
    
    try:
        # Register the repository (idempotent for same source)
        # Always store source as a dict for consistency
        source_to_save = source_dict if source_type == "local" else source_dict
        
        result = registry.register_repository(
            name=repo.name,
            source_type=source_type,
            source=source_to_save,
            branch=repo.branch
        )
        
        return result
        
    except ValueError as e:
        # Repository already registered
        raise HTTPException(
            status_code=409,
            detail=str(e)
        )


@router.get("/api/v1/repositories", response_model=Dict[str, Any])
async def list_repositories(
    status: Optional[str] = Query(None, description="Filter by status"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum results"),
    offset: int = Query(0, ge=0, description="Offset for pagination")
):
    """List registered repositories from SQLite registry."""
    registry = get_registry()
    all_repos = registry.list_repositories()
    
    # Filter by status if specified
    if status:
        all_repos = [r for r in all_repos if r.get("status") == status]
    
    # Apply pagination
    paginated = all_repos[offset:offset + limit]
    
    return {
        "repositories": paginated,
        "total": len(all_repos),
        "offset": offset,
        "limit": limit
    }


@router.get("/api/v1/repositories/{repository_id}", response_model=Dict[str, Any])
async def get_repository(repository_id: str):
    """Get repository details from SQLite registry."""
    registry = get_registry()
    repo = registry.get_repository(repository_id)
    
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    
    return repo


@router.delete("/api/v1/repositories/{repository_id}")
async def delete_repository(
    repository_id: str,
    delete_index: bool = True
):
    """Remove a repository from the registry.
    
    This removes:
    - The registry entry in SQLite
    - Platform-managed repository files (if any)
    - Qdrant points for this repository (unless delete_index=False)
    
    It does NOT delete the developer's original working repository.
    """
    registry = get_registry()
    
    # Get repository to verify it exists and get source
    repo = registry.get_repository(repository_id)
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    
    points_deleted = 0
    if delete_index:
        points_deleted = delete_repository_points(repository_id)
        logger.info(f"Deleted {points_deleted} Qdrant points for {repository_id}")
        SessionMemoryStore().delete_repository(repository_id)
        logger.info(f"Deleted Development Memory for {repository_id}")
    
    # Remove from registry
    success = registry.remove_repository(repository_id)
    
    if not success:
        raise HTTPException(status_code=500, detail="Failed to remove repository")
    
    return {
        "repository_id": repository_id,
        "deleted": True,
        "index_deleted": delete_index,
        "points_deleted": points_deleted,
        "source_type": repo.get("source_type"),
        "source": repo.get("source")
    }


@router.post("/api/v1/repositories/{repository_id}/index")
async def index_repository_snapshot(
    repository_id: str,
    background_tasks: BackgroundTasks,
):
    """Index the CURRENT managed snapshot for a repository.

    This does not refresh the snapshot from the developer's canonical source --
    the indexer has no access to it. Use `surfbots-dev repo reindex` for the full
    refresh-then-index lifecycle.
    """
    registry = get_registry()
    repo = registry.get_repository(repository_id)
    
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    
    # Update status to indexing
    registry.update_status(repository_id, "indexing")
    
    if background_tasks:
        background_tasks.add_task(_perform_indexing, repository_id)
        return {"repository_id": repository_id, "status": "indexing started"}
    else:
        # Synchronous indexing (for testing)
        result = await _perform_indexing(repository_id)
        return result


@router.post("/api/v1/repositories/{repository_id}/reindex", deprecated=True)
async def reindex_repository(
    repository_id: str,
    background_tasks: BackgroundTasks,
):
    """Deprecated alias for /index; indexes the managed snapshot only."""
    return await index_repository_snapshot(repository_id, background_tasks)


def _snapshot_path(repository_id: str) -> str:
    """The only tree the indexer is allowed to read."""
    workspace_base = os.environ.get("WORKSPACE_BASE", "/workspace/repos")
    return os.path.join(workspace_base, repository_id)


async def _perform_indexing(repository_id: str) -> Dict[str, Any]:
    """Background task to index the managed snapshot."""
    registry = get_registry()
    repo = registry.get_repository(repository_id)
    
    if not repo:
        return {"error": "Repository not found"}
    
    branch = repo.get("branch", "main")
    snapshot = _snapshot_path(repository_id)

    if not os.path.isdir(snapshot):
        logger.error("Managed snapshot missing for %s at %s", repository_id, snapshot)
        registry.update_status(repository_id, "failed")
        return {"error": f"Managed snapshot not found: {snapshot}"}

    indexer = CodeIndexer()
    
    try:
        # Chunk IDs are fresh UUIDs, so stale points must be dropped or reindex duplicates
        removed = delete_repository_points(repository_id)
        logger.info(f"Cleared {removed} existing points for {repository_id} before reindex")

        result = await indexer.index_repository(
            repository_id,
            {"type": "local", "path": snapshot},
            branch
        )
        
        # Update repository with indexing results
        registry.update_status(
            repository_id,
            "indexed" if result.get("files_indexed", 0) > 0 else "indexed_empty",
            file_count=result.get("files_indexed", 0),
            chunk_count=result.get("chunks_created", 0),
            last_indexed_at=result.get("indexed_at"),
            last_indexed_commit=result.get("indexed_commit")
        )
        
        return result
        
    except Exception as e:
        logger.error(f"Indexing failed for {repository_id}: {e}")
        registry.update_status(repository_id, "failed")
        return {"error": str(e)}


@router.post("/api/v1/sync")
async def sync_repository(
    sync_request: Dict[str, Any]
):
    """Sync working tree changes from a client."""
    repository_id = sync_request.get("repository_id")
    changes = sync_request.get("changes", [])
    base_commit = sync_request.get("base_commit", "")
    
    registry = get_registry()
    repo = registry.get_repository(repository_id)
    
    if not repo:
        raise HTTPException(status_code=404, detail="Repository not found")
    
    indexer = CodeIndexer()
    result = await indexer.sync_repository(
        repository_id,
        changes,
        base_commit
    )
    
    # Update repository with sync results
    registry.update_status(
        repository_id,
        "indexed",
        last_indexed_at=result.get("indexed_at"),
        last_indexed_commit=result.get("indexed_commit")
    )
    
    return result
