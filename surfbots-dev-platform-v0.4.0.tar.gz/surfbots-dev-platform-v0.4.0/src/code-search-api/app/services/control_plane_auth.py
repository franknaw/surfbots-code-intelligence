"""Kubernetes-authenticated access control for local model-management routes."""
from __future__ import annotations

from pathlib import Path

import httpx

from ..core.config import settings


class ControlPlaneUnauthorized(RuntimeError):
    """Raised when a caller is not the dedicated local control-plane identity."""


class KubernetesTokenReviewer:
    """Verify short-lived CLI service-account tokens with Kubernetes TokenReview."""

    def __init__(self, api_base_url: str | None = None, token_path: str | None = None, ca_path: str | None = None):
        self.api_base_url = (api_base_url or self._service_host()).rstrip("/")
        self.token_path = Path(token_path or settings.kubernetes_service_account_token_path)
        self.ca_path = Path(ca_path or settings.kubernetes_service_account_ca_path)

    @staticmethod
    def _service_host() -> str:
        import os

        host = os.environ.get("KUBERNETES_SERVICE_HOST", "")
        port = os.environ.get("KUBERNETES_SERVICE_PORT_HTTPS", "443")
        return f"https://{host}:{port}" if host else ""

    def _server_token(self) -> str:
        if not self.api_base_url or not self.token_path.is_file():
            raise ControlPlaneUnauthorized("Local control-plane authentication is not configured")
        token = self.token_path.read_text(encoding="utf-8").strip()
        if not token:
            raise ControlPlaneUnauthorized("Local control-plane authentication is not configured")
        return token

    async def verify(self, presented_token: str) -> str:
        if not presented_token:
            raise ControlPlaneUnauthorized("Missing local control-plane credential")
        try:
            async with httpx.AsyncClient(verify=str(self.ca_path), timeout=10.0) as client:
                response = await client.post(
                    f"{self.api_base_url}/apis/authentication.k8s.io/v1/tokenreviews",
                    headers={"Authorization": f"Bearer {self._server_token()}"},
                    json={"apiVersion": "authentication.k8s.io/v1", "kind": "TokenReview", "spec": {"token": presented_token}},
                )
                response.raise_for_status()
                status = response.json().get("status", {})
        except (OSError, httpx.HTTPError, ValueError) as error:
            raise ControlPlaneUnauthorized("Local control-plane credential could not be verified") from error
        expected = f"system:serviceaccount:{settings.kubernetes_namespace}:{settings.model_control_service_account}"
        if not status.get("authenticated") or status.get("user", {}).get("username") != expected:
            raise ControlPlaneUnauthorized("Local control-plane credential is not authorized")
        return expected