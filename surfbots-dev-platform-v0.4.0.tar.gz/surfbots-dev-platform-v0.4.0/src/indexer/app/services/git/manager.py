"""Git repository management for code indexing."""
import os
import subprocess
import logging
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime
import tempfile
import shutil
from urllib.parse import urlparse, urlunparse

from ...core.config import settings

logger = logging.getLogger(__name__)


WOKSPACE_BASE = "/workspace/repos"


class GitRepositoryManager:
    """Manages Git repository cloning and checkout for indexing."""
    
    def __init__(self, workspace_base: str = WOKSPACE_BASE):
        self.workspace_base = Path(workspace_base)
        self.workspace_base.mkdir(parents=True, exist_ok=True)
        logger.info(f"Git workspace base: {self.workspace_base}")
    
    def get_repo_path(self, repository_id: str) -> Path:



        """Get the workspace path for a repository."""

        return self.workspace_base / repository_id
    def _get_ssh_key(self) -> Optional[str]:
        """Get SSH key from config or fallback to first public key in ~/.ssh."""
        # First check if SSH key is provided in config
        if settings.ssh_key:
            return settings.ssh_key
        
        # Fallback: try to read the first public key from ~/.ssh
        try:
            home_ssh = Path.home() / ".ssh"
            if home_ssh.exists():
                # Look for .pub files
                pub_files = list(home_ssh.glob("*.pub"))
                if pub_files:
                    # Read the first public key file
                    pub_file = pub_files[0]
                    private_key = pub_file.with_suffix("")
                    if private_key.exists():
                        key_content = private_key.read_text()
                        logger.info(f"Using SSH key from {private_key}")
                        return key_content
        except Exception as e:
            logger.warning(f"Failed to read SSH key from ~/.ssh: {e}")
        
        return None


    
    def _clone_repository(
        self,
        url: str,
        path: Path,
        branch: str = "main",
        username: Optional[str] = None,
        password: Optional[str] = None,
        ssh_key: Optional[str] = None,
        ssh_key_path: Optional[str] = "/root/.ssh/id_rsa"
    ) -> Dict[str, Any]:
        """Clone a repository."""
        logger.info(f"Cloning repository {url} to {path}")
        
        try:
            # Build clone URL with authentication if provided
            clone_url = url
            
            # Handle SSH key authentication
            if not ssh_key:
                # Try to get SSH key from config or fallback
                ssh_key = self._get_ssh_key()
            if ssh_key:
                logger.info("Using SSH key for authentication")
                # Create .ssh directory
                import os
                ssh_dir = path.parent / ".ssh"
                ssh_dir.mkdir(parents=True, exist_ok=True)
                
                # Write SSH key
                key_path = str(ssh_dir / "id_rsa")
                with open(key_path, "w") as f:
                    f.write(ssh_key)
                os.chmod(key_path, 0o600)
                
                # Configure SSH to use the key
                env = os.environ.copy()
                env["GIT_SSH_COMMAND"] = f"ssh -i {key_path} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
                
                # Clone with specific branch
                result = subprocess.run(
                    ["git", "clone", "-b", branch, url, str(path)],
                    capture_output=True,
                    text=True,
                    timeout=120,
                    env=env
                )
            elif username and password:
                # URL encode credentials and inject into URL
                from urllib.parse import quote
                encoded_username = quote(username)
                encoded_password = quote(password)
                parsed = urlparse(url)
                auth_url = f"{parsed.scheme}://{encoded_username}:{encoded_password}@{parsed.netloc}{parsed.path}"
                clone_url = auth_url
                logger.info(f"Using authenticated URL for repository")
                
                # Clone with specific branch
                result = subprocess.run(
                    ["git", "clone", "-b", branch, clone_url, str(path)],
                    capture_output=True,
                    text=True,
                    timeout=120
                )
            else:
                # Clone with specific branch (no auth)
                result = subprocess.run(
                    ["git", "clone", "-b", branch, url, str(path)],
                    capture_output=True,
                    text=True,
                    timeout=120
                )
            
            if result.returncode != 0:
                logger.error(f"Clone failed: {result.stderr}")
                raise Exception(f"Git clone failed: {result.stderr}")
            
            # Get commit hash
            commit_hash = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                cwd=str(path),
                timeout=30
            ).stdout.strip()
            
            return {
                "success": True,
                "commit_hash": commit_hash,
                "cloned_at": datetime.now().isoformat(),
                "branch": branch
            }
        except subprocess.TimeoutExpired:
            raise Exception("Git clone timed out")
        except Exception as e:
            logger.error(f"Error cloning repository: {e}")
            raise
    
    def _fetch_and_checkout(
        self,
        path: Path,
        branch: str = "main",
        commit: Optional[str] = None,
        ssh_key: Optional[str] = None
    ) -> Dict[str, Any]:
        """Fetch and checkout a specific branch or commit."""
        logger.info(f"Fetching and checking out {branch} at {path}")
        
        try:
            # Set up SSH environment if key is provided
            if not ssh_key:
                # Try to get SSH key from config or fallback
                ssh_key = self._get_ssh_key()
            env = None
            if ssh_key:
                logger.info("Using SSH key for fetch operations")
                # Create .ssh directory
                import os
                ssh_dir = path / ".ssh"
                ssh_dir.mkdir(parents=True, exist_ok=True)
                
                # Write SSH key
                key_path = str(ssh_dir / "id_rsa")
                with open(key_path, "w") as f:
                    f.write(ssh_key)
                os.chmod(key_path, 0o600)
                
                # Configure SSH to use the key
                env = os.environ.copy()
                env["GIT_SSH_COMMAND"] = f"ssh -i {key_path} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
            
            # Fetch latest changes
            subprocess.run(
                ["git", "fetch", "origin"],
                capture_output=True,
                text=True,
                cwd=str(path),
                timeout=120,
                env=env
            )
            
            # Checkout branch or specific commit
            ref = commit if commit else branch
            subprocess.run(
                ["git", "checkout", ref],
                capture_output=True,
                text=True,
                cwd=str(path),
                timeout=60,
                env=env
            )
            
            # Get current commit hash
            current_commit = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                cwd=str(path),
                timeout=30,
                env=env
            ).stdout.strip()
            
            return {
                "success": True,
                "commit_hash": current_commit,
                "checked_out_at": datetime.now().isoformat(),
                "branch": branch
            }
        except subprocess.TimeoutExpired:
            raise Exception("Git operation timed out")
        except Exception as e:
            logger.error(f"Error fetching/checkout: {e}")
            raise
    
    def get_or_clone_repository(
        self,
        repository_id: str,
        git_url: str,
        branch: str = "main",
        commit: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        ssh_key: Optional[str] = None
    ) -> Path:
        """Get existing repo or clone a new one."""
        repo_path = self.get_repo_path(repository_id)
        
        if repo_path.exists():
            # Repository exists, fetch and checkout
            logger.info(f"Repository {repository_id} exists, updating...")
            self._fetch_and_checkout(repo_path, branch, commit, ssh_key)
        else:
            # Clone new repository
            logger.info(f"Repository {repository_id} not found, cloning...")
            self._clone_repository(git_url, repo_path, branch, username, password, ssh_key)
        
        return repo_path
    
    def get_current_commit(self, repository_id: str) -> Optional[str]:
        """Get the current commit hash for a repository."""
        repo_path = self.get_repo_path(repository_id)
        
        if not repo_path.exists():
            return None
        
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                cwd=str(repo_path),
                timeout=30
            )
            return result.stdout.strip()
        except Exception as e:
            logger.error(f"Error getting commit: {e}")
            return None
    
    def repository_exists(self, repository_id: str) -> bool:
        """Check if a repository workspace exists."""
        repo_path = self.get_repo_path(repository_id)
        return repo_path.exists() and (repo_path / ".git").is_dir()


# Global instance
_git_manager: Optional[GitRepositoryManager] = None


def get_git_manager() -> GitRepositoryManager:
    """Get or create the global Git manager instance."""
    global _git_manager
    if _git_manager is None:
        _git_manager = GitRepositoryManager()
    return _git_manager
