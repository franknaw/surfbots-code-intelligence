"""Reranker server backed by a real cross-encoder model."""
import logging
import os
import threading
from typing import List, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)

MODEL_ID = os.environ.get("MODEL_ID", "BAAI/bge-reranker-v2-m3")
MODEL_CACHE = os.environ.get("MODEL_CACHE", "/models")
MAX_LENGTH = int(os.environ.get("MAX_LENGTH", "1024"))

app = FastAPI(title=f"{MODEL_ID} Reranker Server")

_model = None
_load_error: Optional[str] = None


class RerankRequest(BaseModel):
    query: str
    documents: List[str]
    top_n: Optional[int] = None
    model: Optional[str] = None


class RerankDocument(BaseModel):
    document: str
    score: float
    index: int


class RerankResponse(BaseModel):
    results: List[RerankDocument]
    model: Optional[str] = None


def _load_model() -> None:
    global _model, _load_error
    try:
        from sentence_transformers import CrossEncoder

        logger.info("Loading reranker model %s (cache=%s)", MODEL_ID, MODEL_CACHE)
        _model = CrossEncoder(
            MODEL_ID,
            max_length=MAX_LENGTH,
            cache_folder=MODEL_CACHE,
            device="cpu",
        )
        logger.info("Reranker model ready")
    except Exception as exc:  # surfaced via /health so the pod stays unready
        _load_error = str(exc)
        logger.exception("Failed to load reranker model")


@app.on_event("startup")
def startup() -> None:
    threading.Thread(target=_load_model, name="model-loader", daemon=True).start()


@app.get("/health")
def health():
    if _model is not None:
        return {"status": "ready", "model": MODEL_ID}
    raise HTTPException(status_code=503, detail=_load_error or "model still loading")


@app.get("/v1/models")
def models():
    return {"object": "list", "data": [{"id": MODEL_ID, "object": "model"}]}


@app.post("/v1/rerank", response_model=RerankResponse)
def rerank(request: RerankRequest):
    if _model is None:
        raise HTTPException(status_code=503, detail=_load_error or "model still loading")
    if not request.documents:
        return RerankResponse(results=[], model=MODEL_ID)

    pairs = [(request.query, doc) for doc in request.documents]
    scores = _model.predict(pairs, batch_size=8)

    ranked = sorted(
        (
            RerankDocument(document=doc, score=float(score), index=idx)
            for idx, (doc, score) in enumerate(zip(request.documents, scores))
        ),
        key=lambda item: item.score,
        reverse=True,
    )

    if request.top_n:
        ranked = ranked[: request.top_n]

    return RerankResponse(results=ranked, model=MODEL_ID)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", "8002")))
