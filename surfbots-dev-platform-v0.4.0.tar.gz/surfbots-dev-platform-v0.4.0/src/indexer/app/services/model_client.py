"""Client for model services (embedding, reranking)."""
import httpx
import asyncio
from typing import List, Optional
from ..models.service_models import (
    EmbeddingRequest,
    EmbeddingResponse,
    EmbeddingsBatchRequest,
    EmbeddingsBatchResponse,
    RerankRequest,
    RerankResponse,
)
from ..core.config import settings
import logging

logger = logging.getLogger(__name__)


class ModelClient:
    """Base client for model services."""

    def __init__(self, endpoint: str):
        self.endpoint = endpoint
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(30.0, connect=10.0),
            headers={"Content-Type": "application/json"}
        )

    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()


class EmbeddingClient(ModelClient):
    """Client for embedding model service."""

    def __init__(self):
        super().__init__(settings.embedding_endpoint)

    async def generate_embedding(self, text: str) -> Optional[EmbeddingResponse]:
        """Generate an embedding for a single text."""
        try:
            response = await self.client.post(
                f"{self.endpoint}/v1/embeddings",
                json={"text": text}
            )
            response.raise_for_status()
            return EmbeddingResponse(**response.json())
        except Exception as e:
            logger.error(f"Failed to generate embedding: {e}")
            return None

    async def generate_embeddings_batch(
        self,
        texts: List[str],
        batch_size: int = 10
    ) -> List[Optional[EmbeddingResponse]]:
        """Generate embeddings for a batch of texts."""
        results = []

        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            batch_results = await asyncio.gather(
                *[self.generate_embedding(text) for text in batch]
            )
            results.extend(batch_results)

        return results


class RerankerClient(ModelClient):
    """Client for reranker model service."""

    def __init__(self):
        super().__init__(settings.reranker_endpoint)

    async def rerank(
        self,
        query: str,
        documents: List[str],
        top_n: Optional[int] = None
    ) -> Optional[RerankResponse]:
        """Rerank documents based on query relevance."""
        try:
            payload = {
                "query": query,
                "documents": documents
            }
            if top_n:
                payload["top_n"] = top_n

            response = await self.client.post(
                f"{self.endpoint}/v1/rerank",
                json=payload
            )
            response.raise_for_status()
            return RerankResponse(**response.json())
        except Exception as e:
            logger.error(f"Failed to rerank documents: {e}")
            return None