"""Database connection and Qdrant client management."""

import logging
from typing import Optional

from qdrant_client import QdrantClient
from qdrant_client.models import (
    CollectionInfo,
    Distance,
    FieldCondition,
    Filter,
    FilterSelector,
    MatchValue,
    VectorParams,
)

from .config import settings


logger = logging.getLogger(__name__)

CODE_INDEX_COLLECTION = "code-index"

# Global Qdrant client instance
_qdrant_client: Optional[QdrantClient] = None


def get_qdrant_client() -> QdrantClient:
    """Get or create the shared Qdrant client."""
    global _qdrant_client

    if _qdrant_client is None:
        logger.info("Connecting to Qdrant at %s", settings.qdrant_url)
        _qdrant_client = QdrantClient(
            url=settings.qdrant_url,
            api_key=settings.qdrant_api_key,
            timeout=30,
        )

    return _qdrant_client


# Expose client directly for convenience.
qdrant_client = get_qdrant_client()


def create_collection(
    collection_name: str,
    vector_size: int = 1024,
    force: bool = False,
) -> bool:
    """Ensure a Qdrant collection exists with the requested vector size.

    Args:
        collection_name: Name of the collection.
        vector_size: Required vector dimension.
        force: Recreate the collection when its dimensions do not match.

    Returns:
        True when the collection exists with the correct dimensions.
        False when initialization fails or dimensions are incompatible and
        ``force`` is False.
    """
    client = get_qdrant_client()

    try:
        try:
            info: CollectionInfo = client.get_collection(
                collection_name=collection_name
            )
            actual_size = info.config.params.vectors.size

            if actual_size == vector_size:
                logger.info(
                    "Collection %s already exists with correct dimensions (%d)",
                    collection_name,
                    vector_size,
                )
                return True

            if not force:
                logger.warning(
                    "Collection %s has wrong dimensions (%s vs %s)",
                    collection_name,
                    actual_size,
                    vector_size,
                )
                return False

            logger.warning(
                "Collection %s has wrong dimensions (%s vs %s); recreating",
                collection_name,
                actual_size,
                vector_size,
            )
            client.delete_collection(collection_name=collection_name)

        except Exception as exc:
            # A missing collection is expected on a fresh platform.
            error_text = str(exc).lower()
            if "not found" not in error_text and "404" not in error_text:
                logger.warning(
                    "Error checking collection %s: %s",
                    collection_name,
                    exc,
                )

        client.create_collection(
            collection_name=collection_name,
            vectors_config=VectorParams(
                size=vector_size,
                distance=Distance.COSINE,
            ),
        )

        logger.info(
            "Created collection %s with %d dimensions",
            collection_name,
            vector_size,
        )
        return True

    except Exception:
        logger.exception(
            "Failed to initialize collection %s",
            collection_name,
        )
        return False


def ensure_code_index_collection() -> None:
    """Ensure the platform's shared code-index collection is ready.

    This is intended to run during application startup so a freshly
    bootstrapped platform has its Qdrant schema before any repositories
    are registered or indexed.
    """
    if not create_collection(
        CODE_INDEX_COLLECTION,
        vector_size=settings.qdrant_vector_size,
        force=True,
    ):
        raise RuntimeError(
            f"Failed to initialize Qdrant collection "
            f"'{CODE_INDEX_COLLECTION}'"
        )

    logger.info(
        "Collection '%s' ready with %d dimensions",
        CODE_INDEX_COLLECTION,
        settings.qdrant_vector_size,
    )


def delete_collection(collection_name: str) -> bool:
    """Delete a Qdrant collection."""
    client = get_qdrant_client()

    try:
        client.delete_collection(collection_name=collection_name)
        logger.info("Deleted collection: %s", collection_name)
        return True

    except Exception:
        logger.exception("Failed to delete collection %s", collection_name)
        return False


def validate_collection_dimensions(
    collection_name: str,
    expected_size: int,
) -> tuple[bool, str]:
    """Validate that a collection's vector dimensions match the expected size."""
    client = get_qdrant_client()

    try:
        info: CollectionInfo = client.get_collection(
            collection_name=collection_name
        )
        actual_size = info.config.params.vectors.size

        if actual_size == expected_size:
            return (
                True,
                f"Collection '{collection_name}' has correct "
                f"dimensions ({actual_size})",
            )

        return (
            False,
            f"Dimension mismatch: collection has {actual_size} "
            f"but expected {expected_size}",
        )

    except Exception as exc:
        return (
            False,
            f"Failed to validate collection '{collection_name}': {exc}",
        )


def delete_file_points(
    repository_id: str,
    file_path: str,
    collection_name: str = CODE_INDEX_COLLECTION,
) -> int:
    """Delete every point for one file within one repository.

    Scoped by both fields so replacing a file never touches another repository.

    Returns:
        Number of points removed.
    """
    client = get_qdrant_client()

    file_filter = Filter(
        must=[
            FieldCondition(
                key="repository_id",
                match=MatchValue(value=repository_id),
            ),
            FieldCondition(
                key="file_path",
                match=MatchValue(value=file_path),
            ),
        ]
    )

    try:
        before = client.count(
            collection_name=collection_name,
            count_filter=file_filter,
            exact=True,
        ).count

        if before:
            client.delete(
                collection_name=collection_name,
                points_selector=FilterSelector(filter=file_filter),
                wait=True,
            )

        logger.info(
            "Deleted %d points for file %s/%s",
            before,
            repository_id,
            file_path,
        )
        return before

    except Exception:
        logger.exception(
            "Deleting points for %s/%s failed",
            repository_id,
            file_path,
        )
        raise


def delete_repository_points(
    repository_id: str,
    collection_name: str = CODE_INDEX_COLLECTION,
) -> int:
    """Delete every point belonging to a repository.

    Repository isolation is performed with the ``repository_id`` payload
    field rather than separate per-repository Qdrant collections.

    Returns:
        Number of points removed.
    """
    client = get_qdrant_client()

    repo_filter = Filter(
        must=[
            FieldCondition(
                key="repository_id",
                match=MatchValue(value=repository_id),
            )
        ]
    )

    try:
        before = client.count(
            collection_name=collection_name,
            count_filter=repo_filter,
            exact=True,
        ).count

        if before:
            client.delete(
                collection_name=collection_name,
                points_selector=FilterSelector(filter=repo_filter),
                wait=True,
            )

        logger.info(
            "Deleted %d points for repository %s",
            before,
            repository_id,
        )
        return before

    except Exception as exc:
        # A missing collection means there is nothing to delete.
        logger.warning(
            "Could not delete points for repository %s from %s: %s",
            repository_id,
            collection_name,
            exc,
        )
        return 0