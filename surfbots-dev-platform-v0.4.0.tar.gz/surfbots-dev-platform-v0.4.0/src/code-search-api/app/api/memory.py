"""Development Memory API endpoints."""
import logging
from datetime import datetime
from time import perf_counter

from fastapi import APIRouter, HTTPException, Query

from ..models.service_models import SessionMemoryCheckpoint
from ..services.search_metrics import record_memory_operation, record_search_request
from ..services.search_service import search_service

logger = logging.getLogger(__name__)
router = APIRouter()


async def _resolve(repository_id: str) -> str:
    """Accept a repository name or ID so memory is addressed like the search tools.

    Checkpoints are partitioned by the literal value stored here, so an
    unresolved name would silently create a partition nothing else can find.
    """
    return await search_service.resolve_repository_id(repository_id) or repository_id


@router.post("/api/v1/repositories/{repository_id}/memory", status_code=201)
async def create_memory(repository_id: str, checkpoint: SessionMemoryCheckpoint):
    """Create a concise, repository-scoped session checkpoint."""
    record_search_request("memory_create")
    repository_id = await _resolve(repository_id)
    started = perf_counter()
    try:
        result = await search_service.indexer.create_session_memory(
            repository_id, checkpoint.model_dump(mode="json", exclude_none=True)
        )
        if "error" in result:
            raise HTTPException(status_code=502, detail="Development Memory service unavailable")
        record_memory_operation("create", "success", (perf_counter() - started) * 1000)
        return result
    except Exception:
        record_memory_operation("create", "error", (perf_counter() - started) * 1000)
        raise


@router.get("/api/v1/repositories/{repository_id}/memory/recent")
async def recent_memory(
    repository_id: str,
    limit: int = Query(default=5, ge=1, le=20),
):
    """Return the repository's most recent session checkpoints."""
    record_search_request("memory_recent")
    repository_id = await _resolve(repository_id)
    return await _record_retrieval("recent", search_service.indexer.get_recent_session_memory(repository_id, limit))


@router.post("/api/v1/repositories/{repository_id}/memory/search")
async def search_memory(
    repository_id: str,
    query: str = Query(..., min_length=1, max_length=2_000),
    limit: int = Query(default=10, ge=1, le=20),
    memory_type: list[str] | None = Query(default=None),
    retention_class: list[str] | None = Query(default=None),
    file_path: str | None = None,
    symbol: str | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
):
    """Semantically retrieve repository-scoped Development Memory."""
    record_search_request("memory_search")
    repository_id = await _resolve(repository_id)
    result = await _record_retrieval("search", search_service.indexer.search_session_memory(
        repository_id,
        query,
        limit=limit,
        memory_type=memory_type,
        retention_class=retention_class,
        file_path=file_path,
        symbol=symbol,
        created_after=created_after.isoformat() if created_after else None,
        created_before=created_before.isoformat() if created_before else None,
    ))
    return result


@router.get("/api/v1/repositories/{repository_id}/memory/context")
async def memory_context(
    repository_id: str,
    limit: int = Query(default=10, ge=1, le=20),
    created_after: datetime | None = None,
):
    """Return bounded, agent-ready Development Memory context."""
    record_search_request("memory_context")
    repository_id = await _resolve(repository_id)
    return await _record_retrieval("context", search_service.indexer.get_session_memory_context(
        repository_id,
        limit,
        created_after.isoformat() if created_after else None,
    ))


async def _record_retrieval(kind: str, request):
    """Return a retrieval response and aggregate its latency/outcome only."""
    started = perf_counter()
    try:
        result = await request
        if "error" in result:
            raise HTTPException(status_code=502, detail="Development Memory service unavailable")
        outcome = "empty" if not result.get("records") else "success"
        record_memory_operation(kind, outcome, (perf_counter() - started) * 1000)
        return result
    except Exception:
        record_memory_operation(kind, "error", (perf_counter() - started) * 1000)
        raise
    if "error" in result:
        raise HTTPException(status_code=502, detail="Development Memory service unavailable")
    return result


@router.delete("/api/v1/repositories/{repository_id}/memory/{memory_id}", status_code=204)
async def delete_memory(repository_id: str, memory_id: str):
    """Delete a single repository-scoped session checkpoint."""
    repository_id = await _resolve(repository_id)
    result = await search_service.indexer.delete_session_memory(repository_id, memory_id)
    if "error" in result:
        raise HTTPException(status_code=502, detail="Development Memory service unavailable")