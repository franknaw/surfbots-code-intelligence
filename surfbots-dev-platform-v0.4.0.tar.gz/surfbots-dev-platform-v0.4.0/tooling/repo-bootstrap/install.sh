#!/bin/bash
# Surfbots Dev Platform - Repo Bootstrap Script
# Usage: ./install.sh <repo-path>

set -e

REPO_PATH="${1:-.}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$(dirname "$SCRIPT_DIR")")"

# Resolve to absolute path
REPO_PATH=$(cd "$REPO_PATH" 2>/dev/null && pwd || echo "$REPO_PATH")
REPO_NAME=$(basename "$REPO_PATH")

# Detect git info
REPO_BRANCH=$(cd "$REPO_PATH" && git branch --show-current 2>/dev/null || echo "main")
REPO_COMMIT=$(cd "$REPO_PATH" && git rev-parse HEAD 2>/dev/null || echo "unknown")
REPO_REMOTE=$(cd "$REPO_PATH" && git remote get-url origin 2>/dev/null || echo "local")

# Detect languages (simple heuristic)
LANGUAGES=$(cd "$REPO_PATH" && find . -type f \( -name "*.py" -o -name "*.ts" -o -name "*.js" -o -name "*.go" -o -name "*.rs" \) | head -20 | xargs -I{} sh -c 'file {}' 2>/dev/null | grep -oE 'Python|TypeScript|JavaScript|Go|Rust' | sort -u | tr '\n' ',' || echo "unknown")

# Get host workspace root (for dev mode)
# Try common workspace patterns dynamically
HOST_WORKSPACE=""
HOME_DIR="$HOME"

# Try common workspace patterns under home
for pattern in "projects" "code" "work" "repos"; do
    candidate="$HOME_DIR/$pattern"
    if [ -d "$candidate" ]; then
        if echo "$REPO_PATH" | grep -q "^$candidate/"; then
            HOST_WORKSPACE="$candidate"
            break
        fi
    fi
done

# If no pattern found, use repo's parent as workspace
if [ -z "$HOST_WORKSPACE" ]; then
    HOST_WORKSPACE="$(dirname "$REPO_PATH")"
fi

# Platform workspace root
PLATFORM_WORKSPACE="/workspaces"

# Calculate path inside platform
cd "$REPO_PATH"
REPO_RELATIVE=$(pwd | sed "s|^$HOST_WORKSPACE/||")
PLATFORM_PATH="$PLATFORM_WORKSPACE/$REPO_RELATIVE"

echo "=== Surfbots Dev Platform - Repository Bootstrap ==="
echo ""
echo "Repository: $REPO_NAME"
echo "Path: $REPO_PATH"
echo "Branch: $REPO_BRANCH"
echo "Commit: $REPO_COMMIT"
echo "Remote: $REPO_REMOTE"
echo "Languages: $LANGUAGES"
echo ""
echo "Platform mapping:"
echo "  Host:    $HOST_WORKSPACE -> $REPO_PATH"
echo "  Platform: $PLATFORM_WORKSPACE -> $PLATFORM_PATH"
echo ""

# Create .surfbots directory
mkdir -p "$REPO_PATH/.surfbots"

# Create config.yaml
cat > "$REPO_PATH/.surfbots/config.yaml" << EOF
repository:
  name: $REPO_NAME
  path: $REPO_PATH
  branch: $REPO_BRANCH
  commit: $REPO_COMMIT
  remote: $REPO_REMOTE
  languages: $LANGUAGES

surfbots:
  mcpUrl: http://localhost:8003
  searchApi: http://localhost:8001
  platformPath: $PLATFORM_PATH

index:
  profile: code-default
  mode: incremental
  autoSync: true

workspace:
  hostRoot: $HOST_WORKSPACE
  platformRoot: $PLATFORM_WORKSPACE
EOF

echo "✓ Created .surfbots/config.yaml"

# Copy Cline rules
cp "$SCRIPT_DIR/.clinerules/surfbots-code-search.md" "$REPO_PATH/.clinerules/"
echo "✓ Installed .clinerules/surfbots-code-search.md"

echo ""
echo "=== Next Steps ==="
echo ""
echo "1. Verify platform is running:"
echo "   surfbots-dev status (or check platform documentation)"
echo ""
echo "2. Register repository with platform:"
echo "   curl -X POST http://localhost:8001/api/v1/repositories \\\n     -H 'Content-Type: application/json' \\\n     -d @.surfbots/config.yaml"
echo ""
echo "3. Trigger indexing:"
echo "   curl -X POST http://localhost:8001/api/v1/indexes"
echo ""
echo "4. Check status:"
echo "   curl http://localhost:8001/api/v1/repositories/$REPO_NAME"
echo ""
echo "Done! 🚀"
