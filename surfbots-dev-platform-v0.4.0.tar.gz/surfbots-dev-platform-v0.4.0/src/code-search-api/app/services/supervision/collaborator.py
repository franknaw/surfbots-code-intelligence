"""Task collaboration orchestration.

Helps Cline resolve meaningful decisions, blockers, conflicts, unexpected
constraints, and uncertainty during implementation."""
from typing import Any, Optional
import logging

from ..generation_client import GenerationUnavailable
from ..search_service import search_service
from .parsing import InvalidGenerationResponse, parse_with_retry
from .roles import get_role, new_budget, role_runner
from .validation import (
    validate_collaborator_response,
    build_correction_message,
    ValidationError,
    validate_current_state_consistency,
    build_current_state_correction_message,
    CurrentStateValidationError
)

logger = logging.getLogger(__name__)

COLLABORATOR_SCHEMA = {
    "assessment": str,
    "recommendation": str,
    "next_steps": list,
    "risks": list,
    "requires_user_decision": bool,
}

MAX_CODE_SNIPPETS = 3
MAX_MEMORY_RECORDS = 2
MAX_SNIPPET_CHARS = 500
MAX_VALIDATION_ATTEMPTS = 2  # First attempt + one correction retry


class RepositoryNotFound(LookupError):
    """Raised when the requested repository is not registered."""


class ValidationFailed(RuntimeError):
    """Raised when validation fails after all retry attempts."""
    
    def __init__(self, message: str, last_error: ValidationError):
        super().__init__(message)
        self.last_error = last_error


async def _resolve(repository: str) -> tuple[str, dict[str, Any]]:
    """Resolve a name or ID and confirm the repository exists."""
    status = await search_service.get_repository_status(repository)
    if "error" in status:
        raise RepositoryNotFound(f"Repository not found: {repository}")
    return status.get("repository_id") or repository, status


async def _gather_evidence(
    repository_id: str,
    task: str,
    current_state: str,
    question: str,
    budget
) -> list[str]:
    """Offer evidence to the budget in priority order, whole sections only.
    
    Evidence Priority for collaborator:
    1. Explicit task/question/current_state (user intent and current facts)
    2. Repository evidence that directly relates to the question
    3. Semantic search results
    4. Development Memory
    """
    sections: list[str] = []
    
    # First, prioritize the explicit user-supplied context
    # These are authoritative about the architecture and current state
    state_label = "current_state"
    state_text = f"Current implementation state:\n{current_state}"
    budget.offer(state_label, state_text)
    if state_label in budget.included:
        sections.append(state_text)
    
    task_label = "task_context"
    task_text = f"Task intent:\n{task}"
    budget.offer(task_label, task_text)
    if task_label in budget.included:
        sections.append(task_text)
    
    question_label = "question_context"
    question_text = f"Question to resolve:\n{question}"
    budget.offer(question_label, question_text)
    if question_label in budget.included:
        sections.append(question_text)
    
    # Then retrieve repository code for context
    try:
        search_query = question[:100] if len(question) > 100 else question
        results = await search_service.search(
            query=search_query, repository_id=repository_id, limit=MAX_CODE_SNIPPETS
        )
    except Exception:
        logger.warning("Code retrieval failed during collaboration", exc_info=True)
        results = {"results": []}

    for item in results.get("results", [])[:MAX_CODE_SNIPPETS]:
        snippet = (item.get("chunk_content") or "")[:MAX_SNIPPET_CHARS]
        if not snippet:
            continue
        label = f"code:{item.get('file_path')}"
        budget.offer(label, f"Repository file {item.get('file_path')}:\n{snippet}")
        if label in budget.included:
            sections.append(f"Repository file {item.get('file_path')}:\n{snippet}")

    try:
        memory = await search_service.indexer.get_session_memory_context(
            repository_id, limit=MAX_MEMORY_RECORDS
        )
    except Exception:
        logger.warning("Memory retrieval failed during collaboration", exc_info=True)
        memory = {}

    for record in (memory.get("records") or [])[:MAX_MEMORY_RECORDS]:
        summary = record.get("summary", "")
        if not summary:
            continue
        label = f"memory:{record.get('memory_id')}"
        budget.offer(label, summary)
        if label in budget.included:
            sections.append(f"Prior decision: {summary}")

    return sections


def _build_prompt(
    task: str,
    refined_task: Optional[str],
    current_state: str,
    question: str,
    evidence: list[str],
    options: Optional[list[str]],
) -> str:
    # Evidence hierarchy in prompt (higher priority first):
    # 1. User-supplied task and context (authoritative about intent and architecture)
    # 2. Refined specification (if available, grounded in repository evidence)
    # 3. Repository code and memory (supporting evidence)
    # 4. Candidate approaches (if provided)
    
    parts = []
    
    # User intent is authoritative - state it first and emphasize it
    parts.append(f"TASK AND ARCHITECTURAL CONTEXT (authoritative):\n{task}")
    parts.append(f"CURRENT IMPLEMENTATION STATE (authoritative facts about current state):\n{current_state}")
    parts.append(f"QUESTION TO RESOLVE:\n{question}")

    if refined_task:
        parts.append(f"\nREFINED SPECIFICATION (if available):\n{refined_task}")

    if options:
        parts.append("\nCANDIDATE APPROACHES (if provided):\n" + "\n\n".join(f"- {opt}" for opt in options))

    if evidence:
        parts.append("\nREPOSITORY EVIDENCE (supporting context for decision):\n\n" + "\n\n".join(evidence))

    return "\n\n".join(parts)


def _build_validated_response(
    repository_id: str,
    development_task_id: Optional[str],
    response: dict[str, Any],
    raw: dict[str, Any]
) -> dict[str, Any]:
    """Build a response dict with the standard structure."""
    from .roles import get_role
    role = get_role("collaborator")
    
    return {
        "repository_id": repository_id,
        "development_task_id": development_task_id,
        **response,
        "generation": {
            "role": role.name,
            "prompt_version": role.prompt_version,
            "duration_seconds": raw.get("duration_seconds"),
            "prompt_tokens": raw.get("prompt_tokens"),
            "completion_tokens": raw.get("completion_tokens"),
            "profile_id": (raw.get("runtime_execution") or {}).get("profile_id"),
            "provider": (raw.get("runtime_execution") or {}).get("provider"),
            "connection_id": (raw.get("runtime_execution") or {}).get("connection_id"),
            "model": (raw.get("runtime_execution") or {}).get("model"),
        },
    }


async def _collaborate_with_validation(
    repository_id: str,
    task: str,
    current_state: str,
    question: str,
    refined_task: Optional[str],
    options: Optional[list[str]],
    development_task_id: Optional[str],
    budget,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Execute collaboration with deterministic constraint validation.
    
    This function:
    1. Runs the model generation
    2. Parses the JSON response
    3. Validates against architectural constraints
    4. If invalid, applies correction retry
    5. Returns a safe fallback if validation repeatedly fails
    """
    role = get_role("collaborator")
    prompt = _build_prompt(task, refined_task, current_state, question, [], options)
    
    correction = None
    last_error = None
    
    for attempt in range(MAX_VALIDATION_ATTEMPTS):
        async def call(correction_text):
            return await role_runner.run(role, prompt, repository_id=repository_id, correction=correction_text)
        
        try:
            response, raw = await parse_with_retry(call, COLLABORATOR_SCHEMA, allow_retry=False)
        except InvalidGenerationResponse:
            # Parsing failed - let it propagate
            raise
        
        # Validate the parsed response
        is_valid, error = validate_collaborator_response(
            task, current_state, question, response
        )
        
        if not is_valid:
            # Architectural validation failed
            last_error = error
            correction = build_correction_message(error)
            logger.info(
                "Collaborator validation failed (architectural), applying correction (attempt %d/%d): %s",
                attempt + 1, MAX_VALIDATION_ATTEMPTS, error
            )
        else:
            # Check current-state consistency
            is_valid, state_error = validate_current_state_consistency(
                current_state, response
            )
            
            if not is_valid:
                # Current-state validation failed
                last_error = state_error
                correction = build_current_state_correction_message(state_error)
                logger.info(
                    "Collaborator validation failed (current-state), applying correction (attempt %d/%d): %s",
                    attempt + 1, MAX_VALIDATION_ATTEMPTS, state_error
                )
        
        if is_valid:
            return response, raw
        logger.info(
            "Collaborator validation failed, applying correction (attempt %d/%d): %s",
            attempt + 1, MAX_VALIDATION_ATTEMPTS, error
        )
    
    # All attempts exhausted with validation failures
    # Return a safe structured fallback
    
    # Determine the type of error and format message accordingly
    if isinstance(last_error, ValidationError):
        error_type = "architectural"
        error_detail = last_error.constraint
        error_message = f"Constraint violation: {last_error.constraint}"
    elif isinstance(last_error, CurrentStateValidationError):
        error_type = "current-state"
        error_detail = last_error.completed_work or last_error.remaining_work or "inconsistent"
        error_message = f"Current-state violation: {error_detail}"
    else:
        error_type = "unknown"
        error_detail = str(last_error)
        error_message = str(last_error)
    
    safe_fallback = {
        "assessment": (
            f"Unable to produce a grounded recommendation that satisfies the {error_type} "
            f"constraint: {error_detail}"
        ),
        "recommendation": (
            f"The {error_type} constraint in current_state must be preserved. "
            "A valid production-readiness improvement cannot be identified without "
            "first resolving this constraint. "
            "This may require user decision or constraint review."
        ),
        "next_steps": [],
        "risks": [error_message],
        "requires_user_decision": True,
    }
    
    # Build a minimal raw response for the fallback
    raw_fallback = {
        "duration_seconds": None,
        "prompt_tokens": None,
        "completion_tokens": None,
    }
    
    return safe_fallback, raw_fallback


async def collaborate_task(
    repository: str,
    task: str,
    current_state: str,
    question: str,
    refined_task: Optional[str] = None,
    options: Optional[list[str]] = None,
    development_task_id: Optional[str] = None,
) -> dict[str, Any]:
    """Help resolve a meaningful decision during implementation."""
    repository_id, status = await _resolve(repository)

    role = get_role("collaborator")
    budget = new_budget(role)

    evidence = await _gather_evidence(repository_id, task, current_state, question, budget)

    response, raw = await _collaborate_with_validation(
        repository_id, task, current_state, question,
        refined_task, options, development_task_id, budget
    )

    return _build_validated_response(
        repository_id, development_task_id, response, raw
    )
