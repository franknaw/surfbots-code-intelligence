"""Health check endpoint."""
from fastapi import APIRouter, HTTPException
from ..core.database import get_qdrant_client

router = APIRouter()


@router.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy"}


@router.get("/ready")
async def ready():
    """Readiness check endpoint."""
    try:
        client = get_qdrant_client()
        client.get_collections()
        return {"status": "ready"}
    except Exception as e:
        raise HTTPException(status_code=503, detail=str(e))


@router.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint."""
    return {
        "service": "code-indexer",
        "version": "0.1.0",
        "status": "running"
    }