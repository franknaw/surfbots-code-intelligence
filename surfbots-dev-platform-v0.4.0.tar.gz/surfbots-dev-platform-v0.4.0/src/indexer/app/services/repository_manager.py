"""Repository Manager - Local filesystem repository management.

This module handles local filesystem scanning, Git integration,
and file enumeration for the Surfbots Dev Platform.
"""

import os
import hashlib
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
import fnmatch
import yaml
import sqlite3
import uuid
import shutil
import logging

logger = logging.getLogger(__name__)


@dataclass
class FileInfo:
    """Information about an indexed file."""
    path: str
    sha256: str
    size: int
    modified_at: str
    language: Optional[str] = None
    file_type: Optional[str] = None


class RepositoryManager:
    """Manages local repository filesystem operations.
    
    Provides Git-aware file enumeration and local filesystem scanning
    for the Surfbots Dev Platform.
    """
    
    def __init__(self, repo_path: str, branch: str = "main"):
        """Initialize the repository manager.
        
        Args:
            repo_path: Path to the repository directory
            branch: Branch to index (default: main)
        """
        self.repo_path = Path(repo_path).resolve()
        self.branch = branch
        self.git_repo = self._is_git_repo()
    
    def _is_git_repo(self) -> bool:
        """Check if the path is a Git repository."""
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--git-dir"],
                cwd=self.repo_path,
                capture_output=True,
                timeout=10
            )
            return result.returncode == 0
        except Exception:
            return False
    
    def _get_git_tracked_files(self) -> Set[str]:
        """Get all tracked files in Git repository."""
        try:
            result = subprocess.run(
                ["git", "ls-files"],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                return set(result.stdout.strip().split("\n"))
        except Exception as e:
            print(f"Git ls-files failed: {e}")
        return set()
    
    def _get_git_untracked_files(self) -> Set[str]:
        """Get untracked files from Git."""
        try:
            result = subprocess.run(
                ["git", "ls-files", "--others", "--exclude-standard"],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                return set(result.stdout.strip().split("\n"))
        except Exception as e:
            print(f"Git ls-files (untracked) failed: {e}")
        return set()
    
    def _load_gitignore(self) -> List[str]:
        """Load .gitignore patterns."""
        gitignore_path = self.repo_path / ".gitignore"
        if gitignore_path.exists():
            with open(gitignore_path, "r") as f:
                return [line.strip() for line in f if line.strip() and not line.startswith("#")]
        return []
    
    def _matches_gitignore(self, path: str, patterns: List[str]) -> bool:
        """Check if a path matches any .gitignore pattern."""
        path_parts = Path(path).parts
        
        for pattern in patterns:
            # Handle different pattern formats
            if pattern.startswith("/"):
                # Root-relative pattern
                if fnmatch.fnmatch(str(path), pattern[1:]):
                    return True
            else:
                # Match against any path component
                for part in path_parts:
                    if fnmatch.fnmatch(part, pattern):
                        return True
        
        return False
    
    def _should_include_file(self, path: str, gitignore_patterns: List[str]) -> bool:
        """Determine if a file should be included in indexing."""
        # Skip common non-code files
        skip_extensions = {
            ".pyc", ".pyo", ".pyd", ".so", ".o", ".a", ".lib",
            ".pyc", ".pyo", ".pyd", ".so", ".o", ".a", ".lib",
            ".git", ".svn", ".hg", ".DS_Store", ".gitignore",
            ".gitattributes", ".dockerignore", ".env", ".env.*",
            ".idea", ".vscode", "__pycache__", "node_modules",
            "venv", ".venv", "env", "venv", ".pytest_cache",
            ".cache", ".temp", "build", "dist", "egg-info"
        }
        
        path_lower = path.lower()
        
        # Check extension
        if Path(path).suffix.lower() in {".pyc", ".pyo", ".pyd", ".so", ".o", ".a"}:
            return False
        
        # Check directory names
        for part in Path(path).parts:
            if part in skip_extensions:
                return False
            if part.startswith(".") and part not in ".git":
                return False
        
        # Check .gitignore patterns
        if self._matches_gitignore(path, gitignore_patterns):
            return False
        
        return True
    
    def get_files(self) -> List[FileInfo]:
        """Get all files to be indexed.
        
        For Git repos: Uses git ls-files for accurate, fast enumeration
        For non-Git dirs: Recursively scans filesystem
        
        Returns:
            List of FileInfo objects for all indexable files
        """
        files = []
        gitignore_patterns = self._load_gitignore()
        
        if self.git_repo:
            # Git-aware file enumeration
            tracked = self._get_git_tracked_files()
            untracked = self._get_git_untracked_files()
            all_files = tracked | untracked
            
            for rel_path in all_files:
                full_path = self.repo_path / rel_path
                
                if not full_path.exists() or not full_path.is_file():
                    continue
                
                if not self._should_include_file(rel_path, gitignore_patterns):
                    continue
                
                try:
                    file_info = self._get_file_info(full_path, rel_path)
                    if file_info:
                        files.append(file_info)
                except Exception as e:
                    print(f"Error processing {rel_path}: {e}")
        else:
            # Regular recursive scan for non-Git directories
            for root, dirs, filenames in os.walk(self.repo_path):
                # Filter out ignored directories
                dirs[:] = [
                    d for d in dirs 
                    if not d.startswith(".") and d not in {"node_modules", "venv", ".venv", "__pycache__"}
                ]
                
                for filename in filenames:
                    full_path = Path(root) / filename
                    rel_path = str(full_path.relative_to(self.repo_path))
                    
                    if not self._should_include_file(rel_path, gitignore_patterns):
                        continue
                    
                    try:
                        file_info = self._get_file_info(full_path, rel_path)
                        if file_info:
                            files.append(file_info)
                    except Exception as e:
                        print(f"Error processing {rel_path}: {e}")
        
        return files
    
    def _get_file_info(self, full_path: Path, rel_path: str) -> Optional[FileInfo]:
        """GetFileInfo for a single file."""
        try:
            stat = full_path.stat()
            
            # Calculate SHA256
            sha256 = self._calculate_sha256(full_path)
            
            return FileInfo(
                path=rel_path,
                sha256=sha256,
                size=stat.st_size,
                modified_at=datetime.fromtimestamp(stat.st_mtime).isoformat(),
                language=self._detect_language(full_path),
                file_type=self._detect_file_type(full_path)
            )
        except Exception as e:
            print(f"Error getting file info for {rel_path}: {e}")
            return None
    
    def _calculate_sha256(self, file_path: Path) -> str:
        """Calculate SHA256 hash of a file."""
        sha256_hash = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    sha256_hash.update(chunk)
            return sha256_hash.hexdigest()
        except Exception:
            return ""
    
    def _detect_language(self, file_path: Path) -> Optional[str]:
        """Detect programming language from file extension."""
        extension_map = {
            ".py": "python",
            ".pyi": "python",
            ".pyw": "python",
            ".js": "javascript",
            ".ts": "typescript",
            ".jsx": "javascript",
            ".tsx": "typescript",
            ".java": "java",
            ".go": "go",
            ".rs": "rust",
            ".c": "c",
            ".h": "c",
            ".cpp": "cpp",
            ".hpp": "cpp",
            ".cc": "cpp",
            ".cxx": "cpp",
            ".hxx": "cpp",
            ".cs": "csharp",
            ".rb": "ruby",
            ".php": "php",
            ".swift": "swift",
            ".kt": "kotlin",
            ".scala": "scala",
            ".sh": "bash",
            ".bash": "bash",
            ".zsh": "bash",
            ".json": "json",
            ".yaml": "yaml",
            ".yml": "yaml",
            ".xml": "xml",
            ".html": "html",
            ".css": "css",
            ".scss": "scss",
            ".sass": "sass",
            ".sql": "sql",
            ".md": "markdown",
            ".rst": "rst",
            ".tex": "latex",
            ".dockerfile": "dockerfile",
            "Dockerfile": "dockerfile"
        }
        
        return extension_map.get(file_path.suffix.lower())
    
    def _detect_file_type(self, file_path: Path) -> Optional[str]:
        """Detect file type from extension."""
        extension_map = {
            ".py": "source",
            ".js": "source",
            ".ts": "source",
            ".java": "source",
            ".go": "source",
            ".rs": "source",
            ".c": "source",
            ".cpp": "source",
            ".cs": "source",
            ".rb": "source",
            ".php": "source",
            ".swift": "source",
            ".kt": "source",
            ".scala": "source",
            ".sh": "script",
            ".bash": "script",
            ".zsh": "script",
            ".json": "config",
            ".yaml": "config",
            ".yml": "config",
            ".xml": "config",
            ".html": "template",
            ".css": "stylesheet",
            ".md": "documentation",
            ".md": "documentation",
            ".md": "documentation",
            ".md": "documentation",
            ".md": "documentation"
        }
        
        return extension_map.get(file_path.suffix.lower())


class RepositoryWatcher:
    """ Watches filesystem for changes."""
    
    def __init__(self, repo_path: str, callback=None):
        """Initialize the watcher.
        
        Args:
            repo_path: Path to watch
            callback: Function to call on change
        """
        self.repo_path = Path(repo_path).resolve()
        self.callback = callback
        self._running = False
        self._watcher = None
    
    def start(self):
        """Start watching for changes."""
        try:
            import watchdog.events
            import watchdog.observers
            
            class ChangeHandler(watchdog.events.FileSystemEventHandler):
                def __init__(self, callback, repo_path):
                    self.callback = callback
                    self.repo_path = repo_path
                
                def on_modified(self, event):
                    if not event.is_directory:
                        self._handle_change("modified", event.src_path)
                
                def on_created(self, event):
                    if not event.is_directory:
                        self._handle_change("created", event.src_path)
                
                def on_deleted(self, event):
                    if not event.is_directory:
                        self._handle_change("deleted", event.src_path)
                
                def _handle_change(self, change_type: str, path: str):
                    rel_path = str(Path(path).relative_to(self.repo_path))
                    if self.callback:
                        self.callback(change_type, rel_path)
            
            self._watcher = watchdog.observers.Observer()
            self._watcher.schedule(
                ChangeHandler(self.callback, self.repo_path),
                str(self.repo_path),
                recursive=True
            )
            self._watcher.start()
            self._running = True
            
        except ImportError:
            print("Warning: watchdog not installed. Install with: pip install watchdog")
    
    def stop(self):
        """Stop watching for changes."""
        if self._watcher:
            self._watcher.stop()
            self._watcher.join()
        self._running = False


# ============================================================================
# Repository Registry - SQLite-based repository metadata management
# ============================================================================

# Container paths (no host XDG assumptions in Kubernetes)
REPOSITORY_REGISTRY_DB = os.environ.get("REPOSITORY_DB", "/var/lib/surfbots/repositories.db")
WORKSPACE_BASE = os.environ.get("WORKSPACE_BASE", "/workspace/repos")


def ensure_registry_dirs():
    """Ensure repository registry directories exist."""
    os.makedirs(os.path.dirname(REPOSITORY_REGISTRY_DB), exist_ok=True)
    os.makedirs(WORKSPACE_BASE, exist_ok=True)


def get_registry_connection():
    """Get a connection to the repository registry database."""
    ensure_registry_dirs()
    conn = sqlite3.connect(REPOSITORY_REGISTRY_DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_registry():
    """Initialize the repository registry database."""
    ensure_registry_dirs()
    conn = get_registry_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS repositories (
            repository_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            source_type TEXT NOT NULL,
            source TEXT NOT NULL,
            branch TEXT NOT NULL DEFAULT 'main',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'registered',
            file_count INTEGER NOT NULL DEFAULT 0,
            chunk_count INTEGER NOT NULL DEFAULT 0,
            last_indexed_at TEXT,
            last_indexed_commit TEXT
        )
    """)
    
    # Create index for faster lookups
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_repositories_status ON repositories(status)
    """)
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_repositories_source ON repositories(source)
    """)
    
    conn.commit()
    conn.close()


class RepositoryRegistry:
    """Manages repository metadata in SQLite.
    
    The registry stores:
    - repository_id: Unique identifier for the repository
    - source_type: 'local' or 'git'
    - source: The original repository path (e.g., /home/user/projects/foo)
    - branch: The branch to index
    - status: 'registered', 'indexing', 'indexed', 'failed'
    - file_count, chunk_count: Indexing statistics
    """
    
    def __init__(self):
        """Initialize the repository registry."""
        init_registry()
    
    def _get_connection(self):
        """Get a database connection."""
        return get_registry_connection()
    
    def register_repository(
        self,
        name: str,
        source_type: str,
        source: str,
        branch: str = "main"
    ) -> Dict[str, Any]:
        """Register a new repository.
        
        Args:
            name: Repository name
            source_type: 'local' or 'git'
            source: The original repository path
            branch: Branch to index (default: main)
            
        Returns:
            Dictionary with repository information
            
        Raises:
            ValueError: If repository already registered
        """
        # Handle source as dict or string
        if isinstance(source, dict):
            source_path = source.get("path", "")
            if source_type == "local":
                source = source_path
            else:
                source = str(Path(source_path).resolve())
        else:
            source = str(Path(source).resolve())
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        # Check if already registered (idempotent registration)
        cursor.execute(
            "SELECT repository_id FROM repositories WHERE source = ?",
            (source,)
        )
        existing = cursor.fetchone()
        if existing:
            conn.close()
            raise ValueError(
                f"Repository already registered with ID: {existing['repository_id']}"
            )
        
        # Generate unique repository ID
        repository_id = f"repo_{uuid.uuid4().hex[:12]}"
        
        # Determine workspace path (where indexer sees the repo)
        workspace_path = os.path.join(WORKSPACE_BASE, repository_id)
        
        # Create workspace directory for local repositories
        # For local repos, we copy files to make them accessible in k3d
        os.makedirs(os.path.dirname(workspace_path), exist_ok=True)
        
        if source_type == "local":
            # For local repositories, we copy files to the workspace
            # This makes them accessible inside the k3d container
            # The k3d volume mounts /mnt/surfbots/repos -> /workspace/repos
            logger.info(f"Copying repository from {source} to workspace at {workspace_path}")
            try:
                if os.path.islink(workspace_path):
                    os.unlink(workspace_path)
                elif os.path.isdir(workspace_path):
                    shutil.rmtree(workspace_path)
                
                # Copy the entire repository to workspace
                shutil.copytree(source, workspace_path, symlinks=True)
                logger.info(f"Copied {source} to {workspace_path}")
            except Exception as e:
                logger.error(f"Failed to copy repository to workspace: {e}")
                # If copy fails, we'll use the source path directly
                # This might work if the source is accessible inside container
                workspace_path = source
        
        current_time = datetime.now().isoformat()
        
        cursor.execute("""
            INSERT INTO repositories (
                repository_id, name, source_type, source, branch,
                created_at, updated_at, status, file_count, chunk_count
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            repository_id,
            name,
            source_type,
            source,
            branch,
            current_time,
            current_time,
            "registered",
            0,
            0
        ))
        
        conn.commit()
        conn.close()
        
        return {
            "repository_id": repository_id,
            "name": name,
            "source_type": source_type,
            "source": source,
            "branch": branch,
            "status": "registered",
            "workspace_path": workspace_path,
            "created_at": current_time
        }
    
    def get_repository(self, repository_id: str) -> Optional[Dict[str, Any]]:
        """Get repository by ID."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT * FROM repositories WHERE repository_id = ?",
            (repository_id,)
        )
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return dict(row)
        return None
    
    def get_repository_by_source(self, source: str) -> Optional[Dict[str, Any]]:
        """Get repository by source path."""
        source = str(Path(source).resolve())
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT * FROM repositories WHERE source = ?",
            (source,)
        )
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return dict(row)
        return None
    
    def list_repositories(self) -> List[Dict[str, Any]]:
        """List all registered repositories."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM repositories ORDER BY created_at DESC")
        rows = cursor.fetchall()
        conn.close()
        
        return [dict(row) for row in rows]
    
    def update_status(
        self,
        repository_id: str,
        status: str,
        file_count: Optional[int] = None,
        chunk_count: Optional[int] = None,
        last_indexed_at: Optional[str] = None,
        last_indexed_commit: Optional[str] = None
    ) -> bool:
        """Update repository status and metrics."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        updates = ["status = ?", "updated_at = ?"]
        values = [status, datetime.now().isoformat()]
        
        if file_count is not None:
            updates.append("file_count = ?")
            values.append(file_count)
        if chunk_count is not None:
            updates.append("chunk_count = ?")
            values.append(chunk_count)
        if last_indexed_at is not None:
            updates.append("last_indexed_at = ?")
            values.append(last_indexed_at)
        if last_indexed_commit is not None:
            updates.append("last_indexed_commit = ?")
            values.append(last_indexed_commit)
        
        values.append(repository_id)
        
        cursor.execute(
            f"UPDATE repositories SET {', '.join(updates)} WHERE repository_id = ?",
            values
        )
        
        conn.commit()
        conn.close()
        
        return cursor.rowcount > 0
    
    def remove_repository(self, repository_id: str) -> bool:
        """Remove a repository from the registry.

        Managed snapshots are host-side CLI state. The indexer must not mutate
        them because it only has a read-only view of /workspace/repos.
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        # Get the repository source
        cursor.execute(
            "SELECT source, source_type FROM repositories WHERE repository_id = ?",
            (repository_id,)
        )
        row = cursor.fetchone()
        
        if not row:
            conn.close()
            return False
        
        # Delete the registry entry
        cursor.execute(
            "DELETE FROM repositories WHERE repository_id = ?",
            (repository_id,)
        )
        
        conn.commit()
        conn.close()

        return True
