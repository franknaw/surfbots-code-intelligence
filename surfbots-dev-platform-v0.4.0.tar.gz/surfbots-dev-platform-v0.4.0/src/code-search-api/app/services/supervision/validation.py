"""Deterministic validation for Development Supervision responses."""
from typing import Any, Optional
import re


# Architectural constraint patterns to detect - includes both exact and partial matches
# The constraint patterns are designed to match common constraint phrases in current_state
STANDALONE_CONSTRAINTS = [
    "standalone",
    "independent of source checkout",  # without "the"
    "independent of the source checkout",  # with "the"
    "independent of source checkout",  # duplicate for emphasis
    "not coupled",
    "decoupled",
    "independent of repository",
    "independent of checkout",  # partial match for "independently of checkout"
    "independent of source",    # partial match
    "independently of source checkout",  # exact phrase with "ly"
    "independently of the source checkout",  # with "ly" and "the"
]

# Regex patterns for re-coupling detection
RE_COUPLING_PHRASES = [
    ("integrate.*?build system", "integrate into build system"),
    ("integrate.*?project build system", "integrate into project build system"),
    ("integrate.*?repository build system", "integrate into repository build system"),
    ("add.*?dependency", "add as project dependency"),  # Match "add as a project dependency"
    ("add.*?repository.*?dependency", "add as repository dependency"),
    ("couple.*?source checkout", "couple to source checkout"),
    ("couple.*?repository", "couple to repository"),
    ("couple to source", "couple to source checkout"),
    ("integrate into the project", "integrate into project"),
    ("integrate into the repository", "integrate into repository"),
    ("integrate into repository", "integrate into repository"),
    ("integrated into project", "integrated into project"),
    ("integrated into repository", "integrated into repository"),
    ("integrated into the build", "integrated into build"),
]

SHARED_INFRASTRUCTURE_PHRASES = [
    "shared MCP endpoint",
    "shared Qdrant collection",
    "shared resource",
    "shared infrastructure",
]

# Per-repository isolation patterns - detects both "per-" and "Each X should have its own"
PER_REPOSITORY_PHRASES = [
    "per-repository",
    "per repository",
    "per-project",
    "per project",
    "each.*?should have its own",  # Pattern for "Each X should have its own"
    "every.*?should have its own",  # Pattern for "Every X should have its own"
]


# Current-state consistency validation markers
# Explicit completion indicators in authoritative current_state
COMPLETED_MARKERS = [
    "validated",
    "validated end-to-end",
    "fully validated",
    "completed",
    "complete",
    "done",
    "already implemented",
    "implemented",
    "working",
    "successfully tested",
    "finished",
    "verified",
]

# Explicit remaining-work indicators in authoritative current_state
REMAINING_MARKERS = [
    "not yet validated",
    "not yet been validated",
    "not been validated",
    "not validated",
    "not yet implemented",
    "not implemented",
    "incomplete",
    "remaining",
    "still needs",
    "needs validation",
    "needs implementation",
    "pending",
    "unresolved",
    "not yet tested",
]


def _extract_authoritative_constraints(context: str) -> list[str]:
    """Extract explicit architectural constraints from authoritative context."""
    constraints = []
    context_lower = context.lower()
    
    for constraint in STANDALONE_CONSTRAINTS:
        if constraint.lower() in context_lower:
            constraints.append(f"standalone:{constraint}")
    
    for phrase in SHARED_INFRASTRUCTURE_PHRASES:
        if phrase.lower() in context_lower:
            constraints.append(f"shared:{phrase}")
    
    return constraints


def _contains_re_coupling(recommendation: str) -> Optional[str]:
    """Check if recommendation contains re-coupling language.
    
    Returns the violated constraint phrase if found, None otherwise.
    """
    rec_lower = recommendation.lower()
    
    for pattern, description in RE_COUPLING_PHRASES:
        if re.search(pattern, rec_lower):
            return description
    
    return None


def _is_per_repo_recommendation_vs_shared_constraint(
    recommendation: str,
    shared_constraints: list[str]
) -> Optional[str]:
    """Check if recommendation would split shared infrastructure into per-repo.
    
    Returns the violated constraint if found, None otherwise.
    """
    rec_lower = recommendation.lower()
    
    # If the recommendation suggests making something per-repo/project
    # but the context says it's currently shared, that's a contradiction
    for phrase in PER_REPOSITORY_PHRASES:
        if phrase.lower() in rec_lower or re.search(phrase, rec_lower):
            # Check if there's a shared constraint that would be violated
            for shared in shared_constraints:
                if shared.startswith("shared:"):
                    return f"Cannot make {shared[7:]} per-repository when currently shared"
    
    return None


class ValidationError(Exception):
    """Raised when a collaborator response violates an architectural constraint."""
    
    def __init__(self, message: str, constraint: str, response_part: str):
        super().__init__(message)
        self.constraint = constraint
        self.response_part = response_part


def validate_collaborator_response(
    task: str,
    current_state: str,
    question: str,
    response: dict[str, Any]
) -> tuple[bool, Optional[ValidationError]]:
    """Validate a collaborator response against authoritative constraints.
    
    Args:
        task: The authoritative task description
        current_state: The authoritative current state (may contain constraints)
        question: The question being answered
        response: The parsed collaborator response dict
    
    Returns:
        Tuple of (is_valid, error_or_none)
    """
    # Extract constraints from authoritative context
    constraints = _extract_authoritative_constraints(current_state)
    shared_constraints = [c for c in constraints if c.startswith("shared:")]
    
    # Get response components to validate
    assessment = response.get("assessment", "")
    recommendation = response.get("recommendation", "")
    next_steps = response.get("next_steps", [])
    risks = response.get("risks", [])
    
    # Collect all text to validate
    all_text = f"{assessment}\n{recommendation}"
    for step in next_steps:
        all_text += f"\n{step}"
    for risk in risks:
        all_text += f"\n{risk}"
    
    # Check for re-coupling violations
    for constraint in constraints:
        if constraint.startswith("standalone:"):
            constraint_text = constraint[9:]  # Remove "standalone:" prefix
            violated = _contains_re_coupling(all_text)
            if violated:
                error = ValidationError(
                    f"Response violates standalone constraint: '{constraint_text}'",
                    constraint_text,
                    f"contains re-coupling: '{violated}'"
                )
                return False, error
    
    # Check for per-repo vs shared constraints
    for shared_constraint in shared_constraints:
        shared_text = shared_constraint[7:]  # Remove "shared:" prefix
        violated = _is_per_repo_recommendation_vs_shared_constraint(all_text, shared_constraints)
        if violated:
            error = ValidationError(
                f"Response would split shared infrastructure: '{shared_text}'",
                shared_text,
                violated
            )
            return False, error
    
    return True, None


def build_correction_message(error: ValidationError) -> str:
    """Build a correction message for the model.
    
    The correction:
    1. Identifies the violated constraint
    2. Shows what part of the response violated it
    3. Instructs to preserve the constraint
    4. Asks for the highest-value improvement that respects the constraint
    """
    return f"""Your response violates an authoritative architectural constraint.

Constraint: {error.constraint}

The current implementation explicitly maintains this constraint.

Your response contained: {error.response_part}

This directly contradicts the stated architecture. The model MUST preserve
the explicit architectural constraint in all recommendations.

Produce a new recommendation that:
1. Preserves the stated architecture (do not reverse or weaken the constraint)
2. Identifies the highest-value production-readiness improvement
3. Is supported by evidence from the repository

Do not recommend:
- Integrating standalone tools into build systems
- Adding standalone tools as dependencies
- Making shared resources per-project or per-repository
- Reversing explicit architectural constraints

Respond with a single JSON object only, no Markdown fences."""


class CurrentStateValidationError(RuntimeError):
    """Raised when a response repeats completed work or ignores remaining work."""
    
    def __init__(self, message: str, completed_work: str, remaining_work: Optional[str] = None):
        super().__init__(message)
        self.completed_work = completed_work
        self.remaining_work = remaining_work


def _parse_current_state_work(current_state: str) -> dict[str, Any]:
    """Parse authoritative current_state to identify completed and remaining work.
    
    Returns a dict with:
    - completed_items: list of work items marked as completed
    - remaining_items: list of work items marked as remaining/unvalidated
    
    The parsing is context-aware - it detects negations like "not yet validated".
    """
    result = {
        "completed_items": [],
        "remaining_items": []
    }
    
    # First check for remaining work markers (more specific patterns)
    for marker in REMAINING_MARKERS:
        marker_lower = marker.lower()
        idx = current_state.lower().find(marker_lower)
        if idx != -1:
            # Found a remaining work marker
            start = max(0, current_state.lower().rfind(".", 0, idx) + 1)
            end = current_state.lower().find(".", idx)
            if end == -1:
                end = len(current_state)
            context = current_state[start:end].strip()
            
            if context and len(context) > 10:
                result["remaining_items"].append(context)
    
    # Then check for completed work markers
    # But exclude contexts that also contain "not" or similar negations
    for marker in COMPLETED_MARKERS:
        marker_lower = marker.lower()
        idx = current_state.lower().find(marker_lower)
        if idx != -1:
            # Find all occurrences
            start = max(0, current_state.lower().rfind(".", 0, idx) + 1)
            end = current_state.lower().find(".", idx)
            if end == -1:
                end = len(current_state)
            context = current_state[start:end].strip()
            
            if context and len(context) > 10:
                # Check if this context has a negation
                context_lower = context.lower()
                # Check for common negation patterns
                negation_patterns = ["not ", "not yet", "not been", "not been validated"]
                has_negation = any(neg in context_lower for neg in negation_patterns)
                
                # If no negation, add to completed
                if not has_negation:
                    result["completed_items"].append(context)
    
    return result


def _extract_key_noun_phrases(text: str) -> list[str]:
    """Extract key noun phrases from text for comparison."""
    # Remove validation markers and extract key phrases
    markers_to_remove = [
        "not yet", "not", "has been", "has not been", "has not yet been",
        "has not", "is not", "are not", "was not", "were not",
        "has not yet", "is not yet", "are not yet", "was not yet", "were not yet",
        "has not been", "is not been", "are not been", "was not been", "were not been",
        "yet", "been", "to prove", "to demonstrate", "end-to-end", "fully",
        "validated", "validated.", "validate", "validation", "test", "tested",
        "implemented", "implement", "verification", "verified"
    ]
    
    simplified = text.lower()
    for marker in markers_to_remove:
        simplified = simplified.replace(marker, "")
    
    simplified = " ".join(simplified.split())
    
    # Remove trailing punctuation
    simplified = simplified.strip(". ,;:!?")
    
    # Return as a list with the simplified phrase
    if simplified and len(simplified) > 5:  # Skip very short phrases
        return [simplified]
    return []


def _contains_completed_work_recommendation(text: str, completed_items: list[str]) -> Optional[str]:
    """Check if recommendation/review/next_steps re-proposes completed work.
    
    Returns the completed work item that's being recommended again, or None.
    """
    text_lower = text.lower()
    
    for completed in completed_items:
        # Extract key phrases from completed work
        key_phrases = _extract_key_noun_phrases(completed)
        
        # Check if any key phrase appears in a validation context
        for phrase in key_phrases:
            for word in ["validate", "test", "verify", "check"]:
                if word in text_lower and phrase in text_lower:
                    return completed
    
    return None
    """Check if recommendation/review/next_steps re-proposes completed work.
    
    Returns the completed work item that's being recommended again, or None.
    
    Strategy: Extract key noun phrases from completed work and check if they
    appear in a validation action in the recommendation.
    """
    text_lower = text.lower()
    
    for completed in completed_items:
        # Extract key phrases from completed work
        simplified_completed = _extract_key_noun_phrases(completed)
        
        # Check if any key phrase appears in a validation context
        patterns = [
            rf"validate.*?{re.escape(simplified_completed)}",
            rf"test.*?{re.escape(simplified_completed)}",
            rf"implement.*?{re.escape(simplified_completed)}",
            rf"verify.*?{re.escape(simplified_completed)}",
            rf"ensure.*?{re.escape(simplified_completed)}",
        ]
        
        # Check if any key phrase appears in a validation context
        for pattern in patterns:
            if re.search(pattern, text_lower):
                return completed
        
        # Also check for direct mentions of any key phrase
        for key_phrase in simplified_completed:
            if key_phrase and key_phrase in text_lower:
                # But only if it's in a validation context
                for word in ["validate", "test", "verify", "check"]:
                    if word in text_lower:
                        return completed
    
    return None


def _contains_remaining_work_recommendation(text: str, remaining_items: list[str]) -> bool:
    """Check if recommendation targets remaining work (not completed work).
    
    Returns True if at least one remaining item is addressed.
    
    Strategy: Extract key noun phrases from remaining work and check if they appear
    in the recommendation text with a validation action.
    """
    text_lower = text.lower()
    
    for remaining in remaining_items:
        remaining_lower = remaining.lower()
        
        # Extract key phrases by removing common validation markers
        markers_to_remove = [
            "not yet", "not", "has been", "has not been", "has not yet been",
            "has not", "is not", "are not", "was not", "were not",
            "has not yet", "is not yet", "are not yet", "was not yet", "were not yet",
            "has not been", "is not been", "are not been", "was not been", "were not been",
            "yet", "been", "to prove", "to demonstrate"
        ]
        
        # Create a simplified version of the remaining work
        simplified = remaining_lower
        for marker in markers_to_remove:
            simplified = simplified.replace(marker, "")
        
        # Clean up extra spaces and punctuation
        simplified = " ".join(simplified.split())
        simplified = simplified.strip(". ,;:!?")
        
        # Check if the simplified phrase is in the text (must be a substantial match)
        if simplified and len(simplified) > 5 and simplified in text_lower:
            return True
        
        # Check for specific work item mentions
        # Must match at least 2 key words to avoid false positives with generic words
        key_words = [w for w in simplified.split() if len(w) > 3]
        
        for word in key_words:
            if word in text_lower:
                # Must be in a validation context
                for action in ["validate", "test", "verify", "check", "validate the", "test the"]:
                    if action in text_lower:
                        # Count how many key words appear in the text
                        matching_words = sum(1 for kw in key_words if kw in text_lower)
                        if matching_words >= 2:  # Require at least 2 matching key words
                            return True
                        # Also check if the entire phrase appears (for short phrases)
                        if len(simplified.split()) <= 4 and simplified in text_lower:
                            return True
    
    return False


def validate_current_state_consistency(
    current_state: str,
    response: dict[str, Any]
) -> tuple[bool, Optional[CurrentStateValidationError]]:
    """Validate that response doesn't repeat completed work or ignore remaining work.
    
    Args:
        current_state: The authoritative current state (may contain completed/remaining markers)
        response: The parsed collaborator response dict
    
    Returns:
        Tuple of (is_valid, error_or_none)
    """
    parsed = _parse_current_state_work(current_state)
    completed_items = parsed["completed_items"]
    remaining_items = parsed["remaining_items"]
    
    # Nothing to validate if no markers found
    if not completed_items and not remaining_items:
        return True, None
    
    # Get response components
    recommendation = response.get("recommendation", "")
    next_steps = "\n".join(response.get("next_steps", []))
    risks = "\n".join(response.get("risks", []))
    assessment = response.get("assessment", "")
    
    all_text = f"{assessment}\n{recommendation}\n{next_steps}\n{risks}"
    
    # Check 1: Does recommendation re-propose completed work?
    for completed in completed_items:
        if _contains_completed_work_recommendation(all_text, [completed]):
            error = CurrentStateValidationError(
                f"Response re-proposes completed work: '{completed}'",
                completed,
                None
            )
            return False, error
    
    # Check 2: When there's explicit remaining work, does recommendation address it?
    if remaining_items:
        # Recommendation and next_steps should target remaining work
        if not _contains_remaining_work_recommendation(all_text, remaining_items):
            error = CurrentStateValidationError(
                "Response does not address explicitly remaining work in current_state",
                None,
                ", ".join(remaining_items[:3])  # Show first 3 remaining items
            )
            return False, error
    
    return True, None


def build_current_state_correction_message(error: CurrentStateValidationError) -> str:
    """Build a correction message for current-state consistency violations.
    
    The correction:
    1. Identifies which work is already completed
    2. Shows what work remains to be done
    3. Instructs to focus on remaining work, not completed work
    """
    completed_part = f"Completed work in current_state: {error.completed_work}" if error.completed_work else ""
    remaining_part = f"Remaining work in current_state: {error.remaining_work}" if error.remaining_work else ""
    
    return f"""Your response does not correctly reflect the current implementation state.

{completed_part if error.completed_work else ""}

{remaining_part if error.remaining_work else ""}

Do not recommend repeating work that is explicitly marked as completed.
When current_state identifies remaining/unvalidated work, recommend that work instead.
Respond with a single JSON object only, no Markdown fences."""
