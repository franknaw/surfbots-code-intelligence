"""Resolve logical roles from the currently active generation/supervision profile."""
from __future__ import annotations

from dataclasses import dataclass

from .generation_provider import AzureOpenAIProvider, GenerationProvider, GenerationUnavailable, LocalOpenAIProvider, OpenAICompatibleProvider
from .model_profiles import ModelProfile, ProviderConnectionError, ProviderConnectionStore, provider_connection_store
from ..core.config import settings


@dataclass(frozen=True)
class ResolvedRole:
    """Effective role routing chosen at request time, without credential data."""

    role_key: str
    profile_id: str
    provider: str
    model: str
    connection_id: str | None
    client: GenerationProvider
    close_after_request: bool = False


class RoleResolver:
    """The single runtime mapping from logical role to provider and model."""

    def __init__(self, local_provider: GenerationProvider, store: ProviderConnectionStore | None = None):
        self.local_provider = local_provider
        self.store = store or provider_connection_store

    async def resolve_role(self, role_key: str) -> ResolvedRole:
        return await self.resolve_profile_role(self.store.get_active_profile(), role_key)

    async def resolve_profile_role(self, profile: ModelProfile, role_key: str) -> ResolvedRole:
        """Resolve a candidate profile for validation without changing runtime state."""
        try:
            binding = profile.roles[role_key]
        except KeyError as error:
            raise GenerationUnavailable(f"Active profile does not bind role '{role_key}'") from error
        if binding.provider == "local":
            if not self.local_provider.configured:
                raise GenerationUnavailable("Local generation provider is not configured")
            return ResolvedRole(
                role_key=role_key,
                profile_id=profile.id,
                provider=binding.provider,
                model=binding.model,
                connection_id=binding.connection_id,
                client=self.local_provider,
            )
        try:
            connection = await self.store.get(binding.connection_id or "")
            if not connection.enabled:
                raise GenerationUnavailable(f"Provider connection '{connection.id}' is disabled")
            if connection.provider_type != binding.provider:
                raise GenerationUnavailable(
                    f"Role '{role_key}' provider does not match connection '{connection.id}'"
                )
            token = await self.store.credentials.get(connection.id)
        except ProviderConnectionError as error:
            raise GenerationUnavailable(f"Provider connection is unavailable: {error}") from error
        if not token and binding.provider != "local-openai":
            raise GenerationUnavailable(f"Provider connection '{connection.id}' has no configured token")
        return ResolvedRole(
            role_key=role_key,
            profile_id=profile.id,
            provider=binding.provider,
            model=binding.model,
            connection_id=binding.connection_id,
            client=AzureOpenAIProvider(
                base_url=connection.base_url,
                deployment_name=binding.model,
                api_key=token,
                timeout_seconds=settings.generation_timeout_seconds,
                max_concurrency=settings.generation_max_concurrency,
                api_version=connection.api_version or "2025-04-01-preview",
            ) if binding.provider == "azure-openai" else LocalOpenAIProvider(
                base_url=connection.base_url,
                model=binding.model,
                bearer_token=token if token else None,
                timeout_seconds=settings.generation_timeout_seconds,
                max_concurrency=settings.generation_max_concurrency,
            ) if binding.provider == "local-openai" else OpenAICompatibleProvider(
                base_url=connection.base_url,
                model=binding.model,
                bearer_token=token,
                timeout_seconds=settings.generation_timeout_seconds,
                max_concurrency=settings.generation_max_concurrency,
            ),
            close_after_request=True,
        )