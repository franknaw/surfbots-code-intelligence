"""Tests that installed client artifacts teach supervision behaviour.

These assert on what `surfbots-dev init` actually writes into a repository, so a
template edit that forgets a client cannot pass silently.
"""
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

BOOTSTRAP = Path(__file__).resolve().parent
PLATFORM_ROOT = BOOTSTRAP.parents[1]
CLI = BOOTSTRAP / "surfbots-dev"

CLINE_RULE = ".clinerules/surfbots-development-context.md"
CLINE_SKILL = ".clinerules/skills/surfbots-development-context/SKILL.md"
COPILOT_INSTRUCTION = ".github/instructions/surfbots-development-context.instructions.md"
COPILOT_SKILL = ".github/skills/surfbots-development-context/SKILL.md"


@pytest.fixture(scope="module")
def installed(tmp_path_factory):
    """Run the real init once into a throwaway repository."""
    target = tmp_path_factory.mktemp("repo")
    (target / "src").mkdir()
    (target / "src" / "main.py").write_text("x = 1\n")
    result = subprocess.run(
        [sys.executable, str(CLI), "init", str(target)],
        capture_output=True, text=True, timeout=120,
    )
    assert result.returncode in (0, None), result.stderr
    return target


def read(repo: Path, relative: str) -> str:
    path = repo / relative
    assert path.exists(), f"init did not install {relative}"
    return path.read_text()


def test_cline_rule_is_installed(installed):
    assert read(installed, CLINE_RULE)


def test_cline_rule_teaches_refine_and_review(installed):
    rule = read(installed, CLINE_RULE)
    assert "refine_task" in rule
    assert "review_changes" in rule


def test_cline_rule_bounds_review_cycles(installed):
    rule = read(installed, CLINE_RULE)
    assert "two" in rule.lower()
    assert "cycle" in rule.lower()


def test_cline_rule_exempts_trivial_work(installed):
    rule = read(installed, CLINE_RULE).lower()
    assert "trivial" in rule
    assert "typo" in rule


def test_cline_rule_rejects_treating_partial_review_as_success(installed):
    rule = read(installed, CLINE_RULE)
    assert "incomplete_review" in rule
    assert "not proof of correctness" in rule


def test_cline_rule_keeps_existing_retrieval_guidance(installed):
    rule = read(installed, CLINE_RULE)
    for tool in ("repository_status", "get_recent_context", "search_repository_memory", "search_code"):
        assert tool in rule, f"{tool} guidance must survive the supervision update"


def test_cline_skill_is_installed_with_supervision(installed):
    skill = read(installed, CLINE_SKILL)
    assert "refine_task" in skill
    assert "review_changes" in skill
    assert "unable_to_review" in skill


def test_cline_skill_lists_both_new_tools(installed):
    skill = read(installed, CLINE_SKILL)
    tools_section = skill.split("Available Surfbots MCP Tools")[-1]
    assert "refine_task" in tools_section
    assert "review_changes" in tools_section


def test_copilot_instruction_is_installed_with_supervision(installed):
    instruction = read(installed, COPILOT_INSTRUCTION)
    assert "refine_task" in instruction
    assert "review_changes" in instruction
    assert "incomplete_review" in instruction


def test_copilot_skill_is_installed_with_supervision(installed):
    skill = read(installed, COPILOT_SKILL)
    assert "refine_task" in skill
    assert "review_changes" in skill
    assert "coverage" in skill.lower()


def test_copilot_skill_description_mentions_review(installed):
    skill = read(installed, COPILOT_SKILL)
    header = skill.split("---")[1]
    assert "review" in header.lower(), "description drives whether the Skill is invoked at all"


def test_both_clients_describe_the_same_verdicts(installed):
    cline = read(installed, CLINE_SKILL)
    copilot = read(installed, COPILOT_SKILL)
    for verdict in ("no_issues_found", "needs_changes", "incomplete_review", "unable_to_review"):
        assert verdict in cline, f"{verdict} missing from Cline skill"
        assert verdict in copilot, f"{verdict} missing from Copilot skill"


def test_neither_client_claims_review_proves_correctness(installed):
    for relative in (CLINE_SKILL, COPILOT_SKILL):
        text = read(installed, relative)
        assert "Not proof of correctness." in text


def test_repeated_init_does_not_duplicate_content(installed):
    before = read(installed, CLINE_RULE)
    subprocess.run(
        [sys.executable, str(CLI), "init", str(installed)],
        capture_output=True, text=True, timeout=120,
    )
    after = read(installed, CLINE_RULE)
    assert before == after
    assert after.count("## Development Supervision") == 1


def test_repeated_init_keeps_one_skill_directory(installed):
    subprocess.run(
        [sys.executable, str(CLI), "init", str(installed)],
        capture_output=True, text=True, timeout=120,
    )
    skills = list((installed / ".clinerules" / "skills").iterdir())
    assert len(skills) == 1


def test_init_preserves_unrelated_client_files(tmp_path):
    repo = tmp_path / "repo2"
    (repo / ".clinerules").mkdir(parents=True)
    (repo / ".clinerules" / "team-conventions.md").write_text("keep me\n")

    subprocess.run(
        [sys.executable, str(CLI), "init", str(repo)],
        capture_output=True, text=True, timeout=120,
    )

    assert (repo / ".clinerules" / "team-conventions.md").read_text() == "keep me\n"
    assert (repo / CLINE_RULE).exists()
