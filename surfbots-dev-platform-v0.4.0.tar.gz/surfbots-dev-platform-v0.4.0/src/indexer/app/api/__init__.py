"""API routes for the code indexer."""
from .repositories import router as repositories_router
from .indexes import router as indexes_router
from .search import router as search_router
from .symbols import router as symbols_router
from .files import router as files_router
from .files_incremental import router as files_incremental_router
from .health import router as health_router
from .memory import router as memory_router

__all__ = [
    "repositories_router",
    "indexes_router",
    "search_router",
    "symbols_router",
    "files_router",
    "files_incremental_router",
    "health_router",
    "memory_router",
]
