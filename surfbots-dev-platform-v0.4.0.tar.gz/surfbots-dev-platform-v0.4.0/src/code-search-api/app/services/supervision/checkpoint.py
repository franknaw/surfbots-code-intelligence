"""Stateful Development Supervision checkpoint orchestration.

Implements stateful checkpoint tracking to enforce that substantial development
tasks require meaningful Devstral collaboration before final review.

The checkpoint workflow is:

    refine -> investigate -> post_investigation -> implement -> post_implementation
    -> test -> post_test -> ... -> pre_review -> review

Checkpoint phases:
- post_investigation: After repository investigation, before implementation
- post_implementation: After implementation, before testing
- post_test: After meaningful test evidence exists
- failure_analysis: When non-trivial test/runtime failure occurs
- milestone_complete: At meaningful milestone completion
- pre_review: Before final review_changes

Workflow state is persisted using Development Memory/Qdrant, scoped by
repository_id + development_task_id. Each checkpoint invocation actually
calls the configured Devstral collaborator role.
"""
import logging
import os
from typing import Any, Optional

import httpx

from ..generation_client import GenerationUnavailable
from ..search_service import search_service
from .parsing import InvalidGenerationResponse, parse_with_retry, parse_json_object, validate_schema
from .roles import get_role, new_budget, role_runner
from .collaborator import RepositoryNotFound as CollabRepositoryNotFound
from .collaborator import collaborate_task
from .validation import (
    validate_collaborator_response,
    build_correction_message,
    ValidationError,
    validate_current_state_consistency,
    build_current_state_correction_message,
    CurrentStateValidationError,
)
from ...models.service_models import (
    WorkflowState,
    CheckpointPhase,
    CheckpointResult,
    WorkflowEnforcementError,
)

logger = logging.getLogger(__name__)

# Required checkpoints for substantial tasks
REQUIRED_CHECKPOINTS = {
    "substantial": ["post_investigation", "post_implementation", "pre_review"],
    "lightweight": [],  # No required checkpoints for lightweight tasks
}

# Explicit phase dependencies for checkpoint ordering
# A phase can only be invoked after all its dependencies are completed
PHASE_DEPENDENCIES = {
    "post_investigation": [],
    "post_implementation": ["post_investigation"],
    "post_test": ["post_implementation"],
    "failure_analysis": ["post_implementation"],
    "milestone_complete": ["post_implementation"],
    "pre_review": ["post_investigation", "post_implementation"],
}

# Dedicated durable evidence types used by the completion gate.
MEMORY_TYPE_REFINEMENT = "supervision_refinement"
MEMORY_TYPE_REVIEW = "supervision_review"
MEMORY_TYPE_CHECKPOINT_WORKFLOW = "checkpoint_workflow"
MEMORY_TYPE_COLLABORATION = "supervision_collaboration"

# Maximum context snippets for checkpoint evidence
MAX_CODE_SNIPPETS = 3
MAX_MEMORY_RECORDS = 2
MAX_SNIPPET_CHARS = 500

# Checkpoint schema for collaborator response
CHECKPOINT_SCHEMA = {
    "assessment": str,
    "recommendation": str,
    "next_steps": list,
    "risks": list,
    "requires_user_decision": bool,
}


class CheckpointError(Exception):
    """Base exception for checkpoint-related errors."""
    
    def __init__(self, message: str, checkpoint_phase: Optional[str] = None):
        super().__init__(message)
        self.checkpoint_phase = checkpoint_phase


class RepositoryNotFound(CheckpointError):
    """Raised when the requested repository is not registered."""
    
    def __init__(self, repository: str):
        super().__init__(f"Repository not found: {repository}", None)


class TaskNotFound(CheckpointError):
    """Raised when the development task ID is not found."""
    
    def __init__(self, development_task_id: str):
        super().__init__(f"Development task not found: {development_task_id}", None)


class MissingCheckpointError(CheckpointError):
    """Raised when a required checkpoint is missing."""
    
    def __init__(self, development_task_id: str, missing: list[str], message: Optional[str] = None):
        if message:
            full_message = message
        else:
            full_message = (
                f"Required checkpoint(s) missing for task {development_task_id}: "
                f"{', '.join(missing)}"
            )
        super().__init__(full_message, None)
        self.missing = missing
        self.message = message


class ValidationFailedError(CheckpointError):
    """Raised when checkpoint validation fails."""
    
    def __init__(self, message: str, checkpoint_phase: str):
        super().__init__(message, checkpoint_phase)


class WorkflowStateError(CheckpointError):
    """Raised when workflow state operations fail."""
    
    def __init__(self, message: str, development_task_id: str):
        super().__init__(message, None)
        self.development_task_id = development_task_id


async def _resolve(repository: str) -> tuple[str, dict[str, Any]]:
    """Resolve a name or ID and confirm the repository exists."""
    status = await search_service.get_repository_status(repository)
    if "error" in status:
        raise RepositoryNotFound(f"Repository not found: {repository}")
    return status.get("repository_id") or repository, status


async def _get_workflow_state(
    repository_id: str,
    development_task_id: str,
) -> Optional[dict[str, Any]]:
    """Get the current workflow state for a task from Development Memory."""
    try:
        # Use Qdrant REST API directly to get all records
        qdrant_url = os.environ.get("QDRANT_URL", "http://qdrant:6333")
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{qdrant_url}/collections/session-memory/points/scroll",
                json={
                    "limit": 100,
                    "with_payload": True,
                },
            )
            response.raise_for_status()
            data = response.json()
            all_records = data.get("result", {}).get("points", [])
        
        # Filter and sort records for this task
        task_records = [r for r in all_records if r.get("payload", {}).get("development_task_id") == development_task_id]
        # Filter for checkpoint_workflow records only
        task_records = [r for r in task_records if r.get("payload", {}).get("memory_type") == "checkpoint_workflow"]
        task_records = sorted(task_records, key=lambda x: x.get("payload", {}).get("created_at", ""), reverse=True)
        
        logger.info(f"Found {len(task_records)} checkpoint_workflow records for task {development_task_id}")
        
        # Return the most recent record
        if task_records:
            record = task_records[0]
            payload = record.get("payload", {})
            workflow_state = payload.get("workflow_state", payload)  # Support both formats
            logger.info(f"Found workflow state for task {development_task_id}")
            # Use payload which contains id, memory_id, and workflow_state
            # workflow_state alone doesn't have id/memory_id needed for supersedes
            return payload
        
        logger.info(f"No workflow state found for task {development_task_id}")
        return None
    except Exception as e:
        logger.warning(
            "Failed to retrieve workflow state for task %s: %s",
            development_task_id,
            str(e),
            exc_info=True,
        )
        return None


async def _save_workflow_state(
    repository_id: str,
    development_task_id: str,
    phase: str,
    completed: list[str],
    required: list[str],
    next_action: str,
    is_lightweight: bool,
    workflow_complete: bool = False,
    completion_permitted: bool = False,
    final_review_verdict: str | None = None,
    missing_actions: list[str] | None = None,
) -> dict[str, Any]:
    """Save workflow state to Development Memory."""
    from datetime import datetime, timezone
    
    # Resolve repository name to ID for consistent storage
    resolved_id, _ = await _resolve(repository_id)
    
    # Get existing state if any
    existing = await _get_workflow_state(resolved_id, development_task_id)
    
    # Accumulate all completed checkpoints from existing state
    all_completed = list(completed)  # Start with current completed
    if existing:
        existing_completed = (existing.get("workflow_state") or {}).get("completed_checkpoints", [])
        # Add any missing completed checkpoints from existing state
        for cp in existing_completed:
            if cp not in all_completed:
                all_completed.append(cp)
    
    session_id = f"checkpoint-{development_task_id}-{phase}-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
    
    checkpoint = {
        "session_id": session_id,
        "development_task_id": development_task_id,
        "summary": f"Checkpoint {phase} completed",
        "memory_type": "checkpoint_workflow",
        "retention_class": "durable",
        "decisions": [],
        "files_touched": [],
        "symbols_touched": [],
        "completed": completed,
        "unresolved": [],
        "test_results": [],
        "supersedes": [existing.get("memory_id")] if existing else [],
        "checkpoint_phase": phase,
        "workflow_state": {
            "repository_id": repository_id,
            "development_task_id": development_task_id,
            "phase": phase,
            "completed_checkpoints": all_completed,
            "required_checkpoints": required,
            "next_action": next_action,
            "is_lightweight": is_lightweight,
            "last_updated": datetime.now(timezone.utc).isoformat(),
            # Completion state (v4)
            "workflow_complete": workflow_complete,
            "completion_permitted": completion_permitted,
            "final_review_verdict": final_review_verdict,
            "missing_actions": missing_actions or [],
        },
    }
    
    logger.info(f"About to save checkpoint_workflow for {development_task_id} phase {phase}, existing={existing is not None}")
    
    result = await search_service.indexer.create_session_memory(
        repository_id, checkpoint
    )
    
    logger.info(f"Saved checkpoint_workflow for {development_task_id} phase {phase}")
    
    # Also update usage tracker
    from .usage_tracker import get_tracker
    tracker = get_tracker()
    gen_data = checkpoint.get("generation", {}) if checkpoint else {}
    tracker.record_checkpoint_task(
        development_task_id, gen_data.get("prompt_tokens"), 
        gen_data.get("completion_tokens")
    )
    
    return result


async def create_checkpoint(
    repository: str,
    development_task_id: str,
    phase: str,
    task: str,
    current_state: str,
    question: str,
    refined_task: Optional[str] = None,
    options: Optional[list[str]] = None,
) -> dict[str, Any]:
    """Create a new checkpoint and invoke the collaborator role."""
    repository_id, status = await _resolve(repository)
    
    # Get current workflow state
    workflow_state = await _get_workflow_state(repository_id, development_task_id)
    
    # Retrieve all records for this task to compute completed checkpoints
    # Use Qdrant REST API directly to get all records and filter by task ID
    qdrant_url = os.environ.get("QDRANT_URL", "http://qdrant:6333")
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{qdrant_url}/collections/session-memory/points/scroll",
                json={
                    "limit": 100,
                    "with_payload": True,
                },
            )
            response.raise_for_status()
            data = response.json()
            all_records = data.get("result", {}).get("points", [])
    except Exception as e:
        logger.warning(f"Failed to retrieve all records from Qdrant: {e}")
        all_records = []
    
    # Filter and sort records for this task
    task_records = [r for r in all_records if r.get("payload", {}).get("development_task_id") == development_task_id]
    task_records = sorted(task_records, key=lambda x: x.get("payload", {}).get("created_at", ""), reverse=True)
    
    if workflow_state is None:
        # First checkpoint - initialize workflow state
        is_lightweight = status.get("files_indexed", 0) < 100
        
        workflow_state = {
            "memory_id": "initial",
            "checkpoint_phase": None,
            "workflow_state": {
                "repository_id": repository_id,
                "development_task_id": development_task_id,
                "phase": None,
                "completed_checkpoints": [],
                "required_checkpoints": REQUIRED_CHECKPOINTS[
                    "lightweight" if is_lightweight else "substantial"
                ],
                "next_action": "start" if phase == "post_investigation" else "checkpoint",
                "is_lightweight": is_lightweight,
                "last_updated": None,
            },
        }
    
    # Validate that the task exists and is for the correct repository
    # workflow_state may be a container with a workflow_state key, or the workflow_state itself
    ws = workflow_state.get("workflow_state") if isinstance(workflow_state, dict) else workflow_state
    ws = ws if ws else workflow_state
    if ws.get("repository_id") != repository_id:
        raise TaskNotFound(
            f"Task {development_task_id} belongs to a different repository: "
            f"{ws.get('repository_id')}"
        )
    
    # Check required checkpoints before proceeding
    required = ws.get("required_checkpoints", [])
    # Get completed from the most recent record to start with
    current_completed = ws.get("completed_checkpoints", [])
    
    # Compute completed by accumulating all checkpoints from ALL records for this task
    # This ensures we include checkpoints from records created before the fix
    all_completed = list(current_completed)  # Start with completed from most recent record
    for record in task_records:
        payload = record.get("payload", {})
        record_completed = (payload.get("workflow_state") or {}).get("completed_checkpoints", [])
        for cp in record_completed:
            if cp not in all_completed:
                all_completed.append(cp)
    
    completed = all_completed
    
    # Get explicit phase dependencies for this checkpoint
    # This determines what must be completed before this phase can be invoked
    deps = PHASE_DEPENDENCIES.get(phase, [])
    missing_deps = [dep for dep in deps if dep not in completed]
    
    if missing_deps:
        raise MissingCheckpointError(development_task_id, missing_deps)
    
    # All checkpoint phases can be invoked once their dependencies are met
    # The required_checkpoints list is only used for tracking, not blocking
    
    # Build checkpoint-specific prompt
    prompt = _build_checkpoint_prompt(
        phase=phase,
        task=task,
        current_state=current_state,
        question=question,
        refined_task=refined_task,
        options=options,
        workflow_state=workflow_state,
    )
    
    # Invoke the collaborator role
    role = get_role("collaborator")
    budget = new_budget(role)
    
    # Gather evidence for the checkpoint
    try:
        evidence = await _gather_checkpoint_evidence(
            repository_id, phase, task, current_state, budget
        )
    except Exception:
        logger.warning("Failed to gather evidence for checkpoint", exc_info=True)
        evidence = []
    
    # Add evidence to budget
    for section in evidence:
        budget.offer("evidence", section)
    
    # Build prompt with evidence
    prompt_with_evidence = prompt
    if evidence:
        prompt_with_evidence = f"{prompt}\n\nRepository evidence:\n\n" + "\n\n".join(evidence)
    
    async def call(correction):
        return await role_runner.run(role, prompt_with_evidence, correction=correction)
    
    try:
        response, raw = await parse_with_retry(call, CHECKPOINT_SCHEMA)
    except InvalidGenerationResponse as error:
        raise ValidationFailedError(
            f"Checkpoint validation failed: {error}", phase
        )
    
    # Validate that the phase is not already completed
    if phase in completed:
        # Remove duplicates from completed list
        unique_completed = list(dict.fromkeys(completed))
        return {
            "repository_id": repository_id,
            "development_task_id": development_task_id,
            "checkpoint_phase": phase,
            "assessment": f"Checkpoint {phase} has already been completed.",
            "recommendation": "No further action needed for this checkpoint.",
            "next_steps": [],
            "risks": [],
            "requires_user_decision": False,
            "workflow_state": {
                "repository_id": repository_id,
                "development_task_id": development_task_id,
                "phase": phase,
                "completed_checkpoints": unique_completed,
                "required_checkpoints": required,
                "next_action": "checkpoint" if phase != "pre_review" else "review",
                "is_lightweight": ws.get("is_lightweight", False),
            },
            "generation": {},
        }
    
    # Validate collaborator response
    is_valid, error = validate_collaborator_response(task, current_state, question, response)
    if not is_valid:
        correction = build_correction_message(error)
        # parse_with_retry doesn't accept correction directly, so we need to call the function manually
        try:
            result = await call(correction)
            response = parse_json_object(result["text"])
            response = validate_schema(response, CHECKPOINT_SCHEMA)
        except InvalidGenerationResponse:
            raise ValidationFailedError(
                "Validation failed after correction attempt", phase
            )
    
    # Check current-state consistency
    is_valid, state_error = validate_current_state_consistency(current_state, response)
    if not is_valid:
        correction = build_current_state_correction_message(state_error)
        try:
            result = await call(correction)
            response = parse_json_object(result["text"])
            response = validate_schema(response, CHECKPOINT_SCHEMA)
        except InvalidGenerationResponse:
            raise ValidationFailedError(
                "Current-state validation failed after correction attempt", phase
            )
    
    # Build the response
    result = {
        "repository_id": repository_id,
        "development_task_id": development_task_id,
        "checkpoint_phase": phase,
        "assessment": response.get("assessment", ""),
        "recommendation": response.get("recommendation", ""),
        "next_steps": response.get("next_steps", []),
        "risks": response.get("risks", []),
        "requires_user_decision": response.get("requires_user_decision", False),
        "workflow_state": {
            "repository_id": repository_id,
            "development_task_id": development_task_id,
            "phase": phase,
            "completed_checkpoints": completed + [phase],
            "required_checkpoints": required,
            "next_action": "checkpoint" if phase != "pre_review" else "review",
            "is_lightweight": ws.get("is_lightweight", False),
        },
        "generation": {
            "role": role.name,
            "prompt_version": role.prompt_version,
            "duration_seconds": raw.get("duration_seconds"),
            "prompt_tokens": raw.get("prompt_tokens"),
            "completion_tokens": raw.get("completion_tokens"),
            "profile_id": (raw.get("runtime_execution") or {}).get("profile_id"),
            "provider": (raw.get("runtime_execution") or {}).get("provider"),
            "connection_id": (raw.get("runtime_execution") or {}).get("connection_id"),
            "model": (raw.get("runtime_execution") or {}).get("model"),
        },
    }
    
    # Save workflow state
    await _save_workflow_state(
        repository_id,
        development_task_id,
        phase,
        completed + [phase],
        required,
        "checkpoint" if phase != "pre_review" else "review",
        ws.get("is_lightweight", False),
    )
    
    return result


def _build_checkpoint_prompt(
    phase: str,
    task: str,
    current_state: str,
    question: str,
    refined_task: Optional[str] = None,
    options: Optional[list[str]] = None,
    workflow_state: Optional[dict[str, Any]] = None,
) -> str:
    """Build the checkpoint prompt for the collaborator."""
    parts = [
        f"Checkpoint phase: {phase}",
        f"Task intent: {task}",
        f"Current implementation state: {current_state}",
        f"Question to resolve: {question}",
    ]
    
    if refined_task:
        parts.append(f"Refined task: {refined_task}")
    
    if options:
        parts.append(f"Candidate approaches: {options}")
    
    if workflow_state:
        ws = workflow_state.get("workflow_state", {})
        parts.append(f"Workflow state: {ws}")
    
    parts.append(
        "Invoke the collaborator role to assess the current state and "
        "recommend next steps for this checkpoint phase."
    )
    
    return "\n\n".join(parts)


async def _gather_checkpoint_evidence(
    repository_id: str,
    phase: str,
    task: str,
    current_state: str,
    budget: Any,
) -> list[str]:
    """Gather evidence for the checkpoint."""
    sections: list[str] = []
    
    # Priority 1: Current state
    state_label = "current_state"
    state_text = f"Current implementation state:\n{current_state}"
    budget.offer(state_label, state_text)
    if state_label in budget.included:
        sections.append(state_text)
    
    # Priority 2: Task context
    task_label = "task_context"
    task_text = f"Task intent:\n{task}"
    budget.offer(task_label, task_text)
    if task_label in budget.included:
        sections.append(task_text)
    
    # Priority 3: Code retrieval
    try:
        search_query = task[:100] if len(task) > 100 else task
        results = await search_service.search(
            query=search_query,
            repository_id=repository_id,
            limit=MAX_CODE_SNIPPETS,
        )
        for item in results.get("results", [])[:MAX_CODE_SNIPPETS]:
            snippet = (item.get("chunk_content") or "")[:MAX_SNIPPET_CHARS]
            if not snippet:
                continue
            label = f"code:{item.get('file_path')}"
            budget.offer(label, snippet)
            if label in budget.included:
                sections.append(f"File {item.get('file_path')}:\n{snippet}")
    except Exception:
        logger.warning(
            "Code retrieval failed during checkpoint evidence gathering",
            exc_info=True,
        )
    
    # Priority 4: Development Memory
    try:
        memory = await search_service.indexer.get_session_memory_context(
            repository_id,
            limit=MAX_MEMORY_RECORDS,
        )
        for record in memory.get("records", [])[:MAX_MEMORY_RECORDS]:
            summary = record.get("summary", "")
            if not summary:
                continue
            label = f"memory:{record.get('memory_id')}"
            budget.offer(label, summary)
            if label in budget.included:
                sections.append(f"Prior decision: {summary}")
    except Exception:
        logger.warning(
            "Memory retrieval failed during checkpoint evidence gathering",
            exc_info=True,
        )
    
    return sections


async def get_workflow_state(
    repository_id: str,
    development_task_id: str,
) -> Optional[dict[str, Any]]:
    """Get the current workflow state for a task."""
    return await _get_workflow_state(repository_id, development_task_id)


async def get_all_workflow_states() -> list[dict[str, Any]]:
    """Get all workflow states for all tasks from Development Memory."""
    try:
        # Search for all checkpoint workflow memory records
        memory = await search_service.indexer.search_session_memory(
            "*",  # Search all repositories
            "workflow_state",
            memory_type="checkpoint_workflow",
            limit=100,  # Get all records
        )
        records = memory.get("records", [])
        
        # Group by development_task_id and return the most recent state per task
        task_states = {}
        for record in records:
            task_id = record.get("development_task_id")
            if task_id:
                if task_id not in task_states or record.get("created_at", "") > task_states[task_id].get("created_at", ""):
                    task_states[task_id] = record
        
        return list(task_states.values())
    except Exception as e:
        logger.error(f"Failed to retrieve all workflow states: {e}")
        return []


async def get_required_checkpoints(
    development_task_id: str,
) -> list[str]:
    """Get the required checkpoints for a task."""
    ws = await _get_workflow_state(None, development_task_id)
    if ws:
        return ws.get("workflow_state", {}).get("required_checkpoints", [])
    return REQUIRED_CHECKPOINTS["substantial"]


async def is_checkpoint_completed(
    development_task_id: str,
    phase: str,
) -> bool:
    """Check if a checkpoint was completed."""
    ws = await _get_workflow_state(None, development_task_id)
    if ws:
        completed = ws.get("workflow_state", {}).get("completed_checkpoints", [])
        return phase in completed
    return False


async def complete_checkpoint(
    repository: str,
    development_task_id: str,
    phase: str,
) -> dict[str, Any]:
    """Manually mark a checkpoint as completed."""
    repository_id, _ = await _resolve(repository)
    
    ws = await _get_workflow_state(repository_id, development_task_id)
    if ws is None:
        raise TaskNotFound(development_task_id)
    
    current = ws.get("workflow_state", {})
    completed = current.get("completed_checkpoints", [])
    
    if phase in completed:
        return current
    
    completed.append(phase)
    
    return await _save_workflow_state(
        repository_id,
        development_task_id,
        phase,
        completed,
        current.get("required_checkpoints", []),
        current.get("next_action", "checkpoint"),
        current.get("is_lightweight", False),
    )


async def save_workflow_state(
    repository_id: str,
    development_task_id: str,
    phase: str,
    completed: list[str],
    required: list[str],
    next_action: str,
    is_lightweight: bool,
) -> dict[str, Any]:
    """Save workflow state to Development Memory."""
    return await _save_workflow_state(
        repository_id,
        development_task_id,
        phase,
        completed,
        required,
        next_action,
        is_lightweight,
    )


async def enforce_checkpoint_requirements(
    repository_id: str,
    development_task_id: str,
) -> None:
    """Enforce that all required checkpoints are completed."""
    ws = await _get_workflow_state(repository_id, development_task_id)
    if ws is None:
        raise TaskNotFound(development_task_id)
    
    current = ws.get("workflow_state", {})
    required = current.get("required_checkpoints", [])
    completed = current.get("completed_checkpoints", [])
    missing = [req for req in required if req not in completed]
    
    if missing:
        raise MissingCheckpointError(development_task_id, missing)


async def _persist_supervision_evidence(
    repository_id: str,
    development_task_id: str,
    memory_type: str,
    summary: str,
    evidence: dict[str, Any],
) -> dict[str, Any]:
    """Persist one durable supervision-evidence record in Development Memory."""
    from datetime import datetime, timezone

    resolved_id, _ = await _resolve(repository_id)
    now = datetime.now(timezone.utc)
    session_id = (
        f"{memory_type}-{development_task_id}-"
        f"{now.strftime('%Y%m%d%H%M%S%f')}"
    )

    record = {
        "session_id": session_id,
        "development_task_id": development_task_id,
        "summary": summary,
        "memory_type": memory_type,
        "retention_class": "durable",
        "decisions": [],
        "files_touched": [],
        "symbols_touched": [],
        "completed": [],
        "unresolved": [],
        "test_results": [],
        "supersedes": [],
        "created_at": now.isoformat(),
        "evidence": evidence,
    }

    return await search_service.indexer.create_session_memory(resolved_id, record)


async def persist_refinement_evidence(
    repository_id: str,
    development_task_id: str,
    request: str,
    specification: dict[str, Any],
) -> dict[str, Any]:
    """Persist authoritative evidence that refine_task completed successfully."""
    return await _persist_supervision_evidence(
        repository_id=repository_id,
        development_task_id=development_task_id,
        memory_type=MEMORY_TYPE_REFINEMENT,
        summary="Development Supervision refinement completed",
        evidence={
            "request": request,
            "specification": specification,
        },
    )


async def persist_review_evidence(
    repository_id: str,
    development_task_id: str,
    review_evidence: dict[str, Any],
    task_specification: dict[str, Any],
) -> dict[str, Any]:
    """Persist authoritative evidence that review_changes completed."""
    return await _persist_supervision_evidence(
        repository_id=repository_id,
        development_task_id=development_task_id,
        memory_type=MEMORY_TYPE_REVIEW,
        summary="Development Supervision review completed",
        evidence={
            "review_evidence": review_evidence,
            "task_specification": task_specification,
        },
    )


async def _get_supervision_evidence_records(
    repository_id: str,
    development_task_id: str,
    memory_type: str,
) -> list[dict[str, Any]]:
    """Return exact persisted evidence records for one repository/task/type."""
    resolved_id, _ = await _resolve(repository_id)
    qdrant_url = os.environ.get("QDRANT_URL", "http://qdrant:6333")

    must = [
        {
            "key": "repository_id",
            "match": {"value": resolved_id},
        },
        {
            "key": "development_task_id",
            "match": {"value": development_task_id},
        },
        {
            "key": "memory_type",
            "match": {"value": memory_type},
        },
    ]

    records: list[dict[str, Any]] = []
    offset: Any = None
    async with httpx.AsyncClient() as client:
        while True:
            body: dict[str, Any] = {
                "limit": 100,
                "with_payload": True,
                "filter": {"must": must},
            }
            if offset is not None:
                body["offset"] = offset

            response = await client.post(
                f"{qdrant_url}/collections/session-memory/points/scroll",
                json=body,
            )
            response.raise_for_status()
            result = response.json().get("result", {})
            records.extend(result.get("points", []))
            offset = result.get("next_page_offset")
            if offset is None:
                break

    return records


async def verify_refinement_completed(
    repository_id: str,
    development_task_id: str,
) -> bool:
    """Return True only when durable refinement evidence exists for this task."""
    records = await _get_supervision_evidence_records(
        repository_id,
        development_task_id,
        MEMORY_TYPE_REFINEMENT,
    )
    return bool(records)


async def verify_review_completed(
    repository_id: str,
    development_task_id: str,
) -> tuple[bool, Optional[str]]:
    """Verify real review evidence and return its canonical final verdict."""
    records = await _get_supervision_evidence_records(
        repository_id,
        development_task_id,
        MEMORY_TYPE_REVIEW,
    )
    if not records:
        return False, None

    records.sort(
        key=lambda item: item.get("payload", {}).get("created_at", ""),
        reverse=True,
    )
    payload = records[0].get("payload", {})
    evidence = payload.get("evidence", {}) or {}  # Use {} if evidence is None
    review = evidence.get("review_evidence", {})
    verdict = review.get("verdict")

    # The canonical successful review_changes verdict is intentionally strict.
    return verdict == "no_issues_found", verdict

