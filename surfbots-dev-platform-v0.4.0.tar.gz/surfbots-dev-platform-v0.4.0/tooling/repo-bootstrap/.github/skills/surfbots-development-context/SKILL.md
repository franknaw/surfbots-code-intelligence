---
name: surfbots-development-context
description: "Use when: starting coding work in a Surfbots-indexed repository, planning a substantial or ambiguous implementation, reviewing completed implementation work, recovering prior engineering context, making architecture or deployment changes, or recording a meaningful session checkpoint. Retrieves repository-scoped status, Development Memory, and code evidence through Surfbots MCP, and provides task refinement and change review."
argument-hint: "Repository ID and optional current task"
user-invocable: true
disable-model-invocation: false
---

# Surfbots Development Context

Use this Skill to recover compact repository context and work from current evidence. Surfbots MCP exposes capabilities; this Skill defines how to use them.

## Source of Truth

- `repository_status` reports current repository metadata and index health.
- `get_recent_context` and `search_repository_memory` report prior decisions, outcomes, unresolved work, and test history.
- `search_code`, `find_symbol`, `find_references`, `get_file`, and `get_file_range` establish current implementation behavior.
- `refine_task`, `collaborate_task`, and `review_changes` assist with the work itself: turning a request into a specification, helping during implementation, and checking an implementation against it.

When code and memory disagree, follow the current code and briefly note the mismatch. Never treat a memory record as proof that the implementation remains unchanged.

## Tool Autonomy and Clarification Rules

When using Surfbots tools such as `refine_task`, `collaborate_task`, code search, repository context, or related MCP tools:

1. **Do not ask the user to choose a focus** when the intent can reasonably be inferred from:
   * the current request;
   * current repository;
   * conversation context;
   * loaded skills;
   * available code/documentation context.

2. **Prefer autonomous read-only investigation** over clarification.

3. **For broad system-understanding requests**, automatically investigate relevant areas such as:
   * overall architecture;
   * major components and services;
   * component interactions;
   * deployment/runtime infrastructure;
   * APIs and endpoints;
   * storage/persistence;
   * indexing/search/RAG flows;
   * MCP integration;
   * model services;
   * configuration;
   * lifecycle management;
   * developer workflows.

4. **If several interpretations are reasonable**, choose the broadest useful interpretation and proceed.

5. **Mention reasonable assumptions** in the final answer instead of interrupting execution with a question.

6. **Read-only tools do not require conversational permission.**

7. **Continue gathering read-only context** until enough information exists to answer the user's actual request.

## Startup Procedure

1. Determine the repository ID. Do not guess or use a cross-repository search when it is unknown.
2. Call `repository_status`.
3. Call `get_recent_context` with `days: 14` and a small result limit.
4. If the task involves a prior decision, deployment behavior, migration, named symbol, or known issue, call `search_repository_memory` with a focused query.
5. Search or inspect current code for the user's task before meaningful edits.
6. Before broad changes, inspect callers, tests, and affected deployment configuration.

For a command-line context bundle, run [build_context.py](./scripts/build_context.py) or `surfbots-dev context <repository-id> --task "..."`.

## During Work

- Retrieve related memory by exact file or symbol before changing code whose historical rationale matters.
- Retrieve durable decisions before deployment, retention, persistence, or migration changes.
- Keep retrieval bounded. Do not fetch raw memory records beyond what advances the task.
- Gracefully continue when the index or memory service is unavailable; state the degraded source rather than blocking work.

## Checkpoints

Create a checkpoint after completing a meaningful feature, resolving a significant defect, making a durable decision, changing operational behavior, or leaving concrete follow-up work.

Store concise outcomes only: summary, decisions, files/symbols, completed work, unresolved work, and validation results. Never store raw chat transcripts, private prompts, credentials, connection strings, or hidden reasoning.

Use `write_repository_memory` when the MCP client can submit a structured checkpoint directly, or `surfbots-dev memory checkpoint <repository-id> --summary "..."` from the host. Use `--retention-class durable` for architecture decisions and `--supersedes <memory-id>` when replacing one.

## Development Supervision

This is normal working behaviour. The developer should not have to ask for it.

**Before coding.** For a substantial or ambiguous implementation request, call
`refine_task(repository, request)` and implement against the returned
specification. Retain it; the review needs it. Skip refinement for trivial work
such as typo fixes, comment edits, or single-line corrections.

**After implementing.** Run the tests, then call
`review_changes(repository, task_specification, diff, test_results)`. Address the
findings and retest. Perform at most two automatic review-and-fix cycles, then
report anything unresolved instead of iterating further.

**Reading the result.** Verdict and coverage must be read together.

| Verdict | Meaning |
|---|---|
| `no_issues_found` | No defect found in the evidence reviewed. Not proof of correctness. |
| `needs_changes` | Act on the findings. |
| `incomplete_review` | Evidence was omitted. Not success. |
| `unable_to_review` | Nothing reviewable fit the context. Not success. |

`coverage.level` is computed from what actually fit the model context, not
reported by the model, and `coverage.omitted_files` names what was not reviewed.
When coverage is partial, review the omitted files separately or state plainly
that they were not reviewed.

The reviewer is a small local model sharing the active inference profile. It is a
useful second pass that will miss defects, not an authority. If supervision is
unavailable it returns an error rather than a pass; continue with normal
retrieval and say the review did not run.

## Client Artifacts

- Copilot workspace instruction: [surfbots-development-context.instructions.md](../../instructions/surfbots-development-context.instructions.md)
- Cline rule: [surfbots-development-context.md](../../../tooling/repo-bootstrap/.clinerules/surfbots-development-context.md)

## Validation

Before relying on the Skill, verify the MCP server lists `repository_status`, `get_recent_context`, `search_repository_memory`, `search_code`, and `write_repository_memory`. Run `surfbots-dev mcp test --repository-id <repository-id>` when the local MCP port-forward is available; it verifies tool discovery plus repository-scoped memory response schemas.