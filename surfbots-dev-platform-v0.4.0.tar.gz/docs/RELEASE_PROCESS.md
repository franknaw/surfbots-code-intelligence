# Surfbots Dev Platform Release Process

This document describes how releases are built and published, including the bootstrap artifact that serves the public installation script.

## Release Artifacts

Each release produces the following artifacts:

| File | Description |
|------|-------------|
| `surfbots-dev-platform-vX.Y.Z.tar.gz` | Compressed runtime archive containing all runtime code |
| `surfbots-dev-platform-vX.Y.Z.sha256` | SHA-256 checksum for archive verification |
| `manifest.json` | Release metadata including version, product name, and runtime paths |
| `bootstrap.sh` | Public installation script (serves from `/bootstrap/latest/surfbots-bootstrap.sh`) |

## Bootstrap Flow Architecture

```
surfbots-dev-platform (source)
    |
    +-- scripts/package-release.sh
    |
    v
franknaw/surfbots-code-intelligence (public GitHub release)
    |
    +-- https://www.surfbots.ai/bootstrap/latest/surfbots-bootstrap.sh (SWA static)
    |
    v
User downloads and runs bootstrap
```

### Component Roles

| Component | Role | Location |
|-----------|------|----------|
| `surfbots-dev-platform` | Source of truth for all code | Private repo |
| `scripts/package-release.sh` | Packages clean checkout into release archive | `surfbots-dev-platform` |
| `bootstrap.sh` | Public installation entrypoint | Included in release, served from SWA |
| `franknaw/surfbots-code-intelligence` | Public distribution mirror | GitHub Releases |
| `deploy-swa-new.sh` | SWA deployment script that copies bootstrap | `surfbots-main` |
| `staticwebapp.config.json` | SWA routing config (excludes `/bootstrap/*`) | `surfbots-main` |

## Release Process

### 1. Prepare Release

```bash
cd surfbots-dev-platform

# Verify clean working tree
git status

# Run tests
./scripts/package-release.sh --version v0.3.0 --skip-live-tests
```

### 2. Create Release Archive

```bash
./scripts/package-release.sh --version v0.3.0
```

This creates:
- `release-artifacts/out/surfbots-dev-platform-v0.3.0.tar.gz`
- `release-artifacts/out/surfbots-dev-platform-v0.3.0.sha256`
- `release-artifacts/out/manifest.json`

### 3. Publish to GitHub

```bash
./scripts/package-release.sh --version v0.3.0 --publish
```

This creates a GitHub Release with the tag `v0.3.0-local-bootstrap` and uploads:
- The release archive
- The checksum file
- The manifest

### 4. Deploy to Website

```bash
cd surfbots-main
./deploy-swa-new.sh all
```

This copies `bootstrap.sh` from the public GitHub repository to `.swa-build/bootstrap/latest/surfbots-bootstrap.sh` and deploys it via SWA.

## Bootstrap Script

The `bootstrap.sh` script:

1. Downloads the versioned release from GitHub
2. Verifies the SHA-256 checksum
3. Extracts the archive to `XDG_DATA_HOME/surfbots-dev-platform/platform/`
4. Runs `scripts/install-runtime.sh` to install the CLI and configure MCP

### Key Properties

- **Idempotent**: Re-runs reuse existing installations
- **Non-privileged**: Never uses `sudo` or silently installs system packages
- **Checksum-verified**: Mandatory SHA-256 verification before extraction
- **XDG-compliant**: Uses standard user data directories

## Versioning

- **Version format**: `vX.Y.Z` (semantic versioning)
- **Release tag**: `${VERSION}-local-bootstrap` (e.g., `v0.3.0-local-bootstrap`)
- **Latest reference**: `/bootstrap/latest/surfbots-bootstrap.sh` always points to the most recent release

## SWA Routing

The `staticwebapp.config.json` excludes `/bootstrap/*` from SPA fallback:

```json
"navigationFallback": {
  "exclude": [
    "/bootstrap/*",
    ...
  ]
}
```

This ensures that requests to `/bootstrap/latest/surfbots-bootstrap.sh` return the raw script file, not the SPA `index.html`.

## Troubleshooting

### Bootstrap returns HTML instead of script

1. Verify `staticwebapp.config.json` includes `/bootstrap/*` in the exclude list
2. Check that `.swa-build/bootstrap/latest/surfbots-bootstrap.sh` exists and is executable
3. Verify the file is being deployed (check SWA deployment logs)

### Release fails checksum verification

1. Verify the checksum file matches the archive:
   ```bash
   sha256sum -c surfbots-dev-platform-v0.3.0.sha256
   ```
2. Check that the archive is not corrupted during upload

### Website not serving latest bootstrap

1. Run `./deploy-swa-new.sh` from `surfbots-main` after each release
2. The bootstrap is copied fresh from the public repository on each deploy

## Files Changed

| File | Purpose |
|------|---------|
| `scripts/package-release.sh` | Added `bootstrap.sh` to runtime paths and manifest |
| `release-artifacts/surfbots-code-intelligence/bootstrap.sh` | Public bootstrap script (unchanged) |
| `deploy-swa-new.sh` | Added `staging_copy_bootstrap()` function |
| `staticwebapp.config.json` | Added `/bootstrap/*` to navigation fallback exclude |
| `docs/INSTALL.md` | Updated to explain bootstrap flow |
| `README.md` (surfbots-main) | Documented bootstrap flow |
| `docs/RELEASE_PROCESS.md` | This file |