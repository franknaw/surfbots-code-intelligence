# surfbots MCP Server

The Model Context Protocol (MCP) Server for Surfbots Code Indexer.

## Overview

The MCP Server acts as a bridge between AI agents (like Cline) and the Code Search API. It exposes agent-friendly tools that translate to API calls for code search, file retrieval, symbol lookup, and more.

## Architecture

```
Cline (AI Agent)
    │
    ▼
MCP Server (port 8002)
    │
    ├── search_code
    ├── get_file
    ├── get_file_range
    ├── find_symbol
    ├── find_references
    ├── repository_status
    ├── get_recent_context
    ├── search_repository_memory
    └── write_repository_memory
    │
    ▼
Code Search API (port 8001)
    │
    ▼
Code Indexer / Qdrant
```

## Features

- **Agent-Friendly Tools**: Exposes MCP protocol tools for AI agents
- **Code Search**: Semantic search across repositories
- **File Operations**: Retrieve file content and ranges
- **Symbol Navigation**: Find symbol definitions and references
- **Repository Status**: Get repository metadata

## Quick Start

### Prerequisites

- Python 3.11+
- Code Search API service running

### Local Development

```bash
cd src/mcp-server

# Create virtual environment
python -m venv .venv
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Create .env file
cp .env.example .env
# Edit .env with your configuration

# Run the server
python -m app.main
```

### Docker

```bash
docker build -t surfbots/mcp-server .
docker run -p 8002:8002 surfbots/mcp-server
```

### Kubernetes

```bash
helm install mcp-server ./helm/mcp-server -n surfbots-dev-platform
```

## Configuration

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| HOST | 0.0.0.0 | Server host address |
| PORT | 8002 | Server port |
| CODE_SEARCH_URL | http://code-search-api:8000 | Code Search API URL |
| DEBUG | false | Enable debug mode |

## MCP Tools

### search_code
Search for code snippets across repositories.

```json
{
    "name": "search_code",
    "arguments": {
        "query": "search query",
        "repository": "optional-repo-name",
        "language": "python",
        "file_path": "src/code-search-api",
        "limit": 8
    }
}
```

`language` and `file_path` are optional and narrow noisy results. `file_path`
matches any path containing the given substring.

### get_file
Retrieve file content by path.

```json
{
    "name": "get_file",
    "arguments": {
        "path": "src/main.py",
        "repository": "optional-repo-name"
    }
}
```

### get_file_range
Get specific line range from a file.

```json
{
    "name": "get_file_range",
    "arguments": {
        "path": "src/main.py",
        "start_line": 1,
        "end_line": 100
    }
}
```

### find_symbol
Find where a symbol is defined.

```json
{
    "name": "find_symbol",
    "arguments": {
        "symbol": "SearchService",
        "repository": "repo-name-or-id",
        "language": "py"
    }
}
```

### find_references
Find where a symbol is used.

```json
{
    "name": "find_references",
    "arguments": {
        "symbol": "resolve_repository_id",
        "repository": "repo-name-or-id",
        "limit": 20
    }
}
```

Both return `path:line` plus the matching source line, scanned from the managed
snapshot. They reflect the last `surfbots-dev repo reindex`, not uncommitted
working-tree edits.

### repository_status
Get repository status.

```json
{
    "name": "repository_status",
    "arguments": {
        "repository": "repo-name"
    }
}
```

The `repository` argument accepts either the indexed `repository_id` or the
repository name. Names are resolved to IDs by the Code Search API.

### get_recent_context
Get bounded, agent-ready recent Development Memory for a repository.

```json
{"name": "get_recent_context", "arguments": {"repository": "repo-id", "limit": 10}}
```

### search_repository_memory
Semantically search Development Memory within a repository.

```json
{"name": "search_repository_memory", "arguments": {"repository": "repo-id", "query": "why does snapshot refresh run on the host?"}}
```

### write_repository_memory
Store a concise, structured checkpoint after meaningful work. Do not submit conversation transcripts or hidden reasoning.

```json
{
    "name": "write_repository_memory",
    "arguments": {
        "repository": "repo-id",
        "session_id": "session-20260901-001",
        "summary": "Implemented MCP integration verification.",
        "completed": ["Required tool verification"],
        "test_results": ["MCP verifier passed"]
    }
}
```

## Development

### Testing

```bash
pytest tests/ -v
```

### Linting

```bash
flake8 app/
mypy app/
```

## Deployment

The MCP Server is deployed as a Kubernetes service:

- **Service Name**: mcp-server
- **Port**: 8002
- **Namespace**: surfbots-dev-platform

## License

MIT License
