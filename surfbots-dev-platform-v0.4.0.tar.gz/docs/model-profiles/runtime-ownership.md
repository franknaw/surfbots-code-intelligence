# Model Profiles Runtime Ownership

This record identifies the owning repository and local control surface for each
provider-aware model profile concern. Model/profile management is intentionally
independent of the Surfbots Admin web application.

## Confirmed Ownership

| Component | Owning repository | Integration boundary |
|---|---|---|
| Profile persistence | `surfbots-dev-platform` | Code Search API control-plane store |
| Provider adapters | `surfbots-dev-platform` | Code Search API server-side services |
| Role resolver | `surfbots-dev-platform` | Code Search API request path |
| Kubernetes Secrets | `surfbots-dev-platform` | In-cluster Secret adapter and narrowly scoped RBAC |
| Control-plane API | `surfbots-dev-platform` | Cluster-internal Code Search API route, never publicly exposed |
| Activation API | `surfbots-dev-platform` | Server-side validation and activation service called through the internal control-plane API |
| Model/profile CLI | `surfbots-dev-platform` | `surfbots-dev models ...` establishes a temporary localhost port-forward as needed |
| Kubernetes Secrets | `surfbots-dev-platform` | CLI submits a token once through the internal API; API writes it server-side |

## Evidence

- The current Code Search API has no control-plane persistence or authorization
  layer. It has a durable SQLite metrics database on the mounted platform-data
  volume. Phase 1 introduces a separate SQLite control-plane database there.
- `surfbots-dev` already owns local platform bootstrap, profile inspection,
  port-forward lifecycle, and interaction with the local Kubernetes runtime. It
  is the appropriate developer-operated control surface for model profiles.

## Phase 0 Decision

Phases 1 through 7 are implemented entirely in `surfbots-dev-platform`.
`surfbots-dev models ...` is the sole operator-facing model-profile control
surface. It establishes a short-lived `kubectl port-forward` to a
cluster-internal control-plane route, executes one command, then terminates the
port-forward. The route is not exposed through Kubernetes ingress, Azure Static
Web Apps, MCP, or any public service.

## Required Local Control-Plane Call Contract

1. The CLI runs only on the developer/operator workstation and uses the
   operator's existing `kubectl` context to establish a localhost-only
   port-forward to the Code Search API.
2. The control-plane routes bind to `127.0.0.1` through that ephemeral tunnel;
   they are not available through a service LoadBalancer, ingress, Azure proxy,
   browser route, MCP route, or untrusted in-cluster workload.
3. The Code Search API treats requests as privileged only when they arrive over
   the locally established control-plane tunnel and rejects requests lacking the
   local control-plane credential created by the CLI for that command.
4. The CLI obtains the short-lived credential from the operator's Kubernetes
   context and never accepts it as a positional argument or stores it in user
   configuration. The API verifies it before reading request data or writing a
   Secret.
5. Audit actors identify the local operator from the verified Kubernetes context
   where available. A caller-supplied `actor`, arbitrary role header, browser
   assertion, and anonymous proxy request are never trusted.
6. Tokens are submitted once through stdin hidden input to the internal route.
   The API writes them directly to `surfbots-provider-credentials`; neither the
   CLI nor profile export/import files read or display stored token values.

## Implemented Local Credential Flow

Phase 6 uses Kubernetes-issued short-lived service-account tokens rather than a
browser-visible shared secret:

1. `surfbots-dev` will run `kubectl create token code-search-api
   --namespace surfbots-dev-platform --duration=10m` using the operator's current
   Kubernetes context, then establish a localhost-only port-forward to
   `code-search-api` for the duration of that command.
2. The CLI sends the short-lived token as a Bearer credential only to the local
   port-forward. It does not persist it, print it, place it in command arguments,
   or write it to profile configuration.
3. Code Search API calls Kubernetes `TokenReview` using its own workload service
   account. It accepts only an authenticated token whose subject is exactly
   `system:serviceaccount:surfbots-dev-platform:code-search-api`.
4. The model-control identity has `automountServiceAccountToken: false` and no
   workload permissions. It exists only so a permitted local operator can obtain
   a short-lived token. Code Search API has the standard `system:auth-delegator`
   binding needed to request TokenReviews.
5. Any request with no credential, an invalid/expired token, or a token for a
   different identity receives no control-plane access. The endpoint is not
   exposed through ingress, Azure, MCP, browser routes, or a LoadBalancer.

The operator's Kubernetes RBAC must permit `create` on the `serviceaccounts/token`
subresource for `code-search-api` in the platform namespace. This
is the only host-side authorization prerequisite for the Phase 7 CLI. Do not
replace this with a browser-visible shared secret or public endpoint.

No provider token may cross Static Web App runtime configuration, browser
storage, MCP protocol, CLI arguments, shell history, or profile persistence
boundaries. The CLI may submit a token only through hidden interactive input to
the local internal route; the server writes it directly to a Kubernetes Secret
and subsequently returns only `has_token` state.