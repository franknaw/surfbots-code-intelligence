"""Shared parsing for generation responses.

Local instruct models routinely wrap JSON in Markdown fences, so every
supervision tool needs identical unwrapping. Keeping it here prevents each tool
from growing its own slightly different version.
"""
from typing import Any, Callable, Optional
import json
import logging
import re

logger = logging.getLogger(__name__)

# Matches one outer ```json ... ``` or ``` ... ``` wrapper, not fences inside.
_FENCE = re.compile(r"^\s*```(?:json|JSON)?\s*\n?(?P<body>.*?)\n?\s*```\s*$", re.DOTALL)

RETRY_INSTRUCTION = (
    "Your previous response was not valid JSON. "
    "Respond again with the same content as a single JSON object only. "
    "No commentary, no Markdown fences."
)


class InvalidGenerationResponse(ValueError):
    """Raised when a response cannot be parsed or fails schema validation."""


def strip_fence(text: str) -> str:
    """Remove one outer Markdown fence if present, including surrounded fences."""
    stripped = text.strip()
    match = _FENCE.match(stripped)
    if match:
        return match.group("body").strip()
    
    fence_search = re.search(r"```(?:json|JSON)?\s*\n?(?P<body>.*?)\n?\s*```", stripped, re.DOTALL)
    if fence_search:
        return fence_search.group("body").strip()

    return stripped


def parse_json_object(text: str) -> dict[str, Any]:
    """Parse a model response into a JSON object, or fail explicitly."""
    candidate = strip_fence(text)
    try:
        parsed = json.loads(candidate, strict=False)
    except json.JSONDecodeError as error:
        json_match = re.search(r"(\{.*\})", candidate, re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group(1), strict=False)
            except json.JSONDecodeError:
                raise InvalidGenerationResponse(f"Response was not valid JSON: {error.msg}") from error
        else:
            raise InvalidGenerationResponse(f"Response was not valid JSON: {error.msg}") from error

    if not isinstance(parsed, dict):
        raise InvalidGenerationResponse(f"Expected a JSON object, received {type(parsed).__name__}")
    return parsed


def validate_schema(payload: dict[str, Any], required: dict[str, type]) -> dict[str, Any]:
    """Check required keys and their coarse types."""
    missing = [key for key in required if key not in payload]
    if missing:
        raise InvalidGenerationResponse(f"Response missing required fields: {', '.join(sorted(missing))}")

    for key, expected in required.items():
        if not isinstance(payload[key], expected):
            raise InvalidGenerationResponse(
                f"Field '{key}' should be {expected.__name__}, received {type(payload[key]).__name__}"
            )
    return payload


async def parse_with_retry(
    call: Callable[[Optional[str]], Any],
    required: dict[str, type],
    allow_retry: bool = True,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Parse a generation result, allowing at most one corrective retry.

    `call` receives an optional correction instruction and returns the raw
    generation result. Bounded to two attempts so a model that cannot produce
    valid JSON fails rather than looping.
    """
    result = await call(None)
    try:
        return validate_schema(parse_json_object(result["text"]), required), result
    except InvalidGenerationResponse as first_error:
        if not allow_retry:
            raise
        logger.info("Retrying generation once after invalid response: %s", first_error)

    result = await call(RETRY_INSTRUCTION)
    try:
        return validate_schema(parse_json_object(result["text"]), required), result
    except InvalidGenerationResponse as second_error:
        raise InvalidGenerationResponse(
            f"Generation did not return valid JSON after one retry: {second_error}"
        ) from second_error
