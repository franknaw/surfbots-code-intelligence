"""Managed local generation lifecycle management.

Controls the lifecycle of managed local generation models based on the currently
selected generation profile. Scales managed models to zero when not selected,
and starts them when selected.
"""
from __future__ import annotations

import os

import asyncio
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import httpx

from ...core.config import settings
from ..generation_provider import GenerationUnavailable

# Managed generation profiles - these run in-cluster and can be scaled
MANAGED_GENERATION_PROFILES = {
    "local-lightweight",
    "local-quality",
}

# External generation providers - these do NOT run in-cluster managed models
EXTERNAL_GENERATION_PROVIDERS = {
    "openai",
    "azure-openai",
    "openai-compatible",
    "local-openai",
}


@dataclass(frozen=True)
class ManagedGenerationState:
    """Current state of managed generation deployment."""
    
    running: bool
    replicas: int
    model_label: str | None = None


class ManagedGenerationManager:
    """Manages the lifecycle of managed local generation deployments."""
    
    def __init__(
        self,
        deployment_name: str | None = None,
        namespace: str | None = None,
        timeout_seconds: int | None = None,
    ):
        self.deployment_name = deployment_name or settings.local_generation_deployment_name
        self.namespace = namespace or settings.kubernetes_namespace
        self.timeout_seconds = timeout_seconds or settings.local_generation_rollout_timeout_seconds
    
    @staticmethod
    def _api_base_url() -> str:
        host = os.environ.get("KUBERNETES_SERVICE_HOST", "")
        port = os.environ.get("KUBERNETES_SERVICE_PORT_HTTPS", "443")
        if not host:
            raise GenerationUnavailable("Kubernetes management API is not configured")
        return f"https://{host}:{port}"
    
    @staticmethod
    def _headers() -> dict[str, str]:
        token_path = Path(settings.kubernetes_service_account_token_path)
        if not token_path.is_file():
            raise GenerationUnavailable("Kubernetes management credential is unavailable")
        token = token_path.read_text(encoding="utf-8").strip()
        if not token:
            raise GenerationUnavailable("Kubernetes management credential is empty")
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json-patch+json",
        }
    
    async def get_state(self) -> ManagedGenerationState:
        """Get the current state of the managed generation deployment."""
        url = f"{self._api_base_url()}/apis/apps/v1/namespaces/{self.namespace}/deployments/{self.deployment_name}"
        try:
            async with httpx.AsyncClient(
                verify=Path(settings.kubernetes_service_account_ca_path),
                timeout=10.0
            ) as client:
                response = await client.get(url, headers=self._headers())
                if response.is_error:
                    # Deployment may not exist (scaled to zero)
                    return ManagedGenerationState(running=False, replicas=0)
                deployment = response.json()
                status = deployment.get("status", {})
                replicas = status.get("replicas", 0)
                return ManagedGenerationState(
                    running=replicas > 0,
                    replicas=replicas,
                    model_label=self._extract_model_label(deployment),
                )
        except (OSError, httpx.HTTPError):
            return ManagedGenerationState(running=False, replicas=0)
    
    def _extract_model_label(self, deployment: dict) -> str | None:
        """Extract the model label from deployment args."""
        try:
            containers = deployment["spec"]["template"]["spec"]["containers"]
            for container in containers:
                if container.get("name") == "generation-server":
                    args = container.get("args", [])
                    # Look for -hf flag pattern: -hf <repo>:<quantization>
                    for i, arg in enumerate(args):
                        if arg == "-hf" and i + 1 < len(args):
                            hf_arg = args[i + 1]
                            # Extract model label from repo name
                            if "Qwen2.5-Coder-1.5B" in hf_arg:
                                return "local-lightweight"
                            if "Qwen2.5-Coder-3B" in hf_arg:
                                return "local-quality"
        except (KeyError, IndexError):
            pass
        return None
    
    async def scale_to_zero(self) -> None:
        """Scale the managed generation deployment to zero replicas."""
        url = f"{self._api_base_url()}/apis/apps/v1/namespaces/{self.namespace}/deployments/{self.deployment_name}"
        patch = [{"op": "replace", "path": "/spec/replicas", "value": 0}]
        try:
            async with httpx.AsyncClient(
                verify=Path(settings.kubernetes_service_account_ca_path),
                timeout=15.0
            ) as client:
                response = await client.patch(
                    url,
                    headers=self._headers(),
                    json=patch,
                )
                if response.is_error:
                    raise GenerationUnavailable(
                        f"Failed to scale managed generation to zero: {response.status_code}"
                    )
        except (OSError, httpx.HTTPError) as error:
            raise GenerationUnavailable("Kubernetes management service unavailable") from error
    
    async def scale_to_one(self, model_label: str) -> None:
        """Scale the managed generation deployment to one replica and set the model."""
        from ..local_generation_rollout import LocalGenerationRollout
        
        # Use existing LocalGenerationRollout to set the model
        rollout = LocalGenerationRollout(
            deployment_name=self.deployment_name,
            timeout_seconds=self.timeout_seconds,
        )
        await rollout.rollout(model_label)
    
    async def ensure_state(
        self,
        active_profile_id: str,
        provider: str,
        model_label: str | None = None,
    ) -> None:
        """Ensure managed generation state matches the active profile.
        
        Args:
            active_profile_id: The currently active profile
            provider: The provider type for the active profile
            model_label: The local generation model label if provider is local
        """
        current_state = await self.get_state()
        
        # Determine desired state
        is_managed_provider = provider in ("local",)  # "local" is the managed provider type
        
        if is_managed_provider and model_label:
            # Managed profile is active - ensure deployment is running with correct model
            if not current_state.running:
                await self.scale_to_one(model_label)
            elif current_state.model_label != model_label:
                # Model needs to change - scale down, update, scale up
                await self.scale_to_zero()
                await self.scale_to_one(model_label)
        else:
            # External profile is active - scale managed generation to zero
            if current_state.running:
                await self.scale_to_zero()
    
    async def reconcile_active_profile(self, active_profile_id: str) -> None:
        """Reconcile managed generation state based on currently active profile.
        
        This is called on startup and after profile activation to ensure
        the runtime state matches the configuration.
        """
        from ..model_profiles import provider_connection_store
        
        try:
            profile = provider_connection_store.get_active_profile()
        except Exception:
            # If we can't read the profile, don't change anything
            return
        
        # Get the provider for the generation role
        generation_binding = profile.roles.get("generation")
        if not generation_binding:
            return
        
        provider = generation_binding.provider
        model_label = None
        
        if provider == "local":
            model_label = generation_binding.model
        
        await self.ensure_state(
            active_profile_id=active_profile_id,
            provider=provider,
            model_label=model_label,
        )


# Global instance for use throughout the application
managed_generation_manager = ManagedGenerationManager()
