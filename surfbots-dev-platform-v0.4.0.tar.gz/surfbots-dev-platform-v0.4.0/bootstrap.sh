#!/usr/bin/env bash
# Surfbots Dev Platform Bootstrap Script
# This is a minimal bootstrap that downloads the CLI from releases and verifies prerequisites.
# All real installation logic lives in the compiled surfbots-dev program.
#
# Usage: ./bootstrap.sh
#
# For versioned releases, the recommended installation is:
#   curl -fsSL https://install.surfbots.ai/dev | bash

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

VERSION="${SURFBOTS_VERSION:-v0.2.0}"
BASE_URL="https://releases.surfbots.ai/${VERSION}"
BIN_DIR="${HOME}/.local/bin"

# Function to verify checksum
verify_checksum() {
    local file="$1"
    local expected_hash="$2"
    local actual_hash
    
    if [[ "$(uname)" == "Darwin" ]]; then
        actual_hash=$(shasum -a 256 "$file" | awk '{print $1}')
    else
        actual_hash=$(sha256sum "$file" | awk '{print $1}')
    fi
    
    if [[ "$actual_hash" != "$expected_hash" ]]; then
        echo -e "${RED}Error: Checksum validation failed for $file${NC}"
        echo "Expected: $expected_hash"
        echo "Actual:   $actual_hash"
        return 1
    fi
    echo -e "${GREEN}✓ Checksum verified${NC}"
    return 0
}

echo -e "${GREEN}=== Surfbots Dev Platform Bootstrap ===${NC}"
echo ""
echo "Version: $VERSION"
echo "Base URL: $BASE_URL"
echo ""

# Step 1: Verify prerequisites
echo -e "${YELLOW}[1/2] Verifying prerequisites...${NC}"

if ! command -v docker &> /dev/null; then
    echo -e "${RED}Error: Docker is not installed or not in PATH${NC}"
    echo "Please install Docker: https://docs.docker.com/get-docker/"
    exit 1
fi
echo -e "${GREEN}✓ Docker: $(docker --version)${NC}"

if ! command -v helm &> /dev/null; then
    echo -e "${RED}Error: Helm is not installed or not in PATH${NC}"
    echo "Please install Helm: https://helm.sh/docs/intro/install/"
    exit 1
fi
echo -e "${GREEN}✓ Helm: $(helm version --short)${NC}"

if ! command -v kubectl &> /dev/null; then
    echo -e "${RED}Error: kubectl is not installed or not in PATH${NC}"
    echo "Please install kubectl: https://kubernetes.io/docs/tasks/tools/#kubectl"
    exit 1
fi
echo -e "${GREEN}✓ kubectl: $(kubectl version --client --short)${NC}"
echo ""

# Step 2: Download and install surfbots-dev CLI
echo -e "${YELLOW}[2/2] Installing surfbots-dev CLI...${NC}"

mkdir -p "$BIN_DIR"

# Detect architecture
ARCH="$(uname -m)"
case "$ARCH" in
    x86_64)
        TARGET="linux-amd64"
        ;;
    aarch64|arm64)
        TARGET="linux-arm64"
        ;;
    *)
        echo -e "${RED}Error: Unsupported architecture: $ARCH${NC}"
        exit 1
        ;;
esac

CLI_BINARY="surfbots-dev-${TARGET}"
CLI_PATH="${BIN_DIR}/surfbots-dev"
TEMP_FILE=$(mktemp)

# Download the CLI
if command -v curl &> /dev/null; then
    echo "Downloading $CLI_BINARY..."
    curl -fsSL "${BASE_URL}/${CLI_BINARY}" -o "$TEMP_FILE"
else
    echo "Error: curl is required for downloading releases"
    exit 1
fi

# Verify checksum (optional - requires SHA256SUMS file)
if curl -fsSL -o "${TEMP_FILE}.sha256" "${BASE_URL}/SHA256SUMS" 2>/dev/null; then
    EXPECTED_HASH=$(awk "/${CLI_BINARY}/ {print \\$1}" "${TEMP_FILE}.sha256")
    if verify_checksum "$TEMP_FILE" "$EXPECTED_HASH"; then
        rm -f "${TEMP_FILE}.sha256"
    else
        rm -f "${TEMP_FILE}.sha256"
        exit 1
    fi
else
    echo -e "${YELLOW}Warning: SHA256SUMS not available, skipping checksum verification${NC}"
fi

# Install the CLI
mv "$TEMP_FILE" "$CLI_PATH"
chmod +x "$CLI_PATH"
echo -e "${GREEN}✓ surfbots-dev installed to ${CLI_PATH}${NC}"

# Verify installation
if command -v "$CLI_PATH" &> /dev/null; then
    "$CLI_PATH" --version 2>/dev/null || echo "Version: unknown"
fi

echo ""
echo -e "${GREEN}=== Bootstrap Complete! ===${NC}"
echo ""
echo "Next steps:"
echo ""
echo "1. Run surfbots-dev doctor to verify setup:"
echo "   surfbots-dev doctor"
echo ""
echo "2. Add a repository to index:"
echo "   surfbots-dev repo add /path/to/your/project"
echo ""
echo "3. Start the platform and MCP port-forward:"
echo "   ./surfbots-admin.sh start"
echo ""
echo "4. Configure Cline and Copilot MCP (automatic):"
echo "   surfbots-dev mcp configure auto --path /path/to/your/project"
echo ""
echo "5. Verify platform capabilities:"
echo "   surfbots-dev mcp test --repository-id <repository-id>"
echo "   # Exercises Code Intelligence, Development Memory, and Development"
echo "   # Supervision. A reachable MCP server that cannot refine or review is"
echo "   # reported Not Ready and exits non-zero."
echo ""
echo -e "${GREEN}Happy coding! 🚀${NC}"
