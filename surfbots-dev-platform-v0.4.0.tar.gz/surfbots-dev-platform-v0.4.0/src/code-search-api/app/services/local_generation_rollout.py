"""Bounded Kubernetes rollout support for the single local generation deployment."""
from __future__ import annotations

import asyncio
from pathlib import Path

import httpx

from ..core.config import settings
from .generation_provider import GenerationUnavailable


LOCAL_MODEL_PROFILES = {
    "profile-generation": ("Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF", "Q4_K_M"),
    "local-lightweight": ("Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF", "Q4_K_M"),
    "local-quality": ("Qwen/Qwen2.5-Coder-3B-Instruct-GGUF", "Q4_K_M"),
}


class LocalGenerationRollout:
    """Patch and observe only the model-generation deployment."""

    def __init__(self, *, deployment_name: str | None = None, timeout_seconds: int | None = None):
        self.deployment_name = deployment_name or settings.local_generation_deployment_name
        self.timeout_seconds = timeout_seconds or settings.local_generation_rollout_timeout_seconds

    @staticmethod
    def _api_base_url() -> str:
        import os

        host = os.environ.get("KUBERNETES_SERVICE_HOST", "")
        port = os.environ.get("KUBERNETES_SERVICE_PORT_HTTPS", "443")
        if not host:
            raise GenerationUnavailable("Kubernetes rollout service is not configured")
        return f"https://{host}:{port}"

    @staticmethod
    def _headers() -> dict[str, str]:
        token_path = Path(settings.kubernetes_service_account_token_path)
        if not token_path.is_file():
            raise GenerationUnavailable("Kubernetes rollout credential is unavailable")
        token = token_path.read_text(encoding="utf-8").strip()
        if not token:
            raise GenerationUnavailable("Kubernetes rollout credential is empty")
        return {"Authorization": f"Bearer {token}", "Content-Type": "application/strategic-merge-patch+json"}

    async def rollout(self, model_label: str) -> None:
        try:
            repository, quantization = LOCAL_MODEL_PROFILES[model_label]
        except KeyError as error:
            raise GenerationUnavailable(f"Unsupported local generation profile '{model_label}'") from error
        url = f"{self._api_base_url()}/apis/apps/v1/namespaces/{settings.kubernetes_namespace}/deployments/{self.deployment_name}"
        patch = {"spec": {"template": {"spec": {"containers": [{
            "name": "generation-server",
            "args": ["--host", "0.0.0.0", "--port", "8000", "-hf", f"{repository}:{quantization}", "--ctx-size", "8192", "--threads", "8", "--n-gpu-layers", "0"],
        }]}}}}
        try:
            async with httpx.AsyncClient(verify=settings.kubernetes_service_account_ca_path, timeout=15.0) as client:
                response = await client.patch(url, headers=self._headers(), json=patch)
                if response.is_error:
                    raise GenerationUnavailable(f"Local generation rollout request failed ({response.status_code})")
                generation = response.json().get("metadata", {}).get("generation")
                await self._wait_ready(client, url, generation)
        except (OSError, httpx.HTTPError) as error:
            raise GenerationUnavailable("Local generation rollout service is unavailable") from error

    async def _wait_ready(self, client: httpx.AsyncClient, url: str, generation: int | None) -> None:
        deadline = asyncio.get_running_loop().time() + self.timeout_seconds
        while asyncio.get_running_loop().time() < deadline:
            response = await client.get(url, headers={"Authorization": self._headers()["Authorization"]})
            if response.is_error:
                raise GenerationUnavailable(f"Local generation rollout status failed ({response.status_code})")
            deployment = response.json()
            status = deployment.get("status", {})
            if (
                status.get("observedGeneration") == generation
                and status.get("updatedReplicas") == 1
                and status.get("availableReplicas") == 1
                and status.get("unavailableReplicas", 0) == 0
            ):
                return
            await asyncio.sleep(2)
        raise GenerationUnavailable("Local generation rollout timed out waiting for readiness")