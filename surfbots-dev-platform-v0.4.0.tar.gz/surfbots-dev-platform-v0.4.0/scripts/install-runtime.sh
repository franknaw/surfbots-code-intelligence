#!/usr/bin/env bash
# Runs from a verified Surfbots release archive. It does not use sudo.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLATFORM_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
VERSION="$(cat "${PLATFORM_ROOT}/VERSION")"
CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}/surfbots-dev-platform"
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}/surfbots-dev-platform"
STATE_HOME="${XDG_STATE_HOME:-$HOME/.local/state}/surfbots-dev-platform"
BIN_DIR="${HOME}/.local/bin"
LOG_DIR="${STATE_HOME}/logs"
LOG_FILE="${LOG_DIR}/install-$(date +%Y%m%dT%H%M%S).log"
MIN_DISK_GIB=20
MIN_LOCAL_RAM_GIB=12
PROFILE_CONFIG="${CONFIG_HOME}/inference-profile.env"
# XDG Data Home - standard location for user data
XDG_DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
XDG_CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"

# Surfbots data directory (parent for all platform data)
SURFBOTS_DATA_HOME="${XDG_DATA_HOME}/surfbots-dev-platform"
BUILD_RECORD_DIR="${SURFBOTS_DATA_HOME}/builds"

# Registry configuration - must match cluster.sh
HOST_REGISTRY="${SURFBOTS_HOST_REGISTRY:-http://localhost:5000}"
CLUSTER_REGISTRY="${SURFBOTS_CLUSTER_REGISTRY:-k3d-surfbots-dev-platform-registry:5000}"

REQUESTED_PROFILE="${SURFBOTS_INFERENCE_PROFILE:-}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --profile) REQUESTED_PROFILE="${2:-}"; shift 2 ;;
    -h|--help) echo "Usage: $0 [--profile local-lightweight|local-quality]"; exit 0 ;;
    *) fail "Unknown argument: $1" ;;
  esac
done

mkdir -p "${CONFIG_HOME}" "${DATA_HOME}" "${STATE_HOME}" "${LOG_DIR}" "${BIN_DIR}"
exec > >(tee -a "${LOG_FILE}") 2>&1

info() { printf '[INFO] %s\n' "$*"; }
warn() { printf '[WARN] %s\n' "$*" >&2; }
fail() { printf '[ERROR] %s\nLog: %s\n' "$*" "${LOG_FILE}" >&2; exit 1; }

require_linux() {
  [[ "$(uname -s)" == "Linux" ]] || fail "Surfbots supports Linux only."
  case "$(uname -m)" in x86_64|aarch64|arm64) ;; *) fail "Unsupported architecture: $(uname -m)" ;; esac
}

check_command() {
  local name="$1" required="$2"
  if command -v "${name}" >/dev/null 2>&1; then
    printf '  FOUND        %s\n' "${name}"
  elif [[ "${required}" == true ]]; then
    printf '  MISSING      %s\n' "${name}" >&2
    return 1
  else
    printf '  OPTIONAL     %s\n' "${name}"
  fi
}

check_dependencies() {
  local missing=0 name
  info "Checking local dependencies"
  for name in curl git rsync docker kubectl k3d helm python3; do
    check_command "${name}" true || missing=1
  done
  check_command nvidia-smi false || true
  [[ "${missing}" == 0 ]] || fail "Install the missing tools using your distribution package manager, then rerun. Surfbots does not install privileged system packages."
  docker info >/dev/null 2>&1 || fail "Docker daemon is unavailable to this user. Start Docker and configure non-root access before retrying."
}

hardware_summary() {
  local total_kib available_kib disk_kib
  total_kib=$(awk '/MemTotal:/ {print $2}' /proc/meminfo)
  available_kib=$(awk '/MemAvailable:/ {print $2}' /proc/meminfo)
  disk_kib=$(df -Pk "${DATA_HOME}" | awk 'NR == 2 {print $4}')
  RAM_GIB=$((total_kib / 1024 / 1024))
  AVAILABLE_RAM_GIB=$((available_kib / 1024 / 1024))
  AVAILABLE_DISK_GIB=$((disk_kib / 1024 / 1024))
  info "Hardware: $(getconf _NPROCESSORS_ONLN) CPU cores, ${RAM_GIB} GiB RAM, ${AVAILABLE_DISK_GIB} GiB disk available"
  (( AVAILABLE_DISK_GIB >= MIN_DISK_GIB )) || fail "At least ${MIN_DISK_GIB} GiB of free disk is required."
  (( RAM_GIB >= MIN_LOCAL_RAM_GIB )) || warn "Local models may be slow with less than ${MIN_LOCAL_RAM_GIB} GiB RAM."
}

choose_inference_profile() {
  local profile="${REQUESTED_PROFILE}"
  if [[ -z "$profile" && -f "$PROFILE_CONFIG" ]]; then
    # shellcheck disable=SC1090
    source "$PROFILE_CONFIG"
    profile="${SURFBOTS_INFERENCE_PROFILE:-}"
  fi
  if [[ -t 0 && -z "${REQUESTED_PROFILE}" ]]; then
    printf '\nLocal inference profile\n  1. Lightweight [default]\n     Qwen2.5-Coder-1.5B Q4_K_M; lower memory and CPU usage\n  2. Quality\n     Qwen2.5-Coder-3B Q4_K_M; higher generation quality and resource usage\n'
    read -r -p "Select profile [${profile:-local-lightweight}]: " profile
  fi
  profile="${profile:-local-lightweight}"
  case "$profile" in
    1|local-lightweight) profile=local-lightweight ;;
    2|local-quality) profile=local-quality ;;
    openai) fail "OpenAI mode is unavailable in ${VERSION}; no API key was requested or stored." ;;
    *) fail "Unsupported inference profile: $profile" ;;
  esac
  printf 'SURFBOTS_INFERENCE_PROFILE=%q\n' "$profile" > "$PROFILE_CONFIG"
  export SURFBOTS_INFERENCE_PROFILE="$profile"
  info "Inference profile: $profile"
}


install_cli() {
  local data_home="${XDG_DATA_HOME:-$HOME/.local/share}"
  local cli_root="${data_home}/surfbots-dev-platform/cli"
  local venv="${cli_root}/venv"
  local cli_source="${PLATFORM_ROOT}/tooling/repo-bootstrap"

  info "Installing standalone surfbots-dev CLI..."

  if [[ ! -f "${cli_source}/surfbots-dev" ]]; then
    fail "CLI source not found: ${cli_source}/surfbots-dev"
  fi

  mkdir -p "${BIN_DIR}"
  mkdir -p "${cli_root}/repo-bootstrap"

  # Create the bash wrapper that will be installed to ~/.local/bin/surfbots-dev
  cat > "${BIN_DIR}/surfbots-dev" <<WRAPPER
#!/usr/bin/env bash
set -e

DATA_HOME="\${XDG_DATA_HOME:-\$HOME/.local/share}"
CLI_ROOT="\${DATA_HOME}/surfbots-dev-platform/cli"

# Resolve the Python runtime from the CLI bundle
PYTHON_RUNTIME="\${CLI_ROOT}/venv/bin/python"
if [[ ! -x "\${PYTHON_RUNTIME}" ]]; then
  echo "Error: Python runtime not found at \${PYTHON_RUNTIME}" >&2
  exit 1
fi

# Execute the CLI with all arguments
exec "\${PYTHON_RUNTIME}" "\${CLI_ROOT}/repo-bootstrap/surfbots-dev" "\$@"
WRAPPER

  chmod 755 "${BIN_DIR}/surfbots-dev"

  # Copy the Python script and support modules to cli/repo-bootstrap/
  rm -rf "${cli_root}/repo-bootstrap"
  mkdir -p "${cli_root}/repo-bootstrap"
  cp -a "${cli_source}/." "${cli_root}/repo-bootstrap/"

  # The virtual environment is also part of the installed runtime,
  # not the source checkout.
  rm -rf "${venv}"
  python3 -m venv "${venv}"

  "${venv}/bin/python" -m pip install     --quiet     --upgrade     pip     pyyaml     watchfiles

  export PATH="${BIN_DIR}:${PATH}"

  info "Installed standalone CLI:"
  info "  Launcher: ${BIN_DIR}/surfbots-dev"
  info "  Runtime:  ${cli_root}"

  # Install and enable automatic watcher service
  install_watcher_service
}

# Update the standalone CLI from authoritative source
update_cli() {
  local cli_root="${XDG_DATA_HOME:-$HOME/.local/share}/surfbots-dev-platform/cli"
  local repo_bootstrap="${cli_root}/repo-bootstrap"
  local installed_cli="${repo_bootstrap}/surfbots-dev"

  info "Updating surfbots-dev CLI from authoritative source..."

  if [[ ! -f "${PLATFORM_ROOT}/tooling/repo-bootstrap/surfbots-dev" ]]; then
    fail "CLI source not found: ${PLATFORM_ROOT}/tooling/repo-bootstrap/surfbots-dev"
  fi

  if [[ ! -x "${cli_root}/repo-bootstrap/surfbots-dev" ]]; then
    info "CLI not installed yet. Running initial installation..."
    install_cli
    return $?
  fi

  # Run the update command
  info "Running surfbots-dev update-cli..."
  "${cli_root}/repo-bootstrap/surfbots-dev" update-cli

  info "CLI update complete"
}

# Install and enable the user-level watcher service
install_watcher_service() {
  info "Setting up automatic repository monitoring..."

  # Determine the surfbots-dev path
  local cli_root="${XDG_DATA_HOME:-$HOME/.local/share}/surfbots-dev-platform/cli"
  local surfbots_dev="${HOME}/.local/bin/surfbots-dev"

  if [[ ! -f "${surfbots_dev}" ]]; then
    warn "surfbots-dev not found at ${surfbots_dev}; watcher service cannot be installed"
    return 0
  fi

  # Create systemd user directory
  local systemd_user_dir="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"
  mkdir -p "${systemd_user_dir}"

  # Write the watcher unit file
  local unit_path="${systemd_user_dir}/surfbots-dev-watch.service"
  cat > "${unit_path}" <<EOF
[Unit]
Description=Surfbots incremental repository watcher
Documentation=https://github.com/franknaworg/surfbots-dev-platform
After=default.target

[Service]
Type=simple
ExecStart=${surfbots_dev} repo watch-run
Restart=on-failure
RestartSec=10
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=default.target
EOF

  info "  Unit file: ${unit_path}"

  # Reload systemd and enable the service
  if command -v systemctl >/dev/null 2>&1; then
    systemctl --user daemon-reload 2>/dev/null || true
    systemctl --user enable --now surfbots-dev-watch.service 2>/dev/null || true
    info "  Watcher service enabled and started"
  else
    info "  Watcher service installed. Enable with: systemctl --user daemon-reload && systemctl --user enable --now surfbots-dev-watch.service"
  fi
}

# install_port_forward_services - Install systemd user services for port-forwards
install_port_forward_services() {
  info "Installing systemd port-forward services..."
  local systemd_user_dir="${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user"
  local script_dir="${PLATFORM_ROOT}/scripts/systemd"
  
  mkdir -p "${systemd_user_dir}"
  
  # Copy unit files
  local unit_files=(
    "surfbots-indexer-port-forward.service"
    "surfbots-search-port-forward.service"
    "surfbots-mcp-port-forward.service"
    "surfbots-qdrant-port-forward.service"
    "surfbots-embedding-port-forward.service"
    "surfbots-generation-port-forward.service"
    "surfbots-reranker-port-forward.service"
  )
  
  for unit_file in "${unit_files[@]}"; do
    if [ -f "${script_dir}/${unit_file}" ]; then
      cp "${script_dir}/${unit_file}" "${systemd_user_dir}/"
      info "  Installed ${unit_file}"
    fi
  done
  
  # Reload systemd and enable services
  if command -v systemctl >/dev/null 2>&1; then
    systemctl --user daemon-reload 2>/dev/null || true
    
    # Enable all port-forward services
    for unit_file in "${unit_files[@]}"; do
      systemctl --user enable "${unit_file}" 2>/dev/null || true
    done
    
    # Start all port-forward services
    for unit_file in "${unit_files[@]}"; do
      systemctl --user start "${unit_file}" 2>/dev/null || true
    done
    
    info "  Port-forward services installed, enabled, and started"
  else
    info "  Port-forward services installed. Enable with: systemctl --user daemon-reload && systemctl --user enable <service> && systemctl --user start <service>"
  fi
}

# Helper functions for building images with immutable tags and records
service_build_context() {
  case "$1" in
    code-indexer) echo "src/indexer" ;;
    code-search-api) echo "src/code-search-api" ;;
    mcp-server) echo "src/mcp-server" ;;
    model-embedding) echo "src/model-embedding" ;;
    model-reranker) echo "src/model-reranker" ;;
    model-generation)
      warn "model-generation uses upstream image ghcr.io/ggml-org/llama.cpp:server"
      return 2
      ;;
    *)
      fail "Unknown service: $1"
      return 2
      ;;
  esac
}

make_build_tag() {
  local stamp sha
  stamp="$(date -u +%Y%m%d%H%M%S)"
  sha="$(git -C "${PLATFORM_ROOT}" rev-parse --short HEAD 2>/dev/null || echo nogit)"
  printf '%s-%s
' "${stamp}" "${sha}"
}

build_record_file() {
  echo "${BUILD_RECORD_DIR}/$1.latest"
}

record_built_image() {
  local service="$1" image="$2"
  mkdir -p "${BUILD_RECORD_DIR}"
  printf '%s
' "${image}" > "$(build_record_file "${service}")"
}

build_and_import_images() {
  local service context dockerfile tag host_image cluster_image image_id
  local entries=("code-indexer" "code-search-api" "mcp-server" "model-embedding" "model-reranker")
  
  for service in "${entries[@]}"; do
    context="$(service_build_context "${service}")" || continue
    dockerfile="${context}/Dockerfile"
    
    if [[ ! -f "${PLATFORM_ROOT}/${dockerfile}" ]]; then
      fail "Dockerfile not found for ${service}: ${PLATFORM_ROOT}/${dockerfile}"
    fi
    
    tag="$(make_build_tag)"
    host_image="localhost:5000/surfbots/${service}:${tag}"
    cluster_image="${CLUSTER_REGISTRY}/surfbots/${service}:${tag}"
    
    info "Building ${service}"
    info "  Context: ${PLATFORM_ROOT}/${context}"
    info "  Image: ${cluster_image}"
    
    # Build the image with the cluster-visible tag
    # This loads it into docker daemon (because k3d cluster has access to this registry)
    docker build -f "${PLATFORM_ROOT}/${dockerfile}" -t "${cluster_image}" "${PLATFORM_ROOT}/${context}"
    
    # Import into k3d cluster
    info "Importing ${service} into k3d cluster..."
    k3d image import "${cluster_image}" -c surfbots-dev-platform 2>/dev/null ||       info "Image import skipped (image already in cluster)"
    
    # Record the cluster image reference for deploy
    record_built_image "${service}" "${cluster_image}"
    info "Recorded image: $(build_record_file "${service}")"
    info "  ${cluster_image}"
  done
}

run_platform() {
  cd "${PLATFORM_ROOT}"
  export SURFBOTS_DATA_HOME="${DATA_HOME}"
  if ! k3d cluster list | awk 'NR > 1 {print $1}' | grep -qx "surfbots-dev-platform"; then
    ./cluster.sh create
  fi
  build_and_import_images
  ./surfbots-admin.sh start
  ./cluster.sh test
}

configure_clients() {
  local repository_path="$1"
  "${BIN_DIR}/surfbots-dev" mcp configure auto --path "${repository_path}"
}

initialize_repository() {
  local repository_path="$1" answer=Y
  [[ -d "${repository_path}/.git" ]] || return 0
  if [[ -t 0 ]]; then
    read -r -p "Initialize and index ${repository_path}? [Y/n] " answer
    answer="${answer:-Y}"
  fi
  [[ "${answer}" =~ ^[Yy]$ ]] || return 0
  "${BIN_DIR}/surfbots-dev" init "${repository_path}"
  configure_clients "${repository_path}"
  "${BIN_DIR}/surfbots-dev" repo add "${repository_path}"
}

main() {
  require_linux
  check_dependencies
  hardware_summary
  choose_inference_profile
  install_cli
  install_port_forward_services
  run_platform
  local repository_path="${SURFBOTS_PROJECT_PATH:-$PWD}"
  configure_clients "${repository_path}"
  initialize_repository "${repository_path}"
  printf '\nSurfbots Dev Platform %s installed successfully\nMCP: ' "${VERSION}"
  "${PLATFORM_ROOT}/surfbots-admin.sh" urls | awk '/MCP Server:/ {print $NF; exit}'
  printf 'Data: %s\nLogs: %s\n' "${DATA_HOME}" "${LOG_FILE}"
}

main "$@"
