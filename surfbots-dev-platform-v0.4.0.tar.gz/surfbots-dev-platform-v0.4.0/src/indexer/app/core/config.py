"""Configuration management for the code indexer service."""
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional


class Settings(BaseSettings):
    """Application settings."""
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8"
        # case_sensitive=True removed - pydantic-settings reads env vars case-insensitively by default
    )

    # Server settings
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False

    # Qdrant settings
    qdrant_url: str = "http://localhost:6333"
    qdrant_api_key: Optional[str] = None

    # Model service endpoints
    model_endpoint: str = "http://localhost:8000"
    embedding_endpoint: str = "http://localhost:8001"
    reranker_endpoint: str = "http://localhost:8002"

    # Repository settings
    max_file_size_mb: int = 10
    supported_extensions: list = [
        ".py",
        ".ts",
        ".tsx",
        ".js",
        ".jsx",
        ".sh",
        ".bash",
        ".zsh",
        ".yaml",
        ".yml",
        ".json",
        ".md",
        ".txt"
    ]

    # Indexing settings
    chunk_size: int = 500
    chunk_overlap: int = 50
    embedding_model: str = "text-embedding-3-large"

    # Vector database settings
    qdrant_vector_size: int = 1024  # Must match embedding model output

    # Development Memory settings
    session_memory_enabled: bool = True
    session_memory_transient_days: int = 30
    session_memory_max_transient_records: int = 100
    session_memory_context_limit: int = 10
    session_memory_context_char_budget: int = 6_000

    # Rate limiting
    rate_limit_requests: int = 100
    rate_limit_window: int = 60  # seconds

    # SSH key for private Git repositories
    # If not provided, will attempt to read the first .pub key from ~/.ssh
    ssh_key: Optional[str] = None


# Global settings instance
settings = Settings()
