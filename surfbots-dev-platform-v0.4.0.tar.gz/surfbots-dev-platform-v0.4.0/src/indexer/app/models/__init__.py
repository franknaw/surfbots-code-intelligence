"""Data models for the code indexer service."""
from pydantic import BaseModel
from typing import Optional, List, Dict, Any, Union
from datetime import datetime


class GitSource(BaseModel):
    """Git repository source configuration."""
    url: str
    branch: Optional[str] = "main"
    commit: Optional[str] = None
    username: Optional[str] = None  # For token-based auth
    password: Optional[str] = None  # For token-based auth
    ssh_key: Optional[str] = None  # For SSH key-based auth


class LocalSource(BaseModel):
    """Local filesystem source configuration."""
    path: str


class RepositoryBase(BaseModel):
    """Base repository model."""
    name: str
    source_type: str  # local, git, github, gitlab
    branch: Optional[str] = "main"


class RepositoryCreate(RepositoryBase):
    """Request model for creating a repository."""
    source: Union[Dict[str, Any], GitSource, LocalSource]
    include: Optional[List[str]] = [
        "**/*.py",
        "**/*.ts",
        "**/*.tsx",
        "**/*.yaml",
        "**/*.md"
    ]
    exclude: Optional[List[str]] = [
        ".git/**",
        "node_modules/**",
        "dist/**",
        "build/**",
        ".venv/**"
    ]


class RepositoryResponse(BaseModel):
    """Response model for repository operations."""
    repository_id: str
    name: str
    branch: str
    source_type: str
    status: str  # registered, indexing, indexed, failed
    created_at: datetime
    last_indexed_at: Optional[datetime] = None
    file_count: int = 0
    chunk_count: int = 0
    indexed_commit: Optional[str] = None
    repository_commit: Optional[str] = None


class IndexJobBase(BaseModel):
    """Base index job model."""
    repository_id: str
    job_type: str  # full, sync, incremental


class IndexJobCreate(IndexJobBase):
    """Request model for creating an index job."""
    force: Optional[bool] = False


class IndexJobResponse(BaseModel):
    """Response model for index job operations."""
    job_id: str
    repository_id: str
    job_type: str
    status: str  # pending, running, completed, failed
    progress: float = 0.0
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error_message: Optional[str] = None
    files_indexed: int = 0
    chunks_created: int = 0
    indexed_commit: Optional[str] = None


class SyncRequest(BaseModel):
    """Request model for sync operation."""
    repository_id: str
    base_commit: str
    changes: List[Dict[str, Any]]  # {path, operation, content}


class SyncResponse(BaseModel):
    """Response model for sync operation."""
    success: bool
    files_updated: int
    chunks_updated: int
    indexed_commit: str
