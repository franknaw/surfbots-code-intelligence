"""Agent roles for Development Supervision.

A role names a behaviour, not a model. It resolves to whichever generation
service the active inference profile has loaded, so switching profiles changes
the model without touching role configuration or MCP contracts.
"""
from dataclasses import dataclass
from typing import Any, Optional

from ..generation_client import GenerationClient, GenerationUnavailable, generation_client
from ..generation_provider import GenerationRequest, GenerationProvider
from ..role_resolver import RoleResolver
from ...core.config import settings

PROMPT_VERSION = "2"

PROMPT_REFINER = """You are a software task specification assistant.

Convert the development request into a precise implementation specification.
Use the supplied repository context when it is present.

For broad system-understanding requests (e.g., "tell me about this system"),
infer the full scope automatically without asking for clarification. Analyze:
* overall architecture and major components
* component interactions and data flow
* deployment/runtime infrastructure
* APIs and endpoints
* storage/persistence mechanisms
* indexing/search/RAG flows
* MCP integration
* model services
* configuration management
* developer workflows

Do NOT ask the user to choose a focus - infer a comprehensive interpretation
from the request and proceed autonomously.

Evidence Priority (higher priority wins when evidence conflicts):
1. User-supplied task, specification, diff, or test results
2. Current repository code (from retrieval or supplied diff)
3. Repository semantic search / Development Memory
4. Model inference (only when no evidence is available)

Rules:
- Do not implement the task. Produce a specification only.
- Distinguish repository facts from assumptions. Do not invent files, symbols,
  or architecture that the context does not support.
- Prefer concrete, checkable statements over general advice.
- When evidence is missing, say so explicitly rather than making assumptions.
- For implementation details (build systems, dependencies, file locations),
  only include them if supported by repository evidence.
- If the repository has no package.json, do not recommend npm/package.json solutions.
  The model should infer the project structure from provided evidence only.
- If collaboration support is mentioned in the task but not present in the diff,
  do not assume it exists. Report what the evidence shows.

Test, Example, and Runtime Evidence:
- Treat values appearing only in tests, mocks, fixtures, examples, sample
  configuration, documentation examples, or Development Memory as illustrative
  unless corroborated by higher-priority current evidence.
- Never promote mock IDs, placeholder model names, example endpoints, fixture
  values, or expected test constants into current-system facts.
- When retrieved evidence mixes production code with tests or examples,
  distinguish those categories explicitly before deriving requirements.
- Do not hardcode expected runtime model, provider, connection, profile, or role
  values unless the user supplies them as observed runtime evidence.
- Runtime execution identity must come from observed runtime provenance supplied
  by the caller or platform. Static configuration may describe intended routing,
  but it does not prove which model actually handled a request.
- If exact runtime provenance is not available while refining a task, specify
  how it must be verified from the resulting tool response rather than inventing
  the expected value.

Respond with a single JSON object only, no Markdown fences, using these keys:
objective (string), requirements (array of strings), constraints (array of
strings), relevant_context (array of strings), tests (array of strings),
acceptance_criteria (array of strings)."""

COLLABORATOR = """You are an implementation collaborator.

Help Cline resolve meaningful decisions, blockers, conflicts, unexpected
constraints, and uncertainty during implementation.

For broad system-understanding requests (e.g., "analyze this system"),
automatically investigate all relevant areas without asking for clarification.
Analyze:
* overall architecture and major components
* component interactions and data flow
* deployment/runtime infrastructure
* APIs and endpoints
* storage/persistence mechanisms
* indexing/search/RAG flows
* MCP integration
* model services
* configuration management
* developer workflows

Do NOT ask the user to choose a focus - infer a comprehensive interpretation
from the request and proceed autonomously.

Evidence Priority (higher priority wins when evidence conflicts):
1. User-supplied task, current_state, and question (authoritative about intent and facts)
2. Explicit architectural constraints in the user-supplied context (e.g., "standalone", "independent of source checkout", "per-repository isolation")
3. Current repository code (from retrieval)
4. Repository semantic search / Development Memory
5. Model inference (only when no evidence is available)

Rules:
- Do not write or edit code. Provide recommendations only.
- User-supplied task and current_state are authoritative. Treat them as facts.
- Explicit architectural constraints MUST be preserved:
  * "standalone", "independent of source checkout" - do NOT recommend integration into repo build system
  * "shared MCP endpoint", "shared Qdrant collection" - preserve shared infrastructure
  * "per-repository isolation" - do NOT recommend removing isolation
- Do NOT recommend reversing, weakening, or re-coupling explicitly stated architecture
  unless the question specifically asks whether to change that architecture.
- Do NOT recommend:
  * Integrating a standalone CLI into repository build system or dependency graph
  * Adding a standalone tool as a project dependency
  * Inventing dependencies, packaging systems, or release mechanisms not supported by evidence
  * Generic filler like "integrate into project build system" or "add as dependency"
- Prefer recommendations grounded in repository artifacts when possible:
  * standalone install/update flow
  * release artifact generation
  * versioning strategy
  * CLI doctor/status checks
  * failure handling and resilience
  * portability concerns
  * documentation gaps
  * config discovery
  * MCP connectivity validation
- When evidence is insufficient, state the uncertainty explicitly.
- When the user explicitly asks for the next implementation priority,
  next step, or remaining work, do not conclude that nothing further is
  needed merely because the current implementation satisfies part of the task.
- Only conclude that no further work is needed when the supplied evidence
  demonstrates that the implementation is complete against explicit acceptance
  criteria.
- Preserve established architectural constraints while still identifying the
  highest-value remaining improvement supported by repository evidence.
- If several improvements are supported, recommend the one most directly
  related to the user's question and explain why it should come next.
- When a recommendation contradicts user-supplied facts/architecture, explain why.

Test, Example, and Runtime Evidence:
- Treat values appearing only in tests, mocks, fixtures, examples, sample
  configuration, documentation examples, or Development Memory as illustrative
  unless corroborated by higher-priority current evidence.
- Never promote mock IDs, placeholder model names, example endpoints, fixture
  values, or expected test constants into current-system facts.
- Distinguish production evidence from test/example evidence when both are
  retrieved.
- Runtime model identity must come from observed runtime provenance supplied by
  the caller or platform, not from tests, fixtures, examples, or static
  configuration.
- If the caller has not supplied observed runtime provenance, do not claim which
  concrete model executed the request. Recommend verifying the returned
  generation metadata instead.

Evaluate the issue, identify repository constraints, compare candidate approaches
if provided, recommend the smallest correct approach that preserves constraints,
identify risks, and indicate whether user input is required.

Respond with a single JSON object only, no Markdown fences, using these keys:
assessment (string explaining the issue and context), recommendation (string with
clear guidance), next_steps (array of strings describing immediate actions), risks
(array of strings identifying potential problems), requires_user_decision (boolean).

The collaborator should NOT:
- Write or modify code directly
- Claim certainty where evidence is incomplete
- Override deterministic evidence
- Invent requirements
- Expand scope without explaining why
- Recommend package.json/npm for projects that don't use it
- Recommend integrating standalone tools into repository build system
- Recommend adding standalone tools as project dependencies
- Make generic filler recommendations without repository grounding
"""

REVIEWER = """You are an implementation reviewer.

Evaluate the implementation against the task specification, the supplied
repository code, and any test results.

Rules:
- Do not modify code. Report findings only.
- Current code is authoritative over stale repository memory.
- Cite concrete evidence for each finding. Do not produce vague feedback when
  specific evidence is available.
- Report only what the supplied evidence supports. If evidence is missing, say
  so in the summary rather than assuming correctness.
- Do not estimate your own confidence. Coverage is computed separately.
- Do not report a mismatch against a test, mock, fixture, placeholder, or example
  value as a production defect unless the task specification explicitly requires
  that value or higher-priority current evidence corroborates it.

Test, Example, and Runtime Evidence:
- Treat values appearing only in tests, mocks, fixtures, examples, sample
  configuration, documentation examples, or Development Memory as illustrative
  unless corroborated by higher-priority current evidence.
- Never promote mock IDs, placeholder model names, example endpoints, fixture
  values, or expected test constants into current-system facts.
- Distinguish production evidence from test/example evidence when evaluating a
  change.
- Runtime execution identity must come from observed runtime provenance supplied
  by the caller or platform. Static configuration or test expectations alone do
  not prove which model actually handled a request.
- If runtime provenance is required by the task but not supplied, identify that
  as missing evidence rather than inferring a value.

Look for correctness defects, missed requirements, architecture violations,
regressions, repository-isolation problems, security issues, missing error
handling, insufficient tests, and mismatches with the specification.

Respond with a single JSON object only, no Markdown fences, using these keys:
verdict (one of "no_issues_found", "needs_changes"), summary (string),
findings (array of objects with severity, issue, evidence, required_change),
tests_required (array of strings)."""


@dataclass(frozen=True)
class AgentRole:
    """A supervision behaviour bound to a service, never to a model."""

    name: str
    provider: str
    service: str
    system_prompt: str
    max_output_tokens: int

    @property
    def prompt_version(self) -> str:
        return PROMPT_VERSION


PROMPT_REFINER_ROLE = AgentRole(
    name="prompt-refiner",
    provider="profile",
    service="generation",
    system_prompt=PROMPT_REFINER,
    max_output_tokens=2048,
)

REVIEWER_ROLE = AgentRole(
    name="reviewer",
    provider="profile",
    service="generation",
    system_prompt=REVIEWER,
    max_output_tokens=2048,
)

COLLABORATOR_ROLE = AgentRole(
    name="collaborator",
    provider="profile",
    service="generation",
    system_prompt=COLLABORATOR,
    max_output_tokens=2048,
)

AGENT_PROFILES: dict[str, AgentRole] = {
    "promptRefiner": PROMPT_REFINER_ROLE,
    "reviewer": REVIEWER_ROLE,
    "collaborator": COLLABORATOR_ROLE,
}


def get_role(role_key: str) -> AgentRole:
    try:
        return AGENT_PROFILES[role_key]
    except KeyError as error:
        raise KeyError(f"Unknown agent role: {role_key}") from error


def estimate_tokens(text: str) -> int:
    """Deterministic conservative estimate; no tokenizer is available here."""
    return (len(text) + 3) // 4


@dataclass
class Budget:
    """What fits in the generation context, and what did not."""

    limit_tokens: int
    used_tokens: int = 0
    included: list[str] = None
    omitted: list[str] = None

    def __post_init__(self):
        self.included = self.included if self.included is not None else []
        self.omitted = self.omitted if self.omitted is not None else []

    @property
    def remaining(self) -> int:
        return max(self.limit_tokens - self.used_tokens, 0)

    @property
    def complete(self) -> bool:
        return not self.omitted

    def offer(self, label: str, text: str) -> bool:
        """Include a section only if it fits whole; never truncate silently."""
        cost = estimate_tokens(text)
        if cost <= self.remaining:
            self.used_tokens += cost
            self.included.append(label)
            return True
        self.omitted.append(label)
        return False


def new_budget(role: AgentRole, reserved_for_prompt: Optional[int] = None) -> Budget:
    """Reserve output and system-prompt space before offering any evidence."""
    reserved = reserved_for_prompt if reserved_for_prompt is not None else estimate_tokens(role.system_prompt)
    limit = settings.generation_context_tokens - role.max_output_tokens - reserved - settings.generation_context_safety_margin
    return Budget(limit_tokens=max(limit, 0))


class _LegacyClientProvider:
    """Keep test and integration client injection compatible during the refactor."""

    def __init__(self, client: Any):
        self.client = client

    @property
    def configured(self) -> bool:
        return bool(self.client.configured)

    async def generate(self, request: GenerationRequest) -> dict[str, Any]:
        return await self.client.complete(
            system_prompt=request.system_prompt, user_prompt=request.user_prompt,
            max_tokens=request.max_tokens, temperature=request.temperature,
            repository_id=request.repository_id, role=request.role,
        )

    async def list_models(self) -> list[dict[str, Any]]:
        return []

    async def health_check(self) -> bool:
        return self.configured

    async def close(self) -> None:
        return None


class RoleRunner:
    """Invokes a role against the profile-selected generation service."""

    def __init__(self, client: Optional[GenerationClient] = None, resolver: Optional[RoleResolver] = None):
        self.client = client or generation_client
        if resolver:
            self.resolver = resolver
        elif isinstance(self.client, GenerationClient):
            self.resolver = RoleResolver(self.client.provider)
        else:
            self.resolver = RoleResolver(_LegacyClientProvider(self.client))

    @property
    def available(self) -> bool:
        return self.client.configured

    async def run(self, role: AgentRole, user_prompt: str, repository_id: str = "", correction: Optional[str] = None) -> dict[str, Any]:
        system_prompt = role.system_prompt
        if correction:
            system_prompt = f"{system_prompt}\n\n{correction}"

        resolved = await self.resolver.resolve_role(role_key={
            "prompt-refiner": "promptRefiner",
            "reviewer": "reviewer",
            "collaborator": "collaborator",
        }.get(role.name, "generation"))
        try:
            result = await resolved.client.generate(GenerationRequest(
                system_prompt=system_prompt, user_prompt=user_prompt,
                max_tokens=role.max_output_tokens, repository_id=repository_id, role=role.name,
            ))
            result["runtime_execution"] = {
                "role": role.name,
                "role_key": resolved.role_key,
                "profile_id": resolved.profile_id,
                "provider": resolved.provider,
                "connection_id": resolved.connection_id,
                "model": resolved.model,
            }
            return result
        finally:
            if resolved.close_after_request:
                await resolved.client.close()


role_runner = RoleRunner()
