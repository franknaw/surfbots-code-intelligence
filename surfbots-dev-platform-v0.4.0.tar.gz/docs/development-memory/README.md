# Development Memory

Development Memory is a repository-scoped record of durable engineering outcomes from coding sessions. It complements code search by preserving what changed, why it changed, what remains, and how the work was validated.

It must not store hidden model reasoning or raw conversation transcripts. Store concise, reviewable outcomes: decisions, constraints, milestones, issues, checkpoints, affected files and symbols, and test results.

## Current Implementation

Phases 1 through 6 have an initial implementation:

- Indexer-owned `session-memory` Qdrant collection, separate from `code-index`.
- Repository-scoped checkpoint creation with typed, bounded input and server-side secret redaction.
- Deterministic recent reads, semantic search with repository/type/retention/file/symbol/time filters, and character-budgeted durable-first context.
- Code Search API proxy endpoints, plus MCP `get_recent_context` and `search_repository_memory` tools.
- Explicit `surfbots-dev memory checkpoint` host-side producer with Git commit attachment and local redaction.
- Configurable transient retention, scheduled and manual cleanup, repository lifecycle deletion, supersession links, outcome/latency metrics, and admin-summary counts.

Available endpoints:

```text
POST /api/v1/repositories/{repository_id}/memory
GET  /api/v1/repositories/{repository_id}/memory/recent?limit=5
POST /api/v1/repositories/{repository_id}/memory/search?query=...&created_after=...
GET  /api/v1/repositories/{repository_id}/memory/context?limit=10&created_after=...
DELETE /api/v1/repositories/{repository_id}/memory/{memory_id}
POST /api/v1/memory/cleanup?dry_run=true
```

The write endpoint requires `session_id` and `summary`; `created_at` defaults to the current UTC time in the indexer. It accepts the record fields described below and validates allowed memory and retention classes. Successful host-side `repo reindex` operations create a best-effort lifecycle checkpoint. Raw session capture remains deliberately unsupported: it would risk storing transcripts and hidden reasoning rather than reviewable engineering outcomes.

## Goals

- Restore useful working context for a new Cline, Copilot, or MCP session in a few hundred tokens.
- Keep code search (`code-index`) and session knowledge (`session-memory`) independently queryable and retainable.
- Make key decisions discoverable from the code files and symbols they affect.
- Preserve repository isolation, explicit retention, and user control over stored session data.

## Architecture

```text
Coding client / checkpoint producer
                |
                v
         Code Search API
           |           |
           v           v
     code-index    session-memory
           |           |
           +----- Qdrant -----+
                               |
                               v
                          MCP Server
                               |
                               v
                    Context supplied to agent
```

The MCP server should remain a client of Code Search API. Qdrant collection management, persistence, and search belong behind the API/indexer boundary, matching the current platform design.

## Record Contract

Start with a versioned `session_checkpoint` record. Keep the searchable prose compact and structured fields explicit.

```json
{
  "repository_id": "repo_081d12f2ff32",
  "session_id": "session_20260901_001",
  "created_at": "2026-09-01T15:40:00Z",
  "memory_type": "session_checkpoint",
  "retention_class": "transient",
  "summary": "Completed repository snapshot refresh lifecycle and validated idempotent indexing.",
  "decisions": ["The host CLI owns canonical-source refresh."],
  "files_touched": ["tooling/repo-bootstrap/surfbots-dev"],
  "symbols_touched": ["delete_repository_points"],
  "completed": ["Repository-scoped Qdrant deletion"],
  "unresolved": ["Complete MCP client workflow validation"],
  "test_results": ["repository_tests: 25 passed"],
  "commit_sha": "optional commit SHA",
  "supersedes": ["prior-memory-id"]
}
```

Required request fields: `session_id` and `summary`. The repository identifier comes from the path, and remaining fields have safe defaults.

Allowed initial values:

| Field | Values |
| --- | --- |
| `memory_type` | `session_checkpoint`, `decision`, `issue`, `milestone`, `preference` |
| `retention_class` | `transient`, `durable` |

Use Qdrant payload fields for exact filters (`repository_id`, timestamps, type, retention, files, symbols). Embed a deliberately constructed text representation of the summary, decisions, completed work, unresolved work, and test outcomes. Do not embed arbitrary transcript text.

## Delivery Phases

### Phase 0: Boundaries and Acceptance Criteria

Decide which client or host process creates checkpoints, who can write records, and whether writes require an explicit user action in the first release. Document content limits, redaction rules, and the behavior when no `repository_id` is known.

Acceptance criteria:

- A short privacy and data-handling policy is approved.
- Checkpoint input has maximum field and total-size limits.
- The first release excludes raw conversations, hidden reasoning, credentials, and unrestricted command output.

### Phase 1: Storage Foundation

Create an independently managed `session-memory` collection. Its vector size must match the active embedding model, while its distance metric should follow the existing `code-index` convention. Add Qdrant payload indexes for `repository_id`, `created_at`, `memory_type`, `retention_class`, `files_touched`, and `symbols_touched`.

Implement a small persistence service near the existing Qdrant ownership code in `src/indexer/app/core/database.py` and `src/indexer/app/services/`. It should provide idempotent upsert by a stable record ID, filtered listing/search, repository-scoped deletion, and collection health checks.

Acceptance criteria:

- Creating the collection is idempotent and does not alter `code-index`.
- A repository-scoped delete cannot remove another repository's memory.
- A restart preserves records and a health check reports collection availability.
- Unit tests cover schema validation, filtering, upsert idempotency, and deletion isolation.

### Phase 2: API and Validation

Expose typed API models and endpoints from Code Search API. Keep the API responsible for validation, authorization policy, request-size limits, and normalized output.

Initial endpoints:

```text
POST   /api/v1/repositories/{repository_id}/memory
GET    /api/v1/repositories/{repository_id}/memory/recent
POST   /api/v1/repositories/{repository_id}/memory/search
GET    /api/v1/repositories/{repository_id}/memory/context
DELETE /api/v1/repositories/{repository_id}/memory/{memory_id}
```

`recent` is deterministic and timestamp ordered. `search` combines vector similarity with mandatory repository filtering. `context` returns a bounded, agent-ready result containing recent checkpoints plus relevant durable decisions; it must state when results are incomplete or unavailable.

Acceptance criteria:

- Invalid schemas, oversized inputs, and unknown enum values return clear `4xx` errors.
- Every read/write requires a repository identifier and is scoped to it.
- Search supports date, type, retention, file, and symbol filters.
- API tests exercise write, retrieve, semantic search, context budget, and failure handling.

### Phase 3: MCP Retrieval Tools

Add MCP tools to `src/mcp-server/app/api/mcp_server.py`, forwarding only to the Code Search API:

```text
get_recent_context(repository, days=14, limit=5)
search_repository_memory(repository, query, limit=10, file_path?, symbol?)
```

Use concise MCP output with labeled sections for recent activity, durable decisions, unresolved work, and validation results. Expose stored timestamps and record IDs so an agent can request more detail without receiving a large default response.

Do not make memory retrieval implicit in every code search initially. Add optional related-memory enrichment to `find_symbol` only after retrieval quality, prompt size, and latency are measured.

Acceptance criteria:

- MCP tool schemas, handlers, and README examples are documented.
- The tool returns a clear empty result for a repository with no memories.
- Code search and memory retrieval continue working independently when the other feature is unavailable.
- Contract tests validate the API-to-MCP transformation.

### Phase 4: Checkpoint Production

Build a producer that creates structured checkpoints at explicit lifecycle events: session end, major task completion, and optionally a manual command. Start with a host-side CLI integration rather than a Kubernetes workload that reads arbitrary developer directories.

The producer should validate locally, redact known sensitive patterns, attach repository identity and the current commit when available, and send only the structured record to the API. Treat automatic checkpoints as drafts until the producer can reliably distinguish a completed outcome from an incomplete attempt.

Acceptance criteria:

- A developer can create a checkpoint manually for a selected repository.
- The producer never uploads full chat logs or hidden reasoning.
- A failed upload is visible, retryable, and never blocks normal development work.
- Tests cover redaction, missing Git metadata, duplicate submission, and API failure.

### Phase 5: Retention, Supersession, and Deletion

Add configuration with separate transient and durable policies:

```yaml
sessionMemory:
  enabled: true
  retention:
    transientDays: 30
    maxTransientRecordsPerRepository: 100
  retrieval:
    recentSessions: 5
    semanticResults: 10
    contextTokenBudget: 1200
```

A scheduled cleanup job may purge only expired transient records. Durable records remain until explicitly deleted or superseded by a later decision. Preserve the previous record and link it through `supersedes`; do not silently rewrite history.

Acceptance criteria:

- Cleanup uses repository and retention filters and is dry-run capable.
- Explicit repository deletion removes all of its memory records.
- Superseded decisions display their current relationship.
- Retention and deletion behavior are covered by integration tests.

### Phase 6: Observability and Rollout

Extend the operational summary to report the `session-memory` collection: availability, point count, transient versus durable counts, newest checkpoint timestamp, and cleanup outcome. Emit metrics for write volume, retrieval latency, errors, empty retrievals, and cleanup deletions without logging sensitive content.

Roll out behind `sessionMemory.enabled`, first to one repository with synthetic checkpoints, then to opt-in repositories. Measure context size, retrieval relevance, latency, and false-positive rate before enabling symbol-linked enrichment.

Acceptance criteria:

- Disabled mode makes no memory reads or writes.
- Operators can identify collection health and cleanup state from existing platform diagnostics.
- Rollback consists of disabling the feature; it does not require deleting retained data.
- A documented migration and rollback procedure is tested in a non-production cluster.

## Retrieval Policy

Use deterministic retrieval before semantic retrieval:

1. Fetch the most recent bounded checkpoints for the repository.
2. Fetch matching durable decisions and unresolved issues.
3. Run semantic search only when the agent asks a focused question.
4. Deduplicate and enforce the context token budget before returning results.

Rank semantic results using similarity plus recency and durable-status signals. Keep these weights configurable and start with transparent output that shows why an item was selected.

## Security and Privacy Rules

- Never persist hidden chain-of-thought, raw private prompts, or complete conversation transcripts.
- Reject or redact credentials, tokens, private keys, and connection strings before storage and before logging.
- Scope all operations by `repository_id`; do not permit cross-repository fallback.
- Require an explicit retention class and support repository-wide deletion.
- Limit result payloads and pagination to avoid turning memory retrieval into transcript recovery.

## Testing Matrix

| Area | Required coverage |
| --- | --- |
| Storage | Collection bootstrap, dimensions, payload indexes, isolation, idempotent writes |
| API | Validation, permissions, filters, context budget, error responses |
| MCP | Tool discovery, forwarding, concise output, empty and degraded states |
| Producer | Redaction, Git metadata, manual creation, retries, duplicate checkpoints |
| Retention | Expiry, maximum count, durable protection, supersession, deletion |
| Operations | Metrics, summary output, disabled mode, migration and rollback |

## Suggested First Increment

Deliver only Phase 1 plus a minimal Phase 2 write/recent-read path. Use manually submitted synthetic checkpoints for one existing repository, verify Qdrant isolation and retrieval quality, then add MCP retrieval. This establishes the important data contract before automating session capture or broadening client integrations.
