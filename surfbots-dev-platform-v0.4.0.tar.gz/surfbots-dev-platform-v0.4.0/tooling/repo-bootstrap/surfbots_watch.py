"""Host-side filesystem watcher with debounce and periodic reconciliation.

Filesystem events are the fast path. Reconciliation is the correctness backstop
for missed events, queue overflow, sleep, crashes, and branch switches.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Callable
import logging
import threading
import time

from surfbots_sync import (
    DEFAULT_DEBOUNCE_SECONDS,
    DEFAULT_RECONCILE_SECONDS,
    IndexPolicy,
    RepositorySynchronizer,
)

logger = logging.getLogger("surfbots.watch")

MAX_BACKOFF_SECONDS = 60.0


class RepositoryWatcher:
    """Debounces events for one repository and serializes its sync passes."""

    def __init__(
        self,
        synchronizer: RepositorySynchronizer,
        debounce_seconds: float = DEFAULT_DEBOUNCE_SECONDS,
        reconcile_seconds: float = DEFAULT_RECONCILE_SECONDS,
    ):
        self.sync = synchronizer
        self.debounce_seconds = debounce_seconds
        self.reconcile_seconds = reconcile_seconds
        self._lock = threading.Lock()
        self._dirty = False
        self._pending_since: float | None = None
        self._last_reconcile = 0.0
        self._backoff = 0.0
        self._next_attempt = 0.0

    @property
    def repository_id(self) -> str:
        return self.sync.repository_id

    def note_event(self, now: float | None = None) -> None:
        """Record activity; the timer restarts so bursts coalesce into one pass."""
        with self._lock:
            self._dirty = True
            self._pending_since = now if now is not None else time.monotonic()
            self.sync.last_change_at = time.time()

    def _due(self, now: float) -> bool:
        if now < self._next_attempt:
            return False
        with self._lock:
            if self._dirty and self._pending_since is not None:
                return now - self._pending_since >= self.debounce_seconds
        return now - self._last_reconcile >= self.reconcile_seconds

    def tick(self, now: float | None = None) -> dict[str, Any] | None:
        """Run a synchronization pass if one is due. Never raises."""
        now = now if now is not None else time.monotonic()
        if not self._due(now):
            return None

        with self._lock:
            self._dirty = False
            self._pending_since = None

        try:
            result = self.sync.synchronize()
            self._last_reconcile = now
            self._backoff = 0.0
            self.sync.last_error = None
            if result.get("status") != "unchanged":
                logger.info(
                    "%s: %s changed, %s embedded, +%s/-%s chunks in %ss",
                    self.repository_id,
                    result.get("changed"),
                    result.get("embedded"),
                    result.get("chunks_added"),
                    result.get("chunks_removed"),
                    result.get("duration_seconds"),
                )
            return result
        except Exception as error:
            # A failure must not kill the watcher; reconciliation retries it.
            self._backoff = min(max(self._backoff * 2, 5.0), MAX_BACKOFF_SECONDS)
            self._next_attempt = now + self._backoff
            self._last_reconcile = now
            with self._lock:
                self._dirty = True
            self.sync.last_error = str(error)
            logger.warning(
                "%s: synchronization failed (%s); retrying in %.0fs",
                self.repository_id, error, self._backoff,
            )
            return {"repository_id": self.repository_id, "status": "error", "error": str(error)}


class WatchSupervisor:
    """Watches many repositories, one filesystem stream, shared tick loop."""

    def __init__(self, watchers: list[RepositoryWatcher], poll_seconds: float = 1.0):
        self.watchers = {w.repository_id: w for w in watchers}
        self.poll_seconds = poll_seconds
        self._stop = threading.Event()

    def stop(self) -> None:
        self._stop.set()
    def run_zero_repos(self) -> None:
        """Run in zero-repos mode: wait indefinitely without active watchers.
        
        This method is used when no repositories are registered.
        It keeps the watcher alive without attempting to watch any repos.
        """
        import logging
        logger = logging.getLogger("surfbots.watch")
        
        logger.info("Zero repositories to watch; waiting for repositories to be added")
        
        # Just wait for stop signal without doing anything
        # This prevents the systemd service from exiting (which would cause restart loops)
        self._stop.wait()


    def _roots(self) -> dict[str, str]:
        return {w.sync.canonical_source: rid for rid, w in self.watchers.items()}

    def _route(self, changed_paths: set[str]) -> None:
        roots = self._roots()
        now = time.monotonic()
        for raw in changed_paths:
            for root, repository_id in roots.items():
                if raw == root or raw.startswith(root.rstrip("/") + "/"):
                    relative = str(Path(raw).relative_to(root))
                    watcher = self.watchers[repository_id]
                    if watcher.sync.policy.includes(relative):
                        watcher.note_event(now)
                    break

    def run(self) -> None:
        """Reconcile everything at startup, then watch."""
        for watcher in self.watchers.values():
            watcher.tick(time.monotonic() + watcher.reconcile_seconds)

        try:
            from watchfiles import watch as watch_files
        except ImportError:
            logger.warning("watchfiles unavailable; falling back to periodic reconciliation only")
            self._run_poll_only()
            return

        roots = [w.sync.canonical_source for w in self.watchers.values()]
        logger.info("Watching %d repositor%s", len(roots), "y" if len(roots) == 1 else "ies")

        for batch in watch_files(*roots, stop_event=self._stop, rust_timeout=int(self.poll_seconds * 1000), yield_on_timeout=True):
            if batch:
                self._route({path for _, path in batch})
            now = time.monotonic()
            for watcher in self.watchers.values():
                watcher.tick(now)
            if self._stop.is_set():
                break

    def _run_poll_only(self) -> None:
        while not self._stop.is_set():
            now = time.monotonic()
            for watcher in self.watchers.values():
                watcher.tick(now)
            self._stop.wait(self.poll_seconds)
