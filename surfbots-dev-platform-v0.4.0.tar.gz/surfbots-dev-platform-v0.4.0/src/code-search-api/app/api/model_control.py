"""Internal localhost-tunneled model-profile control-plane routes."""
from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Header, HTTPException, Response
from pydantic import BaseModel, Field

from ..services.control_plane_auth import ControlPlaneUnauthorized, KubernetesTokenReviewer
from ..services.generation_provider import AzureOpenAIProvider, GenerationUnavailable, OpenAICompatibleProvider
from ..services.local_generation_rollout import LocalGenerationRollout
from ..services.model_profiles import ProfileRoleBinding, ProviderConnectionError, provider_connection_store
from ..services.profile_activation import ProfileActivationService
from ..services.role_resolver import RoleResolver
from ..services.generation_client import generation_client

from ..services.managed_generation.manager import ManagedGenerationManager
router = APIRouter(prefix="/api/v1/internal/model-control")
token_reviewer = KubernetesTokenReviewer()


async def require_local_control(authorization: Annotated[str | None, Header()] = None) -> str:
    scheme, _, token = (authorization or "").partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise HTTPException(status_code=401, detail="Missing local control-plane credential")
    try:
        return await token_reviewer.verify(token)
    except ControlPlaneUnauthorized as error:
        raise HTTPException(status_code=403, detail="Local control-plane authorization failed") from error


Actor = Annotated[str, Depends(require_local_control)]


class ConnectionInput(BaseModel):
    id: str = Field(min_length=1, max_length=63)
    name: str = Field(min_length=1, max_length=120)
    provider_type: str
    base_url: str = Field(min_length=1, max_length=2000)
    api_version: str | None = Field(default=None, max_length=30)
    token: str = Field(default="", max_length=20_000)


class ConnectionUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    provider_type: str | None = None
    base_url: str | None = Field(default=None, min_length=1, max_length=2000)
    api_version: str | None = Field(default=None, max_length=30)
    enabled: bool | None = None
    token: str | None = Field(default=None, min_length=1, max_length=20_000)


class RoleBindingInput(BaseModel):
    provider: str
    model: str = Field(min_length=1, max_length=200)
    connection_id: str | None = Field(default=None, max_length=63)


class ProfileInput(BaseModel):
    id: str = Field(min_length=1, max_length=63)
    name: str = Field(min_length=1, max_length=120)
    roles: dict[str, RoleBindingInput]


class ProfileCloneInput(BaseModel):
    id: str = Field(min_length=1, max_length=63)
    name: str = Field(min_length=1, max_length=120)


def connection_response(connection) -> dict[str, Any]:
    return {
        "id": connection.id, "name": connection.name, "provider_type": connection.provider_type,
        "base_url": connection.base_url, "api_version": connection.api_version, "enabled": connection.enabled, "has_token": connection.has_token,
        "created_at": connection.created_at, "updated_at": connection.updated_at,
        "last_tested_at": connection.last_tested_at, "last_test_status": connection.last_test_status,
    }


def profile_response(profile) -> dict[str, Any]:
    return {"id": profile.id, "name": profile.name, "roles": {
        key: {"provider": value.provider, "model": value.model, "connection_id": value.connection_id}
        for key, value in profile.roles.items()
    }, "created_at": profile.created_at, "updated_at": profile.updated_at}


def profile_bindings(body: ProfileInput) -> dict[str, ProfileRoleBinding]:
    return {key: ProfileRoleBinding(**value.model_dump()) for key, value in body.roles.items()}


async def provider_for_connection(connection_id: str) -> OpenAICompatibleProvider | AzureOpenAIProvider:
    connection = await provider_connection_store.get(connection_id)
    if not connection.enabled:
        raise ProviderConnectionError(f"Provider connection '{connection_id}' is disabled")
    token = await provider_connection_store.credentials.get(connection_id)
    if connection.provider_type == "azure-openai":
        if not token:
            raise ProviderConnectionError(f"Provider connection '{connection_id}' has no configured token")
        return AzureOpenAIProvider(connection.base_url, "control-plane-health", token, 30, 1, connection.api_version or "2025-04-01-preview")
    return OpenAICompatibleProvider(connection.base_url, "control-plane-health", token, 30, 1)


@router.get("/status")
async def status(_: Actor) -> dict[str, Any]:
    state = provider_connection_store.get_activation_state()
    active = provider_connection_store.get_active_profile()
    return {"activation": state.__dict__, "active_profile": profile_response(active)}


@router.get("/connections")
async def list_connections(_: Actor) -> list[dict[str, Any]]:
    return [connection_response(item) for item in await provider_connection_store.list()]


@router.post("/connections", status_code=201)
async def create_connection(body: ConnectionInput, actor: Actor) -> dict[str, Any]:
    try:
        connection = await provider_connection_store.create(**body.model_dump(), actor=actor)
        return connection_response(connection)
    except ProviderConnectionError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


@router.get("/connections/{connection_id}")
async def get_connection(connection_id: str, _: Actor) -> dict[str, Any]:
    try:
        return connection_response(await provider_connection_store.get(connection_id))
    except ProviderConnectionError as error:
        raise HTTPException(status_code=404, detail=str(error)) from error


@router.patch("/connections/{connection_id}")
async def update_connection(connection_id: str, body: ConnectionUpdate, actor: Actor) -> dict[str, Any]:
    try:
        return connection_response(await provider_connection_store.update(connection_id, **body.model_dump(exclude_unset=True), actor=actor))
    except ProviderConnectionError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


@router.delete("/connections/{connection_id}", status_code=204)
async def delete_connection(connection_id: str, actor: Actor) -> Response:
    try:
        provider_connection_store.delete(connection_id, actor)
        return Response(status_code=204)
    except ProviderConnectionError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


@router.get("/connections/{connection_id}/models")
async def list_connection_models(connection_id: str, _: Actor) -> dict[str, Any]:
    provider = None
    try:
        provider = await provider_for_connection(connection_id)
        return {"connection_id": connection_id, "models": await provider.list_models()}
    except (ProviderConnectionError, GenerationUnavailable) as error:
        raise HTTPException(status_code=502, detail="Provider model discovery failed") from error
    finally:
        if provider:
            await provider.close()


@router.post("/connections/{connection_id}/test")
async def test_connection(connection_id: str, _: Actor) -> dict[str, Any]:
    provider = None
    try:
        provider = await provider_for_connection(connection_id)
        models = await provider.list_models()
        return {"connection_id": connection_id, "status": "connected", "models_discovered": len(models)}
    except (ProviderConnectionError, GenerationUnavailable) as error:
        raise HTTPException(status_code=502, detail="Provider connection test failed") from error
    finally:
        if provider:
            await provider.close()


@router.get("/profiles")
async def list_profiles(_: Actor) -> list[dict[str, Any]]:
    return [profile_response(profile) for profile in provider_connection_store.list_profiles()]


@router.post("/profiles", status_code=201)
async def create_profile(body: ProfileInput, actor: Actor) -> dict[str, Any]:
    try:
        return profile_response(provider_connection_store.create_profile(id=body.id, name=body.name, roles=profile_bindings(body), actor=actor))
    except ProviderConnectionError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


@router.get("/profiles/{profile_id}")
async def get_profile(profile_id: str, _: Actor) -> dict[str, Any]:
    try:
        return profile_response(provider_connection_store.get_profile(profile_id))
    except ProviderConnectionError as error:
        raise HTTPException(status_code=404, detail=str(error)) from error


@router.patch("/profiles/{profile_id}")
async def update_profile(profile_id: str, body: ProfileInput, actor: Actor) -> dict[str, Any]:
    if body.id != profile_id:
        raise HTTPException(status_code=400, detail="Profile ID cannot be changed")
    try:
        return profile_response(provider_connection_store.update_profile(profile_id, name=body.name, roles=profile_bindings(body), actor=actor))
    except ProviderConnectionError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


@router.post("/profiles/{profile_id}/clone", status_code=201)
async def clone_profile(profile_id: str, body: ProfileCloneInput, actor: Actor) -> dict[str, Any]:
    try:
        source = provider_connection_store.get_profile(profile_id)
        return profile_response(provider_connection_store.create_profile(id=body.id, name=body.name, roles=source.roles, actor=actor))
    except ProviderConnectionError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


@router.get("/profiles/{profile_id}/export")
async def export_profile(profile_id: str, _: Actor) -> dict[str, Any]:
    try:
        return profile_response(provider_connection_store.get_profile(profile_id))
    except ProviderConnectionError as error:
        raise HTTPException(status_code=404, detail=str(error)) from error


@router.post("/profiles/apply", status_code=201)
async def apply_profile(body: ProfileInput, actor: Actor) -> dict[str, Any]:
    try:
        return profile_response(provider_connection_store.create_profile(id=body.id, name=body.name, roles=profile_bindings(body), actor=actor))
    except ProviderConnectionError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


@router.delete("/profiles/{profile_id}", status_code=204)
async def delete_profile(profile_id: str, actor: Actor) -> Response:
    try:
        provider_connection_store.delete_profile(profile_id, actor)
        return Response(status_code=204)
    except ProviderConnectionError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


@router.post("/profiles/{profile_id}/activate")
async def activate_profile(profile_id: str, actor: Actor) -> dict[str, Any]:
    service = ProfileActivationService(
        provider_connection_store, RoleResolver(generation_client.provider), LocalGenerationRollout(), ManagedGenerationManager()
    )
    result = await service.activate(profile_id, actor)
    return result.__dict__

@router.post("/managed-generation/reconcile")
async def reconcile_managed_generation(actor: Actor) -> dict[str, Any]:
    """Reconcile managed generation state with the active profile.
    
    Called on startup to ensure runtime state matches the configured active profile.
    Scales managed generation to zero when external profile is active.
    """
    from ..services.managed_generation.manager import managed_generation_manager
    from ..model_profiles import provider_connection_store
    
    try:
        active_profile = provider_connection_store.get_active_profile()
        await managed_generation_manager.reconcile_active_profile(active_profile.id)
        state = await managed_generation_manager.get_state()
        return {
            "status": "reconciled",
            "active_profile": active_profile.id,
            "managed_generation": {
                "running": state.running,
                "replicas": state.replicas,
                "model_label": state.model_label,
            },
        }
    except Exception as error:
        raise HTTPException(status_code=500, detail=f"Reconciliation failed: {error}") from error
