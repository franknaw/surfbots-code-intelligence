"""Host-side incremental synchronization for Surfbots repositories.

The canonical developer tree never leaves the host. This module detects what
changed, refreshes the managed snapshot, and asks the indexer to reindex only
the affected files. The indexer owns the inclusion policy; this module fetches
it so the two cannot drift.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable
import hashlib
import json
import logging
import os
import subprocess
import time

logger = logging.getLogger("surfbots.sync")

DEFAULT_DEBOUNCE_SECONDS = 3.0
DEFAULT_RECONCILE_SECONDS = 600.0
MANIFEST_VERSION = 1
# Kept under the indexer's per-request cap so a large change set still succeeds.
BATCH_SIZE = 200

# Used only until the indexer's policy is fetched; the indexer remains authoritative.
FALLBACK_POLICY = {
    "supported_extensions": [
        ".py", ".ts", ".tsx", ".js", ".jsx", ".sh", ".bash", ".zsh",
        ".yaml", ".yml", ".json", ".md", ".txt",
    ],
    "excluded_directories": [
        ".git", "node_modules", ".venv", "venv", "dist", "build",
        "__pycache__", "coverage", ".mypy_cache", ".pytest_cache",
    ],
    "max_file_size_mb": 10,
}


def state_home() -> Path:
    base = os.environ.get("XDG_STATE_HOME", os.path.expanduser("~/.local/state"))
    path = Path(base, "surfbots-dev-platform")
    path.mkdir(parents=True, exist_ok=True)
    return path


def manifest_path(repository_id: str) -> Path:
    directory = state_home() / "manifests"
    directory.mkdir(parents=True, exist_ok=True)
    return directory / f"{repository_id}.json"


def watch_config_path() -> Path:
    return state_home() / "watched-repositories.json"


def load_watched() -> dict[str, Any]:
    path = watch_config_path()
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except json.JSONDecodeError:
        logger.warning("Watch config was unreadable; treating as empty")
        return {}


def save_watched(config: dict[str, Any]) -> None:
    watch_config_path().write_text(json.dumps(config, indent=2, sort_keys=True))


@dataclass
class FileEntry:
    size: int
    mtime: float
    content_hash: str

    def as_dict(self) -> dict[str, Any]:
        return {"size": self.size, "mtime": self.mtime, "content_hash": self.content_hash}


@dataclass
class Manifest:
    repository_id: str
    files: dict[str, FileEntry] = field(default_factory=dict)
    last_reconciled_at: float | None = None

    @classmethod
    def load(cls, repository_id: str) -> "Manifest":
        path = manifest_path(repository_id)
        if not path.exists():
            return cls(repository_id=repository_id)
        try:
            raw = json.loads(path.read_text())
        except json.JSONDecodeError:
            logger.warning("Manifest for %s was unreadable; rebuilding", repository_id)
            return cls(repository_id=repository_id)
        return cls(
            repository_id=repository_id,
            files={k: FileEntry(**v) for k, v in raw.get("files", {}).items()},
            last_reconciled_at=raw.get("last_reconciled_at"),
        )

    def save(self) -> None:
        payload = {
            "version": MANIFEST_VERSION,
            "repository_id": self.repository_id,
            "last_reconciled_at": self.last_reconciled_at,
            "files": {k: v.as_dict() for k, v in self.files.items()},
        }
        path = manifest_path(self.repository_id)
        # Written via a sibling so an interrupted write cannot corrupt the manifest.
        staging = path.with_suffix(".tmp")
        staging.write_text(json.dumps(payload, indent=2, sort_keys=True))
        staging.replace(path)


@dataclass
class Changes:
    added: list[str] = field(default_factory=list)
    modified: list[str] = field(default_factory=list)
    deleted: list[str] = field(default_factory=list)
    unchanged: int = 0
    scanned: int = 0

    @property
    def is_empty(self) -> bool:
        return not (self.added or self.modified or self.deleted)

    @property
    def to_index(self) -> list[str]:
        return sorted(self.added + self.modified)


class IndexPolicy:
    """Inclusion rules, fetched from the indexer so host and cluster agree."""

    def __init__(self, policy: dict[str, Any] | None = None):
        policy = policy or FALLBACK_POLICY
        self.extensions = set(policy.get("supported_extensions", []))
        self.excluded = set(policy.get("excluded_directories", []))
        self.max_bytes = int(policy.get("max_file_size_mb", 10)) * 1024 * 1024

    def includes(self, relative_path: str) -> bool:
        parts = Path(relative_path).parts
        if any(part in self.excluded for part in parts):
            return False
        return Path(relative_path).suffix in self.extensions


def hash_file(path: Path) -> str | None:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(131_072), b""):
                digest.update(block)
    except OSError:
        return None
    return digest.hexdigest()


def _git_tracked_files(root: Path) -> list[str] | None:
    """Enumerate like the indexer does, so .gitignore is honoured identically.

    Includes untracked files, so uncommitted work is still indexed.
    """
    if not (root / ".git").exists():
        return None
    try:
        result = subprocess.run(
            ["git", "ls-files", "--cached", "--others", "--exclude-standard"],
            cwd=root, capture_output=True, text=True, timeout=60,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def scan_repository(root: Path, policy: IndexPolicy) -> dict[str, FileEntry]:
    """Build the current file state for a canonical repository tree."""
    tracked = _git_tracked_files(root)
    if tracked is not None:
        candidates: Iterable[str] = tracked
    else:
        candidates = (
            str(p.relative_to(root))
            for p in root.rglob("*")
            if p.is_file() and not p.is_symlink()
        )

    entries: dict[str, FileEntry] = {}
    for relative in candidates:
        if not policy.includes(relative):
            continue
        path = root / relative
        if not path.is_file() or path.is_symlink():
            continue
        try:
            stat = path.stat()
        except OSError:
            continue
        if stat.st_size > policy.max_bytes:
            continue
        digest = hash_file(path)
        if digest is None:
            continue
        entries[relative] = FileEntry(size=stat.st_size, mtime=stat.st_mtime, content_hash=digest)
    return entries


def _batched(items: list[str], size: int = BATCH_SIZE) -> Iterable[list[str]]:
    for start in range(0, len(items), size):
        yield items[start:start + size]


def diff_manifest(previous: dict[str, FileEntry], current: dict[str, FileEntry]) -> Changes:
    """Compare by content hash; timestamps alone are not trusted."""
    changes = Changes(scanned=len(current))
    for relative, entry in current.items():
        prior = previous.get(relative)
        if prior is None:
            changes.added.append(relative)
        elif prior.content_hash != entry.content_hash:
            changes.modified.append(relative)
        else:
            changes.unchanged += 1
    for relative in previous:
        if relative not in current:
            changes.deleted.append(relative)
    return changes


class RepositorySynchronizer:
    """Owns one repository's incremental synchronization."""

    def __init__(
        self,
        repository_id: str,
        canonical_source: str,
        refresh_snapshot: Callable[[str, str], str],
        api_request: Callable[..., Any],
        policy: IndexPolicy | None = None,
    ):
        self.repository_id = repository_id
        self.canonical_source = canonical_source
        self._refresh_snapshot = refresh_snapshot
        self._api_request = api_request
        self.policy = policy or IndexPolicy()
        self.manifest = Manifest.load(repository_id)
        self.last_change_at: float | None = None
        self.last_indexed_at: float | None = None
        self.last_error: str | None = None

    def detect(self) -> Changes:
        root = Path(self.canonical_source)
        if not root.is_dir():
            raise FileNotFoundError(f"Canonical source is not a directory: {root}")
        current = scan_repository(root, self.policy)
        self._current = current
        return diff_manifest(self.manifest.files, current)

    def synchronize(self, changes: Changes | None = None) -> dict[str, Any]:
        """Refresh the snapshot and reindex only what changed."""
        started = time.monotonic()
        changes = changes or self.detect()
        result: dict[str, Any] = {
            "repository_id": self.repository_id,
            "scanned": changes.scanned,
            "changed": len(changes.to_index),
            "deleted": len(changes.deleted),
            "chunks_removed": 0,
            "chunks_added": 0,
            "embedded": 0,
        }

        if changes.is_empty:
            result["duration_seconds"] = round(time.monotonic() - started, 3)
            result["status"] = "unchanged"
            self.manifest.last_reconciled_at = time.time()
            self.manifest.save()
            return result

        # A failed refresh leaves the previous snapshot and index untouched.
        self._refresh_snapshot(self.repository_id, self.canonical_source)

        if changes.deleted:
            for batch in _batched(changes.deleted):
                response = self._api_request(
                    f"/api/v1/repositories/{self.repository_id}/files",
                    method="DELETE",
                    payload={"paths": batch},
                )
                result["chunks_removed"] += response.get("chunks_removed", 0)

        if changes.to_index:
            failed_paths: set[str] = set()
            for batch in _batched(changes.to_index):
                response = self._api_request(
                    f"/api/v1/repositories/{self.repository_id}/files/index",
                    method="POST",
                    payload={"paths": batch},
                )
                result["chunks_removed"] += response.get("chunks_removed", 0)
                result["chunks_added"] += response.get("chunks_added", 0)
                result["embedded"] += len(response.get("indexed", []))
                if response.get("failed"):
                    failed_paths.update(item["path"] for item in response["failed"])
                    result.setdefault("failed", []).extend(response["failed"])
            # Leave failures out of the manifest so reconciliation retries them.
            for path in failed_paths:
                self._current.pop(path, None)

        self.manifest.files = self._current
        self.manifest.last_reconciled_at = time.time()
        self.manifest.save()

        self.last_indexed_at = time.time()
        result["duration_seconds"] = round(time.monotonic() - started, 3)
        result["status"] = "synchronized"
        return result
