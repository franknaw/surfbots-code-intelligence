"""Search endpoints."""
from fastapi import APIRouter, HTTPException
from pathlib import Path
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from uuid import uuid4
import logging
import os

from qdrant_client.models import Filter, FieldCondition, MatchValue

from ..core.database import get_qdrant_client
from ..services.model_client import EmbeddingClient
from ..services.symbol_search import find_definitions, find_references

logger = logging.getLogger(__name__)
router = APIRouter()

embedding_client = EmbeddingClient()

WORKSPACE_BASE = os.environ.get("WORKSPACE_BASE", "/workspace/repos")


def _snapshot_root(repository_id: str) -> Path:
    root = Path(WORKSPACE_BASE, repository_id).resolve()
    if not root.is_dir():
        raise HTTPException(status_code=404, detail=f"No managed snapshot for {repository_id}")
    return root


class SearchRequest(BaseModel):
    query: str
    repository_id: Optional[str] = None
    language: Optional[str] = None
    file_path: Optional[str] = None
    limit: int = 10
    offset: int = 0


class RelatedRequest(BaseModel):
    repository_id: str
    file_path: str
    limit: int = 5


@router.post("/api/v1/search")
async def search_code(request: SearchRequest):
    """Search code using semantic search."""
    query = request.query
    repository_id = request.repository_id
    limit = request.limit
    offset = request.offset
    language = request.language
    file_path = request.file_path

    # Generate embedding for query
    embedding = await embedding_client.generate_embedding(query)

    if not embedding or not embedding.embedding:
        raise HTTPException(status_code=503, detail="Embedding service unavailable")

    client = get_qdrant_client()

    # Perform semantic search
    # Build filter based on repository_id
    must_conditions = []
    if repository_id:
        must_conditions.append(
            FieldCondition(key="repository_id", match=MatchValue(value=repository_id))
        )
    if language:
        must_conditions.append(
            FieldCondition(key="language", match=MatchValue(value=language))
        )
    query_filter = Filter(must=must_conditions) if must_conditions else None

    # file_path is a substring match, so over-fetch and narrow after scoring.
    fetch_limit = min(limit * 10, 200) if file_path else limit

    try:
        results = client.query_points(
            collection_name="code-index",
            query=embedding.embedding,
            query_filter=query_filter,
            limit=fetch_limit,
            offset=offset
        )

        points = results.points
        if file_path:
            needle = file_path.lower()
            points = [
                point for point in points
                if needle in (point.payload or {}).get("file_path", "").lower()
            ][:limit]

        return {
            "results": [
                {
                    "id": r.id,
                    "score": r.score,
                    "payload": r.payload
                }
                for r in points
            ],
            "total": len(points)
        }
    except Exception as e:
        logger.exception("Search failed")
        raise HTTPException(status_code=500, detail=f"Search failed: {e}")


@router.post("/api/v1/search/related")
async def find_related(request: RelatedRequest):
    """Find related code snippets."""
    repository_id = request.repository_id
    file_path = request.file_path
    limit = request.limit

    # Generate embedding for the file content or query
    query_text = f"{file_path}:\n\nRelated code"
    embedding = await embedding_client.generate_embedding(query_text)

    if not embedding or not embedding.embedding:
        raise HTTPException(status_code=503, detail="Embedding service unavailable")

    client = get_qdrant_client()

    # Build filter based on repository_id
    query_filter = Filter(
        must=[
            FieldCondition(
                key="repository_id",
                match=MatchValue(value=repository_id)
            )
        ]
    )

    try:
        results = client.query_points(
            collection_name="code-index",
            query=embedding.embedding,
            query_filter=query_filter,
            limit=limit
        )

        return {
            "results": [
                {
                    "id": r.id,
                    "score": r.score,
                    "payload": r.payload
                }
                for r in results.points
            ],
            "total": len(results.points)
        }
    except Exception as e:
        logger.error(f"Find related failed: {e}")
        raise HTTPException(status_code=500, detail=f"Search failed: {e}")


@router.get("/api/v1/symbols/search")
async def search_symbols(
    query: str,
    repository_id: str,
    language: Optional[str] = None,
    limit: int = 20,
):
    """Find where a symbol is defined in the managed snapshot."""
    root = _snapshot_root(repository_id)
    definitions = find_definitions(root, query, limit=limit, language=language)
    return {"symbols": definitions, "total": len(definitions), "repository_id": repository_id, "query": query}


@router.get("/api/v1/symbols/references")
async def symbol_references(
    symbol: str,
    repository_id: str,
    language: Optional[str] = None,
    limit: int = 50,
):
    """Find whole-word occurrences of a symbol in the managed snapshot."""
    root = _snapshot_root(repository_id)
    references = find_references(root, symbol, limit=limit, language=language)
    return {"references": references, "total": len(references), "repository_id": repository_id, "symbol": symbol}


@router.get("/api/v1/symbols/{symbol_id}/references")
async def get_symbol_references(symbol_id: str, limit: int = 10):
    """Retained for compatibility; references are addressed by symbol name."""
    raise HTTPException(
        status_code=501,
        detail="Use GET /api/v1/symbols/references?repository_id=&symbol= instead of symbol_id lookup",
    )


@router.get("/api/v1/symbols/{symbol_id}/definition")
async def get_symbol_definition(symbol_id: str):
    """Retained for compatibility; definitions are addressed by symbol name."""
    raise HTTPException(
        status_code=501,
        detail="Use GET /api/v1/symbols/search?repository_id=&query= instead of symbol_id lookup",
    )