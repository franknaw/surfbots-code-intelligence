# Surfbots Development Supervision

Surfbots Development Supervision is part of the normal development workflow.

Do not treat `refine_task`, `collaborate_task`, and `review_changes` as optional
utilities that are used only when the user explicitly requests them.

## Development Supervision Visibility

Whenever a Development Supervision MCP tool is invoked, surface the
meaningful correspondence in the agent conversation so the user can
observe the supervision process.

### refine_task

Display:

```
Development Supervision — Task Refinement

Request:
<concise description of what was sent to the supervisor>

Supervisor:
<meaningful refinement/specification returned by refine_task>

Then explain how the refinement affects the implementation plan.
```

### collaborate_task

Display:

```
Development Supervision — Collaboration

Agent:
<the engineering question/problem sent to the collaborator>

Collaborator:
<the meaningful assessment/recommendation returned>

Agent:
<what will be done as a result>
```

Do not hide collaborator disagreements, risks, warnings, alternative
approaches, or `requires_user_decision=true` responses.

If `requires_user_decision=true`, stop at the appropriate point and
present the decision to the user rather than silently choosing.

### review_changes

Display:

```
Development Supervision — Review

Submitted:
<concise description of implementation/change set reviewed>

Reviewer:
<findings, risks, omissions, or no-issues result>

Agent:
<response to the review, including fixes that will be made>
```

If `review_changes` returns `needs_changes`, visibly explain each material
finding before making the corresponding correction.

### development_supervision_status

The final completion message should continue to show the authoritative
usage summary:

```
Development Supervision:
- refine_task: Used — N calls — N tokens
- collaborate_task: Used — N calls — N tokens
- review_changes: Used — N calls — N tokens
- Total: N supervision calls — N tokens
```

## PRE: Task Refinement

Before planning or modifying code for a non-trivial development task,
call:

    refine_task

A task is non-trivial if it involves one or more of:

- multiple files
- new functionality
- architecture/design decisions
- API changes
- persistence/database changes
- authentication/authorization/security
- deployment/Kubernetes changes
- configuration/provider/model changes
- concurrency/background processing
- significant refactoring
- behavioral compatibility
- data migration
- indexing/retrieval changes
- unclear/incomplete requirements

Do not use refine_task for obvious typo fixes, formatting-only changes,
simple mechanical renames, or similarly trivial work.

When uncertain whether refinement is warranted, prefer refinement.

Use the refined result as the implementation specification.

Do not do a full implementation design first and call refine_task afterward.

## DURING: Collaboration

During implementation, call:

    collaborate_task

when a meaningful issue requires resolution.

Use collaborate_task for:

- unresolved architectural decisions
- multiple viable approaches
- unexpected constraints
- failed assumptions
- security implications
- conflicting requirements
- significant unclear test failures
- potential scope expansion
- possible architectural-invariant violations
- API/interface uncertainty
- compatibility/deployment concerns
- discoveries that materially change the plan

Do not call collaborate_task for every edit or routine choice.

Each invocation must contain a concrete question or decision.

### Broad Read-Only Collaboration

For broad system-understanding requests, automatically construct a collaborator
assignment that investigates all relevant areas without asking the user to choose.
The collaborator should be asked to analyze:

* overall architecture and major components
* component interactions and data flow
* deployment/runtime infrastructure
* APIs and endpoints
* storage/persistence mechanisms
* indexing/search/RAG flows
* MCP integration
* model services
* configuration management
* developer workflows

Do NOT ask: "What would you like me to focus on?" when the parent task provides
sufficient context.

Use the collaborator's recommendation as advisory engineering input,
not unquestionable authority.

If:

    requires_user_decision = true

stop and ask the user for the required product/preference decision.

## POST: Change Review

After implementing and deterministically validating a non-trivial task,
call:

    review_changes

before reporting completion.

Compare the implementation against:

- original user intent
- refined specification
- acceptance criteria
- current repository architecture
- relevant current code
- deterministic test results

Review should look for:

- missing requirements
- incorrect behavior
- regressions
- architectural violations
- security issues
- repository-isolation problems
- persistence problems
- error-handling gaps
- incomplete implementation
- missing tests
- unintended side effects

Review should return:

    no_issues_found
    needs_changes
    incomplete_review
    unable_to_review

not:

    pass
    guaranteed correct
    approved

Model review does not replace deterministic testing.

## REVIEW/FIX LOOP

If review_changes returns:

    needs_changes

then:

1. inspect every finding
2. validate the finding against current repository truth
3. fix valid findings
4. rerun relevant deterministic tests
5. call review_changes again

Perform at most **TWO** automatic review/fix cycles.

After two cycles, report remaining meaningful issues to the user rather than
entering an indefinite loop.

## SOURCE OF TRUTH

Use this priority:

1. current repository code and deterministic tests
2. current user request and refined specification
3. Surfbots Code Intelligence
4. Surfbots Development Memory
5. model assumptions

Current code overrides stale memory.

## FAILURE BEHAVIOR

If refine_task, collaborate_task, or review_changes is temporarily unavailable:

- continue only when reasonable
- do not pretend the supervision step succeeded
- explicitly state that Development Supervision was unavailable

Do not fabricate supervision results.

## COMPLETION POLICY

For a non-trivial task, do not report completion until:

- implementation is complete
- relevant deterministic validation has run
- review_changes has been attempted
- valid review findings have been addressed or reported

Distinguish deterministic testing from model-based review.

## DEVELOPMENT SUPERVISION STATUS

Before the final completion message, call:

    development_supervision_status

to report authoritative usage and token consumption for Development Supervision.

The status returned by Surfbots is authoritative. You MUST NOT infer, estimate,
or fabricate usage or token counts.

Every non-trivial task completion message MUST include:

    Development Supervision:
    - refine_task: <status> — <calls> — <tokens>
    - collaborate_task: <status> — <calls> — <tokens>
    - review_changes: <status> — <calls> — <tokens>
    - Total: <calls> — <tokens>

Where status is one of:

- `Used` — the tool was invoked
- `Not used` — the tool was not invoked for this task

Label totals as:

    Development Supervision tokens

Do NOT imply these are total Cline/Copilot task tokens.

If a tool was unavailable or failed, report that truthfully.
