"""Development Memory endpoints."""
import logging
from datetime import datetime

from typing import Literal

from fastapi import APIRouter, HTTPException, Query

from ..services.session_memory import SessionMemoryCheckpoint, SessionMemoryStore

logger = logging.getLogger(__name__)
router = APIRouter()
memory_store = SessionMemoryStore()


@router.post("/api/v1/repositories/{repository_id}/memory", status_code=201)
async def create_memory(repository_id: str, checkpoint: SessionMemoryCheckpoint):
    """Store a concise, repository-scoped session checkpoint."""
    try:
        return await memory_store.create(repository_id, checkpoint)
    except RuntimeError as error:
        raise HTTPException(status_code=503, detail=str(error)) from error
    except Exception as error:
        logger.exception("Creating development memory failed")
        raise HTTPException(status_code=500, detail="Could not create development memory") from error


@router.get("/api/v1/repositories/{repository_id}/memory/recent")
async def recent_memory(
    repository_id: str,
    limit: int = Query(default=5, ge=1, le=20),
):
    """Return the repository's most recent checkpoints."""
    try:
        records = memory_store.recent(repository_id, limit)
        return {"repository_id": repository_id, "records": records, "total": len(records)}
    except Exception as error:
        logger.exception("Reading development memory failed")
        raise HTTPException(status_code=500, detail="Could not read development memory") from error


@router.post("/api/v1/repositories/{repository_id}/memory/search")
async def search_memory(
    repository_id: str,
    query: str = Query(..., min_length=1, max_length=2_000),
    limit: int = Query(default=10, ge=1, le=20),
    memory_type: list[Literal["session_checkpoint", "decision", "issue", "milestone", "preference", "checkpoint_workflow", "supervision_refinement", "supervision_review"]] | None = Query(default=None),
    retention_class: list[Literal["transient", "durable"]] | None = Query(default=None),
    file_path: str | None = None,
    symbol: str | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
):
    """Semantically retrieve relevant memory within one repository."""
    try:
        records = await memory_store.search(repository_id, query, limit, memory_type, retention_class, file_path, symbol, created_after, created_before)
        return {"repository_id": repository_id, "records": records, "total": len(records)}
    except RuntimeError as error:
        raise HTTPException(status_code=503, detail=str(error)) from error


@router.get("/api/v1/repositories/{repository_id}/memory/context")
async def memory_context(
    repository_id: str,
    limit: int = Query(default=10, ge=1, le=20),
    created_after: datetime | None = None,
):
    """Return a bounded mix of durable decisions and recent activity."""
    try:
        records = memory_store.context(repository_id, limit, created_after)
        return {"repository_id": repository_id, "records": records, "total": len(records)}
    except RuntimeError as error:
        raise HTTPException(status_code=503, detail=str(error)) from error


@router.delete("/api/v1/repositories/{repository_id}/memory/{memory_id}", status_code=204)
async def delete_memory(repository_id: str, memory_id: str):
    """Delete a single repository-scoped memory record."""
    try:
        memory_store.delete(repository_id, memory_id)
    except RuntimeError as error:
        raise HTTPException(status_code=503, detail=str(error)) from error


@router.post("/api/v1/memory/cleanup")
async def cleanup_memory(
    repository_id: str | None = None,
    dry_run: bool = True,
):
    """Remove expired or excess transient records; durable records are preserved."""
    try:
        deleted = memory_store.cleanup(repository_id, dry_run)
        return {"repository_id": repository_id, "dry_run": dry_run, "records_affected": deleted}
    except RuntimeError as error:
        raise HTTPException(status_code=503, detail=str(error)) from error