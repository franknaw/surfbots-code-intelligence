"""Compatibility facade for the profile-selected local generation provider."""
from typing import Any, Optional

from ..core.config import settings
from .generation_provider import (
    GenerationProvider,
    GenerationRequest,
    GenerationUnavailable,
    LocalOpenAICompatibleProvider,
)


class GenerationClient:
    """Preserve the local-client API while delegating transport to a provider."""

    def __init__(self, endpoint: Optional[str] = None, max_concurrency: Optional[int] = None, provider: GenerationProvider | None = None):
        self.provider = provider or LocalOpenAICompatibleProvider(
            endpoint=(endpoint if endpoint is not None else settings.generation_endpoint or ""),
            timeout_seconds=settings.generation_timeout_seconds,
            max_concurrency=max_concurrency or settings.generation_max_concurrency,
        )

    @property
    def configured(self) -> bool:
        return self.provider.configured

    @property
    def _semaphore(self):
        """Compatibility visibility for the existing local-concurrency test."""
        return getattr(self.provider, "semaphore", None)

    async def model_name(self) -> Optional[str]:
        """Report the loaded model for observability only; never for routing."""
        try:
            models = await self.provider.list_models()
            if models:
                return models[0].get("name") or models[0].get("id")
        except (GenerationUnavailable, KeyError, IndexError):
            return None
        return None

    async def complete(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        temperature: float = 0.1,
        repository_id: str = "",
        role: str = "",
    ) -> dict[str, Any]:
        """Return the completion text plus deterministic call metadata."""
        return await self.provider.generate(GenerationRequest(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            repository_id=repository_id,
            role=role,
        ))

    async def close(self) -> None:
        await self.provider.close()


generation_client = GenerationClient()
