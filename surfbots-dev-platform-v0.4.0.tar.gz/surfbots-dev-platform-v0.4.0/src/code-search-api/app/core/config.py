"""Configuration for the code search API."""
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional


class Settings(BaseSettings):
    """Application settings."""
    model_config = SettingsConfigDict(env_file=".env", env_prefix="")

    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False
    
    # Indexer service URL
    indexer_url: str = "http://localhost:8000"
    
    # Caching
    cache_ttl_seconds: int = 300
    
    # Reranking (optional)
    reranker_endpoint: Optional[str] = None

    # Development Supervision. The profile decides the model; this is the service.
    generation_endpoint: Optional[str] = None
    generation_timeout_seconds: float = 300.0
    generation_max_concurrency: int = 1
    generation_context_tokens: int = 8192
    generation_context_safety_margin: int = 256

    # Development Memory checkpointing
    session_memory_enabled: bool = True

    # Provider-profile control plane. Credentials remain in Kubernetes Secrets.
    model_profiles_db: str = "/var/lib/surfbots/model-profiles.db"
    provider_credentials_secret_name: str = "surfbots-provider-credentials"
    kubernetes_namespace: str = "surfbots-dev-platform"
    kubernetes_service_account_token_path: str = "/var/run/secrets/kubernetes.io/serviceaccount/token"
    kubernetes_service_account_ca_path: str = "/var/run/secrets/kubernetes.io/serviceaccount/ca.crt"
    model_control_service_account: str = "code-search-api"
    model_control_token_max_seconds: int = 600
    local_generation_deployment_name: str = "model-generation-generation"
    local_generation_rollout_timeout_seconds: int = 900
    local_generation_profile: str = "local-lightweight"
    
    # Rate limiting
    max_results_default: int = 20
    max_results_limit: int = 100
    
settings = Settings()