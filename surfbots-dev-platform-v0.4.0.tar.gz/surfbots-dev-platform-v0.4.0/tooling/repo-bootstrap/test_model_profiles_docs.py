"""Release documentation contract for provider-aware model profiles."""
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def test_installation_documents_secure_provider_workflow_and_retrieval_boundary():
    text = (ROOT / "docs" / "INSTALL.md").read_text()

    for phrase in (
        "surfbots-dev models connection add",
        "ten-minute Kubernetes service-account token",
        "localhost-only port-forward",
        "hidden",
        "Kubernetes Secrets",
        "Azure OpenAI",
        "azure-openai",
        "deployment name",
        "models profile set-model",
        "Remote-only activation applies to the next request",
        "code-index",
        "session-memory",
        "separate retrieval-profile migration",
    ):
        assert phrase in text
    assert "OpenAI mode is not enabled in this release" not in text


def test_readme_and_script_reference_cover_model_profile_operations():
    readme = (ROOT / "README.md").read_text()
    scripts = (ROOT / "docs" / "SCRIPTS.md").read_text()

    assert "Provider-Aware Model Profiles" in readme
    assert "surfbots-dev models activate" in readme
    assert "deploy-generation" in scripts
    assert "surfbots-dev models" in scripts