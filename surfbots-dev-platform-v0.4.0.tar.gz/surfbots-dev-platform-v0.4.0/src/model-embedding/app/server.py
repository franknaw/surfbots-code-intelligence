"""Embedding server backed by a real sentence-transformers model."""
import logging
import os
import threading
from typing import List, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)

MODEL_ID = os.environ.get("MODEL_ID", "Qwen/Qwen3-Embedding-0.6B")
MODEL_CACHE = os.environ.get("MODEL_CACHE", "/models")
EXPECTED_DIMENSIONS = int(os.environ.get("EMBEDDING_DIMENSIONS", "1024"))
MAX_SEQ_LENGTH = int(os.environ.get("MAX_SEQ_LENGTH", "1024"))

app = FastAPI(title=f"{MODEL_ID} Embedding Server")

_model = None
_load_error: Optional[str] = None
_dimensions: Optional[int] = None


class EmbeddingRequest(BaseModel):
    text: str
    model: Optional[str] = None


class EmbeddingResponse(BaseModel):
    embedding: List[float]
    dimensions: int
    model: Optional[str] = None


class EmbeddingsBatchRequest(BaseModel):
    texts: List[str]
    model: Optional[str] = None


class EmbeddingsBatchResponse(BaseModel):
    embeddings: List[List[float]]
    dimensions: int
    model: Optional[str] = None


def _load_model() -> None:
    global _model, _load_error, _dimensions
    try:
        from sentence_transformers import SentenceTransformer

        logger.info("Loading embedding model %s (cache=%s)", MODEL_ID, MODEL_CACHE)
        model = SentenceTransformer(MODEL_ID, cache_folder=MODEL_CACHE, device="cpu")
        model.max_seq_length = MAX_SEQ_LENGTH
        dimensions = model.get_sentence_embedding_dimension()

        if dimensions != EXPECTED_DIMENSIONS:
            logger.warning(
                "Model reports %d dimensions but %d was configured; using %d",
                dimensions, EXPECTED_DIMENSIONS, dimensions,
            )

        _dimensions = dimensions
        _model = model
        logger.info("Embedding model ready (%d dimensions)", dimensions)
    except Exception as exc:  # surfaced via /health so the pod stays unready
        _load_error = str(exc)
        logger.exception("Failed to load embedding model")


@app.on_event("startup")
def startup() -> None:
    threading.Thread(target=_load_model, name="model-loader", daemon=True).start()


@app.get("/health")
def health():
    if _model is not None:
        return {"status": "ready", "model": MODEL_ID, "dimensions": _dimensions}
    raise HTTPException(status_code=503, detail=_load_error or "model still loading")


@app.get("/v1/models")
def models():
    return {"object": "list", "data": [{"id": MODEL_ID, "object": "model"}]}


@app.post("/v1/embeddings", response_model=EmbeddingResponse)
def create_embedding(request: EmbeddingRequest):
    if _model is None:
        raise HTTPException(status_code=503, detail=_load_error or "model still loading")

    vector = _model.encode(request.text, normalize_embeddings=True)
    return EmbeddingResponse(
        embedding=vector.tolist(),
        dimensions=len(vector),
        model=MODEL_ID,
    )


@app.post("/v1/embeddings/batch", response_model=EmbeddingsBatchResponse)
def create_embeddings_batch(request: EmbeddingsBatchRequest):
    if _model is None:
        raise HTTPException(status_code=503, detail=_load_error or "model still loading")

    vectors = _model.encode(request.texts, normalize_embeddings=True, batch_size=8)
    return EmbeddingsBatchResponse(
        embeddings=[v.tolist() for v in vectors],
        dimensions=len(vectors[0]) if len(vectors) else _dimensions or 0,
        model=MODEL_ID,
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", "8001")))
