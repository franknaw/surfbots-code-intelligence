# surfbots-code-indexer

A semantic code indexing service for the surfbots-dev-platform.

## Overview

The Code Indexer service provides:
- Repository registration and management
- Semantic code indexing using vector embeddings
- Fast code search and retrieval
- Symbol and file lookups

## Features

- **Repository Management**: Register and manage code repositories
- **Semantic Search**: Search code using natural language queries
- **Symbol Search**: Find functions, classes, and other symbols
- **File Operations**: Retrieve file content and metadata
- **Asynchronous Indexing**: Background indexing jobs

## Quick Start

### Prerequisites

- Python 3.11+
- Qdrant vector database
- Embedding model server (port 8001)
- Reranker model server (port 8002)

### Local Development

```bash
cd src/indexer

# Create and activate virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\\Scripts\\activate

# Install dependencies
pip install -r requirements.txt

# Create .env file from example
cp .env.example .env

# Set environment variables (see Configuration section)
# Edit .env with your Qdrant and model server endpoints

# Run the application
python -m app.main

# Or using uvicorn
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Docker

```bash
docker build -t surfbots/code-indexer .
docker run -p 8000:8000 surfbots/code-indexer
```

### Kubernetes (Helm)

```bash
helm install code-indexer ./helm/code-indexer -n surfbots-dev-platform
```

## Configuration

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| HOST | 0.0.0.0 | Server host address |
| PORT | 8000 | Server port |
| DEBUG | false | Enable debug mode |
| QDRANT_URL | http://localhost:6333 | Qdrant database URL |
| QDRANT_API_KEY | - | Qdrant API key (optional) |
| MODEL_ENDPOINT | http://localhost:8000 | Model generation endpoint |
| EMBEDDING_ENDPOINT | http://localhost:8001 | Embedding model endpoint |
| RERANKER_ENDPOINT | http://localhost:8002 | Reranker model endpoint |
| MAX_FILE_SIZE_MB | 10 | Maximum file size for indexing |
| CHUNK_SIZE | 500 | Text chunk size for embeddings |
| CHUNK_OVERLAP | 50 | Overlap between chunks |

### Environment Variables Example

Create a `.env` file in the root directory:

```bash
HOST=0.0.0.0
PORT=8000
DEBUG=false

QDRANT_URL=http://localhost:6333
QDRANT_API_KEY=

MODEL_ENDPOINT=http://localhost:8000
EMBEDDING_ENDPOINT=http://localhost:8001
RERANKER_ENDPOINT=http://localhost:8002

MAX_FILE_SIZE_MB=10
CHUNK_SIZE=500
CHUNK_OVERLAP=50
```

## API Endpoints

### Repository Management
- `POST /api/v1/repositories` - Register a repository
- `GET /api/v1/repositories` - List repositories
- `GET /api/v1/repositories/{id}` - Get repository details
- `DELETE /api/v1/repositories/{id}` - Remove a repository
- `POST /api/v1/repositories/{id}/reindex` - Trigger reindexing

### Indexing
- `POST /api/v1/indexes` - Start an indexing job
- `GET /api/v1/indexes/{job_id}` - Get job status

### Search
- `POST /api/v1/search` - Semantic code search (JSON body: `query`, `repository_id`, `language`, `file_path`, `limit`, `offset`)
- `POST /api/v1/search/related` - Find related code (JSON body: `repository_id`, `file_path`, `limit`)
- `GET /api/v1/symbols/search` - Search symbols

`language` is an exact payload match. `file_path` is a substring match applied
after scoring, so it narrows results without needing a text index.

### Symbols
- `GET /api/v1/symbols/search` - Find where a symbol is defined (`repository_id`, `query`, `language`, `limit`)
- `GET /api/v1/symbols/references` - Find occurrences of a symbol (`repository_id`, `symbol`, `language`, `limit`)
- `GET /api/v1/symbols/{symbol_id}/references` - Returns 501; symbols are addressed by name
- `GET /api/v1/symbols/{symbol_id}/definition` - Returns 501; symbols are addressed by name

Indexing does not extract symbols, so these scan the managed snapshot with
language-aware definition patterns rather than querying Qdrant. Results are
therefore only as current as the last `surfbots-dev repo reindex`.

### Files
- `GET /api/v1/files` - List files in the managed snapshot
- `GET /api/v1/files/content` - Get file content or a line range by `repository_id` and `path`
- `GET /api/v1/files/{file_id}` - Returns 501; content is addressed by repository and path
- `GET /api/v1/files/{file_id}/outline` - Returns 501; outlines are not extracted yet

File reads are confined to the managed snapshot. Paths that resolve outside it
are rejected with 400.

### Incremental indexing
- `GET /api/v1/index-policy` - The authoritative inclusion rules, so the host watcher cannot drift
- `POST /api/v1/repositories/{id}/files/index` - Replace indexed chunks for specific relative paths
- `DELETE /api/v1/repositories/{id}/files` - Remove indexed chunks for deleted relative paths

Only relative paths inside the managed snapshot are accepted; absolute paths and
traversal are rejected with 400. Both endpoints advance the repository's index
timestamp so cached search results are retired.

```
canonical repo (host only)
   │ watchfiles events → 3s debounce
   ▼
host watcher ── manifest diff (SHA-256) ──┐
   │                                      │ unchanged → no-op
   │ atomic rsync refresh                 │
   ▼                                      ▼
managed snapshot ──► POST files/index · DELETE files ──► Qdrant
```


### Health
- `GET /health` - Health check
- `GET /ready` - Readiness check
- `GET /metrics` - Prometheus metrics

## Project Structure

```
src/indexer/
├── app/
│   ├── api/          # API route handlers
│   │   ├── __init__.py
│   │   ├── health.py
│   │   ├── repositories.py
│   │   ├── indexes.py
│   │   ├── search.py
│   │   ├── symbols.py
│   │   └── files.py
│   ├── core/         # Core functionality
│   │   ├── __init__.py
│   │   ├── config.py
│   │   └── database.py
│   ├── models/       # Data models
│   │   ├── __init__.py
│   │   └── service_models.py
│   ├── services/     # Business logic
│   │   ├── __init__.py
│   │   ├── model_client.py
│   │   ├── repository_parser.py
│   │   └── indexer.py
│   └── main.py       # FastAPI application
├── tests/            # Test files
├── .venv/            # Python virtual environment (ignored)
├── .env.example      # Environment variables template
├── .gitignore        # Git ignore rules
├── requirements.txt  # Python dependencies
├── Dockerfile        # Docker image definition
└── README.md
```

## Development

### Adding a new API endpoint

1. Create a new file in `app/api/`
2. Define the router with FastAPI
3. Import and include in `app/main.py`

### Running tests

```bash
pytest tests/ -v
```

### Linting and type checking

```bash
# Lint
flake8 app/

# Type checking
mypy app/
```

## Troubleshooting

### Can't connect to Qdrant
- Verify Qdrant is running: `kubectl get pods -n surfbots-dev-platform | grep qdrant`
- Check Qdrant URL in `.env` file
- Ensure network policies allow access

### Embedding model not responding
- Verify embedding server is running
- Check EMBEDDING_ENDPOINT in `.env` file
- Test endpoint directly: `curl http://localhost:8001/health`

### Indexing fails
- Check file size exceeds MAX_FILE_SIZE_MB
- Verify supported file extensions in `.env`
- Review logs for detailed error messages

## License

MIT License
