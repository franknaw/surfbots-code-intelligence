# Surfbots Dev Platform - Repository Bootstrap

A portable tool for integrating any repository with Surfbots Dev Platform.

## Overview

This directory contains tools to quickly bootstrap Surfbots integration for any GitHub repository:

- **`install.sh`** - Shell script for quick manual setup
- **`surfbots-dev`** - Python CLI for automated setup
- **`.clinerules/surfbots-code-search.md`** - Cline rules template
- **`config-template.yaml`** - Configuration template

## Quick Start

### Option 1: Using the CLI (Recommended)

```bash
# Initialize a repository
cd /path/to/your/repo
python3 /path/to/surfbots-dev-platform/tooling/repo-bootstrap/surfbots-dev init .

# Check status
python3 /path/to/surfbots-dev-platform/tooling/repo-bootstrap/surfbots-dev status

# Show pending changes; working-tree sync is not implemented yet
python3 /path/to/surfbots-dev-platform/tooling/repo-bootstrap/surfbots-dev sync

# Update the installed CLI from the authoritative source
python3 /path/to/surfbots-dev-platform/tooling/repo-bootstrap/surfbots-dev update-cli
```

### Option 2: Using the Install Script

```bash
cd /path/to/your/repo
/path/to/surfbots-dev-platform/tooling/repo-bootstrap/install.sh .
```

## What Gets Created

After running `surfbots-dev init .`, the following files are created:

```
.your-repo/
├── .surfbots/
│   └── config.yaml          # Repository configuration
├── .clinerules/
│   ├── surfbots-code-search.md   # Cline MCP tool guidance
│   ├── surfbots-development-context.md   # Cline context rule
│   └── skills/
│       └── surfbots-development-context/
│           └── SKILL.md     # Cline-native skill
└── .github/
  ├── instructions/
  │   └── surfbots-development-context.instructions.md
  └── skills/
    └── surfbots-development-context/  # Copilot skill mirror
```

## Configuration

Cline uses `.clinerules` and `.clinerules/skills`. Copilot uses `.github/instructions` and `.github/skills`. Both client artifact sets point agents at the same Surfbots MCP tools and Development Memory workflow.

The Cline MCP widget lists connected MCP servers and tools. Cline skills appear through Cline's skill/customization flow after the window or Cline extension is reloaded; they are not the MCP connection itself.

The generated `.surfbots/config.yaml` looks like this:

```yaml
repository:
  name: your-repo-name
  path: /path/to/your/repo
  branch: main
  commit: abc123
  remote: git@github.com:org/repo.git
  languages: Python,TypeScript

surfbots:
  mcpUrl: http://localhost:8003
  searchApi: http://localhost:8001
  platformPath: /workspaces/your-repo-name

index:
  profile: code-default
  mode: incremental
  autoSync: true

workspace:
  hostRoot: /home/your-username/projects
  platformRoot: /workspaces
```

## Path Architecture

The Surfbots Dev Platform maintains a clear distinction between three path contexts:

| Path Type | Description | Example |
|-----------|-------------|---------|
| **Canonical host source** | Developer's working repository | `/home/username/projects/my-repo` |
| **Host-managed snapshot** | CLI-managed snapshot for indexer | `~/.local/share/surfbots-dev-platform/repos/my-repo` |
| **Container workspace** | Path indexer sees in Kubernetes | `/workspace/repos/my-repo` |

Use `surfbots-dev status` to view the current path configuration for a repository.

## How It Works

```
New GitHub repo
    │
    ▼
Cline (AI Agent)
    │
    ▼
Surfbots MCP Server (port 8003)
    │
    ▼
Code Search API (port 8001)
    │
    ▼
Semantic Indexer
    │
    ▼
Qdrant (Vector Database)
```

### Dev Mode (Shared Workspace)

For active development, use the **dev mode** where the platform accesses your repo directly:

1. Your repo is at: `/home/username/projects/my-repo`
2. Platform maps it to: `/workspaces/my-repo`
3. Indexer reads from `/workspaces/my-repo`
4. No cloning required!

## MCP Tools Available

Once integrated, Cline can use:

| Tool | Description |
|------|-------------|
| `search_code` | Semantic code search |
| `find_symbol` | Find symbol definitions |
| `find_references` | Find symbol usages |
| `get_file` | Get file contents |
| `get_file_range` | Get line range |
| `repository_status` | Check indexing status |
| `get_recent_context` | Get bounded recent Development Memory |
| `search_repository_memory` | Search Development Memory within one repository |
| `write_repository_memory` | Store a concise Development Memory checkpoint |

## Commands Reference

### `surfbots-dev init [path]`

Initialize a repository with Surfbots.

- Detects git info (branch, commit, remote)
- Detects languages
- Creates `.surfbots/config.yaml`
- Installs Cline rules
- Checks platform availability

### `surfbots-dev status [path]`

Check the indexing status of a repository.

### `surfbots-dev index [path]`

Placeholder command. Full indexing from the host CLI is not implemented yet.
### Incremental watching

```bash
surfbots-dev repo watch <repository_id>          # enable
surfbots-dev repo watch-run                      # run in the foreground
surfbots-dev repo watch-status <repository_id>   # watch and sync state
surfbots-dev repo sync-once <repository_id>      # one pass, no watcher
surfbots-dev repo unwatch <repository_id>        # disable
surfbots-dev repo watch-install                  # write the user systemd unit
```

The watcher runs on the host, because only the host can see canonical developer
trees. It debounces filesystem events for 3 seconds, refreshes the managed
snapshot atomically, then asks the indexer to reindex only the changed files.
Every 10 minutes it reconciles the full tree against its manifest to repair
missed events, sleep, crashes, and branch switches.

Change detection compares SHA-256 content hashes, not timestamps, so touching a
file without editing it does no work. The manifest lives in
`${XDG_STATE_HOME:-~/.local/state}/surfbots-dev-platform/manifests/`.

The indexer owns the inclusion policy and serves it from `/api/v1/index-policy`,
so the watcher cannot consider a file indexable that the indexer would skip.

### `surfbots-dev repo reindex [path]`

Full rebuild. Still the recovery path; watching does not replace it.
### `surfbots-dev sync [path]`

Show pending working-tree changes. Working-tree sync is not implemented yet, and there is no live MCP `sync_repository` tool.

## Architecture Notes

### Two Modes of Operation

1. **Dev Mode** (Default)
   - Platform mounts your workspace directory
   - Fastest for active development
   - No cloning required

2. **Managed Mode** (Future)
   - Platform clones the repo itself
   - Useful for remote/shared repos
   - Better isolation

### Workspace Mapping

The CLI automatically detects your workspace root and maps it to `/workspaces` inside the platform:

```
Host:          /home/frank/projects/my-repo
Platform:      /workspaces/my-repo
```

## Integrating with Cline

Once initialized, Cline automatically uses the MCP tools. The `.clinerules/surfbots-code-search.md` file provides guidance.

### Example Workflow

1. **Start task**: Cline reads `.clinerules` and discovers Surfbots
2. **Semantic search**: Cline uses `search_code` to find relevant code
3. **Read files**: Cline uses `get_file` to examine code
4. **Make changes**: Cline edits files as needed
5. **Memory**: Cline uses `write_repository_memory` for meaningful checkpoints

## Troubleshooting

### Platform not available

```bash
Check if the Surfbots MCP server is running (default: http://localhost:8003)
Start the Surfbots MCP server (if installed)
```

### Index not updating

```bash
surfbots-dev sync
```

`surfbots-dev sync` currently reports pending changes only. Use `repository_status` to inspect index state; working-tree sync is planned but not implemented.

### Check logs

```bash
# Check MCP server logs (if available)
# kubectl -n surfbots-dev-platform logs -l app=code-indexer
```

## Future Enhancements

- [ ] Git-based registration (clone from GitHub)
- [ ] Incremental sync for specific files
- [ ] Auto-sync on file changes
- [ ] Multi-branch support
- [ ] Cross-repository search

---

*Part of surfbots-dev-platform* - A semantic code intelligence platform for AI-assisted development.
