"""Service models for the code search API."""
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime


# Search models
class SearchQuery(BaseModel):
    """Search query model."""
    query: str = Field(..., description="Search query string")
    repository_id: Optional[str] = Field(None, description="Repository ID to search")
    repository_name: Optional[str] = Field(None, description="Repository name to search")
    language: Optional[str] = Field(None, description="Filter by programming language")
    file_path: Optional[str] = Field(None, description="Filter by file path pattern")
    limit: int = Field(default=20, ge=1, le=100, description="Maximum number of results")
    offset: int = Field(default=0, ge=0, description="Offset for pagination")
    include_related_memory: bool = Field(default=False, description="Include bounded related Development Memory")


class SearchResponse(BaseModel):
    """Search response model."""
    results: List[Dict[str, Any]] = Field(default_factory=list)
    total: int = 0
    repository_id: Optional[str] = None
    repository_name: Optional[str] = None
    query: str
    timestamp: str
    related_memory: List[Dict[str, Any]] = Field(default_factory=list)


# Symbol models
class SymbolSearchQuery(BaseModel):
    """Symbol search query model."""
    query: str = Field(..., description="Symbol name or pattern")
    repository_id: Optional[str] = None
    symbol_type: Optional[str] = Field(None, description="Filter by symbol type")
    limit: int = Field(default=20, ge=1, le=100)
    offset: int = Field(default=0, ge=0)


class SymbolResponse(BaseModel):
    """Symbol response model."""
    symbol_id: str
    name: str
    type: str
    repository_id: str
    repository_name: Optional[str] = None
    file_path: str
    line_start: int
    line_end: int
    signature: Optional[str] = None
    docstring: Optional[str] = None


# File models
class FileListQuery(BaseModel):
    """File list query model."""
    repository_id: Optional[str] = None
    directory: Optional[str] = None
    language: Optional[str] = None
    limit: int = Field(default=100, ge=1, le=1000)
    offset: int = Field(default=0, ge=0)


class FileResponse(BaseModel):
    """File response model."""
    file_id: str
    repository_id: str
    repository_name: Optional[str] = None
    file_path: str
    language: Optional[str] = None
    line_count: int
    size_bytes: int
    last_modified: Optional[str] = None


class FileRangeResponse(BaseModel):
    """File range response model."""
    file_id: str
    start_line: int
    end_line: int
    lines: List[str]
    total_lines: int


# Repository models
class RepositoryStatusResponse(BaseModel):
    """Repository status response model."""
    repository_id: str
    repository_name: str
    status: str
    indexed_at: Optional[str] = None
    files_indexed: int
    chunks_indexed: int
    last_indexed_commit: Optional[str] = None


# Development Memory models
class SessionMemoryCheckpoint(BaseModel):
    """A concise, reviewable outcome from a coding session."""
    session_id: str = Field(..., min_length=1, max_length=200)
    development_task_id: str | None = Field(default=None, min_length=1, max_length=128)
    created_at: Optional[datetime] = None
    memory_type: str = Field(default="session_checkpoint", pattern="^(session_checkpoint|decision|issue|milestone|preference|supervision_refinement|supervision_review|checkpoint_workflow)$")
    retention_class: str = Field(default="transient", pattern="^(transient|durable)$")
    summary: str = Field(..., min_length=1, max_length=2_000)
    decisions: List[str] = Field(default_factory=list, max_length=20)
    files_touched: List[str] = Field(default_factory=list, max_length=100)
    symbols_touched: List[str] = Field(default_factory=list, max_length=100)
    completed: List[str] = Field(default_factory=list, max_length=50)
    unresolved: List[str] = Field(default_factory=list, max_length=50)
    test_results: List[str] = Field(default_factory=list, max_length=50)
    commit_sha: Optional[str] = Field(default=None, max_length=128)
    supersedes: List[str] = Field(default_factory=list, max_length=20)
    checkpoint_phase: str | None = Field(default=None, max_length=64)
    workflow_state: Dict[str, Any] | None = Field(default=None)
    evidence: Dict[str, Any] = Field(default_factory=dict)


# Health models
class HealthLiveResponse(BaseModel):
    """Live health check response."""
    status: str = "ok"


class HealthReadyResponse(BaseModel):
    """Ready health check response."""
    status: str = "ok"
    indexer_connected: bool = False
    cache_status: str = "ok"


# Common response models
class ErrorResponse(BaseModel):
    """Error response model."""
    error: str
    message: str
    code: Optional[int] = None

# Development Supervision checkpoint models
from enum import Enum


class CheckpointPhase(str, Enum):
    """Checkpoint phases for development tasks."""
    POST_INVESTIGATION = "post_investigation"
    POST_IMPLEMENTATION = "post_implementation"
    POST_TEST = "post_test"
    FAILURE_ANALYSIS = "failure_analysis"
    MILESTONE_COMPLETE = "milestone_complete"
    PRE_REVIEW = "pre_review"


class WorkflowState(BaseModel):
    """Workflow state for a development task."""
    repository_id: str
    development_task_id: str
    required_checkpoints: List[str] = Field(default_factory=list)
    completed_checkpoints: Dict[str, bool] = Field(default_factory=dict)
    current_phase: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Completion state (v4)
    workflow_complete: bool = False
    completion_permitted: bool = False
    final_review_verdict: Optional[str] = None
    missing_actions: List[str] = Field(default_factory=list)
    next_action: Optional[str] = None
    
    def is_checkpoint_completed(self, phase: str) -> bool:
        """Check if a checkpoint has been completed."""
        return self.completed_checkpoints.get(phase, False)
    
    def mark_checkpoint_completed(self, phase: str) -> None:
        """Mark a checkpoint as completed."""
        self.completed_checkpoints[phase] = True
        self.updated_at = datetime.utcnow()
    
    def get_missing_checkpoints(self) -> List[str]:
        """Get list of missing required checkpoints."""
        return [cp for cp in self.required_checkpoints if not self.is_checkpoint_completed(cp)]
    
    def is_workflow_complete(self) -> bool:
        """Check if all required checkpoints are completed."""
        return all(self.is_checkpoint_completed(cp) for cp in self.required_checkpoints)


class CheckpointResult(BaseModel):
    """Result of a checkpoint collaboration."""
    repository_id: str
    development_task_id: str
    phase: str
    assessment: str
    recommendation: str
    next_steps: List[str] = Field(default_factory=list)
    risks: List[str] = Field(default_factory=list)
    requires_user_decision: bool = False
    generation: Dict[str, Any] = Field(default_factory=dict)


class WorkflowEnforcementError(Exception):
    """Error when workflow enforcement fails."""
    pass
