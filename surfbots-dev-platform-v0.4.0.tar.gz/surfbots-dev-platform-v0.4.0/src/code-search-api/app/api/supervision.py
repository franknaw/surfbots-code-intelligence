"""Development Supervision endpoints."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Any, Optional
import logging
import uuid

from ..services.generation_client import GenerationUnavailable, generation_client
from ..services.supervision.parsing import InvalidGenerationResponse
from ..services.supervision.refiner import RepositoryNotFound, refine_task
from ..services.supervision.reviewer import review_changes
from ..services.supervision.collaborator import RepositoryNotFound as CollabRepositoryNotFound, collaborate_task
from ..services.supervision.checkpoint import (
    RepositoryNotFound as CheckpointRepositoryNotFound,
    TaskNotFound as CheckpointTaskNotFound,
    MissingCheckpointError,
    ValidationFailedError,
    create_checkpoint,
    get_required_checkpoints,
    get_workflow_state,
    persist_review_evidence,
)
from ..services.supervision.usage_tracker import get_tracker
from ..services.supervision.checkpoint_creator import CheckpointCreator
from ..services.search_service import search_service
from ..core.config import settings

logger = logging.getLogger(__name__)
router = APIRouter()

# Initialize checkpoint creator
checkpoint_creator = CheckpointCreator(search_service.indexer) if settings.session_memory_enabled else None


# Request models (must be defined before routes that use them)
class RefineRequest(BaseModel):
    request: str = Field(min_length=1, max_length=8_000)
    current_context: Optional[str] = Field(default=None, max_length=20_000)
    constraints: Optional[list[str]] = Field(default=None, max_length=50)
    development_task_id: Optional[str] = Field(default=None, description="Optional task ID for usage tracking isolation")


class ReviewRequest(BaseModel):
    task_specification: str = Field(min_length=1, max_length=20_000)
    diff: Optional[str] = Field(default=None, max_length=400_000)
    changed_files: Optional[list[str]] = Field(default=None, max_length=200)
    test_results: Optional[str] = Field(default=None, max_length=20_000)
    development_task_id: str = Field(min_length=1, max_length=128, description="Stable task ID returned by refine_task")


class CollaborateRequest(BaseModel):
    task: str = Field(min_length=1, max_length=8_000)
    current_state: str = Field(min_length=1, max_length=20_000)
    question: str = Field(min_length=1, max_length=4_000)
    refined_task: Optional[str] = Field(default=None, max_length=20_000)
    options: Optional[list[str]] = Field(default=None, max_length=10)
    development_task_id: str = Field(
        min_length=1,
        max_length=128,
        description="Stable task ID returned by refine_task",
    )


class CheckpointRequest(BaseModel):
    phase: str = Field(min_length=1, max_length=64, description="Checkpoint phase name (e.g., post_investigation)")
    task: str = Field(min_length=1, max_length=8_000)
    current_state: str = Field(min_length=1, max_length=20_000)
    question: str = Field(min_length=1, max_length=4_000)
    refined_task: Optional[str] = Field(default=None, max_length=20_000)
    options: Optional[list[str]] = Field(default=None, max_length=10)
    development_task_id: str = Field(
        min_length=1,
        max_length=128,
        description="Stable task ID returned by refine_task",
    )


@router.get("/api/v1/supervision/status")
async def supervision_status() -> dict[str, Any]:
    """Report whether supervision can run, for bootstrap and verification."""
    configured = generation_client.configured
    model = await generation_client.model_name() if configured else None
    return {
        "configured": configured,
        "available": bool(model),
        "model": model,
        "tools": ["refine_task", "collaborate_task", "review_changes"],
    }


@router.get("/api/v1/supervision/usage")
async def supervision_usage() -> dict[str, Any]:
    """Report Development Supervision tool usage and workflow state for all tasks.
    
    Returns comprehensive status including:
    - Tool usage across all tasks
    - Persisted workflow state from Development Memory
    - Task completion status
    """
    from ..services.supervision.checkpoint import get_all_workflow_states
    
    tracker = get_tracker()
    usage_status = tracker.get_status()
    
    # Get persisted workflow states from Development Memory
    workflow_states = await get_all_workflow_states()
    
    return {
        "usage": usage_status,
        "workflow_states": workflow_states,
    }

@router.get("/api/v1/supervision/usage/{task_id}")
async def supervision_usage_for_task(task_id: str) -> dict[str, Any]:
    """Report Development Supervision tool usage and token counts for a specific task."""
    tracker = get_tracker()
    return tracker.get_status(task_id)


@router.post("/api/v1/repositories/{repository_id}/supervision/refine")
async def refine(repository_id: str, body: RefineRequest) -> dict[str, Any]:
    """Convert a development request into an implementation specification."""
    try:
        # Use the provided development_task_id if present, otherwise generate one
        task_id = body.development_task_id
        if not task_id:
            task_id = str(uuid.uuid4())
        
        result = await refine_task(
            repository=repository_id,
            request=body.request,
            current_context=body.current_context,
            constraints=body.constraints,
            development_task_id=task_id,
        )
        generation = result.get("generation", {})
        prompt_tokens = generation.get("prompt_tokens")
        completion_tokens = generation.get("completion_tokens")
        get_tracker().record_refine_task(task_id, prompt_tokens, completion_tokens)
        
        # Create automatic checkpoint if development memory is enabled
        if checkpoint_creator and result:
            try:
                await checkpoint_creator.create_from_refinement(
                    repository_id,
                    task_id,
                    body.request,
                    result,
                )
            except Exception as e:
                logger.warning(f"Failed to create automatic checkpoint: {e}")
        
        return result
    except RepositoryNotFound as error:
        raise HTTPException(status_code=404, detail=str(error)) from error
    except GenerationUnavailable as error:
        raise HTTPException(status_code=503, detail=f"Supervision unavailable: {error}") from error
    except InvalidGenerationResponse as error:
        raise HTTPException(status_code=502, detail=f"Supervision returned unusable output: {error}") from error


@router.post("/api/v1/repositories/{repository_id}/supervision/collaborate")
async def collaborate(repository_id: str, body: CollaborateRequest) -> dict[str, Any]:
    """Help resolve a meaningful decision during implementation."""
    try:
        # Use the provided development_task_id if present, otherwise generate one
        task_id = body.development_task_id
        
        result = await collaborate_task(
            repository=repository_id,
            task=body.task,
            current_state=body.current_state,
            question=body.question,
            refined_task=body.refined_task,
            options=body.options,
            development_task_id=task_id,
        )
        generation = result.get("generation", {})
        prompt_tokens = generation.get("prompt_tokens")
        completion_tokens = generation.get("completion_tokens")
        get_tracker().record_collaborate_task(task_id, prompt_tokens, completion_tokens)
        
        # Create automatic checkpoint if development memory is enabled
        if checkpoint_creator and result:
            try:
                await checkpoint_creator.create_from_collaboration(
                    repository_id,
                    task_id,
                    body.task,
                    body.question,
                    result,
                )
            except Exception as e:
                logger.warning(f"Failed to create automatic checkpoint: {e}")
        
        return result
    except CollabRepositoryNotFound as error:
        raise HTTPException(status_code=404, detail=str(error)) from error
    except GenerationUnavailable as error:
        raise HTTPException(status_code=503, detail=f"Collaboration unavailable: {error}") from error
    except InvalidGenerationResponse as error:
        raise HTTPException(status_code=502, detail=f"Collaboration returned unusable output: {error}") from error


@router.post("/api/v1/repositories/{repository_id}/supervision/review")
async def review(repository_id: str, body: ReviewRequest) -> dict[str, Any]:
    """Review an implementation against its specification and current code."""
    from ..services.supervision.checkpoint import _resolve
    try:
        # Resolve the repository ID
        resolved_id, _ = await _resolve(repository_id)
        
        # Use the provided development_task_id if present, otherwise generate one
        task_id = body.development_task_id
        
        # Check for missing required checkpoints before allowing review
        ws = await get_workflow_state(resolved_id, task_id)
        logger.info(f"Workflow state for task {task_id}: {ws}")
        if ws:
            current = ws.get("workflow_state") or {}
            required = current.get("required_checkpoints", [])
            completed = current.get("completed_checkpoints", [])
            missing = [req for req in required if req not in completed]
            if missing:
                raise MissingCheckpointError(
                    task_id,
                    missing,
                    "Review is not allowed until all required checkpoints are completed."
                )
        
        result = await review_changes(
            repository=repository_id,
            task_specification=body.task_specification,
            diff=body.diff,
            changed_files=body.changed_files,
            test_results=body.test_results,
            development_task_id=task_id,
        )
        generation = result.get("generation", {})
        prompt_tokens = generation.get("prompt_tokens")
        completion_tokens = generation.get("completion_tokens")
        get_tracker().record_review_changes(task_id, prompt_tokens, completion_tokens)
        
        # Persist review evidence for verification
        try:
            persist_result = await persist_review_evidence(
                repository_id=repository_id,
                development_task_id=task_id,
                review_evidence=result,
                task_specification={"task_specification": body.task_specification},
            )
            if isinstance(persist_result, dict) and persist_result.get("error"):
                logger.error(f"Failed to persist review evidence: {persist_result.get('error')}")
            else:
                logger.info(f"Successfully persisted review evidence for {task_id}")
        except Exception as e:
            logger.error(f"Failed to persist review evidence: {e}")
        
        # Create automatic checkpoint if development memory is enabled
        if checkpoint_creator and result:
            try:
                await checkpoint_creator.create_from_review(
                    repository_id,
                    task_id,
                    result,
                    body.changed_files,
                )
            except Exception as e:
                logger.warning(f"Failed to create automatic checkpoint: {e}")
        
        return result
    except MissingCheckpointError as error:
        raise HTTPException(status_code=409, detail=str(error)) from error
    except RepositoryNotFound as error:
        raise HTTPException(status_code=404, detail=str(error)) from error


@router.post("/api/v1/repositories/{repository_id}/supervision/checkpoint")
async def checkpoint(repository_id: str, body: CheckpointRequest) -> dict[str, Any]:
    """Create a Development Supervision checkpoint.
    
    This endpoint enforces that substantial development tasks require
    meaningful Devstral collaboration before final review.
    """
    try:
        result = await create_checkpoint(
            repository=repository_id,
            development_task_id=body.development_task_id,
            phase=body.phase,
            task=body.task,
            current_state=body.current_state,
            question=body.question,
            refined_task=body.refined_task,
            options=body.options,
        )
        generation = result.get("generation", {})
        prompt_tokens = generation.get("prompt_tokens")
        completion_tokens = generation.get("completion_tokens")
        get_tracker().record_checkpoint_task(
            body.development_task_id, prompt_tokens, completion_tokens
        )
        
        # Create automatic checkpoint if development memory is enabled
        if checkpoint_creator and result:
            try:
                await checkpoint_creator.create_from_collaboration(
                    repository_id,
                    body.development_task_id,
                    body.task,
                    body.question,
                    result,
                )
            except Exception as e:
                logger.warning(f"Failed to create automatic checkpoint: {e}")
        
        return result
    except CheckpointRepositoryNotFound as error:
        raise HTTPException(status_code=404, detail=str(error)) from error
    except CheckpointTaskNotFound as error:
        raise HTTPException(status_code=404, detail=str(error)) from error
    except MissingCheckpointError as error:
        raise HTTPException(status_code=409, detail=str(error)) from error
    except ValidationFailedError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    except GenerationUnavailable as error:
        raise HTTPException(status_code=503, detail=f"Checkpoint unavailable: {error}") from error
    except InvalidGenerationResponse as error:
        raise HTTPException(status_code=502, detail=f"Checkpoint returned unusable output: {error}") from error


class CompleteTaskRequest(BaseModel):
    """Request to complete a development task."""
    development_task_id: str = Field(
        min_length=1,
        max_length=128,
        description="Stable task ID returned by refine_task",
    )
    verification: Optional[str] = Field(
        default=None,
        max_length=5000,
        description="Optional verification evidence for completion",
    )


@router.post("/api/v1/repositories/{repository_id}/supervision/complete")
async def complete_development_task(
    repository_id: str,
    body: CompleteTaskRequest,
) -> dict[str, Any]:
    """Mark a development task as complete.
    
    This endpoint finalizes a development task by:
    - Verifying all required checkpoints are completed
    - Verifying refinement evidence exists (from refine_task)
    - Verifying review evidence exists and has acceptable verdict (from review_changes)
    - Setting workflow_complete and completion_permitted flags
    """
    from ..services.supervision.checkpoint import (
        enforce_checkpoint_requirements,
        get_workflow_state,
        save_workflow_state,
        _resolve,
        verify_refinement_completed,
        verify_review_completed,
    )
    
    try:
        # Resolve repository name to ID
        resolved_id, _ = await _resolve(repository_id)
        
        # Get current workflow state using resolved ID
        workflow_state = await get_workflow_state(
            resolved_id,
            body.development_task_id,
        )
        
        if workflow_state is None:
            raise HTTPException(
                status_code=404,
                detail=f"Development task not found: {body.development_task_id}",
            )
        
        current = workflow_state.get("workflow_state", {}) if workflow_state else {}
        if not current:
            current = workflow_state if isinstance(workflow_state, dict) else {}
        required = current.get("required_checkpoints", [])
        completed = current.get("completed_checkpoints", [])
        
        # completed_checkpoints is a list, convert to set for efficient lookup
        completed_set = set(completed) if isinstance(completed, list) else completed
        
        # Check if all required checkpoints are completed
        missing_checkpoints = [cp for cp in required if cp not in completed_set]
        
        # Verify refinement evidence exists
        refinement_completed = await verify_refinement_completed(resolved_id, body.development_task_id)
        
        # Verify review evidence exists and has acceptable verdict
        review_completed, review_verdict = await verify_review_completed(resolved_id, body.development_task_id)
        
        # Determine if completion is permitted
        # All of these must be satisfied:
        # 1. All required checkpoints are completed
        # 2. Refinement evidence exists
        # 3. Review evidence exists with acceptable verdict
        completion_permitted = (
            len(missing_checkpoints) == 0 and
            refinement_completed and
            review_completed
        )
        
        # Determine missing_actions for the response
        missing_actions = []
        if missing_checkpoints:
            missing_actions.extend([f"checkpoint:{cp}" for cp in missing_checkpoints])
        if not refinement_completed:
            missing_actions.append("refine_task")
        if not review_completed:
            missing_actions.append("review_changes")
        
        # Update workflow state with completion flags
        current["workflow_complete"] = completion_permitted
        current["completion_permitted"] = completion_permitted
        current["missing_actions"] = missing_actions
        current["refinement_completed"] = refinement_completed
        current["review_completed"] = review_completed
        
        # Record the review verdict if available
        if review_verdict:
            current["final_review_verdict"] = review_verdict
        
        # Save the updated workflow state
        from ..services.supervision.checkpoint import _save_workflow_state
        
        result = await _save_workflow_state(
            repository_id=resolved_id,
            development_task_id=body.development_task_id,
            phase="complete",  # Mark as complete phase for completion endpoint
            completed=list(completed),  # completed is already a list
            required=required,
            next_action="complete" if completion_permitted else "missing_actions",
            is_lightweight=current.get("is_lightweight", False),
            workflow_complete=completion_permitted,
            completion_permitted=completion_permitted,
            final_review_verdict=current.get("final_review_verdict"),
            missing_actions=missing_actions,
        )
        
        # Update usage tracker
        tracker = get_tracker()
        gen_result = result or {}
        tracker.record_checkpoint_task(
            body.development_task_id,
            gen_result.get("generation", {}).get("prompt_tokens"),
            gen_result.get("generation", {}).get("completion_tokens"),
        )
        
        return {
            "success": True,
            "development_task_id": body.development_task_id,
            "workflow_complete": completion_permitted,
            "completion_permitted": completion_permitted,
            "missing_checkpoints": missing_checkpoints,
            "missing_actions": missing_actions,
            "refinement_completed": refinement_completed,
            "review_completed": review_completed,
            "final_review_verdict": review_verdict,
            "next_action": "complete" if completion_permitted else "missing_actions",
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Failed to complete development task {body.development_task_id}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/api/v1/supervision/usage")
async def supervision_usage() -> dict[str, Any]:
    """Report Development Supervision tool usage and workflow state for all tasks.
    
    Returns comprehensive status including:
    - Tool usage across all tasks
    - Persisted workflow state from Development Memory
    - Task completion status
    """
    from ..services.supervision.checkpoint import get_all_workflow_states
    
    tracker = get_tracker()
    usage_status = tracker.get_status()
    
    # Get persisted workflow states from Development Memory
    workflow_states = await get_all_workflow_states()
    
    return {
        "usage": usage_status,
        "workflow_states": workflow_states,
    }
