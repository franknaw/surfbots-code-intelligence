"""File-level incremental indexing endpoints.

The watcher runs on the host and sends relative paths only; this module resolves
them inside the managed snapshot so no canonical host path is ever accepted.
"""
from fastapi import APIRouter, HTTPException
from datetime import datetime, timezone
from pathlib import Path
from pydantic import BaseModel, Field
from typing import Any, Dict, List
import logging
import os

from ..core.config import settings
from ..core.database import delete_file_points
from ..services.indexer import CodeIndexer
from ..services.repository_manager import RepositoryRegistry

logger = logging.getLogger(__name__)
router = APIRouter()


def _mark_repository_indexed(repository_id: str) -> None:
    """Advance the index generation so cached search results are retired."""
    try:
        RepositoryRegistry().update_repository(
            repository_id, {"last_indexed_at": datetime.now(timezone.utc).isoformat()}
        )
    except Exception:
        logger.warning("Could not update index timestamp for %s", repository_id, exc_info=True)

EXCLUDED_DIRECTORIES = (
    ".git",
    "node_modules",
    ".venv",
    "venv",
    "dist",
    "build",
    "__pycache__",
    "coverage",
    ".mypy_cache",
    ".pytest_cache",
)


class FilePathsRequest(BaseModel):
    paths: List[str] = Field(min_length=1, max_length=500)


def _snapshot_root(repository_id: str) -> Path:
    workspace_base = os.environ.get("WORKSPACE_BASE", "/workspace/repos")
    root = Path(workspace_base, repository_id).resolve()
    if not root.is_dir():
        raise HTTPException(status_code=404, detail=f"No managed snapshot for {repository_id}")
    return root


def is_indexable(relative_path: str) -> bool:
    """Single authoritative rule for whether a path belongs in the index."""
    parts = Path(relative_path).parts
    if any(part in EXCLUDED_DIRECTORIES for part in parts):
        return False
    return Path(relative_path).suffix in settings.supported_extensions


def _resolve_relative(root: Path, relative_path: str) -> Path:
    """Reject absolute paths, traversal, and symlinks that escape the snapshot."""
    if os.path.isabs(relative_path):
        raise HTTPException(status_code=400, detail=f"Absolute paths are not accepted: {relative_path}")

    target = (root / relative_path).resolve()
    if target != root and root not in target.parents:
        raise HTTPException(status_code=400, detail=f"Path escapes the repository snapshot: {relative_path}")
    return target


@router.get("/api/v1/index-policy")
async def index_policy() -> Dict[str, Any]:
    """Expose the inclusion rules so the host watcher cannot drift from the indexer."""
    return {
        "supported_extensions": list(settings.supported_extensions),
        "excluded_directories": list(EXCLUDED_DIRECTORIES),
        "max_file_size_mb": settings.max_file_size_mb,
    }


@router.post("/api/v1/repositories/{repository_id}/files/index")
async def index_files(repository_id: str, request: FilePathsRequest) -> Dict[str, Any]:
    """Replace the indexed chunks for specific files in the managed snapshot."""
    root = _snapshot_root(repository_id)
    indexer = CodeIndexer()

    indexed, skipped, missing, failed = [], [], [], []
    chunks_removed = chunks_added = 0

    for relative_path in request.paths:
        target = _resolve_relative(root, relative_path)

        if not is_indexable(relative_path):
            skipped.append(relative_path)
            continue

        try:
            # Replace rather than append; chunk counts change as a file is edited.
            chunks_removed += delete_file_points(repository_id, relative_path)

            if not target.is_file():
                missing.append(relative_path)
                continue

            chunks = await indexer.index_file(target, repository_id, relative_path)
            chunks_added += len(chunks)
            indexed.append(relative_path)
        except HTTPException:
            raise
        except Exception as error:
            # One bad file must not abort the batch.
            logger.exception("Indexing %s in %s failed", relative_path, repository_id)
            failed.append({"path": relative_path, "error": str(error)})

    if indexed or chunks_removed:
        _mark_repository_indexed(repository_id)

    return {
        "repository_id": repository_id,
        "indexed": indexed,
        "skipped": skipped,
        "missing": missing,
        "failed": failed,
        "chunks_removed": chunks_removed,
        "chunks_added": chunks_added,
    }


@router.delete("/api/v1/repositories/{repository_id}/files")
async def delete_files(repository_id: str, request: FilePathsRequest) -> Dict[str, Any]:
    """Remove indexed chunks for deleted files, scoped to one repository."""
    root = _snapshot_root(repository_id)

    deleted, failed = [], []
    chunks_removed = 0
    for relative_path in request.paths:
        _resolve_relative(root, relative_path)
        try:
            chunks_removed += delete_file_points(repository_id, relative_path)
            deleted.append(relative_path)
        except Exception as error:
            logger.exception("Deleting %s in %s failed", relative_path, repository_id)
            failed.append({"path": relative_path, "error": str(error)})

    if chunks_removed:
        _mark_repository_indexed(repository_id)

    return {
        "repository_id": repository_id,
        "deleted": deleted,
        "failed": failed,
        "chunks_removed": chunks_removed,
    }
