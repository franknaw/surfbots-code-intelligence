"""Development Supervision usage and token tracking.

For each development task/session, this module tracks:

- Which supervision tools (refine_task, collaborate_task, review_changes)
  were called
- How many times each tool was invoked
- The input/prompt tokens, output/completion tokens, and total tokens
  consumed by each tool

Token counts come from server-side provider usage data. They are never
estimated or fabricated.
"""

from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from typing import Any

import logging

logger = logging.getLogger(__name__)


@dataclass
class ToolUsage:
    """Usage data for a single supervision tool."""

    tool_name: str
    calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    last_call: str | None = None

    def record_call(
        self, prompt_tokens: int | None, completion_tokens: int | None
    ) -> None:
        """Record a tool invocation with provider usage data."""
        self.calls += 1

        # Only aggregate if the provider returned reliable usage data
        if prompt_tokens is not None and isinstance(prompt_tokens, int):
            self.input_tokens += prompt_tokens
        if completion_tokens is not None and isinstance(completion_tokens, int):
            self.output_tokens += completion_tokens

        self.total_tokens = self.input_tokens + self.output_tokens

        # Keep the most recent timestamp as last_call
        from datetime import datetime, timezone

        self.last_call = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict with usage status."""
        if self.calls == 0:
            return {
                "status": "not_used",
                "calls": 0,
                "total_tokens": 0,
            }

        # If provider usage data is unavailable (all zeros), report used with unknown tokens
        # Status should be "used" if called, not "unavailable"
        if self.input_tokens == 0 and self.output_tokens == 0:
            return {
                "status": "used",
                "calls": self.calls,
                "total_tokens": 0,
            }

        return {
            "status": "used",
            "calls": self.calls,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
        }


class SupervisionUsageTracker:
    """Thread-safe usage tracker for Development Supervision tools.

    Usage is scoped per development_task_id. Each task gets its own isolated
    usage tracking. This prevents cross-contamination between Cline tasks.

    For multi-process deployments or distributed environments, external
    persistence would be required.

    This tracker does NOT persist across server restarts.
    """

    _instance: "SupervisionUsageTracker | None" = None
    _lock = threading.Lock()

    def __init__(self) -> None:
        # Map: development_task_id -> {tool_name -> ToolUsage}
        self._tools_by_task: dict[str, dict[str, ToolUsage]] = {}

    @classmethod
    def get_instance(cls) -> "SupervisionUsageTracker":
        """Get or create the singleton tracker instance."""
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

    def _get_task_tools(self, task_id: str) -> dict[str, ToolUsage]:
        """Get or create the tools dict for a specific task_id."""
        if task_id not in self._tools_by_task:
            self._tools_by_task[task_id] = {
                "refine_task": ToolUsage(tool_name="refine_task"),
                "collaborate_task": ToolUsage(tool_name="collaborate_task"),
                "review_changes": ToolUsage(tool_name="review_changes"),
                "development_task_checkpoint": ToolUsage(tool_name="development_task_checkpoint"),
            }
        return self._tools_by_task[task_id]

    def record_refine_task(
        self, task_id: str, prompt_tokens: int | None, completion_tokens: int | None
    ) -> None:
        """Record a refine_task invocation for a specific task."""
        task_tools = self._get_task_tools(task_id)
        task_tools["refine_task"].record_call(prompt_tokens, completion_tokens)

    def record_collaborate_task(
        self, task_id: str, prompt_tokens: int | None, completion_tokens: int | None
    ) -> None:
        """Record a collaborate_task invocation for a specific task."""
        task_tools = self._get_task_tools(task_id)
        task_tools["collaborate_task"].record_call(prompt_tokens, completion_tokens)

    def record_review_changes(
        self, task_id: str, prompt_tokens: int | None, completion_tokens: int | None
    ) -> None:
        """Record a review_changes invocation for a specific task."""
        task_tools = self._get_task_tools(task_id)
        task_tools["review_changes"].record_call(prompt_tokens, completion_tokens)

    def record_checkpoint_task(
        self, task_id: str, prompt_tokens: int | None, completion_tokens: int | None
    ) -> None:
        """Record a checkpoint invocation for a specific task."""
        task_tools = self._get_task_tools(task_id)
        task_tools["development_task_checkpoint"].record_call(prompt_tokens, completion_tokens)

    def get_status(self, task_id: str | None = None) -> dict[str, Any]:
        """Return the current usage status for tools of a specific task.

        If task_id is None, returns combined status across all tasks.
        """
        if task_id is None:
            # Combine all tasks - for backward compatibility
            combined: dict[str, ToolUsage] = {}
            for task_tools in self._tools_by_task.values():
                for name, usage in task_tools.items():
                    if name not in combined:
                        combined[name] = ToolUsage(tool_name=name)
                    combined[name].calls += usage.calls
                    combined[name].input_tokens += usage.input_tokens
                    combined[name].output_tokens += usage.output_tokens

            status: dict[str, Any] = {}
            for name, usage in combined.items():
                status[name] = usage.to_dict()

            total_calls = sum(u.calls for u in combined.values())
            total_tokens = sum(u.input_tokens + u.output_tokens for u in combined.values())

            status["total_calls"] = total_calls
            status["total_tokens"] = total_tokens
            return status

        # Return status for specific task
        task_tools = self._tools_by_task.get(task_id)
        if task_tools is None:
            # No usage for this task yet
            return {
                "refine_task": {"status": "not_used", "calls": 0, "total_tokens": 0},
                "collaborate_task": {"status": "not_used", "calls": 0, "total_tokens": 0},
                "review_changes": {"status": "not_used", "calls": 0, "total_tokens": 0},
                "development_task_checkpoint": {"status": "not_used", "calls": 0, "total_tokens": 0},
                "total_calls": 0,
                "known_total_tokens": 0,
            }

        status: dict[str, Any] = {}
        total_calls = 0
        known_total_tokens = 0

        for name, usage in task_tools.items():
            usage_dict = usage.to_dict()
            status[name] = usage_dict
            total_calls += usage.calls
            # Only count tokens if they were actually recorded (non-zero)
            if usage_dict["status"] == "used" and usage.total_tokens > 0:
                known_total_tokens += usage.total_tokens

        status["total_calls"] = total_calls
        status["known_total_tokens"] = known_total_tokens
        return status

    def reset(self) -> None:
        """Reset all tracked usage. For testing only."""
        with self._lock:
            self._tools_by_task.clear()

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict with usage status."""
        status = {}
        for task_id, task_tools in self._tools_by_task.items():
            task_status = {}
            for name, usage in task_tools.items():
                task_status[name] = usage.to_dict()
            task_status["total_calls"] = sum(u.calls for u in task_tools.values())
            task_status["known_total_tokens"] = sum(
                u.total_tokens for u in task_tools.values() if u.total_tokens > 0
            )
            status[task_id] = task_status
        return status

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SupervisionUsageTracker":
        """Create a tracker instance from a saved dict (for persistence)."""
        tracker = cls.__new__(cls)
        tracker._tools_by_task = {}
        tracker._lock = threading.Lock()
        
        for task_id, task_tools_data in data.items():
            tracker._tools_by_task[task_id] = {}
            for name, usage_data in task_tools_data.items():
                if name in ("total_calls", "known_total_tokens"):
                    continue
                tool_usage = ToolUsage(tool_name=name)
                tool_usage.calls = usage_data.get("calls", 0)
                tool_usage.input_tokens = usage_data.get("input_tokens", 0)
                tool_usage.output_tokens = usage_data.get("output_tokens", 0)
                tool_usage.total_tokens = usage_data.get("total_tokens", 0)
                tool_usage.last_call = usage_data.get("last_call")
                tracker._tools_by_task[task_id][name] = tool_usage
        
        return tracker



def get_tracker() -> SupervisionUsageTracker:
    """Convenience function to get the tracker instance."""
    return SupervisionUsageTracker.get_instance()
