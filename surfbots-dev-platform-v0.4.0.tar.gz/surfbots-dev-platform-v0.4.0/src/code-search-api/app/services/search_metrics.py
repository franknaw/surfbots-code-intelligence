"""Durable request metrics for code-search endpoints."""

import os
import sqlite3
from pathlib import Path


METRICS_DB = Path(os.environ.get(
    "SEARCH_METRICS_DB", "/var/lib/surfbots/search-metrics.db"
))


def _connection() -> sqlite3.Connection:
    METRICS_DB.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(METRICS_DB, timeout=5)
    connection.execute(
        "CREATE TABLE IF NOT EXISTS search_request_metrics ("
        "kind TEXT PRIMARY KEY, request_count INTEGER NOT NULL DEFAULT 0)"
    )
    connection.execute(
        "CREATE TABLE IF NOT EXISTS memory_operation_metrics ("
        "kind TEXT NOT NULL, outcome TEXT NOT NULL, request_count INTEGER NOT NULL DEFAULT 0, "
        "total_duration_ms REAL NOT NULL DEFAULT 0, PRIMARY KEY(kind, outcome))"
    )
    return connection


def record_search_request(kind: str) -> None:
    """Increment the durable count for an accepted search request."""
    with _connection() as connection:
        connection.execute(
            "INSERT INTO search_request_metrics (kind, request_count) VALUES (?, 1) "
            "ON CONFLICT(kind) DO UPDATE SET request_count = request_count + 1",
            (kind,),
        )


def get_search_request_metrics() -> dict[str, int]:
    """Return total requests and a breakdown by search endpoint."""
    if not METRICS_DB.exists():
        return {"total": 0, "by_kind": {}}

    with _connection() as connection:
        rows = connection.execute(
            "SELECT kind, request_count FROM search_request_metrics ORDER BY kind"
        ).fetchall()
    by_kind = {kind: count for kind, count in rows}
    return {"total": sum(by_kind.values()), "by_kind": by_kind}


def record_memory_operation(kind: str, outcome: str, duration_ms: float) -> None:
    """Record aggregate memory operation telemetry without storing request content."""
    with _connection() as connection:
        connection.execute(
            "INSERT INTO memory_operation_metrics (kind, outcome, request_count, total_duration_ms) "
            "VALUES (?, ?, 1, ?) ON CONFLICT(kind, outcome) DO UPDATE SET "
            "request_count = request_count + 1, total_duration_ms = total_duration_ms + excluded.total_duration_ms",
            (kind, outcome, duration_ms),
        )


def get_memory_operation_metrics() -> dict[str, dict[str, float | int]]:
    """Return aggregate outcome counts and average latency for memory operations."""
    if not METRICS_DB.exists():
        return {}
    with _connection() as connection:
        rows = connection.execute(
            "SELECT kind, outcome, request_count, total_duration_ms FROM memory_operation_metrics "
            "ORDER BY kind, outcome"
        ).fetchall()
    return {
        f"{kind}:{outcome}": {
            "count": count,
            "average_duration_ms": round(total_duration / count, 2),
        }
        for kind, outcome, count, total_duration in rows
    }