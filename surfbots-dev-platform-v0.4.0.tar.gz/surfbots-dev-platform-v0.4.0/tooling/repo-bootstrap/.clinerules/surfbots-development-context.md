# Surfbots Development Context

Use Surfbots MCP to recover repository context before meaningful development work.

Development Memory provides continuity across tasks and sessions. Current repository files and observed runtime/test evidence remain authoritative for current implementation truth.

## Context Recovery

At the start of meaningful work in a known repository:

1. Use `repository_status` to verify repository registration and index state.
2. Use `get_recent_context` when previous work may affect the current task.
3. Use `search_repository_memory` for focused historical context such as:
   - prior architectural decisions
   - deployment work
   - migrations
   - significant bug fixes
   - named files or symbols
   - unresolved issues
   - previous supervised task outcomes
4. Inspect current code using:
   - `search_code`
   - `find_symbol`
   - `find_references`
   - `get_file`
   - `get_file_range`

Prefer semantic search before broad manual file scanning.

## Evidence Priority

When evidence conflicts, use this priority:

1. Explicit user instructions and supplied task facts
2. Current repository files and observed runtime/test output
3. Current MCP and Surfbots Code Intelligence results
4. Development Memory
5. Model assumptions

Development Memory is historical context, not authoritative current source.

Current code and observed runtime behavior override stale memory.

If `indexCurrent` is false, indexed code-search results may be stale. Prefer current working-tree evidence when available.

## Development Task Continuity

For a supervised development task, `development_task_id` is the stable task identity.

Once `refine_task` returns a `development_task_id`:

- preserve it
- reuse it for `development_task_checkpoint`
- reuse it for `collaborate_task`
- reuse it for `review_changes`
- reuse it for task-scoped supervision status and related Development Memory operations
- do not generate a new task ID for each development phase

A new task ID represents a new development task.

If task identity cannot be recovered, recover task continuity before performing another required supervision operation.

## Development Supervision

For substantial or ambiguous implementation work, invoke `refine_task` before substantial implementation.

Use the returned specification as the repository-grounded implementation plan unless higher-priority current evidence disproves part of it.

Required phase-transition supervision uses:

`development_task_checkpoint`

Typical substantial-task phases include:

- `post_investigation`
- `post_implementation` or `milestone_complete`
- `post_test` when meaningful test evidence exists
- `failure_analysis` when non-trivial debugging begins to drift
- `pre_review`

Use `collaborate_task` for ad-hoc architecture decisions, blockers, conflicting evidence, or uncertainty outside the normal checkpoint phases.

Detailed supervision behavior is defined in:

`.clinerules/surfbots-development-supervision.md`

Do not duplicate or override that workflow here.

## Broad Read-Only Tasks

For broad system-understanding requests such as "tell me about this system," infer a comprehensive scope when the request already provides enough context.

Relevant areas may include:

- architecture
- major components
- services
- deployment
- APIs
- storage and persistence
- indexing/search flows
- MCP integration
- model services
- configuration
- developer workflows

Do not ask the user to choose a focus when the parent request already establishes a broad system-understanding goal.

## Review Context

After substantial implementation and required checkpoints:

1. Run relevant deterministic tests.
2. Invoke `review_changes` with:
   - the original/refined specification
   - actual changed files or diff
   - exact observed test results
   - the same `development_task_id`
3. Address valid findings.
4. Retest.
5. Review again when required.

Perform at most **two** automatic review-and-fix cycles.

After two cycles, report remaining meaningful issues rather than entering an indefinite loop.

Interpret review results together with coverage:

- `no_issues_found` — no defect was found in the evidence actually reviewed; this is not proof of correctness.
- `needs_changes` — validate and address the findings.
- `incomplete_review` — review coverage was incomplete; this is not success.
- `unable_to_review` — the review could not be performed; this is not success.

If required workflow checkpoints are missing, the backend may reject final review. Complete the missing checkpoints rather than bypassing the gate.

## Supervision Failure Behavior

Required supervision boundaries are fail-closed.

If `refine_task`, a required `development_task_checkpoint`, or `review_changes` fails:

- report the exact failure
- do not pretend supervision succeeded
- do not bypass the required step
- do not silently create another task ID
- do not continue through the required supervision boundary

A terminal command timeout does not by itself prove MCP or the supervision model failed.

Do not substitute terminal `curl`, Python requests, direct pod access, or another transport for the normal MCP supervision workflow merely to bypass a supervision failure.

## Development Memory Writes

Write Development Memory after meaningful outcomes such as:

- durable architectural decisions
- significant bug fixes
- completed milestones
- operational or deployment changes
- unresolved issues
- concrete follow-up work

Store concise structured outcomes rather than transcripts.

Do not store:

- hidden reasoning
- credentials or secrets
- unrestricted command output
- repetitive status chatter
- trivial edits

Checkpoint workflow state is already persisted by Development Supervision. Do not manually duplicate automatic checkpoint records unless a separate durable memory record is genuinely useful.

## Repository Isolation

All Development Memory and supervision context must remain repository scoped.

Task-specific context must also remain scoped to the correct `development_task_id`.

Never use memory or checkpoint state from one repository or task as authoritative state for another.


## Skill Loading and Loop Prevention

Once a skill has been successfully loaded during a task, treat its guidance as available for the remainder of that task.

Do not repeatedly reload the same skill unless:

- the skill content is known to have changed
- a different skill is specifically required
- new evidence demonstrates that the previously loaded skill is insufficient

Never issue the same `skills` call repeatedly after receiving the same result.

If an identical skill or auxiliary context-discovery call would be repeated:

1. reuse the already-loaded guidance
2. inspect current repository evidence
3. use Development Memory or Code Intelligence when additional context is required
4. use `collaborate_task` or `development_task_checkpoint(failure_analysis)` when a genuine engineering uncertainty remains

A repeated skill-loading failure is a tooling dead end, not a reason to restart the development task.

Do not allow repeated skill loading to interrupt or replace the active Development Supervision workflow.

## Context Window Management

Avoid allowing task context to approach the model's maximum context window.

For long-running tasks:

- reuse previously retrieved evidence instead of repeatedly retrieving the same content
- do not repeatedly reload skills
- avoid re-reading large files when a focused range or code search is sufficient
- summarize completed phases before continuing into a new phase
- preserve the active `development_task_id`, decisions, unresolved issues, and current workflow state when context is compacted
- prefer bounded retrieval over adding large command output to context
- preserve sufficient context-window headroom for tool responses, system instructions, MCP results, and model output rather than attempting to consume the full advertised context window

Do not wait until the model request exceeds its context window before reducing accumulated context.