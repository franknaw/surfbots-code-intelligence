"""Platform-level supervision tests.

Covers the acceptance criteria that cannot be proven inside a single service:
model reuse across inference profiles, absence of extra model deployments, and
the bootstrap install path.
"""
import json
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

BOOTSTRAP = Path(__file__).resolve().parent
PLATFORM_ROOT = BOOTSTRAP.parents[1]
CLI = BOOTSTRAP / "surfbots-dev"

GENERATION_VALUES = PLATFORM_ROOT / "helm" / "model-generation"
SUPERVISION_SRC = PLATFORM_ROOT / "src" / "code-search-api" / "app" / "services" / "supervision"
MCP_SRC = PLATFORM_ROOT / "src" / "mcp-server" / "app"

MODEL_NAMES = ("qwen", "1.5b", "3b", "q4_k_m", "gguf")


def load_values(name: str) -> dict:
    return yaml.safe_load((GENERATION_VALUES / name).read_text())


# --- Model reuse across profiles (required cases 3, 4, 5) -------------------

def test_both_profiles_exist():
    assert (GENERATION_VALUES / "values-local.yaml").exists()
    assert (GENERATION_VALUES / "values-local-quality.yaml").exists()


def test_lightweight_profile_selects_the_small_model():
    values = load_values("values-local.yaml")
    assert values["inferenceProfile"] == "local-lightweight"
    assert "1.5B" in values["model"]["hfRepo"]


def test_quality_profile_selects_the_larger_model():
    values = load_values("values-local-quality.yaml")
    assert values["inferenceProfile"] == "local-quality"
    assert "3B" in values["model"]["hfRepo"]


def test_switching_profile_changes_only_the_model():
    """The profile override must not move or rename the generation service."""
    quality = load_values("values-local-quality.yaml")
    # A profile override that touched service or image would break role binding.
    assert set(quality) <= {"inferenceProfile", "model", "resources", "startupProbe"}
    assert "service" not in quality
    assert "image" not in quality


def test_supervision_code_contains_no_model_names():
    """Roles bind to a service; a model name here would break profile switching."""
    for path in SUPERVISION_SRC.rglob("*.py"):
        text = path.read_text().lower()
        for token in MODEL_NAMES:
            assert token not in text, f"{path.name} references model '{token}'"


def test_mcp_layer_contains_no_model_names():
    for path in MCP_SRC.rglob("*.py"):
        text = path.read_text().lower()
        for token in MODEL_NAMES:
            assert token not in text, f"{path.name} references model '{token}'"


def test_generation_client_does_not_pin_a_model():
    provider = (PLATFORM_ROOT / "src" / "code-search-api" / "app" / "services" / "generation_provider.py").read_text()
    # "default" lets the loaded model answer, whichever profile is active.
    local_provider = provider.split("class LocalOpenAICompatibleProvider:")[1].split("class OpenAICompatibleProvider:")[0]
    assert 'generate("default", request)' in local_provider
    for token in MODEL_NAMES:
        assert token not in local_provider.lower()


def test_reported_model_is_observability_only():
    """model_name() must never influence routing."""
    client = (PLATFORM_ROOT / "src" / "code-search-api" / "app" / "services" / "generation_client.py").read_text()
    complete_body = client.split("async def complete(")[1]
    assert "model_name(" not in complete_body


# --- No additional model deployment (required case 6) ----------------------

def test_only_three_model_charts_exist():
    charts = sorted(p.name for p in (PLATFORM_ROOT / "helm").glob("model-*"))
    assert charts == ["model-embedding", "model-generation", "model-reranker"]


def test_no_reviewer_or_refiner_deployment_is_defined():
    for path in (PLATFORM_ROOT / "helm").rglob("*.yaml"):
        text = path.read_text().lower()
        assert "reviewer-model" not in text
        assert "model-reviewer" not in text
        assert "model-refiner" not in text


def test_code_search_api_runs_no_model_container():
    deployment = (PLATFORM_ROOT / "helm" / "code-search-api" / "templates" / "deployment.yaml").read_text()
    assert "llama.cpp" not in deployment
    assert "hfRepo" not in deployment


def test_supervision_reaches_generation_by_service_url():
    values = yaml.safe_load((PLATFORM_ROOT / "helm" / "code-search-api" / "values-local.yaml").read_text())
    endpoint = values["config"]["generationEndpoint"]
    # A stable service address is what makes the model swappable.
    assert endpoint.startswith("http://model-generation")


# --- MCP configuration merge (required case 15) ---------------------------

def test_mcp_configure_preserves_peer_servers(tmp_path, monkeypatch):
    cline_home = tmp_path / "cline"
    settings = cline_home / "data" / "settings"
    settings.mkdir(parents=True)
    config = settings / "cline_mcp_settings.json"
    config.write_text(json.dumps({"mcpServers": {"someone-elses-server": {"url": "http://elsewhere"}}}))

    workspace = tmp_path / "ws"
    workspace.mkdir()

    env = {**dict(**__import__("os").environ), "CLINE_DIR": str(cline_home), "HOME": str(tmp_path)}
    subprocess.run(
        [sys.executable, str(CLI), "mcp", "configure", "cline"],
        capture_output=True, text=True, timeout=60, env=env,
    )

    saved = json.loads(config.read_text())
    assert "someone-elses-server" in saved["mcpServers"], "peer MCP servers must survive configuration"
    assert "surfbots-dev-platform" in saved["mcpServers"]


def test_mcp_configure_auto_approves_supervision_tools(tmp_path):
    cline_home = tmp_path / "cline"
    (cline_home / "data" / "settings").mkdir(parents=True)
    env = {**dict(**__import__("os").environ), "CLINE_DIR": str(cline_home), "HOME": str(tmp_path)}
    subprocess.run(
        [sys.executable, str(CLI), "mcp", "configure", "cline"],
        capture_output=True, text=True, timeout=60, env=env,
    )
    saved = json.loads((cline_home / "data" / "settings" / "cline_mcp_settings.json").read_text())
    approved = set(saved["mcpServers"]["surfbots-dev-platform"]["autoApprove"])
    assert {"refine_task", "collaborate_task", "review_changes"} <= approved


# --- Bootstrap install path (required case 17) ----------------------------

def test_bootstrap_simulation_installs_supervision_artifacts(tmp_path):
    """Simulate what bootstrap does for a fresh repository."""
    repo = tmp_path / "fresh"
    (repo / "src").mkdir(parents=True)
    (repo / "src" / "app.py").write_text("x = 1\n")

    result = subprocess.run(
        [sys.executable, str(CLI), "init", str(repo)],
        capture_output=True, text=True, timeout=120,
    )
    assert result.returncode in (0, None), result.stderr

    expected = [
        ".clinerules/surfbots-development-supervision.md",
        ".clinerules/skills/surfbots-development-context/SKILL.md",
        ".github/instructions/surfbots-development-context.instructions.md",
        ".github/skills/surfbots-development-context/SKILL.md",
    ]
    for relative in expected:
        path = repo / relative
        assert path.exists(), f"bootstrap did not install {relative}"
        text = path.read_text()
        assert "refine_task" in text and "collaborate_task" in text and "review_changes" in text, f"{relative} lacks supervision behaviour"


def test_bootstrap_documents_capability_verification():
    text = (PLATFORM_ROOT / "bootstrap.sh").read_text()
    assert "mcp test" in text
    assert "Supervision" in text


# --- Observability (spec: log metadata, never source content) --------------

def test_generation_logging_records_metadata_without_source():
    provider = (PLATFORM_ROOT / "src" / "code-search-api" / "app" / "services" / "generation_provider.py").read_text()
    log_line = provider.split("logger.info(")[1].split(")")[0]
    for field in ("role", "repository", "duration", "prompt_tokens", "completion_tokens"):
        assert field in log_line, f"supervision logging should record {field}"
    for leak in ("user_prompt", "system_prompt", "text"):
        assert leak not in log_line, f"supervision logging must not include {leak}"




# --- MCP port resolution (required cases 1-10) ----------------------------

def test_mcp_status_shows_running_port():
    """Test that mcp status command runs without errors."""
    result = subprocess.run(
        [str(sys.executable), str(CLI), "mcp", "status"],
        capture_output=True, text=True, timeout=30,
    )
    assert result.returncode == 0, f"mcp status failed: {result.stderr}"
    # The command should complete (MCP server may or may not be running in test env)
    assert "Surfbots MCP Status" in result.stdout, "Should show status header"


def test_mcp_configure_updates_cline_config():
    """Test that mcp configure successfully updates Cline configuration."""
    # Use a temp directory for testing
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        cline_home = Path(tmpdir) / "cline"
        settings = cline_home / "data" / "settings"
        settings.mkdir(parents=True)
        
        env = {
            **dict(**__import__("os").environ),
            "CLINE_DIR": str(cline_home),
            "HOME": str(tmpdir),
        }
        
        result = subprocess.run(
            [str(sys.executable), str(CLI), "mcp", "configure", "cline"],
            capture_output=True, text=True, timeout=60, env=env,
        )
        
        assert result.returncode == 0, f"configure failed: {result.stderr}"
        assert "Cline MCP configuration updated" in result.stdout, "Should report successful update"
        
        config_path = settings / "cline_mcp_settings.json"
        assert config_path.exists(), "Cline config should be created"
        
        saved = json.loads(config_path.read_text())
        assert "surfbots-dev-platform" in saved["mcpServers"], "Surfbots server should be configured"
        
        # Verify the URL uses the correct port
        url = saved["mcpServers"]["surfbots-dev-platform"]["url"]
        assert url.startswith("http://127.0.0.1:"), f"URL should use localhost: {url}"
        assert url.endswith("/mcp"), f"URL should end with /mcp: {url}"
        
        # Verify all required tools are in autoApprove
        approved = saved["mcpServers"]["surfbots-dev-platform"]["autoApprove"]
        required_tools = {
            "search_code", "get_file", "get_file_range", "find_symbol",
            "find_references", "repository_status", "get_recent_context",
            "search_repository_memory", "write_repository_memory",
            "refine_task", "collaborate_task", "review_changes",
            "development_supervision_status"
        }
        assert required_tools <= set(approved), f"Missing tools: {required_tools - set(approved)}"


def test_mcp_configure_is_idempotent():
    """Test that repeated configure runs produce no unintended changes."""
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        cline_home = Path(tmpdir) / "cline"
        settings = cline_home / "data" / "settings"
        settings.mkdir(parents=True)
        
        env = {
            **dict(**__import__("os").environ),
            "CLINE_DIR": str(cline_home),
            "HOME": str(tmpdir),
        }
        
        # First configure
        result1 = subprocess.run(
            [str(sys.executable), str(CLI), "mcp", "configure", "cline"],
            capture_output=True, text=True, timeout=60, env=env,
        )
        assert result1.returncode == 0
        
        config_path = settings / "cline_mcp_settings.json"
        saved1 = json.loads(config_path.read_text())
        
        # Second configure
        result2 = subprocess.run(
            [str(sys.executable), str(CLI), "mcp", "configure", "cline"],
            capture_output=True, text=True, timeout=60, env=env,
        )
        assert result2.returncode == 0
        
        saved2 = json.loads(config_path.read_text())
        
        # Config should be the same after second run
        assert saved1 == saved2, "Second configure should produce identical config"


def test_mcp_configure_preserves_peer_servers():
    """Test that mcp configure preserves unrelated MCP servers."""
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        cline_home = Path(tmpdir) / "cline"
        settings = cline_home / "data" / "settings"
        settings.mkdir(parents=True)
        
        # Create config with peer servers
        config_path = settings / "cline_mcp_settings.json"
        config_path.write_text(json.dumps({
            "mcpServers": {
                "other-server": {"type": "streamableHttp", "url": "http://other:8000/mcp"},
                "another-server": {"type": "stdin", "command": "echo"},
            },
        }))
        
        env = {
            **dict(**__import__("os").environ),
            "CLINE_DIR": str(cline_home),
            "HOME": str(tmpdir),
        }
        
        result = subprocess.run(
            [str(sys.executable), str(CLI), "mcp", "configure", "cline"],
            capture_output=True, text=True, timeout=60, env=env,
        )
        
        assert result.returncode == 0
        
        saved = json.loads(config_path.read_text())
        
        # Verify peer servers preserved
        assert "other-server" in saved["mcpServers"]
        assert "another-server" in saved["mcpServers"]
        
        # Verify surfbots entry added
        assert "surfbots-dev-platform" in saved["mcpServers"]


def test_mcp_port_resolution_with_env_var():
    """Test that SURFBOTS_MCP_PORT environment variable is used."""
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        # Ensure PID file doesn't exist
        pid_file = Path("/tmp/surfbots-mcp.pid")
        if pid_file.exists():
            pid_file.unlink()
        
        cline_home = Path(tmpdir) / "cline"
        settings = cline_home / "data" / "settings"
        settings.mkdir(parents=True)
        
        # Set environment variable for port
        env = {
            **dict(**__import__("os").environ),
            "CLINE_DIR": str(cline_home),
            "HOME": str(tmpdir),
            "SURFBOTS_MCP_PORT": "8025",
        }
        
        result = subprocess.run(
            [str(sys.executable), str(CLI), "mcp", "configure", "cline"],
            capture_output=True, text=True, timeout=60, env=env,
        )
        
        assert result.returncode == 0
        
        config_path = settings / "cline_mcp_settings.json"
        saved = json.loads(config_path.read_text())
        
        # Verify the URL uses the env var port
        url = saved["mcpServers"]["surfbots-dev-platform"]["url"]
        assert "8025" in url, f"URL should use SURFBOTS_MCP_PORT (8025): {url}"
