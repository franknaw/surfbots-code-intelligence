# Development Supervision — Implementation Plan

Adds two agent-assist MCP tools, `refine_task` and `review_changes`, that reuse
the generation model already loaded by the active inference profile.

This document is the implementation plan. Nothing here is built yet.

## Why this is worth planning before coding

Surfbots answers two questions today. This adds a third.

| Capability | Question it answers | Status |
|---|---|---|
| Code Intelligence | What does the repository contain now? | Built |
| Development Memory | What were we doing, and why? | Built |
| Development Supervision | What should the agent do, and did it do it right? | This plan |

## Findings from the current codebase

These were verified against the running platform, and several of them change the
shape of the work.

**The MCP server cannot reach the generation service today.** Its configuration
exposes exactly one outbound URL:

```python
# src/mcp-server/app/core/config.py
code_search_url: str = Field(...)
```

There is no generation client anywhere in `src/*/app/services/model_client.py` —
only embeddings. Supervision needs a new client plus a routing decision, which is
Phase 1 rather than an afterthought.

**Generation is an OpenAI-compatible llama.cpp server.**

```
image: ghcr.io/ggml-org/llama.cpp:server
args:  -hf Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF:Q4_K_M
       --ctx-size 8192 --threads 8 --n-gpu-layers 0
svc:   model-generation:8000
```

`/v1/models` and `/v1/chat/completions` are available. No new client protocol is
required.

**Measured performance, CPU-only:**

```
latency        1.5 s for 83 completion tokens
throughput     55.5 tok/s
context        8192 tokens, shared with the prompt
```

**The model wraps JSON in Markdown fences.** A live call returned:

````
```json
{   "objective": "To enhance the reliability of HTTP client requests...
````

Structured output parsing must strip fences and tolerate malformed output. This
is not a hypothetical edge case; it is the default behaviour.

**Profile switching is a Helm values swap**, so role configuration genuinely can
stay model-agnostic:

```
helm/model-generation/values-local.yaml          hfRepo: Qwen2.5-Coder-1.5B-Instruct-GGUF
helm/model-generation/values-local-quality.yaml  hfRepo: Qwen2.5-Coder-3B-Instruct-GGUF
```

The service name `model-generation:8000` is stable across profiles. An agent role
that targets the service, never a model name, satisfies the acceptance criteria
by construction.

**The verifier already has the extension point:**

```python
# tooling/repo-bootstrap/surfbots-dev
required_tools = {"repository_status", "get_recent_context",
                  "search_repository_memory", "search_code",
                  "write_repository_memory"}
```

## Resolved architecture

Routing is settled:

```
MCP  ->  Code Search API  ->  Generation Service
```

There is deliberately **no direct MCP to model-generation dependency**.

| Component | Owns |
|---|---|
| MCP | Expose `refine_task` and `review_changes`; validate inputs; forward repository-scoped requests; translate API failures into MCP errors |
| Code Search API | Supervision orchestration, repository validation and isolation, code and memory retrieval, role prompt construction, context budgeting, generation invocation, response parsing and validation |
| Generation Service | Remain a generic OpenAI-compatible inference service, with no repository or supervision-specific behaviour |

Both tools need retrieval the Code Search API already owns, including repository
name resolution. Routing through it avoids duplicating that logic in the MCP
layer and keeps the MCP server a thin protocol adapter.

### Binding constraints

1. The 8192-token generation context is an explicit hard budget, not a guideline.
2. Review evidence is never silently truncated.
3. `review_changes` reports deterministic coverage: `full`, `partial`, or
   `unable_to_review`.
4. A partial review may never produce an unqualified pass.
5. Verdicts are `no_issues_found`, `needs_changes`, `incomplete_review`, or
   `unable_to_review`. `no_issues_found` is not proof of correctness.
6. No model-generated confidence scores. Coverage is computed, not asked for.
7. Response parsing is shared in the Code Search layer: trim, strip one outer
   Markdown fence, parse JSON, validate against schema, fail explicitly. Not
   duplicated per tool.
8. At most one constrained retry on invalid JSON. No unbounded correction loop.
9. First implementation is single-pass and bounded. No map-reduce review yet.
10. Roles resolve through the active generation profile. No model name is
    hardcoded in MCP or supervision code.

Constraints 3 through 6 exist because the most dangerous outcome is a review that
reports success without having examined the evidence. Coverage is reported
separately from verdict so a caller can distinguish "found nothing wrong" from
"could not look".

## Phases

### Phase 1 — Agent role abstraction and generation client

Add a `GenerationClient` and an agent-role layer that resolves a role to the
active profile's generation service, in the Code Search API.

```yaml
agentProfiles:
  promptRefiner:
    provider: profile
    service: generation
    role: prompt-refiner
  reviewer:
    provider: profile
    service: generation
    role: reviewer
```

- `GenerationClient` targeting `/v1/chat/completions`, reached via a
  `GENERATION_ENDPOINT` env var following the existing `INDEXER_URL` and
  `RERANKER_ENDPOINT` Helm pattern
- Role prompts stored server-side and version-controlled
- Shared response parser: trim, strip one outer fence, parse, validate, with at
  most one constrained retry
- Explicit token budgeting against the 8192 context, returning what was omitted
- Bounded concurrency: a semaphore of 1 for local profiles, since one llama.cpp
  process serves normal generation, refinement, and review
- No model name appears in role configuration

**Exit:** a role resolves to a live generation call, concurrency is capped,
malformed output fails explicitly, and a provider override remains possible
without touching MCP contracts.

### Phase 2 — `refine_task`

Input `repository_id` and `request`; optional `current_context`, `constraints`.
May internally call `repository_status`, recent memory, and `search_code`.

Returns `objective`, `requirements`, `constraints`, `relevant_context`, `tests`,
`acceptance_criteria`.

- Fence-stripping JSON parser with a clear failure path
- Never implements code; separates repository facts from assumptions
- Strict `repository_id` isolation on every internal retrieval

**Exit:** a real request yields a schema-valid specification, and malformed model
output produces an explicit tool error rather than an empty success.

### Phase 3 — `review_changes`

Input `repository_id` and `task_specification`; optional `diff`, `changed_files`,
`test_results`.

Returns:

```json
{
  "verdict": "no_issues_found | needs_changes | incomplete_review | unable_to_review",
  "coverage": {
    "level": "full | partial | unable_to_review",
    "reviewed_files": ["..."],
    "omitted_files": ["..."],
    "reason": "..."
  },
  "summary": "...",
  "findings": [
    {"severity": "high | medium | low", "issue": "...", "evidence": "...", "required_change": "..."}
  ],
  "tests_required": ["..."]
}
```

- Coverage is computed from what actually fit the budget, never asked of the model
- Omitted evidence is listed explicitly; partial coverage downgrades the verdict
  to `incomplete_review`
- Current code is authoritative over stale memory
- Single-pass only; no chunked or map-reduce review in this iteration

**Exit:** a task plus synthetic diff produces structured findings; an oversized
diff yields `incomplete_review` naming the omitted files, never a silent pass.

### Phase 4 — Cline behaviour

Extend `.clinerules` installed by `surfbots-dev init`.

```
substantial or ambiguous request  -> refine_task -> implement
non-trivial implementation        -> tests -> review_changes -> fix -> retest
```

- Trivial edits are explicitly exempt
- Hard cap of **2** automatic review/fix cycles, then surface findings
- Existing retrieval guidance stays intact
- Re-running `init` must not duplicate rules

### Phase 5 — Copilot Skill and instructions

Mirror Phase 4 into `.github/skills/` and `.github/instructions/`.

Cline reads `.clinerules/skills`; Copilot reads `.github/skills`. The same
behaviour is written to both because the clients share no registry.

### Phase 6 — Bootstrap and verification

Add both tools to `required_tools` in the verifier and extend
`surfbots-dev mcp test` with behavioural smoke tests, not just name checks.

Bootstrap should report:

```
Code Intelligence:        Ready
Development Memory:       Ready
Development Supervision:  Ready
Cline:                    Configured
Copilot:                  Configured
```

Supervision must not report Ready unless both tools respond with valid structure.

### Phase 7 — Tests

The 20 required cases, grouped by what they actually protect:

- **Model reuse (1–6):** both roles hit the active profile service; switching
  profiles changes the model with no agent config change; no second deployment
- **Contracts (7–9):** both schemas validate; fenced and malformed output handled
- **Isolation and resilience (10–11):** generation outage leaves `search_code`,
  `repository_status`, and memory working; no cross-repository retrieval
- **Client integration (12–15):** installed rules and Skill contain supervision
  behaviour; repeated `init` does not duplicate; MCP config merge preserves peers
- **Regression (16–20):** verifier requires both tools; existing indexer, Code
  Search API, and memory tests stay green

## Risks

**Context window is the real constraint.** 8192 tokens is shared between prompt
and completion. Retrieved context plus a diff plus a specification will exceed it
on realistic reviews. Budget explicitly and disclose truncation.

**A 1.5B reviewer will miss defects.** It is a useful second pass, not an
authority. Documentation should not imply otherwise.

**Shared model contention.** Review requests compete with normal generation on
one CPU process. The semaphore prevents resource exhaustion but means review
requests queue behind other work.

**Silent-success is the failure mode to avoid.** A generation outage must surface
as a tool error. A review that cannot run must never return `pass`.

**Review loops.** The 2-cycle cap belongs in the rules, and needs testing.

## Sequencing

Phases 1–3 are the capability. Phases 4–5 make it automatic. Phase 6 makes it
installable. Phase 7 keeps it honest.

Phase 1's routing decision is the only irreversible choice; everything after it
is additive.
