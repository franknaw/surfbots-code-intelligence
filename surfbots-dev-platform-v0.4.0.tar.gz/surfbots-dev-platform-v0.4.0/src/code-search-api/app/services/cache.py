"""Caching service for the code search API."""
import hashlib
import json
import time
from typing import Any, Optional, Dict
from functools import wraps
from cachetools import TTLCache, cachedmethod
from cachetools.keys import hashkey

from ..core.config import settings


class SearchCache:
    """Caching service with TTL support."""
    
    def __init__(self, max_size: int = 1000, default_ttl: int = None):
        self.default_ttl = default_ttl or settings.cache_ttl_seconds
        self._cache: TTLCache = TTLCache(maxsize=max_size, ttl=self.default_ttl)
    
    def _generate_key(
        self,
        repository_id: Optional[str],
        query: str,
        filters: Dict[str, Any],
        limit: int,
        offset: int
    ) -> str:
        """Generate a cache key from search parameters."""
        key_data = {
            "repository_id": repository_id,
            "query": query,
            "filters": json.dumps(filters, sort_keys=True),
            "limit": limit,
            "offset": offset
        }
        key_string = json.dumps(key_data, sort_keys=True)
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def make_key(
        self,
        repository_id: Optional[str],
        query: str,
        filters: Dict[str, Any],
        limit: int,
        offset: int
    ) -> str:
        """Build the cache key. Readers and writers must both use this."""
        return self._generate_key(repository_id, query, filters, limit, offset)

    def get(self, key: str) -> Optional[Any]:
        """Get a value from cache."""
        try:
            return self._cache[key]
        except KeyError:
            return None
    
    def set_by_key(self, key: str, value: Any) -> None:
        """Store a value under a key produced by make_key."""
        self._cache[key] = {
            "value": value,
            "created_at": time.time(),
            "ttl": self.default_ttl
        }

    def set(
        self,
        repository_id: Optional[str],
        query: str,
        filters: Dict[str, Any],
        limit: int,
        offset: int,
        value: Any
    ) -> None:
        """Set a value in cache."""
        key = self._generate_key(repository_id, query, filters, limit, offset)
        self._cache[key] = {
            "value": value,
            "created_at": time.time(),
            "ttl": self.default_ttl
        }
    
    def clear_by_repository(self, repository_id: str) -> None:
        """Clear all cache entries for a repository."""
        keys_to_remove = []
        for key in self._cache.keys():
            # Simple approach: iterate and check
            cached = self._cache[key]
            if isinstance(cached, dict) and isinstance(cached.get("value"), dict):
                if cached["value"].get("repository_id") == repository_id:
                    keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del self._cache[key]
    
    def clear_all(self) -> None:
        """Clear all cache entries."""
        self._cache.clear()


# Global cache instance
cache = SearchCache()