# Provider-Aware Model Profiles - Implementation Plan

## Progress

- **Phase 0 complete:** [runtime-ownership.md](runtime-ownership.md) identifies
   `surfbots-dev` as the independent local model-profile control surface. The
   Admin web application is not a dependency for this capability.
- **Phase 1 complete:** provider-connection metadata is stored in a dedicated
   Code Search API SQLite control-plane database. Tokens are stored only in the
   Helm-precreated `surfbots-provider-credentials` Kubernetes Secret through a
   service-account adapter with resource-name-scoped `get` and `patch` RBAC.
- **Phase 2 complete:** a stable `GenerationProvider` contract and shared
   OpenAI-compatible transport now back the existing local provider. The public
   `GenerationClient` contract, `model: "default"` request, endpoint, and
   concurrency-one behavior remain unchanged.
- **Phase 3 complete:** a request-time role resolver loads the persisted active
   profile. Existing installations migrate to a `current-local` profile that
   binds `generation`, `reviewer`, and `promptRefiner` to the one local provider
   and `profile-generation` model label. Remote bindings fail explicitly until
   Phase 4; they do not fall back to local generation.
- **Phase 4 complete:** OpenAI and OpenAI-compatible bindings resolve to a
   selected remote model using the Phase 1 Secret-backed credential. Remote
   clients use the shared transport and close after each request. Missing,
   disabled, and mismatched connections fail explicitly with no local fallback.
- **Phase 5 complete:** candidate profiles are validated role by role before a
   single active-profile update. Remote-only activation performs discovery where
   available and a source-free smoke request; failed attempts retain the prior
   active profile and report `activation_failed`. Local model-label changes are
   intentionally gated until Phase 8 provides the controlled rollout operation.
- **Phase 6 complete:** the internal model-control API is protected by
   Kubernetes `TokenReview`. It accepts only short-lived tokens for the dedicated
   no-permission `code-search-api` service account, supplied over a
   temporary localhost `kubectl port-forward`; no public Admin API exists.
- **Phase 7 complete:** `surfbots-dev models ...` provides local-only,
   command-lifetime access to the internal control plane. It creates a
   ten-minute service-account token, starts and always terminates a loopback
   `kubectl port-forward`, prompts provider credentials only with hidden input,
   and forwards all provider/profile operations to the server. Profile YAML is
   portable and credential-free: remote bindings use connection names and
   provider types, which are resolved to local connection IDs on import. No
   Admin UI work is planned.
- **Phase 8 complete:** local profile activation uses a Kubernetes API rollout
   service that can patch and observe only `model-generation-generation`, with
   resource-name-scoped RBAC. It accepts only the vetted `local-lightweight` and
   `local-quality` mappings (plus the legacy local label), waits for the new
   deployment revision to become ready, performs the existing local
   health/smoke validation, and retains the previous logical profile on every
   failure. `cluster.sh deploy-generation` exposes the matching generation-only
   Helm operation for operators. Qdrant, indexer, MCP, embedding, reranker, and
   session memory are not rolled.
- **Phase 9 complete:** bootstrap passes the existing local generation selection
   to Code Search API as non-secret configuration. Fresh installations seed
   `current-local` with all three roles bound to that selected label; untouched
   legacy `profile-generation` bindings migrate to it without modifying custom
   or remote profiles. API startup verifies all default local roles resolve, and
   no remote credential is requested. The retained
   `SURFBOTS_INFERENCE_PROFILE` environment variable is now described to
   operators as a local generation deployment selection; retrieval remains
   independent.
- **Phase 10 complete:** release documentation, security/regression coverage,
   and available CLI, API, indexer, Helm, and shell validation now cover the
   provider-aware model profile workflow end to end.

## Purpose

Add runtime-configurable generation and supervision profiles without changing
MCP tool schemas or retrieval/indexing configuration.

A logical role resolves at request time to a provider and model selected by the
active profile:

```text
Cline / Copilot
  -> MCP
  -> Code Search API / Development Supervision
  -> Role Resolver
  -> Generation Provider
  -> local llama.cpp or OpenAI-compatible endpoint
```

The role resolver is the only component that maps a role to a provider,
connection, model, and effective limits. MCP must continue to expose only
`refine_task` and `review_changes`; it must not know tokens, provider URLs,
Secrets, or model deployment details.

## Current Evidence and Constraints

The current system has one local OpenAI-compatible generation service:

- `model-generation:8000` runs llama.cpp and exposes `/v1/models` and
  `/v1/chat/completions`.
- `GenerationClient` in `src/code-search-api/app/services/generation_client.py`
  serializes requests with concurrency one and always sends `model: "default"`.
- `RoleRunner` in `src/code-search-api/app/services/supervision/roles.py` maps
  both `promptRefiner` and `reviewer` to that client.
- `cluster.sh` and `tooling/repo-bootstrap/surfbots-dev` maintain
   `local-lightweight` and `local-quality` local generation profiles. Retrieval
   remains on the fixed local embedding and reranker defaults.
- `helm/model-generation/values-local.yaml` and
  `helm/model-generation/values-local-quality.yaml` select the loaded local
  model. The generation deployment uses a `Recreate` strategy and health
  probes, so it can be used as the controlled local-rollout mechanism.
- Retrieval is independent in practice: the quality overlay changes only the
  generation model. This must become an explicit runtime contract.
- `surfbots-dev` already owns local bootstrap and port-forward lifecycle. Model
   profiles use it as an independent operator surface and do not route through
   Azure Static Web Apps, Surfbots Admin, or MCP.

## Runtime Contract

### Roles

The only configurable logical roles are:

| Role key | Current consumer | Required routing |
|---|---|---|
| `generation` | Normal generation consumers | `resolve_role("generation")` |
| `reviewer` | `review_changes` | `resolve_role("reviewer")` |
| `promptRefiner` | `refine_task` | `resolve_role("promptRefiner")` |

All model-using Code Search API paths must use this resolver. A remote-provider
failure returns an explicit provider error; it must never silently fall back to
the local model.

### Provider connections

A connection represents an endpoint and credential reference, not a selected
model:

```json
{
  "id": "openai-main",
  "name": "OpenAI Main",
  "provider_type": "openai-compatible",
  "base_url": "https://api.openai.com/v1",
  "secret_ref": "surfbots-provider-openai-main",
  "enabled": true,
  "created_at": "...",
  "updated_at": "...",
  "last_tested_at": "...",
  "last_test_status": "connected"
}
```

`secret_ref` is metadata only. The raw token is written directly to a
Kubernetes Secret, injected only into the server-side provider client, and is
never returned by API responses, written to profile data, included in Helm
values, or logged.

### Configuring an OpenAI, Azure OpenAI, or compatible connection

Do not add a provider URL or token to a checked-in YAML file, `.env` file, Helm
value, MCP configuration, or command argument. The supported configuration point
will be `surfbots-dev models connection add <name>` in Phase 7. It collects the
base URL and one-time hidden token interactively, establishes a temporary local
port-forward, and submits the request to the cluster-internal control-plane API.
That API writes the token directly to the
`surfbots-provider-credentials` Kubernetes Secret and thereafter returns only
`has_token` state.

For official OpenAI, use `https://api.openai.com/v1` as the connection base URL.
Azure OpenAI uses provider type `azure-openai`, its resource endpoint such as
`https://your-resource.openai.azure.com`, a hidden CLI-supplied API key, and an
Azure deployment name as the profile model. Azure deployment discovery is not
available through this API, so deployment names are entered manually. Compatible
endpoints such as LM Studio, vLLM, llama.cpp, and company gateways use their own
OpenAI-compatible `/v1` base URL. Do not provide an API token in
chat, terminal command arguments, or source control. Until Phase 7 exposes the
local CLI command, there is intentionally no supported operator-facing command
for adding a remote connection.

### Model profiles

A named profile selects each role independently:

```json
{
  "id": "halo-hybrid",
  "name": "Halo Hybrid",
  "roles": {
    "generation": {"provider": "local", "model": "profile-generation"},
    "reviewer": {
      "provider": "openai-compatible",
      "connection_id": "openai-main",
      "model": "gpt-4.1-mini"
    },
    "promptRefiner": {"provider": "local", "model": "profile-generation"}
  }
}
```

Profiles contain no credential. The single active profile ID is read on each
request, or from a cache with reliable invalidation, so remote-only changes
apply to the next request without a rollout.

### Retrieval remains separate

Generation/supervision profiles must not contain embedding, reranker, vector
dimension, distance-metric, or Qdrant collection configuration. Activating a
model profile must not rebuild or alter `code-index` or `session-memory`.
Changing retrieval profiles remains a separate future operation and may require
an index migration.

## Data Stores and Security Boundaries

| Data | Owner / proposed storage | Secret policy |
|---|---|---|
| Provider connection metadata | Code Search API control-plane persistence | Stores `secret_ref`, never token |
| Provider token | Kubernetes Secret, named by `secret_ref` | Server-side only; redact from logs/errors |
| Named model profiles | Code Search API control-plane persistence | No token fields |
| Active profile ID and activation state | Same control-plane persistence | Atomic update after validation |
| Audit events | Existing platform audit mechanism, or a new append-only control-plane audit store | Actor, timestamp, IDs, non-secret changes only |
| Retrieval vectors | Existing Qdrant `code-index` and `session-memory` collections | Not touched by model-profile operations |
| Local selected model | Existing model-generation Helm values / release state | No remote credential |

Before Phase 1, select the existing persistent store owned by the Code Search
API and add a schema migration there. Do not introduce SQLite, MongoDB, or a
second persistence subsystem if the API already has an established control-plane
store. If none exists, make that decision explicit in the implementation PR
before writing provider code.

## Delivery Phases

### Phase 0 - Settle the control-plane contract

1. Identify the Code Search API persistence mechanism, schema migration pattern,
   audit facility, and privileged administrator authorization boundary.
2. Identify the deployed Admin UI source repository and its existing design
   system. `surfbots-main/api/adminProxy` is a forwarding layer, not the UI.
3. Add a short architecture decision record covering the selected persistent
   store, Secret API/service account, authorization check, and local-rollout
   authority.
4. Define API response schemas that omit `secret_ref` when it would reveal an
   implementation detail and always omit tokens.

**Exit:** exact persistence, authorization, Admin-client ownership, and rollout
permissions are known before any public endpoint or UI is implemented.

### Phase 1 - Provider connections and secret handling

1. Add provider-connection domain models, validation, repository/service, and
   timestamp fields in `src/code-search-api`.
2. Implement privileged create, metadata edit, enable/disable, and delete-if-
   unused operations.
3. Add a server-side Secret adapter for token create/replace/read-by-reference.
   The API accepts a token only for create/replace and responds with
   `has_token: true`, never the token value.
4. Add structured non-secret audit events:
   `provider_connection_created`, `provider_connection_tested`, and
   `provider_token_replaced`.
5. Add log/error sanitization tests for bearer tokens and authorization headers.

**Exit:** an administrator can manage connection metadata and replace a token
without credentials entering profile records or response bodies.

### Phase 2 - Shared generation-provider abstraction

1. Refactor `GenerationClient` transport and response parsing into shared
   OpenAI-compatible HTTP transport in `src/code-search-api/app/services/`.
2. Define a stable `GenerationProvider` interface with `generate`,
   `list_models`, and `health_check` operations.
3. Implement `LocalOpenAICompatibleProvider` using the existing
   `GENERATION_ENDPOINT`, current timeout, and concurrency-one behavior.
4. Retain the current request/response parsing and source-free logging; do not
   duplicate it by role or provider.
5. Introduce request-scoped/effective concurrency limits so remote connections
   have bounded timeouts and explicit limits without weakening local
   serialization.

**Exit:** the current local-only behavior reaches the same llama.cpp service
through the provider interface with no model name introduced into MCP.

### Phase 3 - Profiles, active state, and role resolver

1. Add named profile and role-binding models plus migrations.
2. Create a `RoleResolver` that loads the active profile and returns the
   provider, connection, model, and effective limits for `generation`,
   `reviewer`, and `promptRefiner`.
3. Replace `RoleRunner`'s fixed `provider == "profile"` condition with resolver
   output and provider invocation.
4. Route `refine_task` to `promptRefiner`, `review_changes` to `reviewer`, and
   every normal generation consumer to `generation`.
5. Keep `src/mcp-server/app/api/mcp_server.py` schemas and handlers unchanged
   apart from normal error propagation.

**Exit:** local generation, reviewer, and prompt refiner resolve independently
while still reusing the one local service when configured locally.

### Phase 4 - OpenAI and compatible providers

1. Implement `OpenAICompatibleProvider` on the shared transport with configurable
   base URL and `Authorization: Bearer` from the Secret adapter.
2. Use this implementation for official OpenAI and compatible servers such as
   LM Studio, vLLM, llama.cpp, and company gateways. Provider type may supply a
   default URL but must permit overrides.
3. Add model discovery using authenticated `GET <base_url>/models`.
4. Surface discovery failures without clearing the currently configured model;
   permit manual model IDs when listing is unavailable or incomplete.
5. Add connection health and a minimal generation smoke request that includes no
   repository source content.

**Exit:** each role can independently target local or a remote compatible
provider, and no provider failure silently changes that selection.

### Phase 5 - Transactional activation

1. Add active-profile status: `active`, `pending`, and `activation_failed`, with
   a structured activation-result payload.
2. Validate profile schema, every referenced enabled connection, Secret
   availability, endpoint reachability, credentials, and selected model where
   discovery can verify it.
3. For remote-only changes, run a bounded provider smoke test and atomically
   update `active_profile_id` only after all validation succeeds.
4. For local-model changes, invoke a dedicated rollout service that layers the
   selected model-generation values, waits for readiness, checks `/v1/models`
   and a small generation request, then atomically activates the profile.
5. On any failure, retain the old active profile and return the structured
   failure. Do not restart Qdrant, indexer, MCP, embedding, or reranker.
6. Audit `model_profile_activated` and `model_profile_activation_failed` without
   secrets.

**Exit:** remote activation applies on the next request; local activation is a
controlled, observable generation-only rollout; failures leave the prior
runtime configuration operating.

### Phase 6 - Internal local control-plane API

1. Add Code Search API routes for connections, profiles, model discovery,
   connection testing, active status, activation, and secret-free profile
   export/import. Bind these routes only to the localhost tunnel contract in
   [runtime-ownership.md](runtime-ownership.md); do not publish them through
   ingress, MCP, Azure, or the normal service API.
2. Implement the short-lived CLI-to-control-plane credential and Code Search API
   verification rule determined from the local Kubernetes context. Reject
   missing, expired, or direct/untrusted callers before processing a request.
3. Return only safe models: `has_token`, connection test status, role bindings,
   activation status, and safe failures. Never return token values,
   authorization headers, or Secret content.
4. Keep provider testing, profile validation, activation, and the later rollout
   orchestration server-side. The CLI remains a thin interactive client.

**Exit:** a locally authenticated `surfbots-dev` process can reach the internal
control plane through an ephemeral localhost tunnel; every other caller is
rejected.

### Phase 7 - `surfbots-dev models` CLI

Implement the local developer/operator command family:

```text
surfbots-dev models status

surfbots-dev models connection add <name>
surfbots-dev models connection list
surfbots-dev models connection show <name>
surfbots-dev models connection test <name>
surfbots-dev models connection models <name>
surfbots-dev models connection update <name>
surfbots-dev models connection remove <name>

surfbots-dev models profile add <name>
surfbots-dev models profile list
surfbots-dev models profile show <name>
surfbots-dev models profile edit <name>
surfbots-dev models profile clone <source> <target>
surfbots-dev models profile remove <name>
surfbots-dev models profile export <name>
surfbots-dev models profile apply <file>

surfbots-dev models activate <name>
```

1. For every command, establish a localhost-only `kubectl port-forward` only for
   the command duration, call the Phase 6 internal route, and terminate the
   port-forward in a `finally` path.
2. `connection add` and token replacement use `getpass` hidden input. Tokens are
   never positional arguments, persisted CLI configuration, printed output, or
   log data. The internal API writes them directly to Kubernetes Secrets.
3. Connection test and model discovery invoke the server-side provider client.
   On discovery failure, preserve the configured model and permit a manual model
   ID for compatible endpoints.
4. Profile add/edit presents independent `generation`, `reviewer`, and
   `promptRefiner` assignments. Local assignments use
   `local / profile-generation`; remote assignments choose a connection and
   discovered or manually entered model ID.
5. Profile export/apply uses portable YAML containing role bindings, connection
   names, and provider types only; it never exposes Secret references. It must reject token,
   `Authorization`, `api_key`, and credential-value fields.
6. Status shows effective provider/model for every role plus `active`, `pending`,
   or `activation_failed`. It explains that remote-only activation is immediate
   and a local-model change may restart only `model-generation` in Phase 8.

**Exit:** developers can securely manage connections and profiles without the
Surfbots Admin UI, public APIs, MCP reconfiguration, or credential exposure.

### Phase 8 - Local-model rollout service

1. Extract the model-generation portion of `cluster.sh` into an idempotent,
   narrowly scoped operation callable by the activation service under explicit
   authorization.
2. Permit only known, validated local model selections; map them to vetted Helm
   overlays such as `values-local.yaml` and `values-local-quality.yaml`.
3. Capture rollout phase, deployment generation, readiness, and smoke-test
   outcomes in the activation result and audit record.
4. Ensure remote-only activation does not call Helm or roll any workload.
5. Re-establish or document port-forward behavior after local generation pod
   replacement; this is an operator limitation, not profile-activation success.

**Exit:** local changes restart only `model-generation`, wait for readiness, and
roll back logical active state when validation fails.

### Phase 9 - Migration and bootstrap

1. Migrate existing installations by creating `current-local` (or preserving
   `local-lightweight` if it is the chosen runtime ID) with all three roles set
   to `local` / `profile-generation`.
2. Set that profile active based on the existing
   `SURFBOTS_INFERENCE_PROFILE` selection without prompting for an OpenAI key.
3. Change `cluster.sh` terminology so local retrieval profile information remains
   separate from generation/supervision profiles.
4. Bootstrap validates the default local profile and successful local role
   resolution, but never requires remote configuration.

**Exit:** a local-only installation behaves as before, and new remote support is
entirely opt-in.

### Phase 10 - Tests, documentation, and release validation

Add focused tests to the Code Search API suites, existing supervision tests,
CLI/control-plane tests, Helm/rollout tests, and existing supervision tests.
Required coverage includes:

1. Each role resolves to local or OpenAI-compatible independently; generation
   and reviewer can use different providers.
2. Multiple local roles reuse exactly one generation service/model deployment.
3. `review_changes`, `refine_task`, and normal generation use reviewer,
   promptRefiner, and generation roles respectively.
4. Remote-only activation requires no Kubernetes rollout and is visible on the
   next request.
5. Local changes perform rollout/readiness/smoke validation; a failed rollout
   preserves the old active profile.
6. Invalid token, base URL, disabled connection, and discoverably unavailable
   model prevent activation.
7. Listing works; failed listing preserves configured model; manual model IDs
   work for compatible endpoints.
8. Tokens do not appear in API responses, profiles, logs, audit events, Helm
   values, browser storage, or test fixture snapshots.
9. MCP schemas remain unchanged across profile changes.
10. `code-index` and `session-memory` are neither rebuilt nor altered by any
    model-profile operation.
11. Local control-plane authentication, hidden token input, portable export/apply
   validation, active/pending/failure status, migration, bootstrap, and CLI
   status behavior are covered.
12. Existing MCP, supervision, indexer, and repository tests remain green.

Document role/provider/profile separation, Secret handling, local and
OpenAI-compatible connection setup, model discovery and manual IDs, hot remote
switching, local rollout behavior, and retrieval independence. State explicitly
that changing generation/reviewer/prompt-refiner models does not rebuild vector
indexes, while embedding changes are a separate retrieval-profile migration.

**Complete:** the Code Search API, CLI/bootstrap, indexer, and Helm regression
suites pass. Operator documentation covers hidden credential input, temporary
local control-plane access, connection discovery/manual IDs, profile
export/import, remote activation, local generation-only rollout, and retrieval
independence. No MCP schema or Qdrant collection change was required.

## Exact Files and Areas Expected to Change

| Area | Expected work |
|---|---|
| `src/code-search-api/app/services/generation_client.py` | Split shared transport from local-provider policy; preserve parsing/log redaction |
| `src/code-search-api/app/services/supervision/roles.py` | Replace fixed profile-service binding with role resolver invocation |
| `src/code-search-api/app/services/supervision/refiner.py` | Continue using the `promptRefiner` role only |
| `src/code-search-api/app/services/supervision/reviewer.py` | Continue using the `reviewer` role only |
| `src/code-search-api/app/api/` | Add localhost-tunneled internal provider/profile/activation routes with local control-plane authentication |
| `src/code-search-api/app/core/config.py` | Add non-secret provider/runtime configuration and Secret-adapter settings |
| `src/code-search-api/tests/` | Add provider, resolver, activation, security, and regression coverage |
| `src/mcp-server/app/api/mcp_server.py` | No provider/model schema changes; preserve thin forwarding and error translation |
| `helm/code-search-api/` | Add server-side Secret access/configuration and never serialize raw credentials into values |
| `helm/model-generation/` | Keep the stable service; add only validated local-model rollout support |
| `cluster.sh` | Extract a generation-only rollout path; do not couple it to retrieval services |
| `tooling/repo-bootstrap/surfbots-dev` | Add the interactive Models command family, temporary port-forward client, secure token prompt, and portable export/apply |
| `tooling/repo-bootstrap/test_*.py` | Extend bootstrap, local control-plane, CLI, verifier, and rollout-focused tests |
| `docs/INSTALL.md`, `README.md`, `docs/SCRIPTS.md` | Document local defaults, Secret workflow, profile behavior, and operational limits |

## Non-Goals for This Feature

- Retrieval-profile migration, embedding replacement, vector-dimension changes,
  or Qdrant collection rebuilds.
- MCP schema changes or client-specific provider configuration.
- Automatic hidden provider fallback.
- Starting a separate local model per logical role.
- Browser-side persistence or display of API tokens.
- Prompting for remote credentials during normal bootstrap.

## Completion Criteria

The feature is complete when a local developer/operator can use `surfbots-dev`
to create a secure OpenAI-compatible connection, discover or manually enter
models, independently configure and activate generation/reviewer/promptRefiner
roles, and inspect effective configuration. Remote-only profiles take effect
without a workload rollout; local model changes roll only the generation service
after validation. The active profile survives failures unchanged, MCP contracts
are unchanged, and `code-index` plus `session-memory` remain untouched.
