"""
surfbots-code-indexer
A semantic code indexing service for the surfbots-dev-platform.
"""

__version__ = "0.1.0"
__author__ = "Surfbots Team"