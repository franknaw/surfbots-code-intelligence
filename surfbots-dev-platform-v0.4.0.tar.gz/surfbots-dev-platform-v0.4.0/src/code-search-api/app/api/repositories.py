"""Repository endpoints."""
from fastapi import APIRouter, HTTPException
from typing import Optional
import logging

from ..services.search_service import search_service

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/api/v1/repositories")
async def list_repositories():
    """List repositories."""
    try:
        results = await search_service.indexer.list_repositories()
        return results
    except Exception as e:
        logger.error(f"List repositories failed: {e}")
        raise HTTPException(status_code=500, detail=f"List repositories failed: {str(e)}")


@router.get("/api/v1/repositories/{repository_id}")
async def get_repository(repository_id: str):
    """Get repository details."""
    try:
        results = await search_service.indexer.get_repository(repository_id)
        return results
    except Exception as e:
        logger.error(f"Get repository failed: {e}")
        raise HTTPException(status_code=500, detail=f"Get repository failed: {str(e)}")


@router.get("/api/v1/repositories/{repository_id}/status")
async def get_repository_status(repository_id: str):
    """Get repository indexing status."""
    try:
        results = await search_service.get_repository_status(repository_id)
        return results
    except Exception as e:
        logger.error(f"Get repository status failed: {e}")
        raise HTTPException(status_code=500, detail=f"Get repository status failed: {str(e)}")