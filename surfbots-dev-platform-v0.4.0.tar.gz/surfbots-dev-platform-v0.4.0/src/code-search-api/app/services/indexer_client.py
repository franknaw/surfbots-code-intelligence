"""Client for calling the code indexer API."""
import httpx
import logging
from typing import Optional, Dict, Any

from ..core.config import settings

logger = logging.getLogger(__name__)


class IndexerClient:
    """Client for the code indexer service."""
    
    def __init__(self, base_url: str = None):
        self.base_url = base_url or settings.indexer_url
        self.timeout = httpx.Timeout(30.0, connect=5.0, read=30.0)
        self._client: Optional[httpx.AsyncClient] = None
    
    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create async client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client
    
    async def search(
        self,
        query: str,
        repository_id: Optional[str] = None,
        language: Optional[str] = None,
        file_path: Optional[str] = None,
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """Search code using the indexer."""
        client = await self._get_client()
        
        try:
            response = await client.post(
                f"{self.base_url}/api/v1/search",
                json={
                    "query": query,
                    "repository_id": repository_id,
                    "language": language,
                    "file_path": file_path,
                    "limit": limit,
                    "offset": offset
                }
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Search request failed: {e}")
            return {"results": [], "total": 0, "error": str(e)}

    async def get_file_content(
        self,
        repository_id: str,
        path: str,
        start_line: Optional[int] = None,
        end_line: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Read a file, or a line range, from the managed snapshot."""
        client = await self._get_client()
        params: Dict[str, Any] = {"repository_id": repository_id, "path": path}
        if start_line is not None:
            params["start_line"] = start_line
        if end_line is not None:
            params["end_line"] = end_line

        try:
            response = await client.get(f"{self.base_url}/api/v1/files/content", params=params)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            detail = e.response.json().get("detail", str(e)) if e.response.content else str(e)
            logger.error(f"Get file content failed: {detail}")
            return {"error": detail}
        except httpx.HTTPError as e:
            logger.error(f"Get file content request failed: {e}")
            return {"error": str(e)}
    
    async def find_related(
        self,
        repository_id: str,
        file_path: str,
        limit: int = 5
    ) -> Dict[str, Any]:
        """Find related code snippets."""
        client = await self._get_client()
        
        try:
            response = await client.post(
                f"{self.base_url}/api/v1/search/related",
                json={
                    "repository_id": repository_id,
                    "file_path": file_path,
                    "limit": limit
                }
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Find related request failed: {e}")
            return {"results": [], "total": 0, "error": str(e)}
    
    async def search_symbols(
        self,
        query: str,
        repository_id: Optional[str] = None,
        language: Optional[str] = None,
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """Find symbol definitions."""
        client = await self._get_client()
        params: Dict[str, Any] = {"query": query, "repository_id": repository_id, "limit": limit}
        if language:
            params["language"] = language

        try:
            response = await client.get(f"{self.base_url}/api/v1/symbols/search", params=params)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Search symbols request failed: {e}")
            return {"symbols": [], "total": 0, "error": str(e)}

    async def symbol_references(
        self,
        symbol: str,
        repository_id: str,
        language: Optional[str] = None,
        limit: int = 50,
    ) -> Dict[str, Any]:
        """Find occurrences of a symbol."""
        client = await self._get_client()
        params: Dict[str, Any] = {"symbol": symbol, "repository_id": repository_id, "limit": limit}
        if language:
            params["language"] = language

        try:
            response = await client.get(f"{self.base_url}/api/v1/symbols/references", params=params)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Symbol references request failed: {e}")
            return {"references": [], "total": 0, "error": str(e)}
    
    async def list_files(
        self,
        repository_id: Optional[str] = None,
        directory: Optional[str] = None,
        limit: int = 100,
        offset: int = 0
    ) -> Dict[str, Any]:
        """List files in a repository."""
        client = await self._get_client()
        
        try:
            response = await client.get(
                f"{self.base_url}/api/v1/files",
                params={
                    "repository_id": repository_id,
                    "directory": directory,
                    "limit": limit,
                    "offset": offset
                }
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"List files request failed: {e}")
            return {"files": [], "total": 0, "error": str(e)}
    
    async def list_repositories(self) -> Dict[str, Any]:
        """List repositories known to the indexer."""
        client = await self._get_client()

        try:
            response = await client.get(f"{self.base_url}/api/v1/repositories")
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"List repositories request failed: {e}")
            return {"repositories": [], "error": str(e)}

    async def get_repository_status(
        self,
        repository_id: str
    ) -> Dict[str, Any]:
        """Get repository indexing status."""
        client = await self._get_client()
        
        try:
            response = await client.get(
                f"{self.base_url}/api/v1/repositories/{repository_id}"
            )
            response.raise_for_status()
            repo = response.json()
            return {
                "repository_id": repo.get("repository_id"),
                "repository_name": repo.get("name"),
                "status": repo.get("status", "unknown"),
                "indexed_at": repo.get("last_indexed_at"),
                "files_indexed": repo.get("file_count", 0),
                "chunks_indexed": repo.get("chunk_count", 0)
            }
        except httpx.HTTPError as e:
            logger.error(f"Get repository status request failed: {e}")
            return {"error": str(e)}

    async def create_session_memory(self, repository_id: str, checkpoint: Dict[str, Any]) -> Dict[str, Any]:
        """Create a repository-scoped Development Memory checkpoint."""
        client = await self._get_client()
        try:
            response = await client.post(
                f"{self.base_url}/api/v1/repositories/{repository_id}/memory",
                json=checkpoint,
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Create development memory request failed: {e}")
            return {"error": str(e)}

    async def get_recent_session_memory(self, repository_id: str, limit: int = 5) -> Dict[str, Any]:
        """Get the most recent Development Memory checkpoints for a repository."""
        client = await self._get_client()
        try:
            response = await client.get(
                f"{self.base_url}/api/v1/repositories/{repository_id}/memory/recent",
                params={"limit": limit},
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Get recent development memory request failed: {e}")
            return {"error": str(e)}

    async def search_session_memory(self, repository_id: str, query: str, **filters: Any) -> Dict[str, Any]:
        """Semantically retrieve Development Memory within one repository."""
        client = await self._get_client()
        try:
            response = await client.post(
                f"{self.base_url}/api/v1/repositories/{repository_id}/memory/search",
                params={"query": query, **{key: value for key, value in filters.items() if value is not None}},
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Search development memory request failed: {e}")
            return {"error": str(e)}

    async def get_session_memory_context(
        self,
        repository_id: str,
        limit: int = 10,
        created_after: str | None = None,
    ) -> Dict[str, Any]:
        """Get bounded agent-ready Development Memory context."""
        client = await self._get_client()
        try:
            response = await client.get(
                f"{self.base_url}/api/v1/repositories/{repository_id}/memory/context",
                params={"limit": limit, **({"created_after": created_after} if created_after else {})},
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Get development memory context request failed: {e}")
            return {"error": str(e)}

    async def delete_session_memory(self, repository_id: str, memory_id: str) -> Dict[str, Any]:
        """Delete one repository-scoped Development Memory record."""
        client = await self._get_client()
        try:
            response = await client.delete(
                f"{self.base_url}/api/v1/repositories/{repository_id}/memory/{memory_id}"
            )
            response.raise_for_status()
            return {}
        except httpx.HTTPError as e:
            logger.error(f"Delete development memory request failed: {e}")
            return {"error": str(e)}
    
    async def get_file(self, file_id: str) -> Dict[str, Any]:
        """Get file content by ID."""
        client = await self._get_client()
        
        try:
            response = await client.get(
                f"{self.base_url}/api/v1/files/{file_id}"
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Get file request failed: {e}")
            return {"error": str(e)}
    
    async def get_file_range(
        self,
        file_id: str,
        start_line: int,
        end_line: Optional[int] = None
    ) -> Dict[str, Any]:
        """Get a specific range of lines from a file."""
        client = await self._get_client()
        
        try:
            params = {"start_line": start_line}
            if end_line:
                params["end_line"] = end_line
            
            response = await client.get(
                f"{self.base_url}/api/v1/files/range",
                params=params
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Get file range request failed: {e}")
            return {"error": str(e)}
    
    async def get_file_outline(self, file_id: str) -> Dict[str, Any]:
        """Get file structure outline (symbols)."""
        client = await self._get_client()
        
        try:
            response = await client.get(
                f"{self.base_url}/api/v1/files/{file_id}/outline"
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Get file outline request failed: {e}")
            return {"error": str(e)}
    
    async def get_symbol_references(
        self,
        symbol_id: str,
        limit: int = 10
    ) -> Dict[str, Any]:
        """Find references to a symbol."""
        client = await self._get_client()
        
        try:
            response = await client.get(
                f"{self.base_url}/api/v1/symbols/{symbol_id}/references",
                params={"limit": limit}
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Get symbol references request failed: {e}")
            return {"error": str(e)}
    
    async def get_symbol_definition(self, symbol_id: str) -> Dict[str, Any]:
        """Get symbol definition."""
        client = await self._get_client()
        
        try:
            response = await client.get(
                f"{self.base_url}/api/v1/symbols/{symbol_id}/definition"
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as e:
            logger.error(f"Get symbol definition request failed: {e}")
            return {"error": str(e)}
    
    async def close(self):
        """Close the client."""
        if self._client:
            await self._client.aclose()
            self._client = None


# Global client instance
indexer_client = IndexerClient()