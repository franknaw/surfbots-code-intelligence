"""Repository parsing for local and Git repositories."""
import os
import re
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class RepositoryParser:
    """Parser for source code repositories."""

    def __init__(
        self,
        include_patterns: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None
    ):
        self.include_patterns = include_patterns or [
            "**/*.py",
            "**/*.ts",
            "**/*.tsx",
            "**/*.js",
            "**/*.jsx",
            "**/*.yaml",
            "**/*.yml",
            "**/*.json",
            "**/*.md",
            "**/*.txt"
        ]
        self.exclude_patterns = exclude_patterns or [
            ".git/**",
            "node_modules/**",
            "dist/**",
            "build/**",
            ".venv/**",
            "__pycache__/**"
        ]

    def matches_patterns(
        self,
        path: str,
        patterns: List[str],
        base_dir: Optional[str] = None
    ) -> bool:
        """Check if a path matches any of the given patterns."""
        path = Path(path)

        for pattern in patterns:
            # Convert glob pattern to regex
            regex_pattern = pattern.replace("**/*", ".*").replace("*", "[^/]*")
            if re.match(regex_pattern, str(path)):
                return True
            # Also check with base directory
            if base_dir:
                full_path = Path(base_dir) / path
                if re.match(regex_pattern, str(full_path)):
                    return True

        return False

    def is_excluded(self, path: str, base_dir: Optional[str] = None) -> bool:
        """Check if a path should be excluded."""
        return self.matches_patterns(path, self.exclude_patterns, base_dir)

    def is_included(self, path: str, base_dir: Optional[str] = None) -> bool:
        """Check if a path should be included."""
        return self.matches_patterns(path, self.include_patterns, base_dir)

    def get_supported_files(
        self,
        repo_path: str,
        base_dir: Optional[str] = None
    ) -> List[Path]:
        """Get all supported files in a repository."""
        supported_files = []

        for root, dirs, files in os.walk(repo_path):
            # Filter out excluded directories
            dirs[:] = [
                d for d in dirs
                if not self.is_excluded(os.path.join(root, d), repo_path)
            ]

            for file in files:
                file_path = Path(root) / file
                rel_path = file_path.relative_to(repo_path)

                # Check if file should be included
                if (self.is_included(str(rel_path), repo_path) and
                    not self.is_excluded(str(rel_path), repo_path)):
                    supported_files.append(file_path)

        return supported_files

    def parse_file_content(self, file_path: Path) -> Optional[str]:
        """Parse and return file content."""
        try:
            # Skip binary files
            if self._is_binary_file(file_path):
                logger.warning(f"Skipping binary file: {file_path}")
                return None

            with open(file_path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            logger.error(f"Failed to read file {file_path}: {e}")
            return None

    def _is_binary_file(self, file_path: Path) -> bool:
        """Check if a file is binary."""
        binary_extensions = {".pyc", ".pyo", ".so", ".dll", ".exe"}
        return file_path.suffix.lower() in binary_extensions

    def get_file_info(self, file_path: Path) -> Dict:
        """Get metadata about a file."""
        stat = file_path.stat()
        return {
            "path": str(file_path),
            "relative_path": str(file_path),
            "size": stat.st_size,
            "modified_at": datetime.fromtimestamp(stat.st_mtime).isoformat(),
            "extension": file_path.suffix,
            "language": self.get_language(file_path),
            "line_count": self._count_lines(file_path)
        }

    LANGUAGE_BY_EXTENSION = {
        ".py": "python",
        ".ts": "typescript",
        ".tsx": "typescript",
        ".js": "javascript",
        ".jsx": "javascript",
        ".sh": "shell",
        ".bash": "shell",
        ".zsh": "shell",
        ".yaml": "yaml",
        ".yml": "yaml",
        ".json": "json",
        ".md": "markdown",
        ".txt": "text",
    }

    def get_language(self, file_path: Path) -> str:
        """Map a file to a language identifier for search payloads."""
        return self.LANGUAGE_BY_EXTENSION.get(file_path.suffix.lower(), "unknown")

    def _count_lines(self, file_path: Path) -> int:
        """Count lines in a file."""
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                return sum(1 for _ in f)
        except Exception:
            return 0