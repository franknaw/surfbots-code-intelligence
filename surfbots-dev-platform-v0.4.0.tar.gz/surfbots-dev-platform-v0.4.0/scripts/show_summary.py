#!/usr/bin/env python3
"""Display a live operational summary for surfbots-dev-platform."""

import json
import os
import re
import sqlite3
import subprocess
import urllib.error
import urllib.request
from pathlib import Path

DATA_HOME = Path(os.environ.get(
    "SURFBOTS_DATA_HOME",
    Path.home() / ".local" / "share" / "surfbots-dev-platform",
))
REGISTRY_DB = DATA_HOME / "data" / "repositories.db"
NAMESPACE = "surfbots-dev-platform"
FORWARDS = {
    "Code Indexer": ("code-indexer", 8000),
    "Code Search API": ("code-search-api", 8000),
    "MCP Server": ("mcp", 8003),
    "Qdrant": ("qdrant", 6333),
    "Embedding": ("model-embedding", 8001),
    "Generation": ("model-generation", 8000),
    "Reranker": ("model-reranker", 8002),
}


def heading(title: str) -> None:
    print(f"\n{title}")
    print("-" * 64)


def request_json(url: str, *, method: str = "GET", payload=None) -> dict:
    data = json.dumps(payload).encode() if payload is not None else None
    request = urllib.request.Request(url, data=data, method=method)
    request.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(request, timeout=5) as response:
        return json.loads(response.read().decode())


def port_from_pid_file(label: str, default: int) -> tuple[int, bool]:
    """Return a tracked local port and whether its kubectl process is alive."""
    pid_file = Path(f"/tmp/surfbots-{label}.pid")
    if not pid_file.exists():
        return default, False

    text = pid_file.read_text()
    pid_match = re.search(r"PID: (\d+)", text)
    port_match = re.search(r"Port: (\d+)", text)
    if not pid_match or not port_match:
        return default, False

    pid = int(pid_match.group(1))
    try:
        os.kill(pid, 0)
    except OSError:
        return int(port_match.group(1)), False
    return int(port_match.group(1)), True


def pod_memory_usage() -> dict[str, str]:
    """Return current pod memory usage when the Kubernetes metrics API is available."""
    try:
        result = subprocess.run(
            ["kubectl", "top", "pods", "-n", NAMESPACE, "--no-headers"],
            capture_output=True,
            text=True,
            timeout=10,
            check=True,
        )
    except (OSError, subprocess.SubprocessError):
        return {}

    memory_by_pod = {}
    for line in result.stdout.splitlines():
        columns = line.split()
        if len(columns) >= 3:
            memory_by_pod[columns[0]] = columns[2]
    return memory_by_pod


def print_platform_status() -> None:
    heading("Platform Health")
    try:
        result = subprocess.run(
            ["kubectl", "get", "pods", "-n", NAMESPACE, "-o", "json"],
            capture_output=True,
            text=True,
            timeout=10,
            check=True,
        )
        pods = json.loads(result.stdout).get("items", [])
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError) as error:
        print(f"  Kubernetes status unavailable: {error}")
        return

    ready_count = 0
    memory_by_pod = pod_memory_usage()
    for pod in sorted(pods, key=lambda item: item["metadata"]["name"]):
        statuses = pod.get("status", {}).get("containerStatuses", [])
        ready = bool(statuses) and all(item.get("ready") for item in statuses)
        restarts = sum(item.get("restartCount", 0) for item in statuses)
        phase = pod.get("status", {}).get("phase", "Unknown")
        state = "ready" if ready else phase.lower()
        memory = memory_by_pod.get(pod["metadata"]["name"], "unavailable")
        print(f"  {pod['metadata']['name']}: {state}, restarts {restarts}, memory {memory}")
        ready_count += ready
    print(f"  Workloads ready: {ready_count}/{len(pods)}")


def print_port_forwards() -> dict[str, int]:
    heading("Local Port-Forwards")
    ports = {}
    for name, (label, preferred) in FORWARDS.items():
        port, running = port_from_pid_file(label, preferred)
        ports[label] = port
        state = "running" if running else "not running"
        print(f"  {name:<17} http://localhost:{port:<5} {state}")
    return ports


def print_qdrant_summary(qdrant_port: int) -> None:
    heading("Qdrant Index")
    try:
        collections = request_json(
            f"http://localhost:{qdrant_port}/collections"
        ).get("result", {}).get("collections", [])
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError) as error:
        print(f"  Qdrant is unavailable at localhost:{qdrant_port}: {error}")
        return

    for collection in collections:
        name = collection.get("name", "unknown")
        try:
            detail = request_json(f"http://localhost:{qdrant_port}/collections/{name}")
            config = detail.get("result", {}).get("config", {}).get("params", {})
            vectors = config.get("vectors", {})
            vector_size = vectors.get("size", "unknown") if isinstance(vectors, dict) else "named"
            distance = vectors.get("distance", "unknown") if isinstance(vectors, dict) else "named"
            count = request_json(
                f"http://localhost:{qdrant_port}/collections/{name}/points/count",
                method="POST",
                payload={"exact": True},
            ).get("result", {}).get("count", 0)
            print(f"  {name}: {count} points, {vector_size} dimensions, {distance}")
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError) as error:
            print(f"  {name}: details unavailable ({error})")
    if not collections:
        print("  No collections found")


def count_collection_points(qdrant_port: int, collection: str, filters: list[dict] | None = None) -> int | None:
    try:
        data = request_json(
            f"http://localhost:{qdrant_port}/collections/{collection}/points/count",
            method="POST",
            payload={"exact": True, "filter": {"must": filters or []}},
        )
        return data.get("result", {}).get("count", 0)
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError):
        return None


def print_development_memory_summary(qdrant_port: int) -> None:
    heading("Qdrant Session Index")
    total = count_collection_points(qdrant_port, "session-memory")
    if total is None:
        print("  session-memory collection unavailable")
        return
    print("  Collection: session-memory")
    durable = count_collection_points(qdrant_port, "session-memory", [
        {"key": "retention_class", "match": {"value": "durable"}}
    ])
    transient = count_collection_points(qdrant_port, "session-memory", [
        {"key": "retention_class", "match": {"value": "transient"}}
    ])
    print(f"  Records: {total}")
    print(f"  Durable: {durable if durable is not None else 'unavailable'}")
    print(f"  Transient: {transient if transient is not None else 'unavailable'}")


def table_exists(cursor: sqlite3.Cursor, name: str) -> bool:
    return bool(cursor.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (name,)
    ).fetchone())


def count_repository_points(qdrant_port: int, repository_id: str) -> int | None:
    try:
        data = request_json(
            f"http://localhost:{qdrant_port}/collections/code-index/points/count",
            method="POST",
            payload={
                "exact": True,
                "filter": {
                    "must": [{"key": "repository_id", "match": {"value": repository_id}}]
                },
            },
        )
        return data.get("result", {}).get("count", 0)
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError):
        return None


def print_repository_summary(qdrant_port: int) -> None:
    heading("Repository Registry")
    if not REGISTRY_DB.exists():
        print(f"  Registry not found: {REGISTRY_DB}")
        return

    connection = None
    try:
        connection = sqlite3.connect(REGISTRY_DB)
        connection.row_factory = sqlite3.Row
        cursor = connection.cursor()
        if not table_exists(cursor, "repositories"):
            print(f"  Registry has no repositories table: {REGISTRY_DB}")
            return

        repositories = cursor.execute(
            "SELECT repository_id, name, source, branch, status, file_count, "
            "chunk_count, last_indexed_at, last_indexed_commit "
            "FROM repositories ORDER BY name"
        ).fetchall()
        print(f"  Registered repositories: {len(repositories)}")
        for repo in repositories:
            points = count_repository_points(qdrant_port, repo["repository_id"])
            source = repo["source"] or "unknown"
            commit = repo["last_indexed_commit"] or "unknown"
            indexed_at = repo["last_indexed_at"] or "never"
            point_text = "unavailable" if points is None else str(points)
            snapshot = DATA_HOME / "repos" / repo["repository_id"]
            snapshot_state = "present" if snapshot.is_dir() else "missing"
            print(f"\n  {repo['name']} ({repo['repository_id']})")
            print(f"    Status: {repo['status']} | Snapshot: {snapshot_state} | Points: {point_text}")
            print(f"    Files: {repo['file_count']} | Chunks: {repo['chunk_count']} | Branch: {repo['branch']}")
            print(f"    Last indexed: {indexed_at} | Commit: {commit[:12]}")
            print(f"    Canonical source: {source}")

        if table_exists(cursor, "index_jobs"):
            pending = cursor.execute(
                "SELECT COUNT(*) FROM index_jobs WHERE status IN ('pending', 'running')"
            ).fetchone()[0]
            print(f"\n  Active index jobs: {pending}")
    except sqlite3.Error as error:
        print(f"  Could not read registry: {error}")
    finally:
        if connection is not None:
            connection.close()


def print_search_request_summary(search_port: int) -> None:
    heading("Search Activity")
    try:
        metrics = request_json(f"http://localhost:{search_port}/metrics")
        search_requests = metrics.get("search_requests", {})
        print(f"  Total search requests: {search_requests.get('total', 0)}")
        by_kind = search_requests.get("by_kind", {})
        if by_kind:
            print("  By endpoint: " + ", ".join(
                f"{kind} {count}" for kind, count in by_kind.items()
            ))
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError) as error:
        print(f"  Search metrics unavailable at localhost:{search_port}: {error}")


def print_storage_summary() -> None:
    heading("Local Storage")
    repositories_dir = DATA_HOME / "repos"
    snapshot_count = sum(1 for path in repositories_dir.iterdir() if path.is_dir()) if repositories_dir.exists() else 0
    registry_size = REGISTRY_DB.stat().st_size if REGISTRY_DB.exists() else 0
    platform_size = sum(path.stat().st_size for path in DATA_HOME.rglob("*") if path.is_file())
    models_dir = DATA_HOME / "models"
    models_size = sum(path.stat().st_size for path in models_dir.rglob("*") if path.is_file()) if models_dir.exists() else 0
    print(f"  Data root: {DATA_HOME}")
    print(f"  Managed snapshots: {snapshot_count}")
    print(f"  Repository registry: {registry_size / 1024:.1f} KiB")
    print(f"  Cached model weights: {models_size / (1024 * 1024 * 1024):.1f} GiB")
    print(f"  Total platform data: {platform_size / (1024 * 1024 * 1024):.1f} GiB")


def main() -> None:
    print("\n" + "=" * 64)
    print("surfbots-dev-platform Operational Summary")
    print("=" * 64)
    print_platform_status()
    ports = print_port_forwards()
    print_qdrant_summary(ports["qdrant"])
    print_development_memory_summary(ports["qdrant"])
    print_repository_summary(ports["qdrant"])
    print_search_request_summary(ports["code-search-api"])
    print_storage_summary()
    print()


if __name__ == "__main__":
    main()
