"""Locate symbol definitions and references inside a managed snapshot.

Indexing stores prose-like chunks and never extracts symbols, so symbol queries
are answered by scanning snapshot files directly rather than the vector index.
"""
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterator, Optional
import re

MAX_FILE_BYTES = 1_000_000
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build", ".mypy_cache", ".pytest_cache"}

# Definition forms per extension; NAME is substituted with the escaped symbol.
DEFINITION_PATTERNS: dict[str, tuple[str, ...]] = {
    ".py": (r"^\s*(?:async\s+)?def\s+NAME\b", r"^\s*class\s+NAME\b"),
    ".js": (r"\bfunction\s+NAME\b", r"\bclass\s+NAME\b", r"\b(?:const|let|var)\s+NAME\s*="),
    ".jsx": (r"\bfunction\s+NAME\b", r"\bclass\s+NAME\b", r"\b(?:const|let|var)\s+NAME\s*="),
    ".ts": (r"\bfunction\s+NAME\b", r"\bclass\s+NAME\b", r"\b(?:const|let|var)\s+NAME\s*=", r"\binterface\s+NAME\b", r"\btype\s+NAME\b"),
    ".tsx": (r"\bfunction\s+NAME\b", r"\bclass\s+NAME\b", r"\b(?:const|let|var)\s+NAME\s*=", r"\binterface\s+NAME\b", r"\btype\s+NAME\b"),
    ".go": (r"\bfunc\s+(?:\([^)]*\)\s*)?NAME\b", r"\btype\s+NAME\b"),
    ".rs": (r"\bfn\s+NAME\b", r"\b(?:struct|enum|trait|impl)\s+NAME\b"),
    ".java": (r"\bclass\s+NAME\b", r"\binterface\s+NAME\b", r"\b(?:public|private|protected|static|final|\s)*[\w<>\[\]]+\s+NAME\s*\("),
    ".sh": (r"^\s*(?:function\s+)?NAME\s*\(\s*\)", r"^\s*function\s+NAME\b"),
    ".bash": (r"^\s*(?:function\s+)?NAME\s*\(\s*\)", r"^\s*function\s+NAME\b"),
}

GENERIC_PATTERNS = (r"\b(?:class|def|func|fn|function|struct|interface|type|trait|enum)\s+NAME\b",)


@dataclass
class Hit:
    file_path: str
    line: int
    text: str
    language: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _iter_files(root: Path) -> Iterator[Path]:
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if SKIP_DIRS.intersection(path.parts):
            continue
        try:
            if path.stat().st_size > MAX_FILE_BYTES:
                continue
        except OSError:
            continue
        yield path


def _read_lines(path: Path) -> Optional[list[str]]:
    try:
        return path.read_text(encoding="utf-8").splitlines()
    except (UnicodeDecodeError, OSError):
        return None


def _compile(patterns: tuple[str, ...], symbol: str) -> list[re.Pattern]:
    escaped = re.escape(symbol)
    return [re.compile(p.replace("NAME", escaped)) for p in patterns]


def find_definitions(root: Path, symbol: str, limit: int = 20, language: Optional[str] = None) -> list[dict[str, Any]]:
    """Return lines that declare the symbol, scanning language-appropriate forms."""
    hits: list[Hit] = []
    for path in _iter_files(root):
        if language and path.suffix.lstrip(".") != language.lstrip("."):
            continue
        patterns = DEFINITION_PATTERNS.get(path.suffix, GENERIC_PATTERNS)
        matchers = _compile(patterns, symbol)
        lines = _read_lines(path)
        if lines is None:
            continue
        for number, line in enumerate(lines, start=1):
            if any(m.search(line) for m in matchers):
                hits.append(Hit(str(path.relative_to(root)), number, line.strip()[:300], path.suffix.lstrip(".")))
                if len(hits) >= limit:
                    return [h.as_dict() for h in hits]
    return [h.as_dict() for h in hits]


def find_references(root: Path, symbol: str, limit: int = 50, language: Optional[str] = None) -> list[dict[str, Any]]:
    """Return whole-word occurrences of the symbol across the snapshot."""
    matcher = re.compile(rf"\b{re.escape(symbol)}\b")
    hits: list[Hit] = []
    for path in _iter_files(root):
        if language and path.suffix.lstrip(".") != language.lstrip("."):
            continue
        lines = _read_lines(path)
        if lines is None:
            continue
        for number, line in enumerate(lines, start=1):
            if matcher.search(line):
                hits.append(Hit(str(path.relative_to(root)), number, line.strip()[:300], path.suffix.lstrip(".")))
                if len(hits) >= limit:
                    return [h.as_dict() for h in hits]
    return [h.as_dict() for h in hits]
