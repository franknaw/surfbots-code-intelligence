"""Main FastAPI application for the code indexer."""
import logging
import time
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api import (
    health_router,
    repositories_router,
    indexes_router,
    search_router,
    symbols_router,
    files_router,
    files_incremental_router,
    memory_router,
)
from .core.config import settings
from .core.database import get_qdrant_client, ensure_code_index_collection
from .services.session_memory import ensure_session_memory_collection


logger = logging.getLogger(__name__)

# Configure logging
logging.basicConfig(
    level=logging.INFO if not settings.debug else logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

app = FastAPI(
    title="Surfbots Code Indexer API",
    description="Semantic code indexing service for the surfbots-dev-platform",
    version="0.1.0",
    docs_url="/docs" if settings.debug else None,
    redoc_url="/redoc" if settings.debug else None
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    """Initialize resources on startup."""
    logger.info(f"Qdrant URL: {settings.qdrant_url}")
    logger.info("Initializing Code Indexer...")
    
    # Retry configuration
    max_retries = 5
    initial_delay = 2
    max_delay = 30
    
    for attempt in range(max_retries):
        try:
            # Verify Qdrant connection
            client = get_qdrant_client()
            collections = client.get_collections()
            logger.info(f"Connected to Qdrant. Collections: {collections}")
            
            # Clean up obsolete repositories collection from Qdrant
            from .core.repositories import _cleanup_qdrant_repository_collection
            _cleanup_qdrant_repository_collection()
            # Seed required platform collections on every startup.
            # Both operations are idempotent for correctly configured collections.
            ensure_code_index_collection()
            ensure_session_memory_collection()

            logger.info(
                "Required Qdrant collections ready: code-index, session-memory"
            )
            break
        except Exception as e:
            if attempt < max_retries - 1:
                delay = min(initial_delay * (2 ** attempt), max_delay)
                logger.warning(f"Failed to connect to Qdrant (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {delay}s...")
                time.sleep(delay)
            else:
                logger.error(f"Failed to connect to Qdrant after {max_retries} attempts: {e}")
                raise


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup resources on shutdown."""
    logger.info("Shutting down Code Indexer...")


# Include routers
app.include_router(health_router, prefix="", tags=["health"])
app.include_router(repositories_router, prefix="", tags=["repositories"])
app.include_router(indexes_router, prefix="", tags=["indexes"])
app.include_router(search_router, prefix="", tags=["search"])
app.include_router(symbols_router, prefix="", tags=["symbols"])
app.include_router(files_router, prefix="", tags=["files"])
app.include_router(files_incremental_router, prefix="", tags=["files"])
app.include_router(memory_router, prefix="", tags=["development-memory"])


@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "service": "code-indexer",
        "version": "0.1.0",
        "status": "running",
        "docs": "/docs" if settings.debug else "disabled"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug
    )
