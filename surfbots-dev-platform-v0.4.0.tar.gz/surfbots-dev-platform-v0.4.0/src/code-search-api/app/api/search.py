"""Search endpoints."""
from fastapi import APIRouter, HTTPException, Query
from typing import Optional
import logging

from ..core.config import settings
from ..services.search_service import search_service
from ..services.search_metrics import record_search_request
from ..models.service_models import SearchQuery, SearchResponse

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/api/v1/search", response_model=SearchResponse)
async def search_code(
    query: SearchQuery
):
    """Search code using semantic search with caching."""
    record_search_request("semantic")
    try:
        results = await search_service.search(
            query=query.query,
            repository_id=query.repository_id,
            repository_name=query.repository_name,
            language=query.language,
            file_path=query.file_path,
            limit=query.limit,
            offset=query.offset,
            include_related_memory=query.include_related_memory,
        )
        return SearchResponse(**results)
    except Exception as e:
        logger.error(f"Search failed: {e}")
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")


@router.get("/api/v1/search/related")
async def find_related(
    repository_id: str = Query(...),
    file_path: str = Query(...),
    limit: int = Query(default=5, le=20)
):
    """Find related code snippets."""
    record_search_request("related")
    try:
        results = await search_service.indexer.find_related(
            repository_id=repository_id,
            file_path=file_path,
            limit=limit
        )
        return results
    except Exception as e:
        logger.error(f"Find related failed: {e}")
        raise HTTPException(status_code=500, detail=f"Find related failed: {str(e)}")


@router.get("/api/v1/symbols/search")
async def search_symbols(
    query: str = Query(...),
    repository_id: str = Query(...),
    language: Optional[str] = None,
    limit: int = Query(default=20, le=100),
    offset: int = Query(default=0)
):
    """Find where a symbol is defined."""
    record_search_request("symbol")
    try:
        resolved = await search_service.resolve_repository_id(repository_id) or repository_id
        return await search_service.indexer.search_symbols(
            query=query,
            repository_id=resolved,
            language=language,
            limit=limit,
            offset=offset
        )
    except Exception as e:
        logger.error(f"Symbol search failed: {e}")
        raise HTTPException(status_code=500, detail=f"Symbol search failed: {str(e)}")


@router.get("/api/v1/symbols/references")
async def symbol_references(
    symbol: str = Query(...),
    repository_id: str = Query(...),
    language: Optional[str] = None,
    limit: int = Query(default=50, le=200),
):
    """Find occurrences of a symbol."""
    record_search_request("symbol_references")
    try:
        resolved = await search_service.resolve_repository_id(repository_id) or repository_id
        return await search_service.indexer.symbol_references(
            symbol=symbol,
            repository_id=resolved,
            language=language,
            limit=limit,
        )
    except Exception as e:
        logger.error(f"Symbol references failed: {e}")
        raise HTTPException(status_code=500, detail=f"Symbol references failed: {str(e)}")


@router.get("/api/v1/symbols/{symbol_id}/references")
async def get_symbol_references(
    symbol_id: str,
    limit: int = Query(default=10, le=100)
):
    """Find references to a symbol."""
    try:
        results = await search_service.indexer.get_symbol_references(
            symbol_id=symbol_id,
            limit=limit
        )
        return results
    except Exception as e:
        logger.error(f"Get symbol references failed: {e}")
        raise HTTPException(status_code=500, detail=f"Get symbol references failed: {str(e)}")


@router.get("/api/v1/symbols/{symbol_id}/definition")
async def get_symbol_definition(
    symbol_id: str
):
    """Get symbol definition."""
    try:
        results = await search_service.indexer.get_symbol_definition(
            symbol_id=symbol_id
        )
        return results
    except Exception as e:
        logger.error(f"Get symbol definition failed: {e}")
        raise HTTPException(status_code=500, detail=f"Get symbol definition failed: {str(e)}")