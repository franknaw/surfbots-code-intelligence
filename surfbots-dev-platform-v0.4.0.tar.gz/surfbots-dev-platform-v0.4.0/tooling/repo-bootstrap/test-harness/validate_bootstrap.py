#!/usr/bin/env python3
"""Validation harness for Surfbots Dev Platform public bootstrap/release-artifact installation."""

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Required bundled assets
REQUIRED_CLINE_RULES = [
    ".clinerules/surfbots-code-search.md",
    ".clinerules/surfbots-development-context.md",
    ".clinerules/surfbots-development-supervision.md",
]
REQUIRED_CLINE_SKILLS = [".clinerules/skills/surfbots-development-context/SKILL.md"]
REQUIRED_GITHUB_INSTRUCTIONS = [".github/instructions/surfbots-development-context.instructions.md"]
REQUIRED_GITHUB_SKILLS = [
    ".github/skills/surfbots-development-context/SKILL.md",
    ".github/skills/surfbots-development-context/scripts/build_context.py",
]
ALL_REQUIRED_ASSETS = REQUIRED_CLINE_RULES + REQUIRED_CLINE_SKILLS + REQUIRED_GITHUB_INSTRUCTIONS + REQUIRED_GITHUB_SKILLS

def color(text, code):
    if os.environ.get("NO_COLOR") or not sys.stdout.isatty():
        return text
    return f"\033[{code}m{text}\033[0m"

def green(text): return color(text, "1;32")
def red(text): return color(text, "1;31")
def yellow(text): return color(text, "1;33")

def info(msg): print(f"[INFO] {msg}")
def success(msg): print(f"{green(chr(0x2713))} {msg}")
def failure(msg): print(f"{red(chr(0x2717))} {msg}")
def warning(msg): print(f"{yellow(chr(0x26a0))} {msg}")

def run_command(cmd, cwd=None, env=None, timeout=60, capture_output=True):
    result = subprocess.run(cmd, cwd=cwd, env=env, timeout=timeout, capture_output=capture_output, text=True)
    return result.returncode, result.stdout, result.stderr

def compute_file_hash(filepath):
    sha256_hash = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            sha256_hash.update(chunk)
    return sha256_hash.hexdigest()

class ValidationHarness:
    def __init__(self, release_url=None, release_file=None, install_root=None, platform_services_available=True):
        self.release_url = release_url
        self.release_file = release_file
        self.install_root = install_root
        self.platform_services_available = platform_services_available
        self._temp_dirs = []
        self._cleanup_funcs = []
        self.installation_dir = None
        self.launcher_path = None
        self.runtime_dir = None
        self.repository_path = None
        self.repository_id = None
        self.bundled_asset_hashes = {}
        self.installed_asset_hashes = {}
        self.results = {}
        self.failures = []

    def create_temp_dir(self, prefix):
        path = tempfile.mkdtemp(prefix=prefix)
        self._temp_dirs.append(path)
        return path

    def track_cleanup(self, name, path):
        self._cleanup_funcs.append((name, path))

    def is_tarball_url(self, url):
        """Check if URL points to a tar.gz release artifact."""
        return '.tar.gz' in url and 'surfbots-dev-platform-' in url
    
    def extract_version_from_url(self, url):
        """Extract version from tarball URL like surfbots-dev-platform-v0.3.0.tar.gz."""
        import re
        match = re.search(r'surfbots-dev-platform-v([0-9]+\.[0-9]+\.[0-9]+)\.tar\.gz', url)
        if match:
            return f"v{match.group(1)}"
        return None
    
    def download_release(self):
        if not self.release_url:
            return self.release_file or ""
        
        # Determine if this is a tarball URL or legacy binary URL
        is_tarball = self.is_tarball_url(self.release_url)
        info(f"Downloading release from {self.release_url}")
        info(f"Format: {'tarball' if is_tarball else 'binary'}")
        
        if is_tarball:
            # Handle tarball release artifacts (current format)
            # Download the tarball directly
            download_dir = self.create_temp_dir("surfbots-download-")
            self.track_cleanup("download_dir", download_dir)
            
            # Extract version from URL
            version = self.extract_version_from_url(self.release_url)
            if version:
                archive_name = f"surfbots-dev-platform-{version}.tar.gz"
                checksum_name = f"surfbots-dev-platform-{version}.sha256"
            else:
                # Fallback to extracting from URL
                archive_name = Path(self.release_url).name
                checksum_name = archive_name.replace('.tar.gz', '.sha256')
            
            download_path = os.path.join(download_dir, archive_name)
            checksum_path = os.path.join(download_dir, checksum_name)
            
            # Download tarball
            ret, stdout, stderr = run_command(["curl", "-fsSL", self.release_url, "-o", download_path], timeout=120)
            if ret != 0:
                raise RuntimeError(f"Failed to download tarball: {stderr}")
            success(f"Downloaded {archive_name}")
            
            # Download and verify checksum if available
            # Extract base URL (remove filename)
            release_base = self.release_url.rsplit('/', 1)[0] if '/' in self.release_url else self.release_url
            checksum_url = release_base + '/' + checksum_name
            ret, stdout, stderr = run_command(["curl", "-fsSL", checksum_url, "-o", checksum_path], timeout=30)
            if ret == 0:
                # Verify checksum
                with open(checksum_path, 'r') as f:
                    first_line = f.readline().strip()
                    expected_hash = first_line.split()[0] if first_line else ""
                
                actual_hash = compute_file_hash(download_path)
                if expected_hash and actual_hash != expected_hash:
                    raise RuntimeError(f"Checksum mismatch: expected {expected_hash}, got {actual_hash}")
                success(f"Verified checksum ({expected_hash[:16]}...)")
            else:
                warning(f"Could not download checksum file; skipping verification")
            
            return download_path
        else:
            # Legacy binary distribution mode (surfbots-dev-{target})
            arch = subprocess.run(["uname", "-m"], capture_output=True, text=True, check=True).stdout.strip()
            if arch == "x86_64":
                target = "linux-amd64"
            elif arch in ("aarch64", "arm64"):
                target = "linux-arm64"
            else:
                raise RuntimeError(f"Unsupported architecture: {arch}")
            
            download_dir = self.create_temp_dir("surfbots-download-")
            self.track_cleanup("download_dir", download_dir)
            
            cli_binary = f"surfbots-dev-{target}"
            download_url = f"{self.release_url}/{cli_binary}"
            download_path = os.path.join(download_dir, cli_binary)
            
            ret, _, stderr = run_command(["curl", "-fsSL", download_url, "-o", download_path], timeout=120)
            if ret != 0:
                raise RuntimeError(f"Failed to download binary: {stderr}")
            
            success(f"Downloaded {cli_binary}")
            
            # Checksum verification for legacy mode
            sha256_path = os.path.join(download_dir, "SHA256SUMS")
            ret, _, _ = run_command(["curl", "-fsSL", f"{self.release_url}/SHA256SUMS", "-o", sha256_path], timeout=30)
            if ret == 0:
                with open(sha256_path, 'r') as f:
                    for line in f:
                        if cli_binary in line:
                            expected_hash = line.split()[0]
                            actual_hash = compute_file_hash(Path(download_path))
                            if expected_hash != actual_hash:
                                msg = f"Checksum mismatch for {cli_binary}: Expected: {expected_hash}, Actual: {actual_hash}"
                                raise RuntimeError(msg)
                            break
            
            # Make binary executable
            os.chmod(download_path, 0o755)
            return download_path

    def extract_release(self, artifact_path, is_tarball=True):
        info(f"Extracting release artifact: {artifact_path}")
        
        if is_tarball:
            # Handle tarball format (current release artifacts)
            extract_dir = self.create_temp_dir("surfbots-extract-")
            ret, _, stderr = run_command(["tar", "-xzf", artifact_path, "-C", extract_dir], timeout=120)
            if ret != 0:
                raise RuntimeError(f"Failed to extract release: {stderr}")
            
            # Check if extract_dir contains a single directory (versioned structure)
            items = [d for d in os.listdir(extract_dir) if os.path.isdir(os.path.join(extract_dir, d))]
            if len(items) == 1:
                package_root = os.path.join(extract_dir, items[0])
            else:
                # Direct structure - use extract_dir directly
                package_root = extract_dir
        else:
            # Handle binary format (legacy surfbots-dev-{target})
            # Copy the binary into a temporary directory structure that install_release expects
            extract_dir = self.create_temp_dir("surfbots-extract-")
            package_root = os.path.join(extract_dir, "surfbots-dev-platform")
            os.makedirs(package_root, exist_ok=True)
            
            # Copy the binary
            dest_binary = os.path.join(package_root, "tooling", "repo-bootstrap", "surfbots-dev")
            os.makedirs(os.path.dirname(dest_binary), exist_ok=True)
            shutil.copy2(artifact_path, dest_binary)
            
            # Copy required files from the binary's directory structure
            # For legacy mode, we expect the binary to be standalone
            # Create VERSION file
            version_path = os.path.join(package_root, "VERSION")
            with open(version_path, "w") as f:
                f.write("v0.0.0\n")
            
            # Copy cluster.sh and surfbots-admin.sh (we need these for the test)
            cluster_path = os.path.join(package_root, "cluster.sh")
            with open(cluster_path, "w") as f:
                f.write("""#!/bin/bash
echo 'cluster.sh placeholder'
""")
            
            admin_path = os.path.join(package_root, "surfbots-admin.sh")
            with open(admin_path, "w") as f:
                f.write("""#!/bin/bash
echo 'surfbots-admin.sh placeholder'
""")
        
        success(f"Extracted to: {package_root}")
        return package_root

    def install_release(self, package_root):
        info("Installing release...")
        if not self.install_root:
            self.install_root = self.create_temp_dir("surfbots-install-")
        bin_dir = os.path.join(self.install_root, ".local", "bin")
        cli_root = os.path.join(self.install_root, ".local", "share", "surfbots-dev-platform", "cli")
        os.makedirs(bin_dir, exist_ok=True)
        os.makedirs(cli_root, exist_ok=True)
        repo_bootstrap_src = os.path.join(package_root, "tooling", "repo-bootstrap")
        repo_bootstrap_dst = os.path.join(cli_root, "repo-bootstrap")
        if os.path.isdir(repo_bootstrap_src):
            shutil.copytree(repo_bootstrap_src, repo_bootstrap_dst)
            success(f"Copied repo-bootstrap: {repo_bootstrap_dst}")
        else:
            raise FileNotFoundError(f"repo-bootstrap not found at {repo_bootstrap_src}")
        required_files = [("VERSION", os.path.join(cli_root, "VERSION")), ("cluster.sh", os.path.join(cli_root, "cluster.sh")), ("surfbots-admin.sh", os.path.join(cli_root, "surfbots-admin.sh"))]
        for src, dst in required_files:
            src_path = os.path.join(package_root, src)
            if os.path.exists(src_path):
                shutil.copy2(src_path, dst)
                success(f"Copied {src}: {dst}")
        venv_dir = os.path.join(cli_root, "venv")
        ret, _, stderr = run_command([sys.executable, "-m", "venv", venv_dir], timeout=60)
        if ret != 0:
            raise RuntimeError(f"Failed to create venv: {stderr}")
        success(f"Created virtual environment: {venv_dir}")
        ret, _, stderr = run_command([os.path.join(venv_dir, "bin", "pip"), "install", "--quiet", "--upgrade", "pip", "pyyaml", "watchfiles"], timeout=120)
        launcher_path = os.path.join(bin_dir, "surfbots-dev")
        launcher_content = """#!/usr/bin/env bash
set -e
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
CLI_ROOT="${DATA_HOME}/surfbots-dev-platform/cli"
exec "${CLI_ROOT}/venv/bin/python" "${CLI_ROOT}/repo-bootstrap/surfbots-dev" "$@"
"""
        with open(launcher_path, "w") as f:
            f.write(launcher_content)
        os.chmod(launcher_path, 0o755)
        os.chmod(os.path.join(cli_root, "repo-bootstrap", "surfbots-dev"), 0o755)
        self.launcher_path = launcher_path
        self.installation_dir = self.install_root
        self.runtime_dir = cli_root
        success(f"Installed launcher: {launcher_path}")
        success(f"Installed runtime: {cli_root}")
        return launcher_path, cli_root

    def test_launcher_exists(self):
        if not self.launcher_path:
            self.failures.append("Launcher path not set")
            return False
        if not os.path.exists(self.launcher_path):
            self.failures.append(f"Launcher not found: {self.launcher_path}")
            return False
        if not os.access(self.launcher_path, os.X_OK):
            self.failures.append(f"Launcher not executable: {self.launcher_path}")
            return False
        success(f"Launcher exists and is executable: {self.launcher_path}")
        return True

    def test_self_contained(self):
        if not self.launcher_path or not self.runtime_dir:
            self.failures.append("Launcher path or runtime dir not set")
            return False
        # Test that the Python CLI runs without source checkout dependency
        cli_script = os.path.join(self.runtime_dir, "repo-bootstrap", "surfbots-dev")
        if not os.path.exists(cli_script):
            self.failures.append(f"CLI script not found: {cli_script}")
            return False
        # Create a minimal test environment without source checkout
        test_script = f"""#!/usr/bin/env python3
import os
import subprocess
import sys
test_path = os.environ.get('SURFBOTS_DEV_PLATFORM_SRC', '')
os.environ['PATH'] = ':'.join(p for p in os.environ.get('PATH', '').split(':') if test_path not in p)
os.environ.pop('PYTHONPATH', None)
# Test with --help which is available
result = subprocess.run([sys.executable, '{cli_script}', '--help'], capture_output=True, text=True, timeout=30)
if result.returncode == 0 and 'Available commands' in result.stdout:
    print("SUCCESS: CLI runs without source checkout")
    sys.exit(0)
else:
    print(f"FAILURE: CLI failed: {{result.stderr or result.stdout}}")
    sys.exit(1)
"""
        test_dir = self.create_temp_dir("surfbots-selftest-")
        test_file = os.path.join(test_dir, "test_selfcontained.py")
        with open(test_file, "w") as f:
            f.write(test_script)
        ret, stdout, stderr = run_command([sys.executable, test_file], timeout=60)
        if ret != 0:
            self.failures.append(f"Self-contained test failed: {stderr or stdout}")
            return False
        success("CLI is self-contained (no source checkout dependency)")
        return True

    def test_help_available(self):
        if not self.launcher_path:
            self.failures.append("Launcher path not set")
            return False
        ret, stdout, stderr = run_command([self.launcher_path, "--help"], timeout=30)
        if ret != 0:
            self.failures.append(f"--help failed: {stderr or stdout}")
            return False
        if "Available commands" not in stdout:
            self.failures.append("--help output missing expected content")
            return False
        success("--help works and shows available commands")
        return True

    def verify_bundled_assets(self, package_root):
        info("Verifying bundled assets in release...")
        missing = []
        # Check both root location and tooling/repo-bootstrap location
        for asset in ALL_REQUIRED_ASSETS:
            # Try root first, then repo-bootstrap subdirectory
            asset_path = os.path.join(package_root, asset)
            if not os.path.exists(asset_path):
                asset_path = os.path.join(package_root, "tooling/repo-bootstrap", asset)
            if not os.path.exists(asset_path):
                missing.append(asset)
            else:
                self.bundled_asset_hashes[asset] = compute_file_hash(Path(asset_path))
        if missing:
            self.failures.append(f"Missing bundled assets: {', '.join(missing)}")
            for asset in missing:
                failure(f"Missing asset in release: {asset}")
            return False
        success(f"All {len(ALL_REQUIRED_ASSETS)} bundled assets present in release")
        return True

    def verify_installed_assets(self):
        info("Verifying installed assets...")
        if not self.runtime_dir:
            self.failures.append("Runtime directory not set")
            return False
        missing = []
        for i, asset in enumerate(ALL_REQUIRED_ASSETS):
            expected_path = os.path.join(self.runtime_dir, "repo-bootstrap", asset)
            if not os.path.exists(expected_path):
                missing.append(asset)
            else:
                self.installed_asset_hashes[asset] = compute_file_hash(Path(expected_path))
        if missing:
            self.failures.append(f"Missing installed assets: {', '.join(missing)}")
            for asset in missing:
                failure(f"Missing installed asset: {asset}")
            return False
        success(f"All {len(ALL_REQUIRED_ASSETS)} installed assets present")
        return True

    def compare_asset_hashes(self):
        info("Comparing asset hashes...")
        mismatches = []
        matching = 0
        for asset, bundled_hash in self.bundled_asset_hashes.items():
            if asset not in self.installed_asset_hashes:
                mismatches.append(f"{asset}: missing in installed")
                continue
            installed_hash = self.installed_asset_hashes[asset]
            if bundled_hash != installed_hash:
                mismatches.append(f"{asset}: {bundled_hash[:16]} != {installed_hash[:16]}")
            else:
                matching += 1
        if mismatches:
            self.failures.append(f"Asset hash mismatches: {len(mismatches)}")
            for mismatch in mismatches:
                failure(f"Hash mismatch: {mismatch}")
            return False
        success(f"All {matching} assets have matching hashes")
        return True

    def create_test_repository(self):
        info("Creating test repository...")
        repo_dir = self.create_temp_dir("surfbots-repo-")
        (Path(repo_dir) / "src").mkdir()
        (Path(repo_dir) / "src" / "main.py").write_text("# Test file\nx = 1\n")
        run_command(["git", "init"], cwd=repo_dir, timeout=30)
        run_command(["git", "config", "user.email", "test@example.com"], cwd=repo_dir, timeout=10)
        run_command(["git", "config", "user.name", "Test User"], cwd=repo_dir, timeout=10)
        run_command(["git", "add", "."], cwd=repo_dir, timeout=30)
        run_command(["git", "commit", "-m", "Initial commit"], cwd=repo_dir, timeout=30)
        self.repository_path = repo_dir
        self.track_cleanup("test-repository", repo_dir)
        success(f"Created test repository: {repo_dir}")
        return repo_dir

    def test_repo_add(self):
        if not self.launcher_path:
            self.failures.append("Launcher path not set")
            return False
        if not self.repository_path:
            self.failures.append("Repository path not set")
            return False
        info("Running repo add...")
        # Set XDG_DATA_HOME to ensure the temp CLI is used instead of any cached global installation
        env = os.environ.copy()
        env["XDG_DATA_HOME"] = self.installation_dir + "/.local/share"
        ret, stdout, stderr = run_command([self.launcher_path, "init", self.repository_path], timeout=120, env=env)
        if ret != 0:
            self.failures.append(f"repo add (init) failed: {stderr or stdout}")
            return False
        repo_path = Path(self.repository_path)
        required = [
            repo_path / ".clinerules" / "surfbots-development-context.md",
            repo_path / ".clinerules" / "skills" / "surfbots-development-context" / "SKILL.md",
            repo_path / ".github" / "instructions" / "surfbots-development-context.instructions.md",
            repo_path / ".github" / "skills" / "surfbots-development-context" / "SKILL.md",
            repo_path / ".github" / "skills" / "surfbots-development-context" / "scripts" / "build_context.py",
        ]
        missing = [p for p in required if not p.exists()]
        if missing:
            self.failures.append(f"Assets not provisioned by repo add: {', '.join(str(p) for p in missing)}")
            for p in missing:
                failure(f"Missing asset in repo: {p}")
            return False
        success("repo add successfully provisioned Cline and Copilot assets")
        return True

    def test_repo_asset_hashes(self):
        if not self.repository_path:
            self.failures.append("Repository path not set")
            return False
        info("Verifying provisioned asset hashes...")
        repo_path = Path(self.repository_path)
        mismatches = []
        matching = 0
        for asset in ALL_REQUIRED_ASSETS:
            installed_path = Path(self.runtime_dir) / "repo-bootstrap" / asset
            repo_path_obj = repo_path / asset
            if not repo_path_obj.exists():
                continue
            repo_hash = compute_file_hash(repo_path_obj)
            if asset in self.installed_asset_hashes:
                installed_hash = self.installed_asset_hashes[asset]
                if repo_hash != installed_hash:
                    mismatches.append(f"{asset}: {repo_hash[:16]} != {installed_hash[:16]}")
                else:
                    matching += 1
        if mismatches:
            self.failures.append(f"Asset hash mismatches in repository: {len(mismatches)}")
            for mismatch in mismatches:
                failure(f"Hash mismatch: {mismatch}")
            return False
        success(f"All {matching} provisioned assets match installed runtime")
        return True

    def test_repo_remove(self):
        if not self.platform_services_available:
            info("Skipping repo remove test (platform services not available)")
            return True
        if not self.launcher_path:
            self.failures.append("Launcher path not set")
            return False
        if not self.repository_id:
            info("Skipping repo remove test (repository not registered)")
            return True
        info("Testing repo remove...")
        repo_dir = self.create_temp_dir("surfbots-repo2-")
        (Path(repo_dir) / "src").mkdir()
        (Path(repo_dir) / "src" / "main.py").write_text("# Test file\nx = 1\n")
        run_command(["git", "init"], cwd=repo_dir, timeout=30)
        run_command(["git", "config", "user.email", "test@example.com"], cwd=repo_dir, timeout=10)
        run_command(["git", "config", "user.name", "Test User"], cwd=repo_dir, timeout=10)
        run_command(["git", "add", "."], cwd=repo_dir, timeout=30)
        run_command(["git", "commit", "-m", "Initial commit"], cwd=repo_dir, timeout=30)
        ret, stdout, stderr = run_command([self.launcher_path, "init", repo_dir], timeout=120)
        if ret != 0:
            warning(f"Could not create second repository for remove test: {stderr or stdout}")
            return True
        info("Repo remove test skipped (requires platform services)")
        return True

    def cleanup(self):
        info("Cleaning up...")
        for name, path in self._cleanup_funcs:
            try:
                if os.path.isfile(path):
                    os.remove(path)
                    info(f"Removed: {path}")
                elif os.path.isdir(path):
                    shutil.rmtree(path)
                    info(f"Removed: {path}")
            except Exception as e:
                warning(f"Failed to remove {name} ({path}): {e}")
        for temp_dir in self._temp_dirs:
            try:
                if os.path.isdir(temp_dir):
                    shutil.rmtree(temp_dir)
                    info(f"Removed temp dir: {temp_dir}")
            except Exception as e:
                warning(f"Failed to remove temp dir {temp_dir}: {e}")
        if self.installation_dir and self.installation_dir in self._temp_dirs:
            try:
                if os.path.isdir(self.installation_dir):
                    shutil.rmtree(self.installation_dir)
                    info(f"Removed install root: {self.installation_dir}")
            except Exception as e:
                warning(f"Failed to remove install root {self.installation_dir}: {e}")
        success("Cleanup complete")

    def run_tests(self):
        info("=== Starting Validation Harness ===")
        info("")
        try:
            artifact_path = ""
            if self.release_url or self.release_file:
                artifact_path = self.download_release()
                # Check if artifact is a tarball or binary
                is_tarball = artifact_path.endswith('.tar.gz') or self.is_tarball_url(artifact_path)
                package_root = self.extract_release(artifact_path, is_tarball=is_tarball)
                if not self.verify_bundled_assets(package_root):
                    return self.get_results()
            self.install_release(package_root if 'package_root' in dir() else ".")
            tests = [
                ("launcher_exists", self.test_launcher_exists),
                ("self_contained", self.test_self_contained),
                ("help_available", self.test_help_available),
                ("verify_installed_assets", self.verify_installed_assets),
                ("compare_asset_hashes", self.compare_asset_hashes),
            ]
            for test_name, test_func in tests:
                try:
                    result = test_func()
                    self.results[test_name] = result
                except Exception as e:
                    self.failures.append(f"{test_name} raised exception: {e}")
                    self.results[test_name] = False
                    failure(f"Test {test_name} failed with exception: {e}")
            if "help_available" in self.results and self.results["help_available"]:
                try:
                    self.create_test_repository()
                    if not self.test_repo_add():
                        self.results["repo_add"] = False
                    if not self.test_repo_asset_hashes():
                        self.results["repo_asset_hashes"] = False
                except Exception as e:
                    self.failures.append(f"Repository test failed: {e}")
                    self.results["repo_add"] = False
                    self.results["repo_asset_hashes"] = False
            if "repo_add" in self.results and self.results["repo_add"]:
                self.test_repo_remove()
        except Exception as e:
            self.failures.append(f"Validation harness failed with exception: {e}")
            failure(f"Validation harness failed: {e}")
        return self.get_results()

    def get_results(self):
        # self.cleanup()  # DEBUG: preserve temp dirs
        return self.results


def parse_args():
    parser = argparse.ArgumentParser(
        description="Validate Surfbots Dev Platform public bootstrap/release-artifact installation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples (GitHub release artifact):
  python validate_bootstrap.py --url https://github.com/USER/REPO/releases/download/vX.Y.Z/surfbots-dev-platform-vX.Y.Z.tar.gz
  python validate_bootstrap.py --file /path/to/surfbots-dev-platform-v0.2.0.tar.gz
  python validate_bootstrap.py --url https://github.com/USER/REPO/releases/download/vX.Y.Z/surfbots-dev-platform-vX.Y.Z.tar.gz --no-services

For the public Surfbots Code Intelligence repository:
  python validate_bootstrap.py --url https://github.com/franknaw/surfbots-code-intelligence/releases/download/v0.3.0-local-bootstrap/surfbots-dev-platform-v0.3.0.tar.gz
""",
    )
    parser.add_argument("--url", dest="release_url", help="Public bootstrap URL (tarball or legacy binary)")
    parser.add_argument("--file", dest="release_file", help="Path to local release artifact tarball")
    parser.add_argument("--services", dest="platform_services", action="store_true", default=True, help="Platform services available (default)")
    parser.add_argument("--no-services", dest="platform_services", action="store_false", help="Platform services not available")
    parser.add_argument("--install-root", dest="install_root", help="Custom installation root directory")
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable verbose output")
    return parser.parse_args()


def main():
    args = parse_args()
    if not args.release_url and not args.release_file:
        print("Error: Either --url or --file must be specified")
        print("")
        print("Examples (GitHub release artifact):")
        print("  python validate_bootstrap.py --url https://github.com/USER/REPO/releases/download/vX.Y.Z/surfbots-dev-platform-vX.Y.Z.tar.gz")
        print("  python validate_bootstrap.py --file /path/to/surfbots-dev-platform-v0.2.0.tar.gz")
        print("")
        print("For the public Surfbots Code Intelligence repository:")
        print("  python validate_bootstrap.py --url https://github.com/franknaw/surfbots-code-intelligence/releases/download/v0.3.0-local-bootstrap/surfbots-dev-platform-v0.3.0.tar.gz")
        return 1
    if args.release_url and args.release_file:
        print("Error: Cannot specify both --url and --file")
        return 1
    harness = ValidationHarness(
        release_url=args.release_url,
        release_file=args.release_file,
        install_root=args.install_root,
        platform_services_available=args.platform_services,
    )
    if args.verbose:
        # Verbose mode - prepend [VERBOSE] to info messages
        def verbose_info(msg):
            print(f"[VERBOSE] {msg}")
        global info
        info = verbose_info
    results = harness.run_tests()
    print("")
    print("=== Validation Summary ===")
    passed = sum(1 for v in results.values() if v)
    failed = sum(1 for v in results.values() if not v)
    total = len(results)
    print(f"Passed: {green(str(passed))}/{total}")
    print(f"Failed: {red(str(failed))}/{total}")
    print("")
    for test_name, result in results.items():
        status = green("PASS") if result else red("FAIL")
        print(f"  {test_name}: {status}")
    if harness.failures:
        print("")
        print("=== Failures ===")
        for failure_msg in harness.failures:
            print(f"  {failure_msg}")
    return 1 if failed > 0 else 0


if __name__ == "__main__":
    sys.exit(main())
