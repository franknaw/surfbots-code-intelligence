#!/bin/bash
# surfbots-dev-platform Admin Script
# Usage: ./surfbots-admin.sh {start|stop|status|embed|gen|rerank|mcp|qdrant|help|build|redeploy|rebuild|restart|api|cline|copilot}

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLUSTER_SCRIPT="${SCRIPT_DIR}/cluster.sh"

# Canonical defaults; environment overrides are supported for testing/recovery.
SURFBOTS_CLUSTER_NAME="${SURFBOTS_CLUSTER_NAME:-surfbots-dev-platform}"
SURFBOTS_KUBE_CONTEXT="${SURFBOTS_KUBE_CONTEXT:-k3d-${SURFBOTS_CLUSTER_NAME}}"
SURFBOTS_NAMESPACE="${SURFBOTS_NAMESPACE:-surfbots-dev-platform}"
SURFBOTS_REGISTRY_NAME="${SURFBOTS_REGISTRY_NAME:-surfbots-dev-platform-registry}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Semantic colors for enhanced help output
C_MAGENTA=$'\033[35m'
C_CYAN=$'\033[36m'
C_YELLOW=$'\033[1;33m'
C_GREEN=$'\033[0;32m'
C_RED=$'\033[0;31m'
C_WHITE=$'\033[0;37m'
C_BOLD=$'\033[1m'
RESET=$'\033[0m'


log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# kubectl wrapper - explicitly uses Dev Platform context
kctl() {
    kubectl --context "${SURFBOTS_KUBE_CONTEXT}" --namespace "${SURFBOTS_NAMESPACE}" "$@"
}

# Check if expected cluster exists (exact match)
cluster_exists() {
    k3d cluster list --no-headers 2>/dev/null | awk '{print $1}' | grep -Fxq "${SURFBOTS_CLUSTER_NAME}"
}

# Check if expected context exists
context_exists() {
    kubectl config get-contexts -o name 2>/dev/null | grep -Fxq "${SURFBOTS_KUBE_CONTEXT}"
}

RESERVED_PORTS=" "

# Function to find next available port starting from $1
find_available_port() {
    local start_port=$1
    local max_attempts=${2:-100}
    local port=$start_port
    
    while [ $port -lt $((start_port + max_attempts)) ]; do
        if ! lsof -i :$port >/dev/null 2>&1 && [[ "$RESERVED_PORTS" != *" $port "* ]]; then
            echo $port
            return 0
        fi
        ((port++))
    done
    
    echo ""
    return 1
}

pf_pid_file() { echo "/tmp/surfbots-$1.pid"; }

read_pf_port() {
    local file pid
    file=$(pf_pid_file "$1")
    pid=$(read_pf_pid "$1" 2>/dev/null || true)
    if [ -n "$pid" ] && ps -p "$pid" > /dev/null 2>&1; then
        [ -f "$file" ] && grep -o "Port: [0-9]*" "$file" | grep -o "[0-9]*" | head -n 1 || echo "$2"
    else
        echo "$2"
    fi
}

read_pf_pid() {
    local label=$1
    local file pid service
    file=$(pf_pid_file "$label")
    if [ -f "$file" ]; then
        pid=$(grep -o "PID: [0-9]*" "$file" | grep -o "[0-9]*" || true)
        if [ -n "$pid" ] && ps -p "$pid" > /dev/null 2>&1; then
            echo "$pid"
            return 0
        fi
    fi

    case "$label" in
        mcp) service="mcp-server" ;;
        *) service="$label" ;;
    esac

    pid=$(pgrep -f "kubectl.*port-forward.*svc/${service}" | head -n 1 || true)
    if [ -n "$pid" ] && ps -p "$pid" > /dev/null 2>&1; then
        local port
        port=$(lsof -p "$pid" -a -i -a -sTCP:LISTEN 2>/dev/null | grep -o "TCP .*:[0-9]*" | grep -o "[0-9]*" | head -n 1 || echo "")
        [ -n "$port" ] && echo "$label PID: $pid Port: $port" > "$file"
        echo "$pid"
        return 0
    fi

    return 1
}

forward_is_running() {
    local pid
    pid=$(read_pf_pid "$1" 2>/dev/null || true)
    [ -n "$pid" ] && ps -p "$pid" > /dev/null 2>&1
}

forward_url() {
    local label=$1 preferred=$2 pid port
    pid=$(read_pf_pid "$label" 2>/dev/null || true)
    if [ -n "$pid" ] && ps -p "$pid" > /dev/null 2>&1; then
        port=$(read_pf_port "$label" "$preferred")
        echo "http://localhost:$port"
    else
        echo "not running"
    fi
}

# start_port_forward <label> <service> <preferred-local-port> <remote-port>
start_port_forward() {
    local label=$1 service=$2 preferred=$3 remote=$4
    local port existing

    # Reuse only a forward whose tracked process still owns its local listener.
    existing=$(read_pf_pid "$label" 2>/dev/null || true)
    if [ -n "$existing" ] && forward_is_running "$label"; then
        existing_port=$(read_pf_port "$label" "$preferred")
        if lsof -i ":$existing_port" >/dev/null 2>&1; then
            log_info "$label port-forward already running (port $existing_port)"
            return 0
        fi
        log_warn "$label port-forward is stale; restarting it"
        stop_port_forward "$label"
    fi
    rm -f "$(pf_pid_file "$label")"

    port=$(find_available_port "$preferred")
    if [ -z "$port" ]; then
        log_error "Could not find available port for $label"
        return 1
    fi
    if [ "$port" != "$preferred" ]; then
        log_warn "Port $preferred is in use, using $port for $label"
    fi

    # Reserve before starting the process so later forwards in this invocation
    # cannot choose the same port during kubectl's startup window.
    RESERVED_PORTS+="$port "
    log_info "Starting $label port-forward (port $port)..."
    kctl port-forward "svc/${service}" "${port}:${remote}" \
        > "/tmp/${label}-port-forward.log" 2>&1 &
    echo "$label PID: $! Port: $port" > "$(pf_pid_file "$label")"

    local attempt
    for attempt in {1..50}; do
        if lsof -i ":$port" >/dev/null 2>&1; then
            return 0
        fi
        if ! ps -p "$!" >/dev/null 2>&1; then
            break
        fi
        sleep 0.1
    done
    log_error "$label port-forward did not bind to port $port; inspect /tmp/${label}-port-forward.log"
    rm -f "$(pf_pid_file "$label")"
    return 1
}

stop_port_forward() {
    local label=$1
    local pid
    pid=$(read_pf_pid "$label" 2>/dev/null || true)
    [ -n "$pid" ] && kill "$pid" 2>/dev/null || true
    rm -f "$(pf_pid_file "$label")"
}

show_urls() {
    local indexer_port search_port mcp_port qdrant_port embed_port gen_port rerank_port
    
    # Check actual localhost listeners for systemd-managed services
    qdrant_port=$(check_port_listening 6333)
    embed_port=$(check_port_listening 8024)
    gen_port=$(check_port_listening 8025)
    rerank_port=$(check_port_listening 8026)
    
    # For legacy services (code-indexer, code-search-api, mcp) use read_pf_port
    indexer_port=$(read_pf_port code-indexer 8021)
    search_port=$(read_pf_port code-search-api 8020)
    mcp_port=$(read_pf_port mcp 8023)
    
    echo ""
    echo "=============================================="
    echo "        surfbots-dev-platform URLs"
    echo "=============================================="
    echo ""
    echo "Service URLs (via port-forward):"
    echo "  MCP Server:         $(forward_url mcp 8023)"
    echo "  Code Search API:    $(forward_url code-search-api 8020)"
    echo "  Code Indexer:       $(forward_url code-indexer 8021)"
    echo ""
    echo "Model Service URLs (via port-forward):"
    
    if [ "$embed_port" != "" ] && [ "$embed_port" != "0" ]; then
        echo "  Embedding:          http://localhost:$embed_port"
    else
        echo "  Embedding:          not running"
    fi
    
    if [ "$gen_port" != "" ] && [ "$gen_port" != "0" ]; then
        echo "  Generation:         http://localhost:$gen_port"
    else
        echo "  Generation:         not running"
    fi
    
    if [ "$rerank_port" != "" ] && [ "$rerank_port" != "0" ]; then
        echo "  Reranker:           http://localhost:$rerank_port"
    else
        echo "  Reranker:           not running"
    fi
    
    echo ""
    echo "Qdrant Admin UI:"
    if [ "$qdrant_port" != "" ] && [ "$qdrant_port" != "0" ]; then
        echo "  Local:              http://localhost:$qdrant_port"
    else
        echo "  Local:              not running"
    fi
    echo "  Kubernetes:         http://qdrant.surfbots-dev-platform.svc.cluster.local:6333"
    echo ""
}

# check_port_listening <port> - returns port if listening, empty otherwise
check_port_listening() {
    local port=$1
    if lsof -i :$port >/dev/null 2>&1; then
        echo "$port"
    else
        echo ""
    fi
}

start_cluster() {
    log_info "Starting surfbots-dev-platform..."
    if cluster_exists; then
        log_info "Cluster exists, checking and ensuring builds..."
        # Self-healing: rebuild only missing or invalid images before deploy
        $CLUSTER_SCRIPT ensure_all_builds || {
            log_error "Self-healing failed - some images could not be rebuilt"
            return 1
        }
        log_info "Self-healing complete, deploying services..."
        $CLUSTER_SCRIPT deploy
    else
        log_info "Creating cluster ${SURFBOTS_CLUSTER_NAME}..."
        $CLUSTER_SCRIPT create
        log_info "Deploying services..."
        $CLUSTER_SCRIPT deploy
    fi

    # Find and use available ports for port-forwards
    log_info "Checking port availability..."

    # Start systemd port-forward services for host endpoints
    start_systemd_port_forwards

    # Start legacy systemd port-forwards (code-indexer, code-search-api, mcp)
    start_port_forward "code-indexer" "code-indexer" 8021 8000
    start_port_forward "code-search-api" "code-search-api" 8020 8000
    start_mcp

    local label failed=0
    for label in code-indexer code-search-api mcp; do
        if ! forward_is_running "$label"; then
            log_error "$label port-forward did not start; inspect /tmp/${label}-port-forward.log"
            failed=1
        fi
    done
    if [ "$failed" -ne 0 ]; then
        return 1
    fi

    show_urls
    log_success "All services running!"
}

stop_cluster() {
    log_info "Stopping services..."
    for label in code-indexer code-search-api mcp; do
        stop_port_forward "$label"
    done
    log_info "Stopping systemd port-forward services..."
    systemctl --user stop surfbots-indexer-port-forward.service 2>/dev/null || true
    systemctl --user stop surfbots-search-port-forward.service 2>/dev/null || true
    systemctl --user stop surfbots-mcp-port-forward.service 2>/dev/null || true
    systemctl --user stop surfbots-qdrant-port-forward.service 2>/dev/null || true
    systemctl --user stop surfbots-embedding-port-forward.service 2>/dev/null || true
    systemctl --user stop surfbots-generation-port-forward.service 2>/dev/null || true
    systemctl --user stop surfbots-reranker-port-forward.service 2>/dev/null || true
    $CLUSTER_SCRIPT undeploy
    log_success "All services stopped!"
}

show_status() {
    echo ""
    echo "=============================================="
    echo "        surfbots-dev-platform Status"
    echo "=============================================="
    echo ""
    
    # Check cluster (exact match)
    if cluster_exists; then
        log_success "Cluster: ${SURFBOTS_CLUSTER_NAME} - Running"
    else
        log_error "Cluster: ${SURFBOTS_CLUSTER_NAME} - Missing"
    fi
    
    # Check context
    if context_exists; then
        log_success "Context: ${SURFBOTS_KUBE_CONTEXT} - Available"
    else
        log_error "Context: ${SURFBOTS_KUBE_CONTEXT} - Missing"
    fi
    
    # Check namespace using kubectl wrapper
    if kctl get namespace "${SURFBOTS_NAMESPACE}" >/dev/null 2>&1; then
        log_success "Namespace: ${SURFBOTS_NAMESPACE} - Active"
    else
        log_error "Namespace: ${SURFBOTS_NAMESPACE} - Missing"
    fi
    
    # Check pods using kubectl wrapper
    echo ""
    log_info "=== Pods ==="
    kctl get pods 2>/dev/null || log_error "No pods found"
    
    # Check services using kubectl wrapper
    echo ""
    log_info "=== Services ==="
    kctl get services 2>/dev/null || log_error "No services found"
    
    echo ""
    echo "Managed host endpoints (systemd):"
    for entry in "code-indexer:8021" "code-search-api:8020" "mcp:8023"; do
        label="${entry%%:*}"
        default_port="${entry##*:}"
        port=$(check_port_listening "$default_port")
        # Map label to systemd service name
        case "$label" in
            code-indexer) svc_name="surfbots-indexer-port-forward" ;;
            code-search-api) svc_name="surfbots-search-port-forward" ;;
            mcp) svc_name="surfbots-mcp-port-forward" ;;
        esac
        # Check if systemd service is active
        if systemctl --user is-active --quiet "$svc_name" 2>/dev/null; then
            echo "  ${label^} (${port}): Active"
        else
            echo "  ${label^} (${port}): Inactive"
        fi
    done
    
    # Model services (qdrant, embedding, generation, reranker)
    for entry in "qdrant:6333" "model-embedding:8024" "model-generation:8025" "model-reranker:8026"; do
        label="${entry%%:*}"
        default_port="${entry##*:}"
        # Map label to systemd service name
        case "$label" in
            qdrant) svc_name="surfbots-qdrant-port-forward" ;;
            model-embedding) svc_name="surfbots-embedding-port-forward" ;;
            model-generation) svc_name="surfbots-generation-port-forward" ;;
            model-reranker) svc_name="surfbots-reranker-port-forward" ;;
        esac
        port=$(check_port_listening "$default_port")
        if [ -n "$port" ]; then
            if systemctl --user is-active --quiet "$svc_name" 2>/dev/null; then
                echo "  ${label^} (${port}): Active (systemd)"
            else
                echo "  ${label^} (${port}): Running (other)"
            fi
        else
            echo "  ${label^} (${default_port}): Stopped"
        fi
    done
    
    echo ""
    echo "Port-forwards (systemd):"
    for svc in "surfbots-indexer-port-forward" "surfbots-search-port-forward" "surfbots-mcp-port-forward" "surfbots-qdrant-port-forward" "surfbots-embedding-port-forward" "surfbots-generation-port-forward" "surfbots-reranker-port-forward"; do
        if systemctl --user is-active --quiet "$svc" 2>/dev/null; then
            echo "  $svc: Active"
        elif systemctl --user is-enabled --quiet "$svc" 2>/dev/null; then
            echo "  $svc: Enabled (not running)"
        else
            echo "  $svc: Not installed"
        fi
    done
    show_urls
}

start_mcp() {
    local port
    if forward_is_running mcp; then
        port=$(read_pf_port mcp 8023)
        if curl -fsS --max-time 2 "http://127.0.0.1:${port}/health" >/dev/null 2>&1; then
            log_info "mcp port-forward already running (port $port)"
            return 0
        fi
        log_warn "mcp port-forward is stale; restarting it"
        stop_port_forward mcp
    fi
    start_port_forward "mcp" "mcp-server" 8023 8003
}

start_systemd_port_forwards() {
    log_info "Starting systemd port-forward services..."
    # Start legacy systemd port-forwards (code-indexer, code-search-api, mcp)
    systemctl --user start surfbots-indexer-port-forward.service 2>/dev/null || true
    systemctl --user start surfbots-search-port-forward.service 2>/dev/null || true
    systemctl --user start surfbots-mcp-port-forward.service 2>/dev/null || true
    # Start model service systemd port-forwards (qdrant, embedding, generation, reranker)
    systemctl --user start surfbots-qdrant-port-forward.service 2>/dev/null || true
    systemctl --user start surfbots-embedding-port-forward.service 2>/dev/null || true
    systemctl --user start surfbots-generation-port-forward.service 2>/dev/null || true
    systemctl --user start surfbots-reranker-port-forward.service 2>/dev/null || true
    sleep 2
}

start_qdrant() { start_port_forward "qdrant" "qdrant" 6333 6333; }
start_embed() { start_port_forward "model-embedding" "model-embedding" 8024 8001; }
start_gen() { start_port_forward "model-generation" "model-generation" 8025 8000; }
start_rerank() { start_port_forward "model-reranker" "model-reranker" 8026 8002; }
show_help() {
    # Reset colors if NO_COLOR is set
    if [ -n "${NO_COLOR}" ] || [ "${TERM}" = "dumb" ]; then
        C_MAGENTA=''; C_CYAN=''; C_YELLOW=''; C_GREEN=''; C_RED=''; C_WHITE=''; C_BOLD=''; RESET='';
    fi
    echo ""
    echo -e "${C_MAGENTA}============================================================${RESET}"
    echo -e "${C_MAGENTA}                  ${C_BOLD}${C_WHITE}SURFBOTS DEV PLATFORM${RESET}"
    echo -e "${C_MAGENTA}============================================================${RESET}"
    echo ""
    echo -e "${C_WHITE}Usage:${RESET}"
    echo -e "  ${C_CYAN}$0${RESET} ${C_YELLOW}COMMAND${RESET} [${C_YELLOW}SERVICE...${RESET}]"
    echo ""
    echo -e "${C_CYAN}------------------------------------------------------------${RESET}"
    echo -e "${C_WHITE}${BOLD}Platform${RESET}"
    echo -e "${C_CYAN}------------------------------------------------------------${RESET}"
    echo "  ${C_GREEN}start${RESET}   - Start cluster and all services"
    echo "  ${C_RED}stop${RESET}    - Stop all services"
    echo "  ${C_WHITE}status${RESET}  - Show platform status (dashboard view)"
    echo "  ${C_WHITE}doctor${RESET}  - Detailed health check for all endpoints"
    echo "  ${C_WHITE}summary${RESET} - Show data summary (Qdrant + SQLite)"
    echo "  ${C_WHITE}urls${RESET}    - Show all service URLs"
    echo ""
    echo -e "${C_CYAN}------------------------------------------------------------${RESET}"
    echo -e "${C_WHITE}${BOLD}Build ${C_YELLOW}&${RESET} ${C_WHITE}Deployment${RESET}"
    echo -e "${C_CYAN}------------------------------------------------------------${RESET}"
    echo "  ${C_YELLOW}build${RESET}       - Build Docker image(s)"
    echo "  ${C_YELLOW}redeploy${RESET}    - Build, import, and redeploy service(s)"
    echo "  ${C_YELLOW}rebuild${RESET}     - Same as redeploy"
    echo "  ${C_YELLOW}restart${RESET}     - Restart service(s) without rebuilding"
    echo ""
    echo -e "${C_CYAN}------------------------------------------------------------${RESET}"
    echo -e "${C_WHITE}${BOLD}Port Forwards${RESET}"
    echo -e "${C_CYAN}------------------------------------------------------------${RESET}"
    echo "  ${C_CYAN}api${RESET}       - Start ${C_CYAN}Code Search API${RESET} port-forward"
    echo "  ${C_CYAN}embed${RESET}     - Start ${C_CYAN}model-embedding${RESET} port-forward"
    echo "  ${C_CYAN}gen${RESET}       - Start ${C_CYAN}model-generation${RESET} port-forward"
    echo "  ${C_CYAN}rerank${RESET}    - Start ${C_CYAN}model-reranker${RESET} port-forward"
    echo "  ${C_CYAN}mcp${RESET}       - Start ${C_CYAN}MCP${RESET} port-forward"
    echo "  ${C_MAGENTA}qdrant${RESET}    - Start ${C_MAGENTA}Qdrant${RESET} port-forward"
    echo ""
    echo -e "${C_CYAN}------------------------------------------------------------${RESET}"
    echo -e "${C_WHITE}${BOLD}Systemd Service Management${RESET}"
    echo -e "${C_CYAN}------------------------------------------------------------${RESET}"
    echo "  ${C_WHITE}install-systemd${RESET} - Install systemd user services"
    echo "  ${C_WHITE}uninstall-systemd${RESET} - Uninstall systemd user services"
    echo ""
    echo -e "${C_CYAN}------------------------------------------------------------${RESET}"
    echo -e "${C_WHITE}${BOLD}Supported Services${RESET}"
    echo -e "${C_CYAN}------------------------------------------------------------${RESET}"
    echo "  ${C_CYAN}code-indexer${RESET}        - Index code repositories"
    echo "  ${C_CYAN}code-search-api${RESET}     - API for code search"
    echo "  ${C_CYAN}mcp-server${RESET}          - Model Control Protocol server"
    echo "  ${C_CYAN}model-embedding${RESET}     - Vector embedding model"
    echo "  ${C_CYAN}model-generation${RESET}    - Code generation model"
    echo "  ${C_CYAN}model-reranker${RESET}      - Search result reranker"
    echo ""
    echo -e "${C_CYAN}------------------------------------------------------------${RESET}"
    echo -e "${C_WHITE}${BOLD}Examples${RESET}"
    echo -e "${C_CYAN}------------------------------------------------------------${RESET}"
    echo "  ${C_WHITE}Start the platform:${RESET}"
    echo "    ${C_GREEN}./surfbots-admin.sh start${RESET}"
    echo ""
    echo "  ${C_WHITE}Check platform status:${RESET}"
    echo "    ${C_GREEN}./surfbots-admin.sh status${RESET}"
    echo ""
    echo "  ${C_WHITE}View all service URLs:${RESET}"
    echo "    ${C_GREEN}./surfbots-admin.sh urls${RESET}"
    echo ""
    echo "  ${C_WHITE}Build a specific service:${RESET}"
    echo "    ${C_YELLOW}./surfbots-admin.sh build mcp-server${RESET}"
    echo ""
    echo "  ${C_WHITE}Build all services:${RESET}"
    echo "    ${C_YELLOW}./surfbots-admin.sh build all${RESET}"
    echo ""
    echo "  ${C_WHITE}Build a specific service (alternative):${RESET}"
    echo "    ${C_YELLOW}./surfbots-admin.sh rebuild code-indexer${RESET}"
    echo ""
    echo "  ${C_WHITE}Redeploy a service (build + import + restart):${RESET}"
    echo "    ${C_YELLOW}./surfbots-admin.sh rebuild code-search-api${RESET}"
    echo ""
    echo "  ${C_WHITE}Restart a service without rebuilding:${RESET}"
    echo "    ${C_YELLOW}./surfbots-admin.sh restart model-embedding${RESET}"
    echo ""
    echo "  ${C_WHITE}Stop all services:${RESET}"
    echo "    ${C_RED}./surfbots-admin.sh stop${RESET}"
    echo ""
    echo "  ${C_WHITE}Start a specific port-forward:${RESET}"
    echo "    ${C_CYAN}./surfbots-admin.sh mcp${RESET}"
    echo "    ${C_CYAN}./surfbots-admin.sh qdrant${RESET}"
    echo "    ${C_CYAN}./surfbots-admin.sh api${RESET}"
    echo "    ${C_CYAN}./surfbots-admin.sh embed${RESET}"
    echo "    ${C_CYAN}./surfbots-admin.sh gen${RESET}"
    echo "    ${C_CYAN}./surfbots-admin.sh rerank${RESET}"
    echo ""
    echo "  ${C_WHITE}Configure Cline with Surfbots MCP:${RESET}"
    echo "    ${C_GREEN}./surfbots-admin.sh cline${RESET}"
    echo ""
    echo "  ${C_WHITE}Configure VS Code Copilot with Surfbots MCP:${RESET}"
    echo "    ${C_GREEN}./surfbots-admin.sh copilot${RESET}"
    echo ""
    echo "  ${C_WHITE}Show this help:${RESET}"
    echo "    ${C_CYAN}./surfbots-admin.sh help${RESET}"
}



# install_systemd_services - Install systemd user services for port-forwards
install_systemd_services() {
    log_info "Installing systemd port-forward services..."
    local script_dir="${SCRIPT_DIR}"
    local systemd_dir="$HOME/.config/systemd/user"
    
    mkdir -p "$systemd_dir"
    
    # Copy unit files
    cp "${script_dir}/scripts/systemd/surfbots-indexer-port-forward.service" "$systemd_dir/" 2>/dev/null || true
    cp "${script_dir}/scripts/systemd/surfbots-search-port-forward.service" "$systemd_dir/" 2>/dev/null || true
    cp "${script_dir}/scripts/systemd/surfbots-mcp-port-forward.service" "$systemd_dir/" 2>/dev/null || true
    cp "${script_dir}/scripts/systemd/surfbots-qdrant-port-forward.service" "$systemd_dir/" 2>/dev/null || true
    cp "${script_dir}/scripts/systemd/surfbots-embedding-port-forward.service" "$systemd_dir/" 2>/dev/null || true
    cp "${script_dir}/scripts/systemd/surfbots-generation-port-forward.service" "$systemd_dir/" 2>/dev/null || true
    cp "${script_dir}/scripts/systemd/surfbots-reranker-port-forward.service" "$systemd_dir/" 2>/dev/null || true
    
    # Reload systemd user daemon
    systemctl --user daemon-reload 2>/dev/null || true
    
    # Enable services (they will auto-start on boot)
    systemctl --user enable surfbots-indexer-port-forward.service 2>/dev/null || true
    systemctl --user enable surfbots-search-port-forward.service 2>/dev/null || true
    systemctl --user enable surfbots-mcp-port-forward.service 2>/dev/null || true
    systemctl --user enable surfbots-qdrant-port-forward.service 2>/dev/null || true
    systemctl --user enable surfbots-embedding-port-forward.service 2>/dev/null || true
    systemctl --user enable surfbots-generation-port-forward.service 2>/dev/null || true
    systemctl --user enable surfbots-reranker-port-forward.service 2>/dev/null || true
    
    log_success "Systemd port-forward services installed and enabled"
}

# uninstall_systemd_services - Uninstall systemd user services
uninstall_systemd_services() {
    log_info "Uninstalling systemd port-forward services..."
    local systemd_dir="$HOME/.config/systemd/user"
    
    # Stop services first
    systemctl --user stop surfbots-indexer-port-forward.service 2>/dev/null || true
    systemctl --user stop surfbots-search-port-forward.service 2>/dev/null || true
    systemctl --user stop surfbots-mcp-port-forward.service 2>/dev/null || true
    systemctl --user stop surfbots-qdrant-port-forward.service 2>/dev/null || true
    systemctl --user stop surfbots-embedding-port-forward.service 2>/dev/null || true
    systemctl --user stop surfbots-generation-port-forward.service 2>/dev/null || true
    systemctl --user stop surfbots-reranker-port-forward.service 2>/dev/null || true
    
    # Disable services
    systemctl --user disable surfbots-indexer-port-forward.service 2>/dev/null || true
    systemctl --user disable surfbots-search-port-forward.service 2>/dev/null || true
    systemctl --user disable surfbots-mcp-port-forward.service 2>/dev/null || true
    systemctl --user disable surfbots-qdrant-port-forward.service 2>/dev/null || true
    systemctl --user disable surfbots-embedding-port-forward.service 2>/dev/null || true
    systemctl --user disable surfbots-generation-port-forward.service 2>/dev/null || true
    systemctl --user disable surfbots-reranker-port-forward.service 2>/dev/null || true
    
    # Remove unit files
    rm -f "$systemd_dir/surfbots-indexer-port-forward.service"
    rm -f "$systemd_dir/surfbots-search-port-forward.service"
    rm -f "$systemd_dir/surfbots-mcp-port-forward.service"
    rm -f "$systemd_dir/surfbots-qdrant-port-forward.service"
    rm -f "$systemd_dir/surfbots-embedding-port-forward.service"
    rm -f "$systemd_dir/surfbots-generation-port-forward.service"
    rm -f "$systemd_dir/surfbots-reranker-port-forward.service"
    
    # Reload systemd user daemon
    systemctl --user daemon-reload 2>/dev/null || true
    
    log_success "Systemd port-forward services uninstalled"
}

show_summary() {
    local script_path="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/scripts/show_summary.py"
    
    if [ -f "$script_path" ]; then
        python3 "$script_path"
    else
        echo "Summary script not found: $script_path"
        exit 1
    fi
}

# Admin build - build image using cluster.sh
admin_build() {
    local service="${1:-all}"
    case "$service" in
        code-indexer|code-search-api|mcp-server|model-embedding|model-generation|model-reranker|all)
            $CLUSTER_SCRIPT build "$service"
            ;;
        *)
            log_error "Unknown service: $service"
            log_info "Supported: code-indexer, code-search-api, mcp-server, model-embedding, model-generation, model-reranker, all"
            exit 1
            ;;
    esac
}

# Admin redeploy - redeploy using recorded image
admin_redeploy() {
    local service="${1}"
    if [ -z "$service" ]; then
        log_error "Service name required"
        log_info "Usage: $0 redeploy <service>"
        exit 1
    fi
    $CLUSTER_SCRIPT redeploy "$service"
}

# Admin rebuild - rebuild and deploy
admin_rebuild() {
    local service="${1}"
    if [ -z "$service" ]; then
        log_error "Service name required"
        log_info "Usage: $0 rebuild <service>"
        exit 1
    fi
    $CLUSTER_SCRIPT rebuild "$service"
}

# Admin restart - restart without build
admin_restart() {
    local service="${1}"
    if [ -z "$service" ]; then
        log_error "Service name required"
        log_info "Usage: $0 restart <service>"
        exit 1
    fi
    $CLUSTER_SCRIPT restart "$service"
}

# start_api - Code Search API port-forward
start_api() {
    start_port_forward "code-search-api" "code-search-api" 8020 8000
}

# configure_cline - Delegate to surfbots-dev
configure_cline() {
    local script_path="${SCRIPT_DIR}/tooling/repo-bootstrap/surfbots-dev"
    if [ -x "$script_path" ]; then
        "$script_path" mcp configure cline
    else
        log_error "surfbots-dev not found at: $script_path"
        exit 1
    fi
}

# configure_copilot - Delegate to surfbots-dev
configure_copilot() {
    local script_path="${SCRIPT_DIR}/tooling/repo-bootstrap/surfbots-dev"
    if [ -x "$script_path" ]; then
        "$script_path" mcp configure copilot
    else
        log_error "surfbots-dev not found at: $script_path"
        exit 1
    fi
}

case "${1:-help}" in
    start) start_cluster ;;
    stop) stop_cluster ;;
    status|stat) show_status ;;
    summary|sum) show_summary ;;
    doctor) show_status ;;  # alias for status
    embed) start_embed ;;
    gen) start_gen ;;
    rerank) start_rerank ;;
    mcp) start_mcp ;;
    qdrant) start_qdrant ;;
    urls) show_urls ;;
    build) admin_build "$2" ;;
    redeploy) admin_redeploy "$2" ;;
    rebuild) admin_rebuild "$2" ;;
    restart) admin_restart "$2" ;;
    api) start_api ;;
    install-systemd) install_systemd_services ;;
    uninstall-systemd) uninstall_systemd_services ;;
    cline) configure_cline ;;
    copilot) configure_copilot ;;
    help|--help|-h) show_help ;;
    *) log_error "Unknown: $1"; show_help; exit 1 ;;
esac
