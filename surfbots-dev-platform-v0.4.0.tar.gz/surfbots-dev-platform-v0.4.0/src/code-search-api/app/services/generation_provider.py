"""Shared provider contract for generation and Development Supervision.

Providers own endpoint-specific transport. Role and profile selection belongs to
the Phase 3 role resolver, never to MCP or the individual supervision tools.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
import logging
import time
from typing import Any, Protocol
from urllib.parse import quote

import httpx

logger = logging.getLogger(__name__)


class GenerationUnavailable(RuntimeError):
    """Raised when a configured generation provider cannot complete a request."""


@dataclass(frozen=True)
class GenerationRequest:
    """Provider-neutral completion request; source content is never logged."""

    system_prompt: str
    user_prompt: str
    max_tokens: int
    temperature: float = 0.1
    repository_id: str = ""
    role: str = ""


class GenerationProvider(Protocol):
    """Stable server-side provider contract for all model-using features."""

    @property
    def configured(self) -> bool: ...

    async def generate(self, request: GenerationRequest) -> dict[str, Any]: ...

    async def list_models(self) -> list[dict[str, Any]]: ...

    async def health_check(self) -> bool: ...

    async def close(self) -> None: ...


class OpenAICompatibleTransport:
    """Shared transport for local and remote OpenAI-compatible endpoints."""

    def __init__(
        self,
        base_url: str,
        timeout_seconds: float,
        max_concurrency: int,
        bearer_token: str | None = None,
        extra_headers: dict[str, str] | None = None,
        client: httpx.AsyncClient | None = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.max_concurrency = max_concurrency
        self.bearer_token = bearer_token
        self.extra_headers = extra_headers or {}
        self._client = client
        self._semaphore = asyncio.Semaphore(max_concurrency)

    @property
    def configured(self) -> bool:
        return bool(self.base_url)

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=self.timeout_seconds)
        return self._client

    @property
    def _headers(self) -> dict[str, str] | None:
        headers = dict(self.extra_headers)
        if self.bearer_token:
            headers["Authorization"] = f"Bearer {self.bearer_token}"
        return headers or None

    async def generate(
        self,
        model: str,
        request: GenerationRequest,
        *,
        endpoint_path: str = "/chat/completions",
        params: dict[str, str] | None = None,
        include_model: bool = True,
        max_tokens_field: str = "max_tokens",
        include_temperature: bool = True,
    ) -> dict[str, Any]:
        if not self.configured:
            raise GenerationUnavailable("No generation endpoint is configured")
        payload = {
            "messages": [
                {"role": "system", "content": request.system_prompt},
                {"role": "user", "content": request.user_prompt},
            ],
            max_tokens_field: request.max_tokens,
        }
        if include_temperature:
            payload["temperature"] = request.temperature
        if include_model:
            payload["model"] = model
        started = time.monotonic()
        async with self._semaphore:
            try:
                response = await (await self._get_client()).post(
                    f"{self.base_url}{endpoint_path}", json=payload, headers=self._headers, params=params
                )
                response.raise_for_status()
                body = response.json()
            except httpx.HTTPStatusError as error:
                error_code = ""
                try:
                    candidate = error.response.json().get("error", {}).get("code")
                    if isinstance(candidate, str) and candidate and len(candidate) <= 80 and candidate.replace("-", "").replace("_", "").isalnum():
                        error_code = f" ({candidate})"
                except (ValueError, AttributeError):
                    pass
                raise GenerationUnavailable(f"Generation service returned {error.response.status_code}{error_code}") from error
            except httpx.HTTPError as error:
                raise GenerationUnavailable(f"Generation service unreachable: {error}") from error
            except ValueError as error:
                raise GenerationUnavailable("Generation service returned a non-JSON body") from error
        try:
            text = body["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as error:
            raise GenerationUnavailable("Generation response had no completion content") from error
        usage = body.get("usage", {})
        logger.info(
            "generation provider=%s role=%s repository=%s duration=%.2fs prompt_tokens=%s completion_tokens=%s",
            "authenticated" if self.bearer_token else "local",
            request.role or "unknown",
            request.repository_id or "unknown",
            time.monotonic() - started,
            usage.get("prompt_tokens"),
            usage.get("completion_tokens"),
        )
        return {
            "text": text,
            "duration_seconds": round(time.monotonic() - started, 3),
            "prompt_tokens": usage.get("prompt_tokens"),
            "completion_tokens": usage.get("completion_tokens"),
        }

    async def list_models(self) -> list[dict[str, Any]]:
        if not self.configured:
            return []
        try:
            response = await (await self._get_client()).get(f"{self.base_url}/models", headers=self._headers)
            response.raise_for_status()
            body = response.json()
        except (httpx.HTTPError, ValueError) as error:
            raise GenerationUnavailable("Generation provider model discovery failed") from error
        models = body.get("data") or body.get("models") or []
        if not isinstance(models, list):
            raise GenerationUnavailable("Generation provider returned an invalid model list")
        return [model for model in models if isinstance(model, dict)]

    async def health_check(self) -> bool:
        if not self.configured:
            return False
        try:
            response = await (await self._get_client()).get(f"{self.base_url}/health", headers=self._headers)
            return response.is_success
        except httpx.HTTPError:
            return False

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None


class LocalOpenAICompatibleProvider:
    """The existing llama.cpp service, preserving model=default and concurrency one."""

    def __init__(self, endpoint: str, timeout_seconds: float, max_concurrency: int, transport: OpenAICompatibleTransport | None = None):
        self._transport = transport or OpenAICompatibleTransport(
            base_url=f"{endpoint.rstrip('/')}/v1" if endpoint and not endpoint.rstrip("/").endswith("/v1") else endpoint,
            timeout_seconds=timeout_seconds,
            max_concurrency=max_concurrency,
        )

    @property
    def configured(self) -> bool:
        return self._transport.configured

    @property
    def semaphore(self) -> asyncio.Semaphore:
        return self._transport._semaphore

    async def generate(self, request: GenerationRequest) -> dict[str, Any]:
        return await self._transport.generate("default", request)

    async def list_models(self) -> list[dict[str, Any]]:
        return await self._transport.list_models()

    async def health_check(self) -> bool:
        return await self._transport.health_check()

    async def close(self) -> None:
        await self._transport.close()


class LocalOpenAIProvider:
    """An externally managed local OpenAI-compatible provider with optional authentication."""

    def __init__(
        self,
        base_url: str,
        model: str,
        bearer_token: str | None = None,
        timeout_seconds: float = 300.0,
        max_concurrency: int = 1,
        transport: OpenAICompatibleTransport | None = None,
    ):
        self.model = model
        self._transport = transport or OpenAICompatibleTransport(
            base_url=base_url,
            timeout_seconds=timeout_seconds,
            max_concurrency=max_concurrency,
            bearer_token=bearer_token,
        )

    @property
    def configured(self) -> bool:
        return bool(self.model) and self._transport.configured

    async def generate(self, request: GenerationRequest) -> dict[str, Any]:
        if not self.configured:
            raise GenerationUnavailable("Local OpenAI-compatible provider is not configured")
        return await self._transport.generate(self.model, request)

    async def list_models(self) -> list[dict[str, Any]]:
        return await self._transport.list_models()

    async def health_check(self) -> bool:
        return await self._transport.health_check()

    async def close(self) -> None:
        await self._transport.close()


class OpenAICompatibleProvider:
    """A remote OpenAI-compatible provider bound to a selected profile model."""

    def __init__(
        self,
        base_url: str,
        model: str,
        bearer_token: str,
        timeout_seconds: float,
        max_concurrency: int,
        transport: OpenAICompatibleTransport | None = None,
    ):
        self.model = model
        self._transport = transport or OpenAICompatibleTransport(
            base_url=base_url,
            timeout_seconds=timeout_seconds,
            max_concurrency=max_concurrency,
            bearer_token=bearer_token,
        )

    @property
    def configured(self) -> bool:
        return bool(self.model) and self._transport.configured

    async def generate(self, request: GenerationRequest) -> dict[str, Any]:
        if not self.configured:
            raise GenerationUnavailable("Remote generation provider is not configured")
        return await self._transport.generate(self.model, request)

    async def list_models(self) -> list[dict[str, Any]]:
        return await self._transport.list_models()

    async def health_check(self) -> bool:
        return await self._transport.health_check()

    async def close(self) -> None:
        await self._transport.close()


class AzureOpenAIProvider:
    """Azure OpenAI deployment endpoint using a Secret-backed API key."""

    def __init__(
        self,
        base_url: str,
        deployment_name: str,
        api_key: str,
        timeout_seconds: float,
        max_concurrency: int,
        api_version: str = "2024-02-15-preview",
        transport: OpenAICompatibleTransport | None = None,
    ):
        self.deployment_name = deployment_name
        self.api_version = api_version
        self._transport = transport or OpenAICompatibleTransport(
            base_url=base_url,
            timeout_seconds=timeout_seconds,
            max_concurrency=max_concurrency,
            extra_headers={"api-key": api_key},
        )

    @property
    def configured(self) -> bool:
        return bool(self.deployment_name) and self._transport.configured

    async def generate(self, request: GenerationRequest) -> dict[str, Any]:
        if not self.configured:
            raise GenerationUnavailable("Azure OpenAI provider is not configured")
        try:
            return await self._transport.generate(
                self.deployment_name,
                request,
                endpoint_path=f"/openai/deployments/{quote(self.deployment_name, safe='')}/chat/completions",
                params={"api-version": self.api_version},
                include_model=False,
                max_tokens_field="max_completion_tokens",
                include_temperature=False,
            )
        except GenerationUnavailable as error:
            raise GenerationUnavailable(
                f"Azure OpenAI deployment '{self.deployment_name}' failed ({error}); "
                f"verify the deployment name and API version {self.api_version}"
            ) from error

    async def list_models(self) -> list[dict[str, Any]]:
        # Azure OpenAI does not offer a deployment-listing endpoint to this API.
        return []

    async def health_check(self) -> bool:
        return self.configured

    async def close(self) -> None:
        await self._transport.close()