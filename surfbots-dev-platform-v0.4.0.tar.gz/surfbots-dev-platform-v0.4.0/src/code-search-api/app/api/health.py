"""Health check endpoints."""
from fastapi import APIRouter
import logging

from ..services.indexer_client import indexer_client
from ..services.search_metrics import get_memory_operation_metrics, get_search_request_metrics
from ..core.config import settings

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/health/live")
async def health_live():
    """Liveness probe - always returns 200 if the service is running."""
    return {"status": "ok"}


@router.get("/health/ready")
async def health_ready():
    """Readiness probe - checks if the service is ready to accept traffic."""
    indexer_connected = False
    
    try:
        # Test indexer connection
        result = await indexer_client.list_repositories()
        indexer_connected = "error" not in result
    except Exception as e:
        logger.warning(f"Indexer not ready: {e}")
    
    return {
        "status": "ok" if indexer_connected else "degraded",
        "indexer_connected": indexer_connected,
        "cache_status": "ok"
    }


@router.get("/health/startup")
async def health_startup():
    """Startup probe - used during service initialization."""
    return {"status": "starting"}


@router.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint."""
    return {
        "service": "code-search-api",
        "version": "0.1.0",
        "indexer_url": settings.indexer_url,
        "cache_ttl_seconds": settings.cache_ttl_seconds,
        "max_results_default": settings.max_results_default,
        "max_results_limit": settings.max_results_limit,
        "search_requests": get_search_request_metrics(),
        "memory_operations": get_memory_operation_metrics(),
    }