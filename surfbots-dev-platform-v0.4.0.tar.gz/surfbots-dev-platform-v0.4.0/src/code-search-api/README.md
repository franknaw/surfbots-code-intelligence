# surfbots-code-intelligence

**Semantic code intelligence for AI-assisted development.**

[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://www.python.org/)

## Overview

The **surfbots-code-intelligence** subsystem provides persistent semantic understanding of source repositories to AI coding agents. Rather than forcing agents to repeatedly rediscover repository structure from raw files, Code Intelligence delivers:

- **Repository-aware code search** using hybrid retrieval (dense embeddings + sparse BM25)
- **Symbol and reference discovery** via Tree-sitter parsing for Python, TypeScript, and more
- **Vector-backed indexing** in Qdrant for fast semantic similarity search
- **Model flexibility** with configurable embedding, reranking, and generation providers
- **Repository isolation** ensuring cross-repository queries never leak context

Code Intelligence is a core subsystem of the **surfbots-dev-platform**, serving as the persistent code understanding layer that enables AI agents to maintain repository context across tasks.

### What's Inside

| Component | Description |
|-----------|-------------|
| **Code Indexer** | Parses and indexes code repositories with symbol-aware Tree-sitter parsing |
| **Code Search API** | REST API for code search, symbol lookup, and file retrieval |
| **MCP Server** | Model Context Protocol server for AI agent integration (15 tools) |
| **Qdrant** | Vector database for semantic search and retrieval (1024-dimensional embeddings) |
| **Model Services** | Embedding (Qwen3-Embedding-0.6B), reranking (BGE-v2-m3), and generation models |

## Key Capabilities

### Repository Indexing

Code Intelligence indexes repositories with intelligent parsing and metadata capture:

- **Git-aware file detection** uses `git ls-files` for accurate file enumeration in Git repositories
- **Tree-sitter parsing** extracts symbol definitions, function signatures, and class hierarchies for Python, TypeScript, and other supported languages
- **Incremental updates** track file SHA-256 hashes and only reindex changed files
- **Repository isolation** assigns each repository a unique `repository_id` preventing cross-contamination
- **Managed snapshots** host the CLI syncs canonical working trees into an isolated index workspace

```bash
# Register a repository
surfbots-dev repo add /path/to/repository

# Trigger indexing
surfbots-dev repo index repository-name

# Trigger reindex
surfbots-dev repo reindex repository-name
```

### Semantic and Hybrid Search

The retrieval pipeline combines multiple search strategies for optimal results:

```
User Query
    ↓
Embedding Model (Qwen3-Embedding-0.6B, 1024-dim)
    ↓
Qdrant Vector Retrieval (cosine distance)
    ↓
BM25 Lexical Search (optional)
    ↓
Reranker (BGE-v2-m3) for relevance scoring
    ↓
Bounded Results (configurable limit)
```

Search results are cached in-process with TTL, and cached entries automatically retire on reindex.

### Code-Aware Retrieval

Code Intelligence provides specialized code search capabilities:

| Operation | Description |
|-----------|-------------|
| `search_code` | Semantic code search with repository, language, and file path filtering |
| `get_file` | Retrieve full file content by repository and path |
| `get_file_range` | Retrieve specific line ranges from files |
| `find_symbol` | Find where a symbol is defined across repositories |
| `find_references` | Find all usages of a symbol |

All operations respect repository boundaries via `repository_id`.

### MCP Integration

Code Intelligence exposes 15 MCP tools for seamless AI agent integration:

| Tool | Purpose |
|------|---------|
| `search_code` | Search for code snippets across repositories |
| `get_file` | Retrieve file content by path |
| `get_file_range` | Get specific line range from file |
| `find_symbol` | Find symbol definitions |
| `find_references` | Find symbol usages |
| `repository_status` | Get repository indexing status |
| `get_recent_context` | Get bounded recent Development Memory |
| `search_repository_memory` | Search Development Memory semantically |
| `write_repository_memory` | Store Development Memory checkpoints |
| `refine_task` | Create task specifications via Devstral |
| `collaborate_task` | Resolve architectural decisions |
| `development_task_checkpoint` | Perform supervision checkpoints |
| `review_changes` | Review implementation against specification |
| `development_supervision_status` | Report supervision tool usage and tokens |
| `complete_development_task` | Mark development tasks as complete |

### Repository Isolation

Each repository is assigned a unique `repository_id` that:

- Prevents accidental cross-repository retrieval
- Isolates Development Memory per repository
- Enables multiple repositories to coexist in a single Qdrant collection (`code-index-{repo_id}`)
- Survives restarts and cluster recreations via persistent storage

### Local / Private Operation

Code Intelligence is designed for local/self-hosted operation:

- **Model services** run locally (embedding, generation, reranking)
- **Qdrant** runs as a local Kubernetes pod
- **Code Indexer** and **Code Search API** are local services
- **No external API calls** required when using local model providers
- **Source code remains on infrastructure** you control

Configuration via environment variables and Kubernetes Secrets ensures credentials are never exposed.

### Models

| Role | Model | Dimensions | Provider |
|------|-------|------------|----------|
| Embedding | `Qwen/Qwen3-Embedding-0.6B` | 1024 | Sentence Transformers |
| Reranking | `BAAI/bge-reranker-v2-m3` | - | Local model |
| Generation | `Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF` | - | llama.cpp (GGUF) |

Model selection is configurable via profile activation. Switching between `local-lightweight` and `local-quality` profiles only changes the generation model without requiring reindexing.

### Qdrant

Qdrant serves as the vector database for semantic search:

- **Collection**: `code-index-{repository_id}` per repository
- **Dimensions**: 1024 (from embedding model)
- **Distance metric**: Cosine
- **Persistence**: Host-mounted storage at `~/.local/surfbots/data/qdrant/`

```bash
# Qdrant Admin UI
http://localhost:6333/dashboard
```

### Architecture

```mermaid
flowchart TB
    subgraph Agent
        Cline[Cline / AI Agent]
    end

    subgraph MCP
        MCP[MCP Server<br/>port 8023]
    end

    subgraph CodeSearchAPI
        CSAPI[Code Search API<br/>port 8020]
    end

    subgraph Services
        CI[Code Indexer<br/>port 8021]
        EMBED[Model Embedding<br/>port 8024]
        RERANK[Model Reranker<br/>port 8026]
    end

    subgraph Storage
        QDRANT[Qdrant<br/>port 6333]
    end

    Cline --> MCP
    MCP --> CSAPI
    CSAPI --> CI
    CSAPI --> QDRANT
    CI --> EMBED
    CI --> RERANK
    CI --> QDRANT

    style QDRANT fill:#e1f5ff
    style EMBED fill:#e8f5e9
    style RERANK fill:#fff3e0
```

### API / MCP Usage

**HTTP API (Code Search API):**
```bash
# Semantic code search
curl http://localhost:8020/api/v1/search \
  -H "Content-Type: application/json" \
  -d '{"query":"find login function","repository":"my-repo","limit":5}'

# Get file content
curl "http://localhost:8020/api/v1/files/content?repository_id=my-repo&path=src/main.py"
```

**MCP Tools:**
```bash
curl -X POST http://localhost:8023/mcp \
  -H "Content-Type: application/json" \
  -d '{
    "jsonrpc":"2.0",
    "id":1,
    "method":"tools/call",
    "params":{
      "name":"search_code",
      "arguments":{
        "query":"find login function",
        "repository":"my-repo",
        "limit":5
      }
    }
  }'
```

### Installation / Bootstrap

Code Intelligence is part of the surfbots-dev-platform bootstrap:

```bash
# Start platform
./surfbots-admin.sh start

# Verify status
./surfbots-admin.sh status

# Add repository
surfbots-dev repo add /path/to/repository

# Index repository
surfbots-dev repo index repository-name
```

### Configuration

Key configuration via environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `HOST` | 0.0.0.0 | Service host |
| `PORT` | 8000 | Service port |
| `INDEXER_URL` | http://code-indexer:8000 | Code Indexer URL |
| `QDRANT_URL` | http://qdrant:6333 | Qdrant URL |
| `EMBEDDING_ENDPOINT` | http://localhost:8001 | Embedding model endpoint |
| `RERANKER_ENDPOINT` | http://localhost:8002 | Reranker model endpoint |
| `CACHE_TTL_SECONDS` | 300 | Cache TTL in seconds |

### Troubleshooting

| Issue | Diagnostic |
|-------|------------|
| Search returns no results | Verify indexer has indexed the repository: `kubectl logs -n surfbots-dev-platform -l app=code-indexer` |
| Qdrant connection fails | Check Qdrant status: `kubectl get pods -n surfbots-dev-platform | grep qdrant` |
| Code Search API unavailable | Verify port-forward: `./surfbots-admin.sh api` and check `./surfbots-admin.sh urls` |
| MCP tools not responding | Check MCP server: `curl http://localhost:8023/mcp` |

---

**Version**: v0.4.0  
**Repository**: [surfbots/surfbots-dev-platform](https://github.com/surfbots/surfbots-dev-platform)
