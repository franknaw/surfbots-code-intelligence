"""Task refinement orchestration.

Turns a development request into an implementation specification, grounded in
repository evidence that actually fit the generation context. Everything here is
scoped to one repository; no cross-repository retrieval is possible.
"""
from typing import Any, Optional
import logging

from ..generation_client import GenerationUnavailable
from ..search_service import search_service
from .parsing import InvalidGenerationResponse, parse_with_retry
from .roles import get_role, new_budget, role_runner
from .checkpoint import persist_refinement_evidence

logger = logging.getLogger(__name__)

REFINER_SCHEMA = {
    "objective": str,
    "requirements": list,
    "constraints": list,
    "relevant_context": list,
    "tests": list,
    "acceptance_criteria": list,
}

MAX_CODE_SNIPPETS = 5
MAX_MEMORY_RECORDS = 3
SNIPPET_CHARS = 600


class RepositoryNotFound(LookupError):
    """Raised when the requested repository is not registered."""


async def _resolve(repository: str) -> tuple[str, dict[str, Any]]:
    """Resolve a name or ID and confirm the repository exists."""
    status = await search_service.get_repository_status(repository)
    if "error" in status:
        raise RepositoryNotFound(f"Repository not found: {repository}")
    return status.get("repository_id") or repository, status


async def _gather_evidence(repository_id: str, request: str, budget) -> list[str]:
    """Offer evidence to the budget in priority order, whole sections only."""
    sections: list[str] = []

    try:
        results = await search_service.search(
            query=request, repository_id=repository_id, limit=MAX_CODE_SNIPPETS
        )
    except Exception:
        logger.warning("Code retrieval failed during refinement", exc_info=True)
        results = {"results": []}

    for item in results.get("results", []):
        snippet = (item.get("chunk_content") or "")[:SNIPPET_CHARS]
        if not snippet:
            continue
        label = f"code:{item.get('file_path')}"
        budget.offer(label, f"File {item.get('file_path')}:\n{snippet}")
        if label in budget.included:
            sections.append(f"File {item.get('file_path')}:\n{snippet}")

    try:
        memory = await search_service.indexer.get_session_memory_context(
            repository_id, limit=MAX_MEMORY_RECORDS
        )
    except Exception:
        logger.warning("Memory retrieval failed during refinement", exc_info=True)
        memory = {}

    for record in (memory.get("records") or [])[:MAX_MEMORY_RECORDS]:
        summary = record.get("summary", "")
        if not summary:
            continue
        label = f"memory:{record.get('memory_id')}"
        budget.offer(label, summary)
        if label in budget.included:
            sections.append(f"Prior decision: {summary}")

    return sections


def _build_prompt(
    request: str,
    status: dict[str, Any],
    evidence: list[str],
    current_context: Optional[str],
    constraints: Optional[list[str]],
) -> str:
    parts = [f"Development request:\n{request}"]

    parts.append(
        "Repository: {name} (indexed {files} files, {chunks} chunks)".format(
            name=status.get("repository_name") or status.get("repository_id"),
            files=status.get("files_indexed"),
            chunks=status.get("chunks_indexed"),
        )
    )

    if current_context:
        parts.append(f"Caller-supplied context:\n{current_context}")
    if constraints:
        parts.append("Caller-supplied constraints:\n" + "\n".join(f"- {c}" for c in constraints))

    if evidence:
        parts.append("Repository evidence:\n\n" + "\n\n".join(evidence))
    else:
        parts.append(
            "No repository evidence was retrieved. Treat architecture details as assumptions "
            "and say so in relevant_context."
        )

    return "\n\n".join(parts)


async def refine_task(
    repository: str,
    request: str,
    current_context: Optional[str] = None,
    constraints: Optional[list[str]] = None,
    development_task_id: Optional[str] = None,
) -> dict[str, Any]:
    """Produce an implementation specification for a development request."""
    repository_id, status = await _resolve(repository)

    role = get_role("promptRefiner")
    budget = new_budget(role)

    if current_context:
        budget.offer("caller_context", current_context)
    evidence = await _gather_evidence(repository_id, request, budget)

    prompt = _build_prompt(request, status, evidence, current_context, constraints)

    async def call(correction):
        return await role_runner.run(role, prompt, repository_id=repository_id, correction=correction)

    specification, raw = await parse_with_retry(call, REFINER_SCHEMA)
    
    # Persist refinement evidence for integrity validation
    await persist_refinement_evidence(
        repository_id=repository_id,
        development_task_id=development_task_id,
        request=request,
        specification=specification,
    )

    return {
        "repository_id": repository_id,
        "development_task_id": development_task_id,
        **specification,
        # Deterministic, computed from what fit; never self-reported by the model.
        "context": {
            "included": budget.included,
            "omitted": budget.omitted,
            "complete": budget.complete,
            "budget_tokens": budget.limit_tokens,
            "used_tokens": budget.used_tokens,
        },
        "generation": {
            "role": role.name,
            "prompt_version": role.prompt_version,
            "duration_seconds": raw.get("duration_seconds"),
            "prompt_tokens": raw.get("prompt_tokens"),
            "completion_tokens": raw.get("completion_tokens"),
            "profile_id": (raw.get("runtime_execution") or {}).get("profile_id"),
            "provider": (raw.get("runtime_execution") or {}).get("provider"),
            "connection_id": (raw.get("runtime_execution") or {}).get("connection_id"),
            "model": (raw.get("runtime_execution") or {}).get("model"),
        },
    }
