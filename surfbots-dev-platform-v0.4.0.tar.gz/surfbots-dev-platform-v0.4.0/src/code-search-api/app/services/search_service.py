"""Search service with caching and result normalization."""
import logging
import time
from typing import Optional, Dict, Any, List, Tuple
from datetime import datetime

from .indexer_client import indexer_client
from .cache import cache
from ..core.config import settings

logger = logging.getLogger(__name__)

# How long an index version is reused before re-checking, in seconds.
INDEX_VERSION_TTL = 10


class SearchService:
    """Search service with caching and result normalization."""
    
    def __init__(self):
        self.indexer = indexer_client
        self._index_versions: Dict[str, Tuple[str, float]] = {}
    
    async def resolve_repository_id(self, repository_name: str) -> Optional[str]:
        """Map a repository name or ID to its indexed repository_id."""
        listing = await self.indexer.list_repositories()
        for repo in listing.get("repositories", []):
            if repository_name in (repo.get("name"), repo.get("repository_id")):
                return repo.get("repository_id")
        return None

    async def _index_version(self, repository_id: Optional[str]) -> str:
        """Identify the current index generation so a reindex retires cached entries.

        Briefly memoized so this costs one status call per window, not one per search.
        """
        if not repository_id:
            return "none"

        cached = self._index_versions.get(repository_id)
        if cached and time.monotonic() - cached[1] < INDEX_VERSION_TTL:
            return cached[0]

        status = await self.indexer.get_repository_status(repository_id)
        if "error" in status:
            version = "unknown"
        else:
            # Status is part of the version so a rebuild in progress is not served from cache.
            version = f"{status.get('status')}:{status.get('indexed_at')}"
        self._index_versions[repository_id] = (version, time.monotonic())
        return version

    async def search(
        self,
        query: str,
        repository_id: Optional[str] = None,
        repository_name: Optional[str] = None,
        language: Optional[str] = None,
        file_path: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
        include_related_memory: bool = False,
    ) -> Dict[str, Any]:
        """Perform semantic search with caching and normalization."""
        # Callers may identify a repository by name, but Qdrant filters on the ID.
        if not repository_id and repository_name:
            repository_id = await self.resolve_repository_id(repository_name)

        # Check cache first
        cache_filters = {
            "language": language,
            "file_path": file_path,
            "include_related_memory": include_related_memory,
            "index_version": await self._index_version(repository_id),
        }
        cache_key = cache.make_key(repository_id, query, cache_filters, limit, offset)
        cached = cache.get(cache_key)
        if cached:
            logger.info(f"Cache hit for query: {query[:50]}...")
            return cached["value"]
        
        # Call indexer
        results = await self.indexer.search(
            query=query,
            repository_id=repository_id,
            language=language,
            file_path=file_path,
            limit=min(limit, settings.max_results_limit),
            offset=offset
        )
        
        # Normalize results
        normalized = self._normalize_search_results(
            results,
            repository_id,
            repository_name,
            query
        )
        
        # Cache the result
        cache.set_by_key(cache_key, normalized)
        
        if include_related_memory and repository_id:
            memory = await self.indexer.search_session_memory(
                repository_id, query, limit=3, retention_class=["durable"]
            )
            normalized["related_memory"] = memory.get("records", []) if "error" not in memory else []
        return normalized
    
    def _normalize_search_results(
        self,
        results: Dict[str, Any],
        repository_id: Optional[str],
        repository_name: Optional[str],
        query: str
    ) -> Dict[str, Any]:
        """Normalize search results."""
        normalized_results = []
        
        for r in results.get("results", []):
            payload = r.get("payload", {})
            normalized_results.append({
                "id": r.get("id"),
                "score": r.get("score", 0),
                "repository_id": payload.get("repository_id") or repository_id,
                "repository_name": repository_name,
                "file_path": payload.get("file_path", ""),
                "chunk_content": payload.get("content", ""),
                "chunk_index": payload.get("chunk_index", 0),
                "language": payload.get("language")
                or payload.get("file_info", {}).get("language", "unknown"),
                "line_numbers": payload.get("line_numbers"),
                "symbol_name": payload.get("symbol_name")
            })
        
        return {
            "results": normalized_results,
            "total": results.get("total", 0),
            "repository_id": repository_id,
            "repository_name": repository_name,
            "query": query,
            "timestamp": datetime.now().isoformat()
        }
    
    async def search_symbols(
        self,
        query: str,
        repository_id: Optional[str] = None,
        symbol_type: Optional[str] = None,
        limit: int = 20,
        offset: int = 0
    ) -> Dict[str, Any]:
        """Search for symbols."""
        results = await self.indexer.search_symbols(
            query=query,
            repository_id=repository_id,
            symbol_type=symbol_type,
            limit=min(limit, settings.max_results_limit),
            offset=offset
        )
        
        return {
            "symbols": results.get("symbols", []),
            "total": results.get("total", 0),
            "repository_id": repository_id,
            "query": query,
            "timestamp": datetime.now().isoformat()
        }
    
    async def list_files(
        self,
        repository_id: Optional[str] = None,
        directory: Optional[str] = None,
        language: Optional[str] = None,
        limit: int = 100,
        offset: int = 0
    ) -> Dict[str, Any]:
        """List files in a repository."""
        results = await self.indexer.list_files(
            repository_id=repository_id,
            directory=directory,
            limit=min(limit, settings.max_results_limit * 10),
            offset=offset
        )
        
        # Filter by language if specified
        files = results.get("files", [])
        if language:
            files = [f for f in files if f.get("language") == language]
        
        return {
            "files": files[offset:offset + limit],
            "total": len(files),
            "repository_id": repository_id,
            "directory": directory,
            "timestamp": datetime.now().isoformat()
        }
    
    async def get_repository_status(
        self,
        repository_id: str
    ) -> Dict[str, Any]:
        """Get repository indexing status by repository ID or name."""
        status = await self.indexer.get_repository_status(repository_id)
        if "error" not in status:
            return status

        resolved = await self.resolve_repository_id(repository_id)
        if resolved and resolved != repository_id:
            return await self.indexer.get_repository_status(resolved)
        return status
    
    async def close(self):
        """Clean up resources."""
        await self.indexer.close()


# Global service instance
search_service = SearchService()