# Surfbots Development Supervision

Surfbots Development Supervision is part of the normal development workflow.

For substantial development tasks, supervision is not an optional utility and must not be deferred until the end of implementation.

The Development Supervision roles are:

- `refine_task` — establish the repository-grounded task specification
- `development_task_checkpoint` — perform mandatory stateful supervision at meaningful phase transitions
- `collaborate_task` — resolve ad-hoc architectural decisions, blockers, conflicts, or uncertainty
- `review_changes` — perform final implementation review after required checkpoints are satisfied
- `development_supervision_status` — report authoritative workflow state, usage, and token consumption

The implementation agent and Development Supervision models are separate execution identities.

## Development Task Identity

Every substantial supervised task has one stable `development_task_id`.

The originating `refine_task` creates or returns that ID.

After refinement:

- preserve the returned `development_task_id`
- reuse that exact ID for every `development_task_checkpoint`
- reuse it for every `collaborate_task`
- reuse it for `review_changes`
- reuse it for task-scoped supervision status and related Development Memory operations
- never silently create or substitute another task ID

A new `development_task_id` represents a new development task, not another phase of the same task.

If task identity cannot be recovered, stop and recover task continuity rather than starting another supervision task.

## Development Supervision Visibility

Whenever a Development Supervision MCP tool is invoked, surface the meaningful correspondence in the agent conversation so the user can observe the supervision process.

Do not expose raw internal reasoning. Show the useful task, recommendation, decision, evidence, and outcome.

### `refine_task`

Display:

```text
Development Supervision — Task Refinement

Request:
<concise description of what was sent to the supervisor>

Supervisor:
<meaningful refinement/specification returned by refine_task>

Agent:
<how the refinement affects the implementation plan>
```

Also preserve and surface the returned `development_task_id`.

### `development_task_checkpoint`

Display:

```text
Development Supervision — Checkpoint

Phase:
<checkpoint phase>

Agent State:
<concise implementation state and evidence supplied>

Supervisor:
<meaningful assessment/recommendation returned by the checkpoint>

Workflow:
<completed checkpoints, missing checkpoints, and next required action>

Agent:
<what will be done as a result>
```

Do not hide:

- risks
- warnings
- architectural conflicts
- missing requirements
- `requires_user_decision=true`
- missing required checkpoints

If `requires_user_decision=true`, stop at the appropriate point and present the decision to the user.

### `collaborate_task`

Display:

```text
Development Supervision — Collaboration

Agent:
<the engineering question/problem sent to the collaborator>

Collaborator:
<the meaningful assessment/recommendation returned>

Agent:
<what will be done as a result>
```

Do not hide collaborator disagreements, risks, warnings, alternative approaches, or `requires_user_decision=true`.

If `requires_user_decision=true`, stop and present the decision to the user rather than silently choosing.

### `review_changes`

Display:

```text
Development Supervision — Review

Submitted:
<concise description of implementation/change set reviewed>

Reviewer:
<verdict, findings, risks, omissions, or no-issues result>

Agent:
<response to the review, including fixes that will be made>
```

If `review_changes` returns `needs_changes`, visibly explain each material finding before making the corresponding correction.

### `development_supervision_status`

Before final completion, invoke `development_supervision_status` and use its returned workflow and usage data as authoritative.

Do not estimate or reconstruct authoritative usage when the status tool provides it.

## PRE: Task Refinement

Before planning or modifying code for a substantial development task, invoke:

`refine_task`

A task is substantial if it involves one or more of:

- multiple files
- new functionality
- architecture or design decisions
- API changes
- persistence or database changes
- authentication, authorization, or security
- deployment or Kubernetes changes
- configuration, provider, or model changes
- concurrency or background processing
- significant refactoring
- behavioral compatibility
- data migration
- indexing or retrieval changes
- unclear or incomplete requirements

Small mechanical tasks such as obvious typo fixes, formatting-only changes, and simple mechanical renames do not require the full substantial-task workflow unless the user explicitly requests supervision.

When uncertain whether refinement is warranted, prefer refinement.

Use the refined result as the implementation specification.

Do not perform a complete implementation design first and invoke `refine_task` afterward.

### Refinement Frequency

`refine_task` normally runs exactly once per substantial `development_task_id`.

After refinement:

- do not repeatedly refine because new implementation details were discovered
- use `development_task_checkpoint` for required phase supervision
- use `collaborate_task` for ad-hoc architectural decisions or course corrections
- invoke `refine_task` again only when the user materially changes task scope or requirements

## DURING: Stateful Checkpoint Supervision

For substantial tasks, mandatory implementation-phase supervision uses:

`development_task_checkpoint`

The checkpoint must actually invoke the configured collaborator role. Recording metadata without supervisor execution does not satisfy the checkpoint.

### Required Normal Workflow

The normal minimum workflow is:

`refine_task → post_investigation → post_implementation or milestone_complete → pre_review → review_changes`

Additional checkpoints apply when relevant.

### `post_investigation`

Invoke after repository investigation and before substantial implementation.

Provide:

- refined specification
- current repository evidence
- proposed implementation approach
- expected files/components to change
- architectural constraints
- unresolved assumptions or risks

Do not begin substantial implementation until this checkpoint succeeds.

### `post_implementation`

Invoke after a substantial implementation result and before proceeding to final validation or another major phase.

Provide:

- what changed
- current implementation state
- observed runtime evidence
- remaining risks

### `milestone_complete`

Use for multi-stage tasks when a major implementation milestone is complete.

Provide:

- completed milestone
- deterministic evidence
- next milestone
- remaining risks or assumptions

### `post_test`

Invoke when meaningful deterministic test or runtime evidence exists.

Provide exact observed results.

Do not claim tests passed unless their output was observed.

### `failure_analysis`

Invoke when:

- a non-trivial test/runtime failure occurs
- repeated debugging begins looping
- more than one plausible root cause exists
- a workaround may violate architecture or lifecycle constraints
- repository/runtime evidence contradicts an important assumption

Provide:

- observed failure
- attempted fixes
- current evidence
- suspected causes
- relevant constraints

Do not repeatedly investigate the same symptom without this checkpoint.

Simple syntax errors, typos, missing imports, and other clearly mechanical defects do not require `failure_analysis`.

### `pre_review`

Invoke immediately before final `review_changes`.

Provide:

- completed implementation
- acceptance evidence
- exact deterministic test results
- unresolved limitations
- intentionally deferred work

Required substantial-task checkpoints must exist before final review can proceed.

## DURING: Ad-Hoc Collaboration

`collaborate_task` is advisory collaboration outside the mandatory phase-transition workflow.

Use it for:

- unresolved architectural decisions
- multiple viable approaches
- unexpected constraints
- failed assumptions
- security implications
- conflicting requirements
- API/interface uncertainty
- compatibility or deployment concerns
- discoveries that materially change the plan
- product or preference decisions requiring user input

Do not call `collaborate_task` for every edit or routine choice.

Each invocation must contain a concrete question or decision.

Do not use repeated `refine_task` calls as a substitute for collaboration.

### Current State Consistency

When `collaborate_task` or `development_task_checkpoint` is invoked, the supplied current state is authoritative task evidence.

The supervisor must:

1. distinguish completed work from remaining work
2. avoid recommending repetition of already completed work unless explicit revalidation is requested
3. prioritize unfinished or unvalidated work
4. use completed work only as relevant background
5. distinguish current evidence from stale Development Memory or documentation

Example:

```text
Correct:
current_state:
"The standalone repo-add path is validated end-to-end.
The public bootstrap path remains unvalidated."

recommendation:
"Validate the public bootstrap path."

Incorrect:
recommendation:
"Validate the standalone repo-add path again."
```

## Broad Read-Only Collaboration

For broad system-understanding requests, construct a comprehensive collaborator assignment without asking the user to choose a focus when the parent task already provides sufficient context.

Relevant areas may include:

- overall architecture and major components
- component interactions and data flow
- deployment/runtime infrastructure
- APIs and endpoints
- storage and persistence
- indexing/search/RAG flows
- MCP integration
- model services
- configuration management
- developer workflows

Use collaborator recommendations as advisory engineering input, not unquestionable authority.

If `requires_user_decision=true`, stop and ask the user for the required product or preference decision.

## POST: Change Review

After implementation, required checkpoints, and deterministic validation, invoke:

`review_changes`

Use the same `development_task_id`.

Provide:

- original user intent
- refined specification
- acceptance criteria
- actual changed files or diff
- relevant current repository evidence
- exact deterministic test results

The backend review gate is authoritative.

For substantial tasks, `review_changes` must not proceed when required checkpoints are missing.

If review is rejected for missing checkpoints:

- do not bypass the gate
- do not create another task ID
- complete the named missing checkpoint
- retry review

Review should evaluate:

- missing requirements
- incorrect behavior
- regressions
- architectural violations
- security issues
- repository-isolation problems
- task-isolation problems
- persistence problems
- error-handling gaps
- incomplete implementation
- missing tests
- unintended side effects

Model review does not replace deterministic testing.

## REVIEW/FIX LOOP

If `review_changes` returns `needs_changes`:

1. inspect every finding
2. validate each finding against current repository truth
3. fix valid findings
4. rerun relevant deterministic tests
5. complete any newly applicable checkpoint
6. invoke `review_changes` again using the same task ID

Perform at most two automatic review/fix cycles.

After two cycles, report remaining meaningful issues to the user rather than entering an indefinite loop.

## SOURCE OF TRUTH

Use this priority:

1. explicit user instructions and supplied task facts
2. current repository code and deterministic runtime/test evidence
3. current MCP and Surfbots Code Intelligence results
4. Development Memory
5. model assumptions

Current repository evidence overrides stale memory.

## FAILURE BEHAVIOR

Required supervision boundaries are fail-closed.

If `refine_task`, a required `development_task_checkpoint`, or `review_changes` fails:

- stop at that supervision boundary
- report the exact failure
- do not pretend the step succeeded
- do not bypass supervision
- do not continue implementation assuming the step will work later
- do not silently create another task ID

If an optional/ad-hoc `collaborate_task` fails, report the failure truthfully and determine whether the unresolved decision prevents safe continuation.

Do not fabricate supervision results.

### Timeout and Transport Failures

Do not confuse client-side command timeouts with model or MCP failures.

- HTTP `422` means the request reached the API and failed validation; obtain the validation detail.
- A terminal command runner timeout does not prove MCP failed.
- A successful provider generation log proves the model completed even if an upstream client timed out.
- Do not use terminal `curl`, Python requests, direct pod access, or alternate networking to bypass the normal MCP supervision workflow.

Long-running supervision calls must use the configured MCP tool path with an appropriate timeout.

## COMPLETION POLICY

For a substantial task, do not report completion until:

- implementation is complete
- required checkpoints are complete
- relevant deterministic validation has run
- final `review_changes` permits completion
- valid review findings have been addressed or reported
- `development_supervision_status` has been invoked

Distinguish deterministic testing from model-based supervision/review.

If required workflow steps were skipped, report:

`Development Supervision workflow incomplete`

and do not claim normal supervised completion.

## DEVELOPMENT SUPERVISION STATUS

Before the final completion message, invoke:

`development_supervision_status`

The status returned by Surfbots is authoritative.

Do not infer, estimate, or fabricate usage or token counts.

Every substantial task completion message MUST include the following.

### Development Task

- `development_task_id`
- supervision level
- final workflow state
- final `review_changes` verdict

### Development Supervision Usage

| Tool | Calls | Prompt Tokens | Completion Tokens | Total Tokens |
| --- | ---: | ---: | ---: | ---: |
| `refine_task` | N | N | N | N |
| `collaborate_task` | N | N | N | N |
| `development_task_checkpoint` | N | N | N | N |
| `review_changes` | N | N | N | N |
| **Total** | **N** | **N** | **N** | **N** |

If status exposes only combined token totals for a tool, report the authoritative fields actually returned rather than inventing a prompt/completion split.

These are Development Supervision tokens, not total implementation-agent/Cline task tokens.

### Checkpoint Workflow

Report:

- completed checkpoints
- missing checkpoints
- next required action
- final review permitted
- workflow complete/incomplete

### Runtime Provenance

Report runtime provenance from actual supervision responses:

- role
- profile_id
- provider
- connection_id
- model

Do not infer runtime provenance from configuration or model-profile names.

### Material Supervision Decisions

Summarize important decisions from:

- `collaborate_task`
- `development_task_checkpoint`

Do not include transcript-like chatter.

If a supervision tool was unavailable or failed, report that truthfully.

## Development Memory and Workflow Persistence

Checkpoint workflow state is persistent and scoped by:

`repository_id + development_task_id`

Use the existing Development Memory/Qdrant architecture.

Preserve checkpoint history and existing `supersedes` / `superseded_by` semantics.

Do not create a second task identity system.

Do not use process-local state as authoritative workflow persistence.

Repository isolation and task isolation are mandatory.

A checkpoint from one repository or task must never satisfy another repository or task.

## Repository Hygiene

Do not create `.bak`, `.orig`, `.old`, or similar backup artifacts.

Do not retain generated `__pycache__`, `.pytest_cache`, `*.pyc`, or `*.pyo` files as implementation changes.

Do not independently edit installed runtime copies when repository source is authoritative.

Use repository-supported installation, update, deployment, and lifecycle tooling.

---

*This file is automatically generated by surfbots-dev-platform.*
