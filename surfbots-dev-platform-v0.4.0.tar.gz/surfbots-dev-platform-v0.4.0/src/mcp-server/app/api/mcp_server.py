"""MCP Server implementation with the official MCP library."""
from datetime import datetime, timedelta, timezone
import httpx
import time
import json
from typing import Any

from mcp.server.lowlevel import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    CallToolResult,
    TextContent,
    ListToolsResult,
    PaginatedRequestParams,
)
from mcp.shared.exceptions import MCPError

from app.core.config import settings


class McpServer:
    """MCP Server with tool handlers."""
    
    def __init__(self):
        self.http_client: httpx.AsyncClient | None = None
        self._tools = self._create_tools()
        
        # Create low-level server with callbacks
        # Note: Server name appears in health endpoint
        self.mcp_server = Server(
            name="surfbots-dev-platform-mcp",
            version="1.0.0",
            description="Surfbots Dev Platform Code Intelligence MCP Server",
            on_list_tools=self._on_list_tools,
            on_call_tool=self._on_call_tool,
        )
    
    def _create_tools(self) -> list[Tool]:
        """Create MCP tools."""
        return [
            Tool(
                name="search_code",
                title="Search Code",
                description="Search for code snippets across repositories",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"},
                        "repository": {"type": "string", "description": "Repository name or ID"},
                        "language": {"type": "string", "description": "Restrict results to one language, for example python"},
                        "file_path": {"type": "string", "description": "Restrict results to paths containing this substring, for example src/code-search-api"},
                        "limit": {"type": "integer", "description": "Max results", "default": 8},
                    },
                    "required": ["query"],
                },
            ),
            Tool(
                name="get_file",
                title="Get File",
                description="Retrieve file content by path",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "File path"},
                        "repository": {"type": "string", "description": "Repository name"},
                    },
                    "required": ["path"],
                },
            ),
            Tool(
                name="get_file_range",
                title="Get File Range",
                description="Get specific line range from file",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string"},
                        "start_line": {"type": "integer"},
                        "end_line": {"type": "integer"},
                        "repository": {"type": "string"},
                    },
                    "required": ["path", "start_line", "end_line"],
                },
            ),
            Tool(
                name="find_symbol",
                title="Find Symbol",
                description="Find where a symbol is defined",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "symbol": {"type": "string", "description": "Exact symbol name"},
                        "repository": {"type": "string", "description": "Repository name or ID"},
                        "language": {"type": "string", "description": "Restrict to one language, for example python"},
                    },
                    "required": ["symbol", "repository"],
                },
            ),
            Tool(
                name="find_references",
                title="Find References",
                description="Find all usages of a symbol",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "symbol": {"type": "string", "description": "Exact symbol name"},
                        "repository": {"type": "string", "description": "Repository name or ID"},
                        "language": {"type": "string", "description": "Restrict to one language, for example python"},
                        "limit": {"type": "integer", "description": "Max results", "default": 20},
                    },
                    "required": ["symbol", "repository"],
                },
            ),
            Tool(
                name="development_task_checkpoint",
                title="Development Task Checkpoint",
                description=(
                    "Create a Development Supervision checkpoint to enforce that substantial development "
                    "tasks require meaningful Devstral collaboration before final review. "
                    "Use after investigation, after implementation milestones, after tests, "
                    "when facing failures, and before final review. Does not write code. "
                    "For broad system-understanding requests, automatically construct a "
                    "comprehensive collaborator assignment without asking for user focus selection."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "repository": {"type": "string", "description": "Repository name or ID"},
                        "phase": {"type": "string", "description": "Checkpoint phase name (e.g., post_investigation)"},
                        "task": {"type": "string", "description": "The current task intent"},
                        "current_state": {"type": "string", "description": "Where implementation currently stands"},
                        "question": {"type": "string", "description": "The concrete issue to resolve"},
                        "refined_task": {"type": "string", "description": "Result of refine_task, if available"},
                        "options": {"type": "array", "items": {"type": "string"}, "description": "Optional candidate approaches"},
                        "development_task_id": {"type": "string", "description": "Stable task ID returned by refine_task"},
                    },
                    "required": ["repository", "phase", "task", "current_state", "question", "development_task_id"],
                },
            ),
            Tool(
                name="refine_task",
                title="Refine Task",
                description=(
                    "Turn a development request into an implementation specification grounded in "
                    "repository evidence. Use for substantial or ambiguous work before coding. "
                    "Does not write code. "
                    "For broad system-understanding requests, automatically infer a comprehensive "
                    "scope without asking for user clarification. Analyze architecture, components, "
                    "services, deployment, APIs, and workflows."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "repository": {"type": "string", "description": "Repository name or ID"},
                        "request": {"type": "string", "description": "The development request to refine"},
                        "current_context": {"type": "string", "description": "Optional context the caller already has"},
                        "constraints": {"type": "array", "items": {"type": "string"}, "description": "Optional caller constraints"},
                        "development_task_id": {"type": "string", "description": "Optional existing task ID; omit to create a new supervised task"},
                    },
                    "required": ["repository", "request"],
                },
            ),
            Tool(
                name="collaborate_task",
                title="Collaborate Task",
                description=(
                    "Help Cline resolve meaningful decisions, blockers, conflicts, unexpected "
                    "constraints, and uncertainty during implementation. Use when a concrete "
                    "issue requires resolution before continuing. Does not write code. "
                    "For broad system-understanding requests, automatically construct a "
                    "comprehensive collaborator assignment without asking for user focus selection."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "repository": {"type": "string", "description": "Repository name or ID"},
                        "task": {"type": "string", "description": "The current task intent"},
                        "current_state": {"type": "string", "description": "Where implementation currently stands"},
                        "question": {"type": "string", "description": "The concrete issue to resolve"},
                        "refined_task": {"type": "string", "description": "Result of refine_task, if available"},
                        "options": {"type": "array", "items": {"type": "string"}, "description": "Optional candidate approaches"},
                        "development_task_id": {"type": "string", "description": "Stable task ID returned by refine_task"},
                    },
                    "required": ["repository", "task", "current_state", "question", "development_task_id"],
                },
            ),
            Tool(
                name="review_changes",
                title="Review Changes",
                description=(
                    "Review an implementation against its task specification and current repository "
                    "code. Returns findings plus deterministic review coverage. Does not modify code. "
                    "A partial review never reports a clean result."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "repository": {"type": "string", "description": "Repository name or ID"},
                        "task_specification": {"type": "string", "description": "What the work was supposed to achieve"},
                        "diff": {"type": "string", "description": "Unified diff of the changes"},
                        "changed_files": {"type": "array", "items": {"type": "string"}, "description": "Changed paths, used when no diff is supplied"},
                        "test_results": {"type": "string", "description": "Test output, if any"},
                        "development_task_id": {"type": "string", "description": "Stable task ID returned by refine_task"},
                    },
                    "required": ["repository", "task_specification", "development_task_id"],
                },
            ),
            Tool(
                name="development_supervision_status",
                title="Development Supervision Status",
                description=(
                    "Report Development Supervision tool usage and token counts for the current "
                    "development task. Returns authoritative usage data from server-side provider "
                    "usage tracking. Use before final task completion to show which supervision "
                    "tools were used and their token consumption. Does not modify code."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {},
                    "required": [],
                },
            ),
            Tool(
                name="complete_development_task",
                title="Complete Development Task",
                description=(
                    "Complete a development task and mark it as finished. "
                    "Verifies all required checkpoints are complete, sets workflow_complete flag, "
                    "and records final review verdict."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "repository": {"type": "string", "description": "Repository name or ID"},
                        "development_task_id": {"type": "string", "description": "Stable task ID returned by refine_task"},
                        "verification": {"type": "string", "description": "Optional verification evidence for completion"},
                    },
                    "required": ["repository", "development_task_id"],
                },
            ),
            Tool(
                name="repository_status",
                title="Repository Status",
                description="Get repository status",
                inputSchema={
                    "type": "object",
                    "properties": {"repository": {"type": "string"}},
                    "required": ["repository"],
                },
            ),
            Tool(
                name="get_recent_context",
                title="Get Recent Context",
                description="Get bounded recent Development Memory for a repository",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "repository": {"type": "string"},
                        "days": {"type": "integer", "description": "Only include records from this many days", "default": 14},
                        "limit": {"type": "integer", "description": "Maximum records", "default": 10},
                    },
                    "required": ["repository"],
                },
            ),
            Tool(
                name="search_repository_memory",
                title="Search Repository Memory",
                description="Semantically search Development Memory within one repository",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "repository": {"type": "string"},
                        "query": {"type": "string", "description": "Focused question or topic"},
                        "limit": {"type": "integer", "description": "Maximum records", "default": 10},
                        "file_path": {"type": "string", "description": "Exact affected file path"},
                        "symbol": {"type": "string", "description": "Exact affected symbol"},
                    },
                    "required": ["repository", "query"],
                },
            ),
            Tool(
                name="write_repository_memory",
                title="Write Repository Memory",
                description="Store a concise, structured Development Memory checkpoint after meaningful work",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "repository": {"type": "string"},
                        "session_id": {"type": "string", "description": "Stable session ID for idempotent writes"},
                        "summary": {"type": "string", "description": "Concise outcome summary, not transcript text"},
                        "memory_type": {"type": "string", "enum": ["session_checkpoint", "decision", "issue", "milestone", "preference"]},
                        "retention_class": {"type": "string", "enum": ["transient", "durable"]},
                        "decisions": {"type": "array", "items": {"type": "string"}},
                        "files_touched": {"type": "array", "items": {"type": "string"}},
                        "symbols_touched": {"type": "array", "items": {"type": "string"}},
                        "completed": {"type": "array", "items": {"type": "string"}},
                        "unresolved": {"type": "array", "items": {"type": "string"}},
                        "test_results": {"type": "array", "items": {"type": "string"}},
                        "supersedes": {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["repository", "session_id", "summary"],
                },
            ),
        ]

    async def _on_list_tools(
        self, params: PaginatedRequestParams | None = None
    ) -> ListToolsResult:
        """Handle tool listing requests."""
        return ListToolsResult(tools=self._tools)

    async def _on_call_tool(self, name: str, arguments: dict) -> CallToolResult:
        """Route tool calls to the appropriate handler."""
        if self.http_client is None:
            self.http_client = httpx.AsyncClient(
                base_url=settings.code_search_url,
                timeout=httpx.Timeout(60.0, read=120.0)
            )

        async def _call_code_search_api(path: str, payload: dict, method: str = "GET", query_params: bool = False):
            if query_params:
                params = payload
                response = await self.http_client.request(method, path, params=params)
            else:
                if method == "GET":
                    response = await self.http_client.request(method, path, params=payload)
                else:
                    response = await self.http_client.request(method, path, json=payload)
            if response.is_error:
                raise MCPError(
                    -32603,
                    f"Code Search API {response.status_code} for {path}: {response.text}",
                )
            return response.json()

        async def _resolve_repository_id(repository: str) -> str:
            """Resolve a repository name or ID to the authoritative repository ID."""
            if not repository:
                raise MCPError(-32602, "repository is required")

            result = await _call_code_search_api("/api/v1/repositories", {})
            if result.get("error") or result.get("detail"):
                reason = result.get("error") or result.get("detail")
                raise MCPError(-32603, f"Unable to resolve repository: {reason}")

            repositories = result.get("repositories", [])

            for item in repositories:
                repository_id = item.get("repository_id") or item.get("id")
                if repository_id == repository:
                    return repository_id

            matches = []
            for item in repositories:
                repository_id = item.get("repository_id") or item.get("id")
                if item.get("name") == repository and repository_id:
                    matches.append(repository_id)

            if len(matches) == 1:
                return matches[0]

            if len(matches) > 1:
                raise MCPError(
                    -32602,
                    f"Repository name '{repository}' is ambiguous; use repository ID",
                )

            raise MCPError(-32602, f"Repository not found: {repository}")

        if name == "search_code":
            params = {
                "query": arguments.get("query", ""),
                "repository_id": arguments.get("repository", ""),
                "limit": arguments.get("limit", 8),
            }

            if arguments.get("language"):
                params["language"] = arguments["language"]

            if arguments.get("file_path"):
                params["file_path"] = arguments["file_path"]

            result = await _call_code_search_api(
                "/api/v1/search",
                params,
                method="POST",
            )

            return self._format_search_results(result)
        elif name == "get_file":
            result = await _call_code_search_api(
                "/api/v1/files", {
                    "path": arguments.get("path", ""),
                    "repository": arguments.get("repository", ""),
                }
            )
            return self._format_file_result(result)

        elif name == "get_file_range":
            result = await _call_code_search_api(
                "/api/v1/files/range", {
                    "path": arguments.get("path", ""),
                    "start_line": arguments.get("start_line", 1),
                    "end_line": arguments.get("end_line", 10),
                    "repository": arguments.get("repository", ""),
                }
            )
            return self._format_file_range(result)

        elif name == "find_symbol":
            result = await _call_code_search_api(
                "/api/v1/symbols/definitions", {
                    "symbol": arguments.get("symbol", ""),
                    "repository_id": arguments.get("repository", ""),
                    "limit": arguments.get("limit", 20),
                }
            )
            return self._format_symbol_hits(result.get("definitions", []), result, "No definitions found.")

        elif name == "find_references":
            params = {
                "symbol": arguments.get("symbol", ""),
                "repository_id": arguments.get("repository", ""),
                "limit": arguments.get("limit", 20),
            }
            if arguments.get("language"):
                params["language"] = arguments["language"]
            result = await _call_code_search_api("/api/v1/symbols/references", params)
            return self._format_symbol_hits(result.get("references", []), result, "No references found.")

        elif name == "refine_task":
            repository = arguments.get("repository", "")
            request_text = arguments.get("request", "")
            if not repository or not request_text:
                raise MCPError(-32602, "repository and request are required")

            repository_id = await _resolve_repository_id(repository)

            payload = {"request": request_text}
            if arguments.get("current_context"):
                payload["current_context"] = arguments["current_context"]
            if arguments.get("constraints"):
                payload["constraints"] = arguments["constraints"]

            # The Code Search API owns creation of the initial development_task_id.
            # An existing task ID may be supplied only when intentionally continuing a task.
            if arguments.get("development_task_id"):
                payload["development_task_id"] = arguments["development_task_id"]

            result = await _call_code_search_api(
                f"/api/v1/repositories/{repository_id}/supervision/refine",
                payload,
                method="POST",
            )
            return self._format_specification(result)

        elif name == "development_task_checkpoint":
            repository = arguments.get("repository", "")
            if (
                not repository
                or not arguments.get("phase")
                or not arguments.get("task")
                or not arguments.get("current_state")
                or not arguments.get("question")
                or not arguments.get("development_task_id")
            ):
                raise MCPError(
                    -32602,
                    "repository, phase, task, current_state, question, and development_task_id are required",
                )

            repository_id = await _resolve_repository_id(repository)

            payload = {
                "phase": arguments.get("phase"),
                "task": arguments.get("task"),
                "current_state": arguments.get("current_state"),
                "question": arguments.get("question"),
                "development_task_id": arguments.get("development_task_id"),
            }
            if arguments.get("refined_task"):
                payload["refined_task"] = arguments.get("refined_task")
            if arguments.get("options"):
                payload["options"] = arguments.get("options")

            result = await _call_code_search_api(
                f"/api/v1/repositories/{repository_id}/supervision/checkpoint",
                payload,
                method="POST",
            )
            return self._format_checkpoint(result)

        elif name == "collaborate_task":
            repository = arguments.get("repository", "")
            if (
                not repository
                or not arguments.get("task")
                or not arguments.get("current_state")
                or not arguments.get("question")
            ):
                raise MCPError(
                    -32602,
                    "repository, task, current_state, and question are required",
                )

            repository_id = await _resolve_repository_id(repository)

            task_id = arguments.get("development_task_id")
            if not task_id:
                raise MCPError(
                    -32602,
                    "development_task_id is required for collaborate_task",
                )

            payload = {
                "task": arguments.get("task"),
                "current_state": arguments.get("current_state"),
                "question": arguments.get("question"),
                "development_task_id": task_id,
            }
            if arguments.get("refined_task"):
                payload["refined_task"] = arguments.get("refined_task")
            if arguments.get("options"):
                payload["options"] = arguments.get("options")

            result = await _call_code_search_api(
                f"/api/v1/repositories/{repository_id}/supervision/collaborate",
                payload,
                method="POST",
            )
            return self._format_collaboration(result)

        elif name == "review_changes":
            repository = arguments.get("repository", "")
            specification = arguments.get("task_specification", "")
            if not repository or not specification:
                raise MCPError(
                    -32602,
                    "repository and task_specification are required",
                )

            repository_id = await _resolve_repository_id(repository)

            # development_task_id is REQUIRED - must match the task being reviewed
            task_id = arguments.get("development_task_id")
            if not task_id:
                raise MCPError(
                    -32602,
                    "development_task_id is required for review_changes",
                )

            payload = {
                "task_specification": specification,
                "development_task_id": task_id,
            }
            for field_name in ("diff", "changed_files", "test_results"):
                if arguments.get(field_name):
                    payload[field_name] = arguments[field_name]

            result = await _call_code_search_api(
                f"/api/v1/repositories/{repository_id}/supervision/review",
                payload,
                method="POST",
            )
            return self._format_review(result)

        elif name == "development_supervision_status":
            # Call the Code Search API to get supervision usage status
            # This will return combined status across all tasks if task_id is not provided
            result = await _call_code_search_api("/api/v1/supervision/usage", {})
            content = [TextContent(type="text", text=json.dumps(result, indent=2))]
            return CallToolResult(content=content)

        elif name == "complete_development_task":
            repo = arguments.get("repository", "")
            task_id = arguments.get("development_task_id", "")
            verification = arguments.get("verification", None)
            if not repo or not task_id:
                raise MCPError(-32602, "repository and development_task_id are required")
            result = await _call_code_search_api(
                f"/api/v1/repositories/{repo}/supervision/complete",
                {"development_task_id": task_id, "verification": verification},
                method="POST",
            )
            content = [TextContent(type="text", text=json.dumps(result, indent=2))]
            return CallToolResult(content=content)

        elif name == "repository_status":
            repo = arguments.get("repository", "")
            result = await _call_code_search_api(f"/api/v1/repositories/{repo}/status", {})
            content = [TextContent(type="text", text=json.dumps(result))]
            return CallToolResult(content=content)

        elif name == "get_recent_context":
            repo = arguments.get("repository", "")
            days = arguments.get("days", 14)
            if not isinstance(days, int) or days < 1:
                raise MCPError(-32602, "days must be a positive integer")
            result = await _call_code_search_api(
                f"/api/v1/repositories/{repo}/memory/context",
                {
                    "limit": arguments.get("limit", 10),
                    "created_after": (datetime.now(timezone.utc) - timedelta(days=days)).isoformat(),
                },
            )
            return self._format_memory_results(result)

        elif name == "search_repository_memory":
            repo = arguments.get("repository", "")
            params = {"query": arguments.get("query", ""), "limit": arguments.get("limit", 10)}
            for field_name in ("file_path", "symbol"):
                if arguments.get(field_name):
                    params[field_name] = arguments[field_name]
            result = await _call_code_search_api(
                f"/api/v1/repositories/{repo}/memory/search", params, method="POST", query_params=True
            )
            return self._format_memory_results(result)

        elif name == "write_repository_memory":
            repository_id = arguments.get("repository", "")
            session_id = arguments.get("session_id", "")
            summary = arguments.get("summary", "")
            if not repository_id or not session_id or not summary:
                raise MCPError(-32602, "repository, session_id, and summary are required")
            payload = {
                field_name: arguments[field_name]
                for field_name in (
                    "session_id", "summary", "memory_type", "retention_class", "decisions",
                    "files_touched", "symbols_touched", "completed", "unresolved", "test_results", "supersedes",
                )
                if field_name in arguments
            }
            result = await _call_code_search_api(
                f"/api/v1/repositories/{repository_id}/memory", payload, method="POST"
            )
            return CallToolResult(content=[TextContent(type="text", text=json.dumps({
                "status": "success",
                "repository_id": repository_id,
                "session_id": session_id,
            }))])

        else:
            raise MCPError(-32601, f"Unknown tool: {name}")

    def _format_search_results(self, result: dict) -> CallToolResult:
        """Return search results as a compact, agent-friendly format."""
        items = result.get("results", [])
        if not items:
            return CallToolResult(content=[TextContent(type="text", text="No results found.")])
        
        content = []
        for item in items[:5]:  # Limit to top 5 results
            file_path = item.get("file_path", "")
            line = item.get("line", 0)
            chunk = item.get("chunk_content", "")[:200]  # Truncate for readability
            content.append(TextContent(type="text", text=f"{file_path}:{line}\n{chunk}"))
        
        return CallToolResult(content=content)

    def _format_file_result(self, result: dict) -> CallToolResult:
        """Return file content or error message."""
        if "error" in result or "detail" in result:
            reason = result.get("error") or result.get("detail")
            return CallToolResult(content=[TextContent(type="text", text=f"Could not read file: {reason}")])

        header = f"{result.get('path', '')} (lines 1-{result.get('total_lines', 'unknown')})"
        return CallToolResult(content=[TextContent(type="text", text=f"{header}\n\n{result.get('content', '')}")])

    def _format_file_range(self, result: dict) -> CallToolResult:
        """Return file range content or error message."""
        if "error" in result or "detail" in result:
            reason = result.get("error") or result.get("detail")
            return CallToolResult(content=[TextContent(type="text", text=f"Could not read file range: {reason}")])

        header = f"{result.get('path', '')} (lines {result.get('start_line')}-{result.get('end_line')} of {result.get('total_lines')})"
        return CallToolResult(content=[
            TextContent(type="text", text=f"{header}\n\n{result.get('content', '')}")
        ])

    def _format_symbol_hits(self, hits: list, result: dict, empty_message: str) -> CallToolResult:
        """Render symbol locations as path, line, and the matching source line."""
        if "error" in result or "detail" in result:
            reason = result.get("error") or result.get("detail")
            return CallToolResult(content=[TextContent(type="text", text=f"Symbol lookup failed: {reason}")])

        content = [
            TextContent(
                type="text",
                text=f"{hit.get('file_path')}:{hit.get('line')}\n{hit.get('text', '')}",
            )
            for hit in hits
        ]
        if not content:
            content.append(TextContent(type="text", text=empty_message))
        return CallToolResult(content=content)

    def _format_specification(self, result: dict) -> CallToolResult:
        """Return the specification plus the deterministic context coverage."""
        payload = {
            "repository_id": result.get("repository_id"),
            "objective": result.get("objective"),
            "requirements": result.get("requirements", []),
            "constraints": result.get("constraints", []),
            "relevant_context": result.get("relevant_context", []),
            "tests": result.get("tests", []),
            "acceptance_criteria": result.get("acceptance_criteria", []),
            "context": result.get("context", {}),
        }
        if "development_task_id" in result:
            payload["development_task_id"] = result["development_task_id"]
        if "generation" in result:
            payload["generation"] = result["generation"]
        return CallToolResult(content=[TextContent(type="text", text=json.dumps(payload, indent=2))])

    def _format_checkpoint(self, result: dict[str, Any]) -> CallToolResult:
        """Format checkpoint result for MCP response."""
        import json
        content_parts = []
        
        # Assessment
        if result.get("assessment"):
            content_parts.append(f"Assessment:\n{result['assessment']}")
        
        # Recommendation
        if result.get("recommendation"):
            content_parts.append(f"\nRecommendation:\n{result['recommendation']}")
        
        # Next steps
        if result.get("next_steps"):
            steps = "\n".join(f"- {step}" for step in result["next_steps"])
            content_parts.append(f"\nNext Steps:\n{steps}")
        
        # Risks
        if result.get("risks"):
            risks = "\n".join(f"- {risk}" for risk in result["risks"])
            content_parts.append(f"\nRisks:\n{risks}")
        
        # Workflow state
        if result.get("workflow_state"):
            content_parts.append(f"\nWorkflow State:\n{json.dumps(result['workflow_state'], indent=2)}")
        
        # Generation metadata
        if result.get("generation"):
            content_parts.append(f"\nGeneration:\n{json.dumps(result['generation'], indent=2)}")
        
        text = "\n".join(content_parts) if content_parts else json.dumps(result, indent=2)
        return CallToolResult(content=[TextContent(type="text", text=text)])
    def _format_collaboration(self, result: dict) -> CallToolResult:
        """Return the collaboration result with assessment and recommendations."""
        payload = {
            "repository_id": result.get("repository_id"),
            "assessment": result.get("assessment", ""),
            "recommendation": result.get("recommendation", ""),
            "next_steps": result.get("next_steps", []),
            "risks": result.get("risks", []),
            "requires_user_decision": result.get("requires_user_decision", False),
        }
        if "development_task_id" in result:
            payload["development_task_id"] = result["development_task_id"]
        if "generation" in result:
            payload["generation"] = result["generation"]
        return CallToolResult(content=[TextContent(type="text", text=json.dumps(payload, indent=2))])

    def _format_review(self, result: dict) -> CallToolResult:
        """Return the verdict together with the coverage it was based on."""
        payload = {
            "repository_id": result.get("repository_id"),
            "verdict": result.get("verdict"),
            "summary": result.get("summary"),
            "findings": result.get("findings", []),
            "tests_required": result.get("tests_required", []),
            "coverage": result.get("coverage", {}),
        }
        if "development_task_id" in result:
            payload["development_task_id"] = result["development_task_id"]
        if "generation" in result:
            payload["generation"] = result["generation"]
        return CallToolResult(content=[TextContent(type="text", text=json.dumps(payload, indent=2))])

    def _format_memory_results(self, result: dict) -> CallToolResult:
        """Return compact, agent-ready memory outcomes rather than raw payloads."""
        records = result.get("records", [])
        compact_records = [
            {
                key: record[key]
                for key in ("memory_id", "memory_type", "retention_class", "created_at", "summary", "decisions", "unresolved", "test_results", "superseded_by")
                if key in record
            }
            for record in records
        ]
        payload = {
            "repository_id": result.get("repository_id"),
            "records": compact_records,
            "total": result.get("total", len(compact_records)),
        }
        return CallToolResult(content=[TextContent(type="text", text=json.dumps(payload))])
    
    def get_server(self) -> Server:
        """Get the MCP server instance."""
        return self.mcp_server
    
    async def close(self):
        """Close HTTP client."""
        if self.http_client:
            await self.http_client.aclose()
            self.http_client = None


# Global server instance
mcp_server = McpServer()
