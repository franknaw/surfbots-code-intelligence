# Cline Project Rules

This directory contains project-specific instructions for Cline.

## Available Documentation

- **surfbots-dev-platform.md** - API documentation and instructions for the surfbots-dev-platform

## Usage

When Cline starts, it will automatically load these instructions to understand:

1. Available services and their endpoints
2. How to interact with the surfbots-dev-platform
3. Common tasks and their solutions
4. Quick reference commands

This reduces context consumption by providing structured, reusable instructions.


surfbots-development-context.md
    → context retrieval, memory, skills, avoiding repeated context loading

surfbots-development-supervision.md
    → refine/checkpoint/collaborate/review/completion behavior

surfbots-code-search.md
    → MCP/code-search tool usage