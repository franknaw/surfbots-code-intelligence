# Development Context Skill

The Development Context Skill defines how a coding agent uses Surfbots Dev Platform. It is the behavior and orchestration layer; it is not a database, indexing service, or MCP implementation.

Surfbots MCP provides capabilities. The Skill makes those capabilities consistent across Cline, Copilot, and other coding clients.

## Current Implementation

All initial phases are implemented as an opt-in, workspace-scoped workflow:

- Copilot Skill: [SKILL.md](../../.github/skills/surfbots-development-context/SKILL.md)
- Scoped Copilot instruction: [surfbots-development-context.instructions.md](../../.github/instructions/surfbots-development-context.instructions.md)
- Cline rule installed by `surfbots-dev init`: [surfbots-development-context.md](../../tooling/repo-bootstrap/.clinerules/surfbots-development-context.md)
- Cline Skill installed by `surfbots-dev init`: [SKILL.md](../../tooling/repo-bootstrap/.clinerules/skills/surfbots-development-context/SKILL.md)
- Bounded startup context command: `surfbots-dev context <repository-id> --task "..."`
- Reviewable local drafts: `surfbots-dev memory draft --summary "..."`
- Draft submission: `surfbots-dev memory checkpoint <repository-id> --draft .surfbots/memory-checkpoint-draft.json`
- Opt-in code-search enrichment: set `include_related_memory: true` in the Code Search API request.

These client artifacts orchestrate existing MCP and Development Memory capabilities. They do not capture raw conversations or hidden reasoning.

Cline skills are loaded from Cline-supported skill directories such as `.clinerules/skills`. Copilot skills are loaded from `.github/skills`. The same Surfbots behavior is mirrored into both locations because the clients do not share a skill registry.

```text
Surfbots Dev Platform MCP                 Development Context Skill
-------------------------                 -------------------------
search_code                               When to retrieve context
get_recent_context                        How to distinguish memory from code
search_repository_memory                  When to inspect code before edits
find_symbol                               When to write a checkpoint
find_references                           How to keep retrieved context bounded
repository_status                         Client-specific operating policy
```

## Goals

- Give every coding session a compact, evidence-based starting context.
- Recover active work, durable decisions, unresolved items, and validation results without replaying transcripts.
- Treat indexed code as the authority for current implementation details.
- Treat Development Memory as context for prior decisions, outcomes, constraints, and unfinished work.
- Write compact checkpoints only at meaningful milestones.
- Keep the MCP server generic so individual clients can adopt their own policies.

## Principles

| Source | Answers | Authority |
| --- | --- | --- |
| `repository_status` | Is this repository indexed and healthy? | Current repository metadata |
| Development Memory | What was being worked on, decided, or left unfinished? | Historical engineering context |
| `search_code`, `find_symbol`, `get_file` | What does the code do now? | Current implementation |

The Skill must prefer current code evidence over a memory record whenever they conflict. A memory record may explain why a design exists, but it must not be treated as proof that the implementation still matches that design.

## Agent Routine

At the start of a coding task in a known repository:

1. Determine the repository ID from the current workspace or the task context. Do not guess or search across repositories when it is unknown.
2. Call `repository_status` to confirm repository identity and indexing status.
3. Call `get_recent_context` with a bounded lookback, normally 14 days and at most 10 records.
4. When the request concerns an existing design decision, bug, deployment change, or named symbol, call `search_repository_memory` with a focused query.
5. Call `search_code`, `find_symbol`, or `get_file` for the user’s current task before making meaningful edits.
6. Before a broad or risky change, inspect relevant symbols, callers, tests, and deployment configuration.
7. After a meaningful result, create a compact checkpoint through the Development Memory API or the host CLI.

The Skill should not call every tool mechanically. It skips unavailable capabilities gracefully and keeps outputs bounded to the immediate task.

## Checkpoint Policy

Create a checkpoint after one of these outcomes:

- A feature or meaningful slice is complete.
- An architecture or operational decision is made.
- A significant defect is found or resolved.
- Deployment, persistence, security, or retention behavior changes.
- Work ends with a concrete unresolved item or failed validation that needs continuation.

Do not create checkpoints for exploratory turns, routine file reads, temporary errors, or speculative reasoning. Never write raw conversation content or model reasoning.

A checkpoint should contain:

```text
Summary: what changed or was learned
Decisions: selected option and concise reason
Files/symbols: exact affected locations when known
Completed: verified outcomes
Unresolved: concrete next work
Tests: commands and result summaries
Retention: transient for session state; durable for enduring decisions
```

Use `surfbots-dev memory checkpoint` for explicit writes. A successful `surfbots-dev repo reindex` also creates a best-effort lifecycle checkpoint.

## Phase 0: Policy Baseline

Create a client-neutral Skill document named `surfbots-development-context`. It must describe the source-of-truth distinction, startup routine, checkpoint criteria, content restrictions, and bounded retrieval rules.

Acceptance criteria:

- The Skill never instructs a client to save raw transcripts or hidden reasoning.
- Startup retrieval is repository-scoped and optional when the repository ID is unavailable.
- Code is explicitly preferred over memory for current behavior.
- The Skill identifies explicit checkpoint creation as a meaningful-task action, not a per-turn action.

## Phase 1: Static Client Integration

Package the baseline policy in formats supported by the initial clients:

- Cline rule or project instruction file.
- Copilot custom instruction or Skill file.
- A plain Markdown version for manual client adoption.

The instruction should reference only stable MCP tool names: `repository_status`, `get_recent_context`, `search_repository_memory`, `search_code`, `find_symbol`, `find_references`, `get_file`, and `get_file_range`.

Acceptance criteria:

- A new client session can discover the MCP and apply the routine without application code changes.
- Client-specific files contain no secrets, repository paths, or hard-coded repository IDs.
- Each client artifact is generated from the same canonical policy to prevent drift.

## Phase 2: Startup Context Builder

Add an optional context-builder command or client hook that performs the bounded startup routine.

```text
repository_status
      |
      +-- get_recent_context(days=14, limit=5)
      |
      +-- search_repository_memory(task keywords) when relevant
      |
      +-- search_code(task keywords)
      v
compact context for the coding agent
```

The builder must return an explicit degraded state when index or memory services are unavailable. It must not block a user’s task because one retrieval source is down.

Acceptance criteria:

- Default output stays within a configurable token or character budget.
- Empty memory is represented clearly, not as an error.
- Memory and code retrieval failures are independently reported.
- The builder does not make semantic code search until it has a focused task query.

## Phase 3: Checkpoint Assistance

Add client-side checkpoint drafting after meaningful milestones. Drafts should include only observable outcomes such as changed files, test results, explicit decisions, and unresolved work. The user or agent must review the concise content before it is stored.

Use the existing structured Development Memory write path. The Skill may recommend durable retention for architectural decisions and transient retention for ordinary session progress.

Acceptance criteria:

- The draft is bounded and reviewable.
- No full transcript, prompt history, or hidden reasoning is available to the producer.
- Failed writes warn and preserve the task result; they do not undo code changes or block completion.
- Repeated submissions use a stable session ID so the persistence layer is idempotent.

## Phase 4: Contextual Retrieval During Work

Add focused retrieval rules for ongoing work:

- Before changing a named symbol, search memory by symbol or file when historical rationale could matter.
- Before deployment or migration work, search durable decisions first.
- Before reworking an unresolved area, retrieve related issues and the latest test result.
- When memory contradicts code, report the difference briefly and follow the current code.

Do not automatically enrich every code result. Related memory should be added only on focused requests or to explicitly enabled clients after relevance and latency measurements are favorable.

Acceptance criteria:

- Related memory is limited to a small configured result count.
- Returned records show their timestamp, type, and whether a decision is superseded.
- Context remains repository-scoped at every stage.
- The policy produces no cross-repository fallback results.

## Phase 5: Quality, Privacy, and Rollout

Evaluate the Skill with realistic coding sessions and synthetic memory records. Measure whether startup context reduces repeated discovery work without increasing incorrect assumptions or token use.

Roll out in stages:

1. Documentation-only static Skill for opt-in use.
2. One client integration using manual checkpoints.
3. Context-builder hook with bounded startup retrieval.
4. Draft-assisted checkpointing.
5. Optional focused related-memory enrichment.

Acceptance criteria:

- Users can disable the Skill without disabling MCP capabilities.
- Telemetry records only aggregate retrieval outcomes and latency, never memory content.
- A rollback removes the client policy/hook while retained records remain controlled by Development Memory retention rules.
- Documentation explains how to inspect, supersede, and delete stored memory.

## Canonical Instruction Draft

```text
At the start of a coding task in a known repository, retrieve repository status and bounded recent Development Memory before making changes. Use Development Memory for prior decisions, constraints, unfinished work, and validation history. Use indexed code and source files as the authority for current implementation details.

For the current task, perform focused code search or symbol/file inspection before significant edits. When a named symbol, deployment behavior, architecture decision, or unresolved issue is relevant, perform focused repository-memory retrieval.

After completing a meaningful task, making a durable decision, resolving a significant defect, or leaving concrete follow-up work, create a concise structured checkpoint. Store outcomes, not transcripts or hidden reasoning. Include affected files or symbols, tests, decisions, and unresolved work when known. Do not create checkpoints for routine exploration or every turn.
```

## Implementation Boundary

This Skill consumes MCP capabilities; it does not add new Qdrant collections, write directly to storage, or embed policy in the MCP server. Development Memory persistence and retention belong to the platform described in [docs/development-memory/README.md](../development-memory/README.md).
