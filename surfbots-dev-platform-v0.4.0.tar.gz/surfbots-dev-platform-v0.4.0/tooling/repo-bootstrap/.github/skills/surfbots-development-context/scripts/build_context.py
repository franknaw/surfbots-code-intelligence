#!/usr/bin/env python3
"""Build bounded startup context from the Surfbots Code Search API."""
import argparse
from datetime import datetime, timedelta, timezone
import json
import os
import urllib.error
import urllib.parse
import urllib.request


INDEXER_URL = os.environ.get("SURFBOTS_INDEXER_URL", "http://127.0.0.1:8021")
SEARCH_API_URL = os.environ.get("SURFBOTS_SEARCH_API_URL", "http://127.0.0.1:8020")


def request(base_url: str, path: str, method: str = "GET", payload: dict | None = None) -> dict:
    data = json.dumps(payload).encode() if payload is not None else None
    request_object = urllib.request.Request(
        f"{base_url}{path}",
        data=data,
        headers={"Content-Type": "application/json"},
        method=method,
    )
    with urllib.request.urlopen(request_object, timeout=10) as response:
        return json.loads(response.read().decode())


def section(title: str, result: dict | None, error: Exception | None) -> list[str]:
    lines = [f"## {title}"]
    if error:
        return lines + [f"Unavailable: {error}"]
    if not result:
        return lines + ["No data available."]
    if title == "Repository Status":
        return lines + [json.dumps(result, indent=2)]
    records = result.get("records", result.get("results", []))
    if not records:
        return lines + ["No matching records."]
    for record in records:
        if "summary" in record:
            lines.append(f"- {record.get('memory_type', 'memory')}: {record['summary']}")
        else:
            lines.append(f"- {record.get('file_path', 'code')}: {record.get('chunk_content', '')[:240]}")
    return lines


def main() -> int:
    parser = argparse.ArgumentParser(description="Build bounded Surfbots repository context")
    parser.add_argument("repository_id")
    parser.add_argument("--task", default=None, help="Focused task for code and memory search")
    parser.add_argument("--days", type=int, default=14)
    parser.add_argument("--limit", type=int, default=5)
    args = parser.parse_args()
    if args.days < 1 or args.limit < 1:
        parser.error("--days and --limit must be positive")

    created_after = urllib.parse.quote((datetime.now(timezone.utc) - timedelta(days=args.days)).isoformat())
    results = []
    requests = [
        ("Repository Status", INDEXER_URL, f"/api/v1/repositories/{args.repository_id}", "GET", None),
        ("Recent Development Memory", INDEXER_URL, f"/api/v1/repositories/{args.repository_id}/memory/context?limit={args.limit}&created_after={created_after}", "GET", None),
    ]
    if args.task:
        requests.extend([
            ("Relevant Development Memory", INDEXER_URL, f"/api/v1/repositories/{args.repository_id}/memory/search?query={urllib.parse.quote(args.task)}&limit={args.limit}", "POST", None),
            ("Current Code Evidence", SEARCH_API_URL, "/api/v1/search", "POST", {"query": args.task, "repository_id": args.repository_id, "limit": args.limit}),
        ])

    for title, base_url, path, method, payload in requests:
        try:
            results.extend(section(title, request(base_url, path, method, payload), None))
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError) as error:
            results.extend(section(title, None, error))
    print("\n".join(results))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())