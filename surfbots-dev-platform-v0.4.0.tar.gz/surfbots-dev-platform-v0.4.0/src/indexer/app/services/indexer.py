"""Code indexing service with local filesystem support."""
from pathlib import Path
import hashlib
import uuid
from typing import List, Dict, Optional, Any
from datetime import datetime
import logging
import subprocess

from .repository_parser import RepositoryParser
from .model_client import EmbeddingClient
from ..core.database import create_collection, delete_collection, validate_collection_dimensions, get_qdrant_client
from ..core.config import settings

logger = logging.getLogger(__name__)


class CodeIndexer:
    """Indexes code repositories into Qdrant."""

    def __init__(self):
        self.parser = RepositoryParser()
        self.embedding_client = EmbeddingClient()
        self.collection_name = "code-index"
        self.vector_size = settings.qdrant_vector_size
        
        # Ensure collection exists with correct dimensions
        # Force recreation if dimensions don't match
        is_valid, message = validate_collection_dimensions(self.collection_name, self.vector_size)
        if not is_valid:
            logger.warning(f"{message}. Recreating collection...")
            delete_collection(self.collection_name)
        
        # Create collection with force=True to handle dimension mismatch
        create_collection(self.collection_name, vector_size=self.vector_size, force=True)
        logger.info(f"Collection '{self.collection_name}' ready with {self.vector_size} dimensions")

    def create_chunks(
        self,
        content: str,
        chunk_size: int = None,
        chunk_overlap: int = None
    ) -> List[str]:
        """Split content into chunks for indexing."""
        chunk_size = chunk_size or settings.chunk_size
        chunk_overlap = chunk_overlap or settings.chunk_overlap

        # Simple chunking by character count
        words = content.split()
        chunks = []
        current_chunk = []
        current_length = 0

        for word in words:
            word_length = len(word) + 1  # +1 for space
            if current_length + word_length > chunk_size and current_chunk:
                chunks.append(" ".join(current_chunk))
                # Keep overlap
                overlap_words = current_chunk[-(chunk_overlap // 10):]
                current_chunk = overlap_words + [word]
                current_length = sum(len(w) + 1 for w in current_chunk)
            else:
                current_chunk.append(word)
                current_length += word_length

        if current_chunk:
            chunks.append(" ".join(current_chunk))

        return chunks

    async def index_file(
        self,
        file_path: Path,
        repository_id: str,
        relative_path: str
    ) -> List[Dict]:
        """Index a single file."""
        content = self.parser.parse_file_content(file_path)
        if content is None:
            return []

        file_info = self.parser.get_file_info(file_path)
        chunks = self.create_chunks(content)
        content_hash = hashlib.sha256(content.encode("utf-8", errors="replace")).hexdigest()

        indexed_chunks = []
        points = []
        for i, chunk in enumerate(chunks):
            # Generate embedding for the chunk
            embedding_response = await self.embedding_client.generate_embedding(
                f"{relative_path}:\n\n{chunk}"
            )
            
            # Extract the actual embedding list from the response
            embedding = embedding_response.embedding if embedding_response else None
            if not embedding:
                logger.warning(f"Failed to generate embedding for {relative_path} chunk {i}")
                continue
            
            # Deterministic so a retry upserts the same point instead of duplicating.
            point_id = str(uuid.uuid5(
                uuid.NAMESPACE_URL,
                f"{repository_id}:{relative_path}:{content_hash}:{i}",
            ))
            payload = {
                "repository_id": repository_id,
                "file_path": str(relative_path),
                "language": file_info.get("language", "unknown"),
                "content": chunk,
                "content_hash": content_hash,
                "file_info": file_info,
                "chunk_index": i,
                "total_chunks": len(chunks)
            }
            points.append({"id": point_id, "vector": embedding, "payload": payload})
            indexed_chunks.append({
                "chunk_id": point_id,
                "relative_path": relative_path,
                "chunk_index": i
            })

        if points:
            get_qdrant_client().upsert(collection_name=self.collection_name, points=points)
        
        return indexed_chunks

    async def index_repository(
        self,
        repository_id: str,
        source: Any,
        branch: str = "main"
    ) -> Dict[str, Any]:
        """Index an entire repository from local filesystem."""
        source_type, source_dict = self._parse_source(source)
        
        # Get the repository path
        repo_path = Path(source_dict.get("path", "/tmp/repo"))
        
        if not repo_path.exists():
            raise ValueError(f"Repository path does not exist: {repo_path}")
        
        # Track indexing results
        files_indexed = 0
        chunks_created = 0
        errors = []
        
        try:
            # Get list of files to index
            file_list = self._get_file_list(repo_path, source_type)
            
            for relative_path in file_list:
                file_path = repo_path / relative_path
                
                if not file_path.is_file():
                    continue
                
                try:
                    chunks = await self.index_file(file_path, repository_id, str(relative_path))
                    files_indexed += 1
                    chunks_created += len(chunks)
                except Exception as e:
                    logger.error(f"Failed to index {file_path}: {e}")
                    errors.append({"path": str(file_path), "error": str(e)})
            
            indexed_commit = None
            if source_type == "git" or self._is_git_repo(repo_path):
                indexed_commit = self._get_latest_commit(str(repo_path))
            
            return {
                "files_indexed": files_indexed,
                "chunks_created": chunks_created,
                "indexed_at": datetime.utcnow().isoformat(),
                "indexed_commit": indexed_commit,
                "errors": errors
            }
        except Exception as e:
            logger.error(f"Indexing failed: {e}")
            return {
                "files_indexed": files_indexed,
                "chunks_created": chunks_created,
                "indexed_at": datetime.utcnow().isoformat(),
                "indexed_commit": None,
                "errors": [{"error": str(e)}]
            }

    def _parse_source(self, source: Any) -> tuple:
        """Parse source into (source_type, source_dict)."""
        if isinstance(source, dict):
            return source.get("type", "local"), source
        return "local", {"path": str(source)}

    def _is_git_repo(self, repo_path: Path) -> bool:
        """Check if path is a Git repository."""
        return (repo_path / ".git").exists()

    def _get_file_list(self, repo_path: Path, source_type: str) -> List[str]:
        """Get list of files to index from repository."""
        if source_type == "git" or self._is_git_repo(repo_path):
            # Use git ls-files for Git repos to get tracked files
            candidates = self._get_git_file_list(repo_path)
        else:
            # Use recursive filesystem scan for non-Git directories
            return self._get_filesystem_file_list(repo_path)

        # Both enumeration paths must honour the same extension filter
        return [p for p in candidates if self._is_supported_extension(Path(p))]

    def _get_git_file_list(self, repo_path: Path) -> List[str]:
        """Get list of files tracked by Git using git ls-files."""
        try:
            result = subprocess.run(
                ["git", "ls-files", "--cached", "--others", "--exclude-standard"],
                cwd=repo_path,
                capture_output=True,
                text=True,
                check=True
            )
            return [line.strip() for line in result.stdout.strip().split("\n") if line.strip()]
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to get Git file list: {e}")
            return []
        except FileNotFoundError:
            logger.warning("Git not found, falling back to filesystem scan")
            return self._get_filesystem_file_list(repo_path)

    def _get_filesystem_file_list(self, repo_path: Path) -> List[str]:
        """Get list of files via recursive filesystem scan."""
        file_list = []
        excluded_patterns = [".git/", "node_modules/", "dist/", "build/", ".venv/", "__pycache__/"]
        
        for file_path in repo_path.rglob("*"):
            if not file_path.is_file():
                continue
            
            relative_path = str(file_path.relative_to(repo_path))
            
            # Check if file should be excluded
            should_exclude = False
            for pattern in excluded_patterns:
                if pattern in relative_path:
                    should_exclude = True
                    break
            
            if not should_exclude and self._is_supported_extension(file_path):
                file_list.append(relative_path)
        
        return file_list

    def _is_supported_extension(self, file_path: Path) -> bool:
        """Check if file has a supported extension."""
        return file_path.suffix in settings.supported_extensions

    def _get_latest_commit(self, repo_path: str) -> str:
        """Get the latest commit hash from a Git repository."""
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=repo_path,
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to get Git commit: {e}")
            return "unknown"
        except FileNotFoundError:
            return "unknown"

    async def sync_repository(
        self,
        repository_id: str,
        changes: List[Dict],
        base_commit: str
    ) -> Dict[str, Any]:
        """Sync changes from a repository."""
        # Process each change
        files_updated = 0
        chunks_updated = 0
        
        for change in changes:
            operation = change.get("operation")
            path = change.get("path")
            content = change.get("content")
            
            if operation == "add" or operation == "modify":
                # Index the new content
                file_path = Path(path)
                chunks = await self.index_file(file_path, repository_id, path)
                files_updated += 1
                chunks_updated += len(chunks)
            elif operation == "delete":
                # TODO: Remove from Qdrant
                pass
        
        return {
            "success": True,
            "files_updated": files_updated,
            "chunks_updated": chunks_updated,
            "indexed_commit": "synced-" + datetime.utcnow().isoformat()
        }
