"""Repository metadata storage using SQLite.

SQLite is the control-plane metadata database for the Surfbots Dev Platform.
It stores information about what files/repos should be in Qdrant, but NOT
the actual code chunks or embeddings.

Think of it like this:

    Local repository
          |
          v
    Repository Manager
          |
          +---- SQLite (this file)
          |       "What files/repos do I know about?"
          |       "What was the last hash?"
          |       "Is indexing current?"
          |
          +---- Indexer
                  |
                  v
                Qdrant
                  "Here are the searchable code chunks/vectors"

A practical SQLite database lives at:

    /var/lib/surfbots/repositories.db

The database contains these tables:

| Table             | What it tracks                                     |
| ----------------- | -------------------------------------------------- |
| `repositories`    | Registered repositories and their local paths      |
| `files`           | Every indexed file, hash, size, mtime, chunk count |
| `index_jobs`      | Current/history of indexing operations             |
| `index_events`    | File create/update/delete events and failures      |
| `schema_versions` | Embedding/chunker/index compatibility              |
| `settings`        | Small runtime metadata                             |
"""
import sqlite3
import json
import os
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid


class SQLiteRepositoryStore:
    """SQLite-based repository metadata storage.
    
    Stores repository metadata in a local SQLite database for fast
    lookup and indexing without requiring database migrations.
    """
    
    def __init__(self, db_path: Optional[str] = None):
        """Initialize the repository store.
        
        Args:
            db_path: Path to the SQLite database file. Defaults to
                    /var/lib/surfbots/repositories.db
        """
        if db_path is None:
            db_path = self._get_default_db_path()
        
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self._init_db()
    
    def _get_default_db_path(self) -> str:
        """Get the default database path."""
        # Default to container path; environment variables control placement
        env_db = os.environ.get("REPOSITORY_DB")
        if env_db:
            return env_db
        # Container path for Kubernetes
        container_dir = Path("/var/lib/surfbots")
        container_dir.mkdir(parents=True, exist_ok=True)
        return str(container_dir / "repositories.db")
    
    def _init_db(self):
        """Initialize the database schema."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Repositories table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS repositories (
                    repository_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    source_type TEXT NOT NULL DEFAULT 'local',
                    source TEXT NOT NULL,
                    branch TEXT DEFAULT 'main',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    status TEXT DEFAULT 'registered',
                    file_count INTEGER DEFAULT 0,
                    chunk_count INTEGER DEFAULT 0,
                    last_indexed_at TEXT,
                    indexed_commit TEXT
                )
            """)
            
            # Files table for tracking indexed files
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS indexed_files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    repository_id TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    sha256 TEXT NOT NULL,
                    content_size INTEGER NOT NULL,
                    indexed_at TEXT NOT NULL,
                    FOREIGN KEY (repository_id) REFERENCES repositories(repository_id)
                )
            """)
            
            # Indexes for faster queries
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_files_repository 
                ON indexed_files(repository_id)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_files_path 
                ON indexed_files(file_path)
            """)
            
            
            # Index jobs table for tracking indexing operations
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS index_jobs (
                    job_id TEXT PRIMARY KEY,
                    repository_id TEXT NOT NULL,
                    type TEXT NOT NULL DEFAULT 'full',
                    status TEXT NOT NULL DEFAULT 'pending',
                    started_at TEXT,
                    finished_at TEXT,
                    files_total INTEGER DEFAULT 0,
                    files_processed INTEGER DEFAULT 0,
                    files_failed INTEGER DEFAULT 0,
                    error TEXT,
                    FOREIGN KEY (repository_id) REFERENCES repositories(repository_id)
                )
            """)
            
            # Index events table for file create/update/delete events
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS index_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    repository_id TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    hash TEXT,
                    timestamp TEXT NOT NULL,
                    processed INTEGER DEFAULT 0,
                    FOREIGN KEY (repository_id) REFERENCES repositories(repository_id)
                )
            """)
            
            # Schema versions table for tracking compatibility
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS schema_versions (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            # Settings table for runtime metadata
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            
            # Indexes for new tables
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_jobs_repository 
                ON index_jobs(repository_id)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_events_repository 
                ON index_events(repository_id)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_events_file 
                ON index_events(file_path)
            """)
            
            conn.commit()
    def create_repository(self, repository_id: str, name: str, 
                          source_type: str, source: Dict[str, Any],
                          branch: str = "main") -> Dict[str, Any]:
        """Create a new repository record."""
        now = datetime.utcnow().isoformat()
        source_json = json.dumps(source)
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO repositories 
                (repository_id, name, source_type, source, branch, created_at, updated_at, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'registered')
            """, (repository_id, name, source_type, source_json, branch, now, now))
            conn.commit()
        
        return self.get_repository(repository_id)
    
    def get_repository(self, repository_id: str) -> Optional[Dict[str, Any]]:
        """Get repository by ID."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM repositories WHERE repository_id = ?
            """, (repository_id,))
            row = cursor.fetchone()
            
            if row:
                repo = dict(row)
                repo['source'] = json.loads(repo['source'])
                return repo
            return None
    
    def get_repositories(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get all repositories, optionally filtered by status."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            if status:
                cursor.execute("""
                    SELECT * FROM repositories WHERE status = ?
                """, (status,))
            else:
                cursor.execute("SELECT * FROM repositories")
            
            repos = []
            for row in cursor.fetchall():
                repo = dict(row)
                repo['source'] = json.loads(repo['source'])
                repos.append(repo)
            return repos
    
    def update_repository(self, repository_id: str, updates: Dict[str, Any]) -> bool:
        """Update repository metadata."""
        now = datetime.utcnow().isoformat()
        
        # Build update query dynamically
        set_clause = "updated_at = ?"
        values = [now]
        
        for key, value in updates.items():
            if key in ['name', 'source_type', 'source', 'branch', 'status', 
                       'file_count', 'chunk_count', 'last_indexed_at', 'indexed_commit']:
                set_clause += f", {key} = ?"
                values.append(value)
        
        values.append(repository_id)
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute(f"UPDATE repositories SET {set_clause} WHERE repository_id = ?", values)
            conn.commit()
            return cursor.rowcount > 0
    
    def add_or_update_repository(self, repo_data: Dict[str, Any]) -> bool:
        """Add a new repository or update an existing one."""
        repository_id = repo_data.get("repository_id")
        if not repository_id:
            return False
        
        now = datetime.utcnow().isoformat()
        
        # Check if repository exists
        existing = self.get_repository(repository_id)
        
        if existing:
            # Update existing repository
            updates = {k: v for k, v in repo_data.items() if k not in ["repository_id", "created_at"]}
            updates["updated_at"] = now
            return self.update_repository(repository_id, updates)
        else:
            # Insert new repository
            source = repo_data.get("source", {})
            if isinstance(source, dict):
                source = json.dumps(source)
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO repositories 
                    (repository_id, name, source_type, source, branch, status, 
                     created_at, updated_at, file_count, chunk_count, last_indexed_at, 
                     indexed_commit)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    repository_id,
                    repo_data.get("name", ""),
                    repo_data.get("source_type", "local"),
                    source,
                    repo_data.get("branch", "main"),
                    repo_data.get("status", "registered"),
                    now,
                    now,
                    repo_data.get("file_count", 0),
                    repo_data.get("chunk_count", 0),
                    repo_data.get("last_indexed_at"),
                    repo_data.get("indexed_commit")
                ))
                conn.commit()
                return cursor.rowcount > 0
    
    def add_indexed_file(self, repository_id: str, file_path: str,
                         sha256: str, content_size: int) -> int:
        """Track an indexed file."""
        now = datetime.utcnow().isoformat()
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO indexed_files 
                (repository_id, file_path, sha256, content_size, indexed_at)
                VALUES (?, ?, ?, ?, ?)
            """, (repository_id, file_path, sha256, content_size, now))
            conn.commit()
            return cursor.lastrowid
    
    def get_indexed_files(self, repository_id: str) -> List[Dict[str, Any]]:
        """Get all indexed files for a repository."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM indexed_files WHERE repository_id = ?
                ORDER BY file_path
            """, (repository_id,))
            return [dict(row) for row in cursor.fetchall()]
    
    def get_file_sha256(self, repository_id: str, file_path: str) -> Optional[str]:
        """Get the SHA256 hash of a file."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT sha256 FROM indexed_files 
                WHERE repository_id = ? AND file_path = ?
            """, (repository_id, file_path))
            row = cursor.fetchone()
            return row[0] if row else None
    
    def remove_indexed_file(self, repository_id: str, file_path: str) -> bool:
        """Remove an indexed file."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                DELETE FROM indexed_files 
                WHERE repository_id = ? AND file_path = ?
            """, (repository_id, file_path))
            conn.commit()
            return cursor.rowcount > 0
    # Index Job methods
    def create_index_job(self, repository_id: str, job_type: str = "full") -> str:
        """Create a new index job record."""
        job_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO index_jobs 
                (job_id, repository_id, type, status, started_at)
                VALUES (?, ?, ?, 'pending', ?)
            """, (job_id, repository_id, job_type, now))
            conn.commit()
        return job_id
    
    def update_index_job(self, job_id: str, updates: Dict[str, Any]) -> bool:
        """Update an index job record."""
        now = datetime.utcnow().isoformat()
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            set_clause = "updated_at = ?, "
            values = [now]
            
            for key, value in updates.items():
                if key in ['status', 'started_at', 'finished_at', 
                          'files_total', 'files_processed', 'files_failed', 'error']:
                    set_clause += f"{key} = ?, "
                    values.append(value)
            
            set_clause = set_clause.rstrip(", ")
            values.append(job_id)
            
            cursor.execute(f"UPDATE index_jobs SET {set_clause} WHERE job_id = ?", values)
            conn.commit()
            return cursor.rowcount > 0
    
    def get_index_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Get an index job by ID."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM index_jobs WHERE job_id = ?", (job_id,))
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def get_repository_jobs(self, repository_id: str) -> List[Dict[str, Any]]:
        """Get all jobs for a repository."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM index_jobs WHERE repository_id = ? ORDER BY started_at DESC", (repository_id,))
            return [dict(row) for row in cursor.fetchall()]
    
    # Index Event methods
    def add_index_event(self, repository_id: str, file_path: str, 
                        event_type: str, hash: Optional[str] = None) -> int:
        """Add an index event."""
        now = datetime.utcnow().isoformat()
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO index_events 
                (repository_id, file_path, event_type, hash, timestamp)
                VALUES (?, ?, ?, ?, ?)
            """, (repository_id, file_path, event_type, hash, now))
            conn.commit()
            return cursor.lastrowid
    
    def get_pending_events(self) -> List[Dict[str, Any]]:
        """Get all unprocessed events."""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM index_events WHERE processed = 0 ORDER BY timestamp")
            return [dict(row) for row in cursor.fetchall()]
    
    def mark_event_processed(self, event_id: int) -> bool:
        """Mark an event as processed."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE index_events SET processed = 1 WHERE event_id = ?", (event_id,))
            conn.commit()
            return cursor.rowcount > 0
    
    # Schema Version methods
    def get_schema_version(self, key: str) -> Optional[str]:
        """Get a schema version value."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM schema_versions WHERE key = ?", (key,))
            row = cursor.fetchone()
            return row[0] if row else None
    
    def set_schema_version(self, key: str, value: str) -> None:
        """Set a schema version value."""
        now = datetime.utcnow().isoformat()
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO schema_versions (key, value, updated_at)
                VALUES (?, ?, ?)
            """, (key, value, now))
            conn.commit()
    
    # Settings methods
    def get_setting(self, key: str) -> Optional[str]:
        """Get a setting value."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
            row = cursor.fetchone()
            return row[0] if row else None
    
    def set_setting(self, key: str, value: str) -> None:
        """Set a setting value."""
        now = datetime.utcnow().isoformat()
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO settings (key, value, updated_at)
                VALUES (?, ?, ?)
            """, (key, value, now))
            conn.commit()
    
    def delete_repository(self, repository_id: str) -> bool:
        """Delete a repository and its associated data."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            # Delete related records first (cascading)
            cursor.execute("DELETE FROM index_events WHERE repository_id = ?", (repository_id,))
            cursor.execute("DELETE FROM index_jobs WHERE repository_id = ?", (repository_id,))
            cursor.execute("DELETE FROM indexed_files WHERE repository_id = ?", (repository_id,))
            cursor.execute("DELETE FROM repositories WHERE repository_id = ?", (repository_id,))
            conn.commit()
            return cursor.rowcount > 0


