"""Phase 6 tests: the verifier must fail when supervision is missing or broken.

A reachable MCP endpoint is not evidence that the platform works. These tests
drive the verifier against a fake MCP server so every failure mode is exercised.
"""
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from types import SimpleNamespace

import pytest

BOOTSTRAP = Path(__file__).resolve().parent
sys.path.insert(0, str(BOOTSTRAP))

import importlib.util

spec = importlib.util.spec_from_loader(
    "surfbots_dev_cli",
    importlib.machinery.SourceFileLoader("surfbots_dev_cli", str(BOOTSTRAP / "surfbots-dev")),
)
cli = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cli)


ALL_TOOLS = [
    "search_code", "get_file", "get_file_range", "find_symbol", "find_references",
    "repository_status", "get_recent_context", "search_repository_memory",
    "write_repository_memory", "refine_task", "collaborate_task", "review_changes",
]

GOOD_SPEC = {
    "repository_id": "repo_test", "objective": "do the thing", "requirements": ["r"],
    "constraints": [], "relevant_context": [], "tests": ["t"], "acceptance_criteria": ["a"],
    "context": {"included": [], "omitted": [], "complete": True, "budget_tokens": 100, "used_tokens": 1},
}

GOOD_REVIEW = {
    "repository_id": "repo_test", "verdict": "no_issues_found", "summary": "s",
    "findings": [], "tests_required": [],
    "coverage": {"level": "full", "reviewed_files": ["a.py"], "omitted_files": [], "reason": "ok"},
}


class FakeMcp:
    """Minimal MCP server whose behaviour each test can shape."""

    def __init__(self, tools=None, responses=None, errors=None):
        self.tools = tools if tools is not None else list(ALL_TOOLS)
        self.responses = responses or {}
        self.errors = errors or {}
        handler = self._handler()
        self.server = HTTPServer(("127.0.0.1", 0), handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    @property
    def url(self):
        return f"http://127.0.0.1:{self.server.server_port}/mcp"

    def stop(self):
        self.server.shutdown()
        self.server.server_close()

    def _handler(self):
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                method = body.get("method")
                if method == "tools/list":
                    payload = {"result": {"tools": [{"name": n} for n in outer.tools]}}
                else:
                    name = body["params"]["name"]
                    if name in outer.errors:
                        payload = {"error": {"message": outer.errors[name]}}
                    else:
                        text = outer.responses.get(name, json.dumps({"repository_id": "repo_test"}))
                        payload = {"result": {"content": [{"type": "text", "text": text}]}}
                data = json.dumps(payload).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

        return Handler


def run_verifier(monkeypatch, fake, repository_id="repo_test"):
    monkeypatch.setattr(cli, "mcp_url", lambda: fake.url)
    monkeypatch.setattr(cli, "first_registered_repository", lambda: repository_id)
    args = SimpleNamespace(repository_id=repository_id, path=".")
    return cli.mcp_test(args)


def default_responses():
    return {
        "repository_status": json.dumps({"repository_id": "repo_test", "status": "indexed"}),
        "search_code": "Result 1:\nPath: a.py\nContent: x",
        "get_recent_context": json.dumps({"repository_id": "repo_test", "records": [], "total": 0}),
        "search_repository_memory": json.dumps({"repository_id": "repo_test", "records": [], "total": 0}),
        "refine_task": json.dumps(GOOD_SPEC),
        "review_changes": json.dumps(GOOD_REVIEW),
    }


@pytest.fixture()
def fake():
    servers = []

    def make(**kwargs):
        server = FakeMcp(**kwargs)
        servers.append(server)
        return server

    yield make
    for server in servers:
        server.stop()


def test_healthy_platform_passes(monkeypatch, fake, capsys):
    server = fake(responses=default_responses())
    assert run_verifier(monkeypatch, server) == 0
    out = capsys.readouterr().out
    assert "Development Supervision:    Ready" in out


def test_missing_refine_task_fails(monkeypatch, fake, capsys):
    tools = [t for t in ALL_TOOLS if t != "refine_task"]
    server = fake(tools=tools, responses=default_responses())
    assert run_verifier(monkeypatch, server) == 1
    out = capsys.readouterr().out
    assert "Missing required Surfbots tools" in out
    assert "refine_task" in out


def test_missing_review_changes_fails(monkeypatch, fake, capsys):
    tools = [t for t in ALL_TOOLS if t != "review_changes"]
    server = fake(tools=tools, responses=default_responses())
    assert run_verifier(monkeypatch, server) == 1
    assert "review_changes" in capsys.readouterr().out


def test_invalid_specification_structure_fails(monkeypatch, fake, capsys):
    responses = default_responses()
    responses["refine_task"] = json.dumps({"repository_id": "repo_test", "objective": "x"})
    server = fake(responses=responses)
    assert run_verifier(monkeypatch, server) == 1
    out = capsys.readouterr().out
    assert "Development Supervision:    Not Ready" in out


def test_specification_without_coverage_fails(monkeypatch, fake, capsys):
    responses = default_responses()
    payload = dict(GOOD_SPEC)
    payload.pop("context")
    responses["refine_task"] = json.dumps(payload)
    server = fake(responses=responses)
    assert run_verifier(monkeypatch, server) == 1
    assert "deterministic context coverage" in capsys.readouterr().out


def test_invalid_review_verdict_fails(monkeypatch, fake, capsys):
    responses = default_responses()
    bad = dict(GOOD_REVIEW, verdict="looks good to me")
    responses["review_changes"] = json.dumps(bad)
    server = fake(responses=responses)
    assert run_verifier(monkeypatch, server) == 1
    assert "unexpected verdict" in capsys.readouterr().out


def test_review_without_coverage_level_fails(monkeypatch, fake, capsys):
    responses = default_responses()
    bad = dict(GOOD_REVIEW, coverage={"reviewed_files": [], "omitted_files": []})
    responses["review_changes"] = json.dumps(bad)
    server = fake(responses=responses)
    assert run_verifier(monkeypatch, server) == 1
    assert "unexpected coverage level" in capsys.readouterr().out


def test_generation_unavailable_fails(monkeypatch, fake, capsys):
    server = fake(
        responses=default_responses(),
        errors={"refine_task": "Code Search API error: 503: Supervision unavailable"},
    )
    assert run_verifier(monkeypatch, server) == 1
    out = capsys.readouterr().out
    assert "Development Supervision:    Not Ready" in out
    # Retrieval capabilities must still be reported as working.
    assert "Development Memory:         Ready" in out


def test_supervision_failure_does_not_mask_working_retrieval(monkeypatch, fake, capsys):
    server = fake(responses=default_responses(), errors={"review_changes": "boom"})
    assert run_verifier(monkeypatch, server) == 1
    out = capsys.readouterr().out
    assert "Code Intelligence:          Ready" in out
    assert "Development Memory:         Ready" in out
    assert "Development Supervision:    Not Ready" in out


def test_broken_memory_is_reported_separately(monkeypatch, fake, capsys):
    responses = default_responses()
    responses["get_recent_context"] = json.dumps({"repository_id": "wrong_repo", "records": [], "total": 0})
    server = fake(responses=responses)
    assert run_verifier(monkeypatch, server) == 1
    out = capsys.readouterr().out
    assert "Development Memory:         Not Ready" in out
    assert "Development Supervision:    Ready" in out


def test_unreachable_mcp_reports_not_running(monkeypatch, capsys):
    monkeypatch.setattr(cli, "mcp_url", lambda: "http://127.0.0.1:9/mcp")
    monkeypatch.setattr(cli, "first_registered_repository", lambda: "repo_test")
    assert cli.mcp_test(SimpleNamespace(repository_id="repo_test", path=".")) == 1
    out = capsys.readouterr().out
    assert "MCP Server:                 Not Running" in out


def test_without_repository_capabilities_are_not_claimed_ready(monkeypatch, fake, capsys):
    server = fake(responses=default_responses())
    monkeypatch.setattr(cli, "first_registered_repository", lambda: None)
    monkeypatch.setattr(cli, "mcp_url", lambda: server.url)
    cli.mcp_test(SimpleNamespace(repository_id=None, path="."))
    out = capsys.readouterr().out
    # Presence alone must never be reported as Ready.
    assert "Ready" not in out.split("=== Platform Capabilities ===")[1].replace("Not Ready", "")
    assert "not exercised" in out


def test_review_changes_without_development_task_id_fails(monkeypatch, fake, capsys):
    """Test that review_changes fails when development_task_id is missing."""
    # First, verify the CLI properly requires development_task_id
    # by checking the MCP server schema
    server = fake(
        responses=default_responses(),
        errors={"review_changes": "development_task_id is required for review_changes"},
    )
    # This test verifies the MCP server requires development_task_id
    # The actual validation happens in mcp_server.py which raises an error
    # if development_task_id is not provided
    assert run_verifier(monkeypatch, server) == 1
    out = capsys.readouterr().out
    assert "Development Supervision:    Not Ready" in out
